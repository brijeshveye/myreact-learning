# Taskly Windows – Backend API Specification

Last updated: 2025-10-22

This document defines the HTTP API contract expected by the Taskly Windows Electron client (`src/assets/js/custom.js`). Implement these endpoints so the app can authenticate users, fetch workspaces/projects/tasks, start/stop time tracking, and upload screenshots.

Base URL: {SITE_URL}/api/
- The user enters `{SITE_URL}` in the login screen. The client constructs all requests to `{SITE_URL}/api/...`.
- Example: If the user enters `https://app.example.com`, the API base is `https://app.example.com/api/`.

## Authentication
- Token-based via `Authorization: Bearer <token>` header on all endpoints except `POST /login`.
- Token is returned by `POST /login` and stored by the client as `_token`.

## Conventions
- Request/response bodies are JSON unless otherwise stated.
- Top-level envelope on success: `{ "is_success": true, "data": ... }`
- Top-level envelope on error: `{ "is_success": false, "message": "...", "errors": { ... } }`
- Date/time strings: Prefer `YYYY-MM-DD HH:mm:ss` (24h). Note: the client may send unpadded components (e.g., `2025-9-3 7:3:4`). Accept both.
- Booleans: Use JSON booleans (`true`/`false`) or 0/1 for `is_billable` as indicated.
- IDs: Integers (or opaque strings if your system requires), but must be stable across calls.

## Error status codes
- 200 with `is_success: true` for success.
- 400 for malformed payload; include `message`.
- 401 for auth failures (missing/invalid token).
- 404 for not found (e.g., workspace or project doesn’t exist).
- 422 for validation errors; include `errors` object keyed by field.
- 5xx for server errors.

---

## GET /app-version
Return the latest desktop app version so the client can prompt users to contact IT for updates.

Headers
- None required (public endpoint is fine)

Response 200
```
{
  "is_success": true,
  "data": {
    "latest_version": "1.2.3",
    "notes": "Optional release notes string"
  }
}
```

Notes
- The client only cares about `latest_version`. If it's greater than the app's local version, it will show a message to contact IT; it does not auto-update.
- If you already expose a different shape (e.g., `{ version: "1.2.3" }`), the client will also accept `version` or `latest` as fallback keys.

---

## POST /login
Authenticate a user and return an auth token plus user prefs that the client stores.

Headers
- `Content-Type: application/json`

Request
```
{
  "email": "user@example.com",
  "password": "secret"
}
```

Response 200 (success)
```
{
  "is_success": true,
  "data": {
    "_token": "<bearer-token>",
    "user_id": 123,
    "user_name": "Jane Doe",
    "avatar": "https://cdn.example.com/avatars/jane.png", // optional; full http(s) URL
    "shot_time": 10,   // minutes between screenshots (int)
    "show_shot": 2     // seconds to show screenshot preview (int)
  }
}
```

Response 401 (invalid credentials)
```
{
  "is_success": false,
  "message": "Invalid email or password."
}
```

Response 422 (validation)
```
{
  "is_success": false,
  "message": "Validation failed.",
  "errors": {
    "email": ["The email field is required."],
    "password": ["The password field is required."]
  }
}
```

Notes
- The client sets the base site URL from the login page; no server-side redirect should occur.
- On success, the client saves `data` to `localStorage` as `user_data` and uses `_token` for subsequent calls.

---

## POST /logout
Invalidate the current token/session.

Headers
- `Authorization: Bearer <token>`

Request body
- Empty JSON `{}` or no body.

Response 200
```
{ "is_success": true }
```

---

## GET /get-workspace
Return the list of workspaces accessible to the user.

Headers
- `Authorization: Bearer <token>`

Response 200
```
{
  "is_success": true,
  "data": [
    { "id": 1, "name": "Acme" },
    { "id": 2, "name": "Side Project" }
  ]
}
```

Notes
- The client populates a `<select>` with this list. It then calls `/get-projects?work_space={id}` using the selected value.

---

## GET /get-projects?work_space={workspace_id}
Return projects and their tasks for the selected workspace.

Headers
- `Authorization: Bearer <token>`

Query parameters
- `work_space` (required): integer/string – the workspace ID from `/get-workspace`.

Response 200
```
{
  "is_success": true,
  "data": [
    {
      "id": 101,
      "name": "Website Redesign",
      "tasks": [
        { "id": 1001, "name": "Create wireframes" },
        { "id": 1002, "name": "Build landing page" }
      ]
    },
    {
      "id": 102,
      "name": "Mobile App",
      "tasks": [
        { "id": 2001, "name": "Implement login" }
      ]
    }
  ]
}
```

Notes
- Only minimal fields are required by the client: project `id`, `name`, and a `tasks` array with each task’s `id` and `name`.
- You may include additional metadata; the client will ignore unknown fields.

---

## POST /add-tracker
Start or stop a time-tracking session for a task.

Headers
- `Authorization: Bearer <token>`
- `Content-Type: application/json`

Request (start)
```
{
  "action": "start",              // "start" | "end"
  "time": "2025-09-25 14:03:05",  // start timestamp
  "task_id": 1001,
  "workin_on": "Refactoring login form", // free text entered by user
  "traker_id": null,               // NOTE: client sends this field name (typo); see notes below
  "workspaces_id": 1,
  "is_billable": 1                 // 1 = billable, 0 = non-billable
}
```

Request (end)
```
{
  "action": "end",
  "time": "2025-09-25 16:47:12", // end timestamp
  "task_id": 1001,
  "workin_on": "Refactoring login form",
  "traker_id": 555,               // tracker/session ID returned from start
  "workspaces_id": 1,
  "is_billable": 1
}
```

Response 200 (start)
```
{
  "is_success": true,
  "data": {
    "id": 555,                     // tracker/session ID
    "action": "start",
    "started_at": "2025-09-25 14:03:05"
  }
}
```

Response 200 (end)
```
{
  "is_success": true,
  "data": {
    "id": 555,
    "action": "end",
    "started_at": "2025-09-25 14:03:05",
    "ended_at": "2025-09-25 16:47:12",
    "duration_seconds": 973,       // server-computed duration (optional but recommended)
    "billable": true               // optional echo/derivation
  }
}
```

Response 422 (examples)
```
{
  "is_success": false,
  "message": "Validation failed.",
  "errors": {
    "task_id": ["Task not found"],
    "traker_id": ["Unknown tracker session"],
    "action": ["Action must be start or end"]
  }
}
```

Notes
- Field name `traker_id` is a client-side typo. Either:
  1) Accept `traker_id` as-is in requests, OR
  2) Support both `traker_id` and `tracker_id` for compatibility, OR
  3) Coordinate a client fix.
- The client immediately starts a local UI timer after a successful `start` and disables changing the selected task/workspace until `end`.

---

## GET /get-daily-reports?date={date}&workspace_id={workspace_id}
Return daily time tracking reports for a specific date and workspace.

Headers
- `Authorization: Bearer <token>`

Query parameters
- `date` (required): Date in YYYY-MM-DD format (e.g., "2025-09-26")
- `workspace_id` (required): Workspace ID to filter reports

Response 200
```
{
  "is_success": true,
  "data": {
    "total_seconds": 28800,
    "total_formatted": "08:00:00",
    "date": "2025-09-26",
    "entries": [
      {
        "id": 123,
        "task_name": "Create wireframes",
        "project_name": "Website Redesign",
        "description": "Working on login page wireframes",
        "start_time": "2025-09-26 09:00:00",
        "end_time": "2025-09-26 11:30:00",
        "duration_seconds": 9000,
        "is_billable": true,
        "workspace_name": "Acme"
      },
      {
        "id": 124,
        "task_name": "Build landing page",
        "project_name": "Website Redesign", 
        "description": "Implementing responsive design",
        "start_time": "2025-09-26 13:15:00",
        "end_time": null,
        "duration_seconds": 3600,
        "is_billable": false,
        "workspace_name": "Acme"
      }
    ]
  }
}
```

Response 200 (no entries)
```
{
  "is_success": true,
  "data": {
    "total_seconds": 0,
    "total_formatted": "00:00:00",
    "date": "2025-09-26",
    "entries": []
  }
}
```

Notes
- `end_time` is `null` for currently running time entries
- `duration_seconds` should be calculated from start to end (or start to current time if running)
- Include both completed and currently running entries
- Sort entries by `start_time` descending (most recent first)

---

## POST /upload-photos
Upload a periodic screenshot associated with a tracker session.

Headers
- `Authorization: Bearer <token>`
- Content-Type: `application/x-www-form-urlencoded` OR `multipart/form-data`
  - The current client sends URL-encoded form data without explicitly setting Content-Type.

Request fields
- `img`: Base64-encoded image contents (JPEG recommended)
- `imgName`: Original file name (e.g., `2025-09-25_14-05-00_555.jpg`)
- `time`: Timestamp of capture (string, same format as above)
- `tracker_id`: Associated tracker/session ID (integer/string)

Example request body (form fields)
```
img=/<base64>...&imgName=2025-09-25_14-05-00_555.jpg&time=2025-09-25 14:05:00&tracker_id=555
```

Response 200
```
{
  "is_success": true,
  "data": {
    "id": 9876,                    // stored screenshot ID
    "url": "https://cdn.example.com/shots/9876.jpg" // optional
  }
}
```

Notes
- The client may show a small preview window for a few seconds; this is local-only and unrelated to the API.
- The client deletes the local temp file after a successful upload.
- Enforce max image size server-side if needed (e.g., 1–2 MB after base64 decoding).

---

## GET /attendance/summary?date={date}&workspace_id={workspace_id}
Return attendance/time summary for a specific date and workspace.

Headers
- Authorization: Bearer <token>

Query parameters
- date (required): YYYY-MM-DD (client uses today’s date)
- workspace_id (optional): If your model is workspace-scoped; otherwise ignore

Response 200
```
{
  "is_success": true,
  "data": {
    "date": "2025-09-26",
    "is_clocked_in": true,
    "is_on_break": false,
    "total_seconds": 14400,          // worked (non-break) seconds today
    "total_break_seconds": 900,      // break seconds today
    "total_idle_seconds": 600,       // idle seconds today (within on-duty time)
    "break_quota_seconds": 3600      // optional daily break allowance
  }
}
```

---

## POST /attendance/clock-in
Clock the user in for the day.

Headers
- Authorization: Bearer <token>
- Content-Type: application/json

Request
```
{ "time": "2025-09-26 09:00:00", "workspaces_id": 1 }
```

Response 200
```
{ "is_success": true, "data": { "clock_in_at": "2025-09-26 09:00:00" } }
```

---

## POST /attendance/clock-out
Clock the user out for the day.

Headers
- Authorization: Bearer <token>
- Content-Type: application/json

Request
```
{ "time": "2025-09-26 17:30:00", "workspaces_id": 1 }
```

Response 200
```
{ "is_success": true, "data": { "clock_out_at": "2025-09-26 17:30:00" } }
```

---

## POST /attendance/break-start
Start a break interval.

Headers
- Authorization: Bearer <token>
- Content-Type: application/json

Request
```
{ "time": "2025-09-26 13:00:00", "workspaces_id": 1 }
```

Response 200
```
{ "is_success": true, "data": { "break_start_at": "2025-09-26 13:00:00" } }
```

---

## POST /attendance/break-end
End a break interval.

Headers
- Authorization: Bearer <token>
- Content-Type: application/json

Request
```
{ "time": "2025-09-26 13:15:00", "workspaces_id": 1 }
```

Response 200
```
{ "is_success": true, "data": { "break_end_at": "2025-09-26 13:15:00" } }
```

Notes
- Server should prevent overlapping breaks and ensure breaks only occur while clocked in.
- Summary should exclude break seconds from worked total.

---

## POST /attendance/idle-start
Mark the beginning of an idle interval while clocked in.

Headers
- Authorization: Bearer <token>
- Content-Type: application/json

Request
```
{ "time": "2025-09-26 14:05:00", "workspaces_id": 1, "tracker_id": 555 }
```

Response 200
```
{ "is_success": true, "data": { "id": 321, "idle_start_at": "2025-09-26 14:05:00" } }
```

Response 422 (examples)
```
{
  "is_success": false,
  "message": "Validation failed.",
  "errors": {
    "time": ["The time field is required."],
    "state": ["User must be clocked in to start idle."],
    "overlap": ["An idle interval is already open."]
  }
}
```

---

## POST /attendance/idle-end
Mark the end of an idle interval.

Headers
- Authorization: Bearer <token>
- Content-Type: application/json

Request
```
{ "time": "2025-09-26 14:12:30", "workspaces_id": 1, "idle_id": 321 }
```

Response 200
```
{ "is_success": true, "data": { "idle_end_at": "2025-09-26 14:12:30", "duration_seconds": 450 } }
```

Response 422 (examples)
```
{
  "is_success": false,
  "message": "Validation failed.",
  "errors": {
    "time": ["The time field is required."],
    "idle_id": ["No open idle interval found."],
    "order": ["End time must be after start time."]
  }
}
```

Notes
- If `idle_id` is missing, the server may infer the last open idle interval for the user on that day.
- Idle seconds should not be included in `total_seconds` and should be reported separately as `total_idle_seconds`.

---

## Idle tracking behavior and rules

Overview
- The client detects user inactivity ("idle") based on a client-side threshold. When idle begins, it calls `POST /attendance/idle-start`; when activity resumes, it calls `POST /attendance/idle-end`.
- The client also attempts to end any open idle interval before changing attendance state (e.g., clock-out, break-start). The server must still be robust to enforce consistency.

Server expectations
- Exactly one open idle interval per user/day. If `idle-start` is called while an idle is already open, return the existing open interval or a 409/422 error.
- Auto-close idle on attendance transitions:
  - On `clock-out`, if an idle interval is open, close it at `clock-out` time.
  - On `break-start`, if an idle interval is open, close it at `break-start` time.
- Ignore idle intervals while off duty or during breaks. The server should reject or auto-trim intervals that overlap break or off-duty periods.
- Idle time is excluded from worked `total_seconds` and reported separately as `total_idle_seconds` in `/attendance/summary`.
- `tracker_id` on idle records is optional and may be used for correlation with active task tracking if provided by the client.

Edge cases
- Missing or out-of-order calls: If the client fails to send `idle-end`, the next attendance transition (break/clock-out) should implicitly close the open idle.
- Duplicate calls: Multiple `idle-end` calls without an open idle should be safely rejected or treated as no-ops.
- Validation: Ensure timestamps are within the same day or apply your cross-day policy; normalize to server TZ/UTC as needed.


## Additional recommendations
- Idempotency: If the app is closed while tracking, ensure that calling `end` twice (or with stale timestamps) doesn’t corrupt data. Consider rejecting with 409 or returning the existing final state.
- Rate limiting: The app calls `/upload-photos` at intervals defined by `shot_time` minutes. Ensure the server can handle the cadence for your user base.
- CORS: Electron apps aren’t bound by normal browser CORS, but enabling CORS does not hurt if you reuse the API elsewhere.
- Time zones: Prefer server-side normalization to UTC and return ISO-8601 (with offset) if you later rev the client. For compatibility with the existing client, continue accepting simple `YYYY-M-D HH:mm:ss`.
- Validation: Enforce that `task_id` belongs to the provided `workspaces_id` for the authenticated user.

## Appendix – Field glossary
- `_token` (string): Bearer token for subsequent requests.
- `user_name` (string): Display name.
- `avatar` (string): Absolute http(s) URL to the avatar image.
- `shot_time` (int, minutes): Interval between automatic screenshots.
- `show_shot` (int, seconds): Duration the preview window remains visible.
- `workspaces_id` (int/string): Workspace context for tracking.
- `task_id` (int/string): Selected task to track against.
- `traker_id` / `tracker_id` (int/string): Tracking session identifier; returned by `start` and required for `end` and screenshot uploads.
- `is_billable` (0|1): Whether time is billable. The UI toggles this with a dollar icon.
- `idle_id` (int/string): Idle interval identifier returned by `idle-start` and referenced by `idle-end` (server may also infer the open idle if omitted).
- `total_idle_seconds` (int): Sum of idle seconds for the day, returned by `/attendance/summary`.

## Versioning
- Start with v1 under `/api/` as shown. If you introduce breaking changes, consider namespacing `/api/v2/` and supporting both during migration.
