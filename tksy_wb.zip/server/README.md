# Tasker Backend

Express + MongoDB backend for the Tasker app.

## Quick start

1. Copy `.env.example` to `.env` and edit if needed.
2. Install deps.
3. Run dev server.
4. In a separate terminal, run the frontend dev server inside `frontend/`.

## Scripts
- `npm run dev` - start with hot reload
- `npm start` - start production server
- `npm run seed:admin` - create a default Super Admin user

## API base
All endpoints are under `/api`.

- Auth: `/api/auth/register`, `/api/auth/login`, `/api/auth/me`
- Users: `/api/users` CRUD (protected, role-based)
- Departments: `/api/departments` CRUD (protected, role-based)
- Tasks: `/api/tasks` CRUD (protected)
- Comments: `/api/comments` list/create/delete (protected)

JWT is required for protected routes via `Authorization: Bearer <token>`.

## Notes
- Models match schema in `Todos/Schema.txt`.
- Add indexes/validation as needed per business rules.