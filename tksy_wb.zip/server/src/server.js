import dotenv from 'dotenv';
dotenv.config();

import express from 'express';
import http from 'http';
import { Server as SocketIOServer } from 'socket.io';
import jwt from 'jsonwebtoken';
import helmet from 'helmet';
import cors from 'cors';
import morgan from 'morgan';
import path from 'path';
import rateLimit from 'express-rate-limit';
import { connectDB } from './utils/db.js';
import { notFound, errorHandler } from './middlewares/error.js';
import authRoutes from './routes/auth.routes.js';
import userRoutes from './routes/user.routes.js';
import departmentRoutes from './routes/department.routes.js';
import taskRoutes from './routes/task.routes.js';
import commentRoutes from './routes/comment.routes.js';
import notificationRoutes from './routes/notification.routes.js';
import trackerRoutes from './routes/tracker.routes.js';
import windowsRoutes from './routes/windows.routes.js';
import screenshotsRoutes from './routes/screenshots.routes.js';
import crmRoutes from './routes/crm.routes.js';
import attendanceRoutes from './routes/attendance.routes.js';
import attendanceAdminRoutes from './routes/attendance.admin.routes.js';

const app = express();
const server = http.createServer(app);
export const io = new SocketIOServer(server, {
  cors: { origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173', credentials: true },
  transports: ['websocket', 'polling']
});

// Socket authentication & room join by user id
io.use((socket, next) => {
  try {
    let token = socket.handshake.auth?.token || socket.handshake.query?.token;
    if (!token) return next(new Error('No token provided'));
    if (typeof token === 'string' && token.startsWith('Bearer ')) {
      token = token.slice('Bearer '.length);
    }
    const payload = jwt.verify(token, process.env.JWT_SECRET || 'dev_secret');
    // JWT created with { sub, role } but support common variants
    const uid = payload?.sub || payload?.id || payload?._id || payload?.userId;
    const role = payload?.role || payload?.userGroup || payload?.scope;
    socket.data.user = { _id: uid, role };
    if (process.env.SOCKET_DEBUG === '1') {
      console.log('[socket-auth] success', {
        sub: uid,
        role,
        ip: socket.handshake.address,
        ua: socket.handshake.headers['user-agent']
      });
    }
    return next();
  } catch (err) {
    console.warn('[socket-auth] failed', err.message);
    return next(new Error('Auth error'));
  }
});

io.on('connection', (socket) => {
  const userId = socket.data.user?._id;
  if (userId) {
    socket.join(`user:${userId}`);
    if (process.env.SOCKET_DEBUG === '1') console.info('Socket joined room', `user:${userId}`);
  }
  socket.emit('connected', { ts: Date.now() });
  socket.on('disconnect', (reason) => {
    if (process.env.SOCKET_DEBUG === '1') console.info('Socket disconnected', reason);
  });
  socket.conn.on('upgrade', (transport) => {
    if (process.env.SOCKET_DEBUG === '1') {
      console.log('[socket] upgraded transport', transport.name);
    }
  });
});

// Basic security and parsing
app.use(helmet());
app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173', credentials: true }));
// Increase limits to accommodate base64 images sent via urlencoded by Windows client
app.use(express.json({ limit: '5mb' }));
app.use(express.urlencoded({ extended: true, limit: '5mb' }));
// Static file serving for uploaded avatars
app.use('/uploads/avatars', express.static(path.join(process.cwd(), 'uploads', 'avatars'), {
  setHeaders: (res) => {
    // res.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
    res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
  }
}));
// Static file serving for uploaded screenshots
app.use('/uploads/shots', express.static(path.join(process.cwd(), 'uploads', 'shots'), {
  setHeaders: (res) => {
    res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
  }
}));

if (process.env.NODE_ENV !== 'test') {
  app.use(morgan('dev'));
}

// Rate limiting
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 1000 });
app.use(limiter);

// Health
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', ts: new Date().toISOString() });
});

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/departments', departmentRoutes);
app.use('/api/tasks', taskRoutes);
app.use('/api/comments', commentRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/tracker', trackerRoutes);
app.use('/api/screenshots', screenshotsRoutes);
app.use('/api/crm', crmRoutes);
app.use('/api/crm', crmRoutes);
app.use('/api', attendanceRoutes);
app.use('/api', attendanceAdminRoutes);

// API Routes for Windows Electron client (mounted at /api per client spec)
app.use('/api', windowsRoutes);

// 404 and error handler
app.use(notFound);
app.use(errorHandler);

const PORT = process.env.PORT || 4000;

connectDB().then(() => {
  server.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
});

export default app;
