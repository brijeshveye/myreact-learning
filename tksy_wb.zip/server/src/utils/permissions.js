/**
 * Role & Permission Utility
 * Centralizes role hierarchy and fine grained permission checking.
 *
 * Example (route usage):
 *   import { auth } from '../middlewares/auth.js';
 *   import { ROLES, PERMISSIONS, authorizeRoles, authorizePermission } from '../utils/permissions.js';
 *
 *   router.get('/admin-only', auth(), authorizeRoles(ROLES.SUPER_ADMIN), handler);
 *   router.post('/tasks', auth(), authorizePermission(PERMISSIONS.TASK_CREATE), createTask);
 *
 * Add new granular permissions in PERMISSIONS then assign them in ROLE_PERMISSIONS.
 * Keep ownership/business rules (e.g. can update only own task) inside route/controller logic.
 */

export const ROLES = {
  SUPER_ADMIN: 'Super Admin',
  SUPER_MANAGEMENT: 'Super Management',
  MANAGEMENT: 'Management',
  EMPLOYEE: 'Employee'
};

// Define atomic permission strings
export const PERMISSIONS = {
  USER_READ: 'user.read',
  USER_CREATE: 'user.create',
  USER_UPDATE: 'user.update',
  USER_DELETE: 'user.delete',
  TASK_CREATE: 'task.create',
  TASK_READ: 'task.read',
  TASK_UPDATE: 'task.update',
  TASK_DELETE: 'task.delete',
  TASK_APPROVE: 'task.approve',
  DEPARTMENT_READ: 'department.read',
  DEPARTMENT_CREATE: 'department.create',
  DEPARTMENT_UPDATE: 'department.update',
  DEPARTMENT_DELETE: 'department.delete',
};

// Map each role to a set of permissions (inherit manually for clarity)
const ROLE_PERMISSIONS = {
  [ROLES.EMPLOYEE]: new Set([
    PERMISSIONS.TASK_READ,
    PERMISSIONS.TASK_CREATE, // allow employees to create their own tasks
    PERMISSIONS.TASK_UPDATE // allow updating own task status (ownership enforced elsewhere)
  ]),
  [ROLES.MANAGEMENT]: new Set([
    PERMISSIONS.TASK_CREATE,
    PERMISSIONS.TASK_READ,
    PERMISSIONS.TASK_UPDATE,
    PERMISSIONS.TASK_DELETE,
    PERMISSIONS.TASK_APPROVE,
    PERMISSIONS.USER_READ,
    PERMISSIONS.DEPARTMENT_READ
  ]),
  [ROLES.SUPER_MANAGEMENT]: new Set([
    PERMISSIONS.TASK_CREATE,
    PERMISSIONS.TASK_READ,
    PERMISSIONS.TASK_UPDATE,
    PERMISSIONS.TASK_DELETE,
    PERMISSIONS.TASK_APPROVE,
    PERMISSIONS.USER_READ,
    PERMISSIONS.USER_UPDATE
  ]),
  [ROLES.SUPER_ADMIN]: new Set([
    PERMISSIONS.TASK_CREATE,
    PERMISSIONS.TASK_READ,
    PERMISSIONS.TASK_UPDATE,
    PERMISSIONS.TASK_DELETE,
    PERMISSIONS.TASK_APPROVE,
    PERMISSIONS.DEPARTMENT_MANAGE,
    PERMISSIONS.USER_READ,
    PERMISSIONS.USER_CREATE,
    PERMISSIONS.USER_UPDATE,
    PERMISSIONS.USER_DELETE,
    PERMISSIONS.DEPARTMENT_READ,
    PERMISSIONS.DEPARTMENT_CREATE,
    PERMISSIONS.DEPARTMENT_UPDATE,
    PERMISSIONS.DEPARTMENT_DELETE
  ])
};

/** Check if a role includes a permission */
export function roleHasPermission(role, permission) {
  return !!(ROLE_PERMISSIONS[role] && ROLE_PERMISSIONS[role].has(permission));
}

/** Return array form of role's permissions */
export function getRolePermissions(role) {
  return Array.from(ROLE_PERMISSIONS[role] || []);
}

// Middleware: require one of the listed roles
/** Middleware: require one of the provided roles */
export function authorizeRoles(...roles) {
  const allowed = new Set(roles);
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ message: 'Unauthorized' });
    if (allowed.size === 0 || allowed.has(req.user.userGroup)) return next();
    return res.status(403).json({ message: 'Forbidden: insufficient role' });
  };
}

// Middleware: require a specific permission
/** Middleware: require a single specific permission */
export function authorizePermission(permission) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ message: 'Unauthorized' });
    if (roleHasPermission(req.user.userGroup, permission)) return next();
    return res.status(403).json({ message: 'Forbidden: missing permission' });
  };
}

// Combine: allow if user has any one of provided permissions
/** Middleware: allow if user has ANY of the provided permissions */
export function authorizeAnyPermission(...permissions) {
  const perms = permissions.flat();
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ message: 'Unauthorized' });
    const ok = perms.some(p => roleHasPermission(req.user.userGroup, p));
    if (ok) return next();
    return res.status(403).json({ message: 'Forbidden: missing required permission' });
  };
}
