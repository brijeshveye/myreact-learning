// Utility to provide random default avatar file names based on gender.
// Assumes frontend will resolve /assets/images/<filename>

const boyAvatars = [
  'boy-default-avatar.png',
  'boy-default-avatar_2.png',
  'boy-default-avatar_3.png'
];

const girlAvatars = [
  'girl-default-avatar.png',
  'girl-default-avatar_2.png',
  'girl-default-avatar_3.png',
  'girl-default-avatar_4.png',
  'girl-default-avatar_5.png'
];

export function randomAvatar(gender) {
  const g = (gender || '').toLowerCase();
  let pool = boyAvatars.concat(girlAvatars); // fallback mixed pool
  if (g === 'male') pool = boyAvatars;
  else if (g === 'female') pool = girlAvatars;
  if (pool.length === 0) return null;
  return pool[Math.floor(Math.random() * pool.length)];
}

export function avatarPath(filename) {
  if (!filename) return null;
  return `/assets/images/${filename}`;
}
