import { Router } from 'express';
import {
	winLogin,
	winLogout,
	getWorkspaces,
	getProjects,
	addTracker,
	uploadPhotos,
  getDailyReports,
  winAppVersion,
} from '../controllers/windows.controller.js';
import { windowsAuth } from '../middlewares/windowsAuth.js';

const router = Router();

// Public
router.post('/login', winLogin);
router.get('/app-version', winAppVersion);

// Protected
router.post('/logout', windowsAuth, winLogout);
router.get('/get-workspace', windowsAuth, getWorkspaces);
router.get('/get-projects', windowsAuth, getProjects);
router.post('/add-tracker', windowsAuth, addTracker);
router.post('/upload-photos', windowsAuth, uploadPhotos);
router.get('/get-daily-reports', windowsAuth, getDailyReports);

export default router;