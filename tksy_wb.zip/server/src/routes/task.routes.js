import { Router } from 'express';
import { auth, requireActive } from '../middlewares/auth.js';
import { createTask, deleteTask, getTask, listTasks, updateTask, listAllTasks } from '../controllers/task.controller.js';
import { authorizePermission, authorizeAnyPermission, PERMISSIONS } from '../utils/permissions.js';
import { ensureTaskAccess } from '../middlewares/ownership.js';

const router = Router();

router.use(auth());
router.use(requireActive);

// List tasks (requires read permission)
router.get('/', authorizeAnyPermission(PERMISSIONS.TASK_READ), listTasks);
// Admin-wide listing endpoint
router.get('/all', authorizeAnyPermission([
	PERMISSIONS.TASK_READ,
	PERMISSIONS.TASK_DELETE,
	PERMISSIONS.TASK_CREATE,
	PERMISSIONS.TASK_UPDATE,
	PERMISSIONS.TASK_APPROVE
]), listAllTasks);
// Create task
router.post('/', authorizePermission(PERMISSIONS.TASK_CREATE), createTask);
// Get single task
router.get('/:id', authorizeAnyPermission(PERMISSIONS.TASK_READ), getTask);
// Update task: allow if has update permission or owns task
router.put('/:id', ensureTaskAccess(false), updateTask);
router.patch('/:id', ensureTaskAccess(false), updateTask);
// Delete task: allow if has delete permission or owns task (ownership.js checks)
router.delete('/:id', ensureTaskAccess(true), deleteTask);

export default router;
