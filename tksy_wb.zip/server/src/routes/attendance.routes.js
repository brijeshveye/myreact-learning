import { Router } from 'express';
import { windowsAuth } from '../middlewares/windowsAuth.js';
import { getAttendanceSummary, clockIn, clockOut, breakStart, breakEnd, idleStart, idleEnd } from '../controllers/attendance.controller.js';

const router = Router();

// All attendance endpoints are protected by Windows client auth
router.get('/attendance/summary', windowsAuth, getAttendanceSummary);
router.post('/attendance/clock-in', windowsAuth, clockIn);
router.post('/attendance/clock-out', windowsAuth, clockOut);
router.post('/attendance/break-start', windowsAuth, breakStart);
router.post('/attendance/break-end', windowsAuth, breakEnd);
router.post('/attendance/idle-start', windowsAuth, idleStart);
router.post('/attendance/idle-end', windowsAuth, idleEnd);

export default router;
