import { Router } from 'express';
import { auth, requireActive } from '../middlewares/auth.js';
import { authorizeAnyPermission, authorizePermission, PERMISSIONS } from '../utils/permissions.js';
import { listNotifications, createNotification, markNotificationRead, markAllNotificationsRead, deleteNotification, sendDirectNotification } from '../controllers/notification.controller.js';

const router = Router();

// All notification routes require authentication & active user
router.use(auth());
router.use(requireActive);

// List current user's notifications (any authenticated active user allowed)
router.get('/', listNotifications);

// Create a notification (restrict to roles that can create tasks or users - reuse existing permissions as proxy)
router.post('/', authorizeAnyPermission(PERMISSIONS.TASK_CREATE, PERMISSIONS.USER_CREATE), createNotification);

// Send a direct (non-persisted) notification - still require similar privilege
router.post('/direct', authorizeAnyPermission(PERMISSIONS.TASK_CREATE, PERMISSIONS.USER_CREATE), sendDirectNotification);

// Mark single notification read/unread
router.patch('/:id/read', markNotificationRead);

// Mark all as read
router.post('/mark-all-read', markAllNotificationsRead);

// Delete single notification
router.delete('/:id', deleteNotification);

export default router;
