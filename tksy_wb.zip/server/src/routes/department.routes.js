import { Router } from 'express';
import { auth, requireActive } from '../middlewares/auth.js';
import { createDepartment, deleteDepartment, getDepartment, listDepartments, updateDepartment } from '../controllers/department.controller.js';
import { authorizePermission, authorizeAnyPermission, PERMISSIONS } from '../utils/permissions.js';

const router = Router();

router.use(auth());
router.use(requireActive);

router.get('/', authorizeAnyPermission(PERMISSIONS.DEPARTMENT_READ), listDepartments);
router.post('/', authorizePermission(PERMISSIONS.DEPARTMENT_CREATE), createDepartment);
router.get('/:id', authorizeAnyPermission(PERMISSIONS.DEPARTMENT_READ), getDepartment);
router.put('/:id', authorizePermission(PERMISSIONS.DEPARTMENT_UPDATE), updateDepartment);
router.delete('/:id', authorizePermission(PERMISSIONS.DEPARTMENT_DELETE), deleteDepartment);

export default router;
