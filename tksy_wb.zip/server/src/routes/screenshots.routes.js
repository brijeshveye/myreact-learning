import { Router } from 'express';
import { auth } from '../middlewares/auth.js';
import { getScreenshotTimeline } from '../controllers/screenshots.controller.js';

const router = Router();
router.use(auth());

router.get('/timeline', getScreenshotTimeline);

export default router;
