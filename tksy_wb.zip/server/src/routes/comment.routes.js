import { Router } from 'express';
import { auth, requireActive } from '../middlewares/auth.js';
import { createComment, deleteComment, listComments } from '../controllers/comment.controller.js';
import { authorizeAnyPermission, authorizePermission, PERMISSIONS } from '../utils/permissions.js';
import { ensureCommentDelete } from '../middlewares/ownership.js';

const router = Router();

router.use(auth());
router.use(requireActive);

router.get('/', authorizeAnyPermission(PERMISSIONS.TASK_READ), listComments);
router.post('/', authorizePermission(PERMISSIONS.TASK_UPDATE), createComment);
router.delete('/:id', ensureCommentDelete(), deleteComment);

export default router;
