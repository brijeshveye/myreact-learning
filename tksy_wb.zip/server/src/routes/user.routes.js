import { Router } from 'express';
import { auth, authorize, requireActive } from '../middlewares/auth.js';
import { PERMISSIONS, authorizePermission, authorizeAnyPermission, ROLES } from '../utils/permissions.js';
import { createUser, deleteUser, getUser, listUsers, setUserStatus, updateUser, updateAvatar } from '../controllers/user.controller.js';
import { avatarUpload } from '../middlewares/upload.js';

const router = Router();

router.use(auth());
router.use(requireActive);

// New permission-based approach; fallback authorize for legacy roles kept if needed.
router.get('/', authorizeAnyPermission(PERMISSIONS.USER_READ), listUsers);
router.post('/', authorizePermission(PERMISSIONS.USER_CREATE), createUser);
router.get('/:id', authorizeAnyPermission(PERMISSIONS.USER_READ), getUser);

router.put('/:id', authorizePermission(PERMISSIONS.USER_UPDATE), updateUser);
router.patch('/:id', authorizePermission(PERMISSIONS.USER_UPDATE), updateUser);
router.delete('/:id', authorizePermission(PERMISSIONS.USER_DELETE), deleteUser);
router.patch('/:id/status', authorizePermission(PERMISSIONS.USER_UPDATE), setUserStatus);
// Avatar update: allow self without permission; otherwise require USER_UPDATE
router.patch('/:id/avatar', (req, res, next) => {
	const reqUserId = req.user?._id || req.user?.id || req.user?.sub;
	if (reqUserId && String(reqUserId) === String(req.params.id)) {
		return next();
	}
	return authorizePermission(PERMISSIONS.USER_UPDATE)(req, res, next);
}, avatarUpload.single('avatar'), updateAvatar);

export default router;
