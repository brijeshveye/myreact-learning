import { Router } from 'express';
import { auth, requireActive } from '../middlewares/auth.js';
import { getCrmMetrics, getCrmLast7Days } from '../controllers/crm.controller.js';
import {
	getUsersSummary,
	getUsersRegistrations,
	getLeadsByUser,
	getLeadsCountsByUser,
		getLeadsUpdatedByUser,
	getLeadsStatusCounts,
	getLeadsStageCounts,
	getLeadsSourceCounts,
	getLeadsTypeCounts,
	getLeadsValueSumByUser,
	getLeadsWonByUser,
	getLeadsLostByUser,
	getActivitiesCallByUser,
	getActivitiesCreatedByUser,
	getActivitiesByType,
	getActivitiesDoneByUser,
	getActivitiesPendingByUser,
	getActivitiesTypesByUser,
} from '../controllers/crm.analytics.controller.js';

const router = Router();
router.use(auth());
router.use(requireActive);

// Employee self-scope allowed; admin/manager could query userId in future
router.get('/analytics/metrics', getCrmMetrics);
router.get('/analytics/last7days', getCrmLast7Days);

// New: Proxy routes to Custom Analytics API v1
router.get('/analytics/users/summary', getUsersSummary);
router.get('/analytics/users/registrations', getUsersRegistrations);
router.get('/analytics/leads/by-user', getLeadsByUser);
router.get('/analytics/leads/counts-by-user', getLeadsCountsByUser);
router.get('/analytics/leads/updated-by-user', getLeadsUpdatedByUser);
router.get('/analytics/leads/status-counts', getLeadsStatusCounts);
router.get('/analytics/leads/stage-counts', getLeadsStageCounts);
router.get('/analytics/leads/source-counts', getLeadsSourceCounts);
router.get('/analytics/leads/type-counts', getLeadsTypeCounts);
router.get('/analytics/leads/value-sum-by-user', getLeadsValueSumByUser);
router.get('/analytics/leads/won-by-user', getLeadsWonByUser);
router.get('/analytics/leads/lost-by-user', getLeadsLostByUser);
router.get('/analytics/activities/call-by-user', getActivitiesCallByUser);
router.get('/analytics/activities/created-by-user', getActivitiesCreatedByUser);
router.get('/analytics/activities/by-type', getActivitiesByType);
router.get('/analytics/activities/done-by-user', getActivitiesDoneByUser);
router.get('/analytics/activities/pending-by-user', getActivitiesPendingByUser);
router.get('/analytics/activities/types-by-user', getActivitiesTypesByUser);

export default router;
