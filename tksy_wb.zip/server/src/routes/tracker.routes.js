import { Router } from 'express';
import { auth, requireActive } from '../middlewares/auth.js';
import { getTrackerReport } from '../controllers/tracker.controller.js';
import { authorizeAnyPermission, PERMISSIONS } from '../utils/permissions.js';

const router = Router();
router.use(auth());
router.use(requireActive);

// Restrict to privileged users (reuse existing permission that makes sense, e.g. USER_VIEW or TASK_VIEW fallback)
router.get('/report/:id', authorizeAnyPermission(PERMISSIONS.USER_VIEW, PERMISSIONS.USER_LIST, PERMISSIONS.TASK_VIEW, PERMISSIONS.TASK_CREATE), getTrackerReport);

export default router;
