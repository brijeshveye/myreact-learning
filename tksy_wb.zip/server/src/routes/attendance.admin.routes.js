import { Router } from 'express';
import { auth, authorize, requireActive } from '../middlewares/auth.js';
import { adminGetAttendanceDay } from '../controllers/attendance.admin.controller.js';

const router = Router();

router.get('/attendance/admin/day', auth(true), requireActive, authorize('Super Admin'), adminGetAttendanceDay);

export default router;
