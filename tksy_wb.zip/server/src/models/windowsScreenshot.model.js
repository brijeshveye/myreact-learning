import mongoose from 'mongoose';

const windowsScreenshotSchema = new mongoose.Schema(
  {
    tracker: { type: mongoose.Schema.Types.ObjectId, ref: 'WindowsTracker', required: true },
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    fileName: { type: String, required: true },
    capturedAt: { type: Date, required: true },
    size: { type: Number },
    mime: { type: String },
  },
  { timestamps: true }
);

windowsScreenshotSchema.index({ tracker: 1, capturedAt: -1 });

export const WindowsScreenshot = mongoose.model('WindowsScreenshot', windowsScreenshotSchema);
