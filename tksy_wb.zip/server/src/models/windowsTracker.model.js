import mongoose from 'mongoose';

const windowsTrackerSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    task: { type: mongoose.Schema.Types.ObjectId, ref: 'Task', required: true },
    workspaceId: { type: String },
    isBillable: { type: Boolean, default: true },
    workNote: { type: String },
    startedAt: { type: Date, required: true },
    endedAt: { type: Date },
  },
  { timestamps: true }
);

windowsTrackerSchema.index({ user: 1, task: 1, endedAt: 1 });

export const WindowsTracker = mongoose.model('WindowsTracker', windowsTrackerSchema);
