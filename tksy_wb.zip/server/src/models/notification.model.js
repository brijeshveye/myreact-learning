import mongoose from 'mongoose';

// Notification Schema
// Represents a user-targeted notification. Optionally linked to task, comment, department or user.
// Indexed for efficient unread queries per user.
const notificationSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true }, // target user
    type: { type: String, enum: ['task', 'comment', 'status', 'approval', 'system'], default: 'system', index: true },
    title: { type: String, required: true }, // short label e.g., 'New task assigned'
    message: { type: String, required: true }, // full descriptive text
    icon: { type: String }, // material icon name (frontend mapping)
    color: { type: String, enum: ['primary', 'purple', 'success', 'warning', 'danger', 'neutral'], default: 'primary' },
    isRead: { type: Boolean, default: false, index: true },
    readAt: { type: Date },
    // Optional relational context
    task: { type: mongoose.Schema.Types.ObjectId, ref: 'Task' },
    comment: { type: mongoose.Schema.Types.ObjectId, ref: 'Comment' },
    actor: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, // who triggered the notification
    meta: { type: Object }, // extra JSON (safe, unstructured)
    deletedAt: { type: Date },
  },
  { timestamps: { createdAt: 'createdAt', updatedAt: 'updatedAt' } }
);

// Compound index for listing newest unread quickly
notificationSchema.index({ user: 1, isRead: 1, createdAt: -1 });
notificationSchema.index({ user: 1, createdAt: -1 });

export default mongoose.model('Notification', notificationSchema);
