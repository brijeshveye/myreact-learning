import mongoose from 'mongoose';

const userSchema = new mongoose.Schema(
  {
    firstName: { type: String, required: true, trim: true },
    middleName: { type: String, trim: true },
    lastName: { type: String, required: true, trim: true },
    profilePicture: { type: String },
    dob: { type: Date },
    gender: { type: String, enum: ['Male', 'Female', 'Other'] },
    permanentAddress: { type: String },
    currentAddress: { type: String },
    designation: { type: String },
    department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department' },
    userGroup: { type: String, enum: ['Super Admin', 'Super Management', 'Management', 'Employee'], default: 'Employee' },
    employeeId: { type: String, unique: true, sparse: true },
    personalEmail: { type: String, match: [/.+@.+\..+/, 'Please enter a valid email address'], },
    companyUnofficialGmail: { type: String, match: [/.+@gmail\.com$/, 'Please enter a valid Gmail address'], },
    companyOfficialEmail: { type: String, unique: true, sparse: true, match: [/.+@.+\..+/, 'Please enter a valid email address'], required: true },
    officePhone: { type: String, match: [/^\+?[0-9]{7,15}$/, 'Invalid phone number'], },
    personalPhone: { type: String, match: [/^\+?[0-9]{7,15}$/, 'Invalid phone number'], },
    status: { type: String, enum: ['Active', 'Rejected', 'Banned', 'Suspended', 'Pending'], default: 'Pending' },
    adminComments: { type: String, maxlength: 1000 },
    password: { type: String, required: true },
  },
  {
    timestamps: { createdAt: 'createdAt', updatedAt: 'updatedAt' },
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

// Virtual for full name
userSchema.virtual('fullName').get(function () {
  return [this.firstName, this.middleName, this.lastName].filter(Boolean).join(' ');
});

// Virtual for email
userSchema.virtual('email').get(function () {
  return this.companyOfficialEmail || this.companyUnofficialGmail || this.personalEmail || '-';
});

// Text index for search
userSchema.index({ firstName: 'text', lastName: 'text', employeeId: 'text' });

// Additional unique index for employeeId (ensures fast lookups)
// userSchema.index({ employeeId: 1 }, { unique: true, sparse: true });


userSchema.virtual('avatarUrl').get(function () {
  if (!this.profilePicture) {
    return `${process.env.FRONTEND_URL}/avatars/default1.png`; // fallback
  }

  const isDefault = this.profilePicture.startsWith('/assets');

  return isDefault
    ? `${process.env.FRONTEND_URL}${this.profilePicture}` // from React public folder
    : `${process.env.BACKEND_URL}${this.profilePicture}`; // from Express server
});

export default mongoose.model('User', userSchema);
