import mongoose from 'mongoose';

const taskSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    description: { type: String, required: false, trim: true },
    priority: { type: Number, min: 0, max: 5, default: 2 },
    status: { type: String, enum: ['Pending', 'Ongoing', 'Hold', 'In Progress', 'Suspended', 'Completed'], default: 'Pending' },
    dateStart: { type: Date, default: Date.now },
    dateExpectedEnd: { type: Date, required: false },
    dateClose: { type: Date, required: false },
    assignedTo: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    assignedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    assignedType: { type: String, enum: ['Employee', 'Department'], default: 'Employee' },
    additionalTask: { type: Boolean, default: false },
    assignedDepartment: { type: mongoose.Schema.Types.ObjectId, ref: 'Department' },
    rawStatus: { type: String, enum: ['Approved', 'Modified', 'Pending', 'Rejected'], default: 'Pending' }, // for admin
    deletedAt: { type: Date },
  },
  {
    timestamps: { createdAt: 'createdAt', updatedAt: 'updatedAt' },
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

// Virtual for priority label
taskSchema.virtual('priorityLabel').get(function () {
  const labels = ['Normal', 'High', 'Low', 'Critical', 'Urgent'];
  return labels[this.priority] || 'Unknown';
});

taskSchema.index({ title: 'text', description: 'text' });

export default mongoose.model('Task', taskSchema);
