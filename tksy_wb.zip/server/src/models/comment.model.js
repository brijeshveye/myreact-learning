import mongoose from 'mongoose';

const commentSchema = new mongoose.Schema(
  {
    comment: { type: String, required: true },
    parentComment: { type: mongoose.Schema.Types.ObjectId, ref: 'Comment' },
    task: { type: mongoose.Schema.Types.ObjectId, ref: 'Task', required: true },
    commentBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    commentAt: { type: Date, default: Date.now },
    deletedAt: { type: Date },
  },
  { timestamps: { createdAt: 'createdAt', updatedAt: 'updatedAt' } }
);

export default mongoose.model('Comment', commentSchema);
