import mongoose from 'mongoose';

const BreakSchema = new mongoose.Schema(
  {
    start: { type: Date, required: true },
    end: { type: Date, default: null },
  },
  { _id: false }
);

const IdleSchema = new mongoose.Schema(
  {
    start: { type: Date, required: true },
    end: { type: Date, default: null },
    trackerId: { type: String, default: null },
  },
  { _id: true }
);

const AttendanceDaySchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    workspaceId: { type: String, required: true },
    dateKey: { type: String, required: true }, // YYYY-MM-DD in server local time
    clockInAt: { type: Date, required: true },
    clockOutAt: { type: Date, default: null },
    breaks: { type: [BreakSchema], default: [] },
    idles: { type: [IdleSchema], default: [] },
  },
  { timestamps: true }
);

AttendanceDaySchema.index({ user: 1, workspaceId: 1, dateKey: 1 }, { unique: true });

export const AttendanceDay = mongoose.model('AttendanceDay', AttendanceDaySchema);
export default AttendanceDay;
