import Notification from '../models/notification.model.js';
import { io } from '../server.js';
import User from '../models/user.model.js';
import { sendNotificationEmail } from './email.service.js';

export async function createAndDispatchNotification({ user, type = 'system', title, message, icon = 'notifications', color = 'primary', task, comment, actor, meta }) {
  if (!user || !title || !message) return null;
  const payload = { user, type, title, message, icon, color, task, comment, actor, meta };
  const n = await Notification.create(payload);
  try { io.to(`user:${n.user.toString()}`).emit('notification:new', n); } catch {}
  (async () => {
    try {
      const target = await User.findById(n.user).select('companyOfficialEmail personalEmail');
    //   if (target) await sendNotificationEmail(n, target);
    } catch {}
  })();
  return n;
}

export async function sendDirectToUser({ user, title, message, icon = 'notifications', color = 'primary', type = 'system', meta }) {
  if (!user || !title || !message) return false;
  const payload = { _id: `direct_${Date.now()}`, user, type, title, message, icon, color, createdAt: new Date(), meta };
  try { io.to(`user:${String(user)}`).emit('notification:direct', payload); } catch {}
  return true;
}
