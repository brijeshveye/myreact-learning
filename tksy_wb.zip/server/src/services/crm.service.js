import axios from 'axios';

const DEFAULT_BASE = process.env.CRM_BASE_URL || process.env.KRAYIN_BASE_URL || 'http://localhost:8000';

// Token caching: cache for 4 days by default
const TOKEN_TTL_MS = Number(process.env.CRM_TOKEN_TTL_MS || 4 * 24 * 60 * 60 * 1000); // 4 days
let TOKEN_CACHE = process.env.CRM_TOKEN || process.env.KRAYIN_TOKEN || '';
let TOKEN_ISSUED_AT = TOKEN_CACHE ? Date.now() : 0; // when the current token was obtained
let TOKEN_SOURCE = TOKEN_CACHE ? 'env' : 'login'; // 'env' tokens are considered static and won't be auto-refreshed
let AUTH_PROMISE = null; // single-flight guard for concurrent logins

export class CrmError extends Error {
  constructor(message, { status, code, cause } = {}) {
    super(message);
    this.name = 'CrmError';
    if (status) this.status = status;
    if (code) this.code = code;
    if (cause) this.cause = cause;

    console.error(`[CrmError] ${message}`, { status, code, cause });
  }
}

function mapAxiosError(err, context = 'CRM request failed') {
  const status = err?.response?.status;
  const dataMsg = err?.response?.data?.message || err?.response?.data?.error || err?.message;
  const fallbackStatus = err?.code === 'ECONNABORTED' ? 504 : 502;
  const message = `${context}${status ? ` (status ${status})` : ''}: ${dataMsg || 'Unknown error'}`;
  return new CrmError(message, { status: status || fallbackStatus, code: err?.code, cause: err });
}

async function getAuthToken() {
  // 1) Reuse token if present and valid (env tokens are always considered valid; login tokens need TTL check)
  const isLoginTokenExpired = TOKEN_SOURCE === 'login' && TOKEN_ISSUED_AT && (Date.now() - TOKEN_ISSUED_AT >= TOKEN_TTL_MS);
  if (TOKEN_CACHE && !isLoginTokenExpired) {
    return TOKEN_CACHE;
  }

  // 2) Single-flight login to avoid multiple concurrent token requests
  if (AUTH_PROMISE) {
    return AUTH_PROMISE;
  }

  AUTH_PROMISE = (async () => {
    const email = process.env.CRM_ADMIN_EMAIL || process.env.KRAYIN_ADMIN_EMAIL;
    const password = process.env.CRM_ADMIN_PASSWORD || process.env.KRAYIN_ADMIN_PASSWORD;
    const device = process.env.CRM_DEVICE_NAME || process.env.KRAYIN_DEVICE_NAME || 'tasker-server';
    if (!email || !password) throw new CrmError('CRM admin credentials are not set (CRM_ADMIN_EMAIL, CRM_ADMIN_PASSWORD)', { status: 500 });
    const client = axios.create({ baseURL: DEFAULT_BASE, timeout: 12000, headers: { Accept: 'application/json' } });
    const body = new URLSearchParams({ email, password, device_name: device });
    let data;
    try {
      ({ data } = await client.post('/api/v1/login', body, { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }));
    } catch (err) {
      throw mapAxiosError(err, 'CRM login failed');
    }
    const token = data?.data?.token || data?.token;
    if (!token) throw new CrmError('CRM login succeeded but token was not found in response', { status: 502 });
    TOKEN_CACHE = token;
    TOKEN_ISSUED_AT = Date.now();
    TOKEN_SOURCE = 'login';
    const masked = `${String(token).slice(0, 6)}...${String(token).slice(-4)}`;
    console.info(`[crm.service] obtained new auth token via login (ttl ${Math.round(TOKEN_TTL_MS / (24 * 60 * 60 * 1000))}d)`, masked);
    return TOKEN_CACHE;
  })();

  try {
    return await AUTH_PROMISE;
  } finally {
    AUTH_PROMISE = null;
  }
}

async function getClient() {
  const token = await getAuthToken();
  const headers = token ? { Authorization: `Bearer ${token}`, Accept: 'application/json' } : { Accept: 'application/json' };
  return axios.create({ baseURL: DEFAULT_BASE, headers, timeout: 12000 });
}

/**
 * Generic paginator for Krayin collection endpoints that return { data: [] }
 */
async function fetchAll(path, { params = {}, pageStart = 1, limit = 200, maxPages = 10 } = {}) {
  let client = await getClient();
  const all = [];
  let page = pageStart;
  for (let i = 0; i < maxPages; i++) {
    let dataResp;
    try {
      const { data } = await client.get(path, { params: { ...params, page, limit } });
      dataResp = data;
    } catch (err) {
      // If unauthorized, try re-login once
      if (err?.response?.status === 401) {
        TOKEN_CACHE = '';
        TOKEN_ISSUED_AT = 0;
        TOKEN_SOURCE = 'login';
        client = await getClient();
        try {
          const { data } = await client.get(path, { params: { ...params, page, limit } });
          dataResp = data;
        } catch (err2) {
          throw mapAxiosError(err2, 'CRM request unauthorized after re-login');
        }
      } else if (err?.response?.status === 429) {
        throw mapAxiosError(err, 'CRM rate limit exceeded');
      } else {
        throw mapAxiosError(err, 'CRM request failed');
      }
    }
    const arr = Array.isArray(dataResp?.data) ? dataResp.data : (Array.isArray(dataResp) ? dataResp : []);
    all.push(...arr);
    if (!arr.length) break;
    page += 1;
  }
  return all;
}

function toDate(d) {
  try { return d ? new Date(d) : null; } catch { return null; }
}

function inRange(d, start, end) {
  if (!d) return false; const t = d.getTime();
  if (start && t < start.getTime()) return false;
  if (end && t >= end.getTime()) return false; // end exclusive (next-day)
  return true;
}

export async function findCrmUserByEmail(email) {
  if (!email) return null;
  const users = await fetchAll('/api/v1/settings/users', { limit: 200, maxPages: 10 }).catch((e) => { throw e; });
  return users.find(u => (u?.email || '').toLowerCase() === email.toLowerCase()) || null;
}

export async function listLeadsByUserEmail(email) {
  const leads = await fetchAll('/api/v1/leads', { limit: 200, maxPages: 15 }).catch((e) => { throw e; });
  return leads.filter(l => {
    const matchUser = (l?.user?.email || '').toLowerCase() === (email || '').toLowerCase();
    if (!matchUser) return false;
    return true;
  });
}

export async function listActivitiesByUserEmail(email) {
  if (!email) return [];
  const crmUser = await findCrmUserByEmail(email);
  if (!crmUser?.id) return [];
  const activities = await fetchAll('/api/v1/activities', { limit: 200, maxPages: 20 }).catch((e) => { throw e; });

  return activities.filter(a => {
    if (String(a?.user_id) !== String(crmUser.id)) return false;
    return true;
  });
}

// Proxy helper for the Custom Analytics API (v1)
export async function analyticsGet(path, { params = {} } = {}) {
  let client = await getClient();
  const url = `/api/v1/analytics${path.startsWith('/') ? path : `/${path}`}`;
  try {
    const { data } = await client.get(url, { params });
    // Some endpoints may wrap payload in { data }
    return (data && (data.data !== undefined)) ? data.data : data;
  } catch (err) {
    if (err?.response?.status === 401) {
      // Clear token and retry once
      TOKEN_CACHE = '';
      TOKEN_ISSUED_AT = 0;
      TOKEN_SOURCE = 'login';
      client = await getClient();
      try {
        const { data } = await client.get(url, { params });
        return (data && (data.data !== undefined)) ? data.data : data;
      } catch (err2) {
        throw mapAxiosError(err2, `CRM analytics request unauthorized after re-login: GET ${url}`);
      }
    }
    throw mapAxiosError(err, `CRM analytics request failed: GET ${url}`);
  }
}

export default {
  fetchAll,
  findCrmUserByEmail,
  listLeadsByUserEmail,
  listActivitiesByUserEmail,
  analyticsGet,
};
