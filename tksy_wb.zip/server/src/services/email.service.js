import nodemailer from 'nodemailer';

let cachedTransporter = null;

function createTransporter() {
  if (cachedTransporter) return cachedTransporter;
  const {
    SMTP_HOST,
    SMTP_PORT = 587,
    SMTP_SECURE,
    SMTP_USER,
    SMTP_PASS,
    SMTP_FROM
  } = process.env;

  if (!SMTP_HOST || !SMTP_USER || !SMTP_PASS) {
    console.warn('[email] Missing SMTP env vars; email sending disabled');
    return null;
  }

  const transporter = nodemailer.createTransport({
    host: SMTP_HOST,
    port: Number(SMTP_PORT),
    secure: SMTP_SECURE === 'true' || Number(SMTP_PORT) === 465,
    auth: { user: SMTP_USER, pass: SMTP_PASS }
  });

  cachedTransporter = transporter;
  return transporter;
}

export async function sendNotificationEmail(notification, user) {
  try {
    const transporter = createTransporter();
    if (!transporter) return;

    const from = process.env.SMTP_FROM || `Tasker <no-reply@tasker.local>`;
    const to = user.companyOfficialEmail || user.personalEmail;
    if (!to) {
      console.warn('[email] No recipient email for user', user._id?.toString());
      return;
    }

    const subject = notification.title || 'You have a new notification';
    const lines = [];
    if (notification.message) lines.push(notification.message);
    if (notification.type) lines.push(`Type: ${notification.type}`);
    lines.push('');
    lines.push('Login to Tasker to view more details.');

    const text = lines.join('\n');
    const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#222;">
      <h3 style="margin:0 0 10px 0;">${subject}</h3>
      <p style="margin:0 0 8px 0; white-space:pre-line;">${(notification.message||'').replace(/</g,'&lt;')}</p>
      ${notification.type ? `<p style=\"margin:0 0 8px 0;color:#555;\">Type: ${notification.type}</p>`:''}
      <p style="margin:16px 0 6px 0;">Login to Tasker to view more details.</p>
      <hr style="border:none;border-top:1px solid #eee;margin:18px 0;"/>
      <p style="font-size:12px;color:#888;">This is an automated message; please do not reply.</p>
    </div>`;

    await transporter.sendMail({ from, to, subject, text, html });
  } catch (err) {
    console.warn('[email] Failed to send notification email', err.message);
  }
}
