import jwt from 'jsonwebtoken';
import User from '../models/user.model.js';

export async function windowsAuth(req, res, next) {
  try {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return res.status(401).json({ is_success: false, message: 'Unauthorized' });
    const payload = jwt.verify(token, process.env.JWT_SECRET || 'dev_secret');
    const userId = payload?.sub || payload?.id || payload?._id || payload?.userId;
    const user = await User.findById(userId).select('-password');
    if (!user) return res.status(401).json({ is_success: false, message: 'Unauthorized' });
    req.user = user;
    next();
  } catch (err) {
    return res.status(401).json({ is_success: false, message: 'Unauthorized' });
  }
}
