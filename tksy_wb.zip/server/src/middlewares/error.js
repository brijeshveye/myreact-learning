import httpStatus from 'http-status';

export function notFound(req, res, next) {
  res.status(httpStatus.NOT_FOUND).json({ message: 'Not Found' });
}

// eslint-disable-next-line no-unused-vars
export function errorHandler(err, req, res, next) {
  const status = err.status || err.statusCode || httpStatus.INTERNAL_SERVER_ERROR;
  const message = err.message || 'Something went wrong';
  const details = process.env.NODE_ENV === 'production' ? undefined : err.stack;
  res.status(status).json({ message, details });
}
