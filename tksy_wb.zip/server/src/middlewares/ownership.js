import Task from '../models/task.model.js';
import Comment from '../models/comment.model.js';
import { PERMISSIONS, roleHasPermission } from '../utils/permissions.js';

// Ensure user can modify a task: either has task.update / task.delete or owns it (assignedTo)
export function ensureTaskAccess(requireDelete = false) {
  return async (req, res, next) => {
    try {
      if (!req.user) return res.status(401).json({ message: 'Unauthorized' });
      const id = req.params.id;
      if (!id) return res.status(400).json({ message: 'Task id required' });
      const task = await Task.findById(id).select('assignedTo');
      if (!task) return res.status(404).json({ message: 'Task not found' });
      const needPerm = requireDelete ? PERMISSIONS.TASK_DELETE : PERMISSIONS.TASK_UPDATE;
      const hasPerm = roleHasPermission(req.user.userGroup, needPerm);
      const owns = task.assignedTo && task.assignedTo.toString() === req.user._id.toString();
      if (!hasPerm && !owns) return res.status(403).json({ message: 'Forbidden: insufficient rights' });
      req.task = task; // attach for downstream
      next();
    } catch (e) { next(e); }
  };
}

// Ensure user can delete a specific comment: has permission or is owner of comment
export function ensureCommentDelete() {
  return async (req, res, next) => {
    try {
      if (!req.user) return res.status(401).json({ message: 'Unauthorized' });
      const id = req.params.id;
      const comment = await Comment.findById(id).select('commentBy');
      if (!comment) return res.status(404).json({ message: 'Comment not found' });
      const hasPerm = roleHasPermission(req.user.userGroup, PERMISSIONS.TASK_UPDATE) || roleHasPermission(req.user.userGroup, PERMISSIONS.TASK_DELETE);
      const owns = comment.commentBy && comment.commentBy.toString() === req.user._id.toString();
      if (!hasPerm && !owns) return res.status(403).json({ message: 'Forbidden: cannot delete comment' });
      req.comment = comment;
      next();
    } catch (e) { next(e); }
  };
}
