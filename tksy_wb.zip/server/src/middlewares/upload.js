import multer from 'multer';
import path from 'path';
import fs from 'fs';

const rootDir = path.resolve(process.cwd());
const uploadDir = path.join(rootDir, 'uploads', 'avatars');

if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    const ext = path.extname(file.originalname).toLowerCase();
    const safeName = Date.now() + '-' + Math.round(Math.random() * 1e9) + ext;
    cb(null, safeName);
  }
});

const allowed = new Set(['.png', '.jpg', '.jpeg', '.gif', '.webp']);

function fileFilter(req, file, cb) {
  const ext = path.extname(file.originalname).toLowerCase();
  if (!allowed.has(ext)) {
    return cb(new Error('Invalid file type'));
  }
  cb(null, true);
}

export const avatarUpload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 4 * 1024 * 1024 } // 4MB
});

export function buildAvatarUrl(filename) {
  if (!filename) return null;
  return `/uploads/avatars/${filename}`;
}
