import jwt from 'jsonwebtoken';
import User from '../models/user.model.js';

export function auth(required = true) {
  return async (req, res, next) => {
    try {
      const header = req.headers.authorization || '';
      const token = header.startsWith('Bearer ') ? header.slice(7) : null;
      if (!token) {
        if (required) return res.status(401).json({ message: 'Unauthorized' });
        req.user = null; return next();
      }
      const payload = jwt.verify(token, process.env.JWT_SECRET || 'dev_secret');
      const user = await User.findById(payload.sub).select('-password');
      if (!user) return res.status(401).json({ message: 'Invalid token' });
      req.user = user;
      next();
    } catch (err) {
      return res.status(401).json({ message: 'Unauthorized' });
    }
  };
}

export function authorize(...roles) {
  const allowed = new Set(roles);
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ message: 'Unauthorized' });
    if (allowed.size === 0 || allowed.has(req.user.userGroup)) return next();
    return res.status(403).json({ message: 'Forbidden' });
  };
}

export function requireActive(req, res, next) {
  if (!req.user) return res.status(401).json({ message: 'Unauthorized' });
  if (req.user.status !== 'Active') return res.status(403).json({ message: 'Account is pending approval' });
  return next();
}
