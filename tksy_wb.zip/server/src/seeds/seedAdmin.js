import dotenv from 'dotenv';
dotenv.config();
import bcrypt from 'bcryptjs';
import { connectDB } from '../utils/db.js';
import User from '../models/user.model.js';

async function run() {
  await connectDB();
  const email = process.env.SEED_ADMIN_EMAIL || 'admin@tasker.local';
  const pass = process.env.SEED_ADMIN_PASSWORD || 'admin123';
  let user = await User.findOne({ companyOfficialEmail: email });
  if (!user) {
    user = await User.create({
      firstName: 'Super',
      lastName: 'Admin',
      companyOfficialEmail: email,
      userGroup: 'Super Admin',
      password: await bcrypt.hash(pass, 10),
    });
    console.log('Seeded admin:', email);
  } else {
    console.log('Admin already exists:', email);
  }
  process.exit(0);
}

run();
