import Comment from '../models/comment.model.js';
import Task from '../models/task.model.js';
import { createAndDispatchNotification } from '../services/notification.service.js';

export async function listComments(req, res) {
  const { taskId } = req.query;
  const filter = {};
  if (taskId) filter.task = taskId;
  const comments = await Comment.find(filter).populate('commentBy task parentComment');
  res.json(comments);
}

export async function createComment(req, res) {
  const comment = await Comment.create({ ...req.body, commentBy: req.user?._id });
  try {
    const task = await Task.findById(comment.task).select('assignedTo title');
    if (task?.assignedTo) {
      await createAndDispatchNotification({
        user: task.assignedTo,
        type: 'comment',
        title: 'New Comment on Task',
        message: `${req.user?.name || 'Someone'} commented on: ${task.title}`,
        icon: 'chat',
        color: 'info',
        task: task._id,
        comment: comment._id,
        actor: req.user?._id,
        meta: { event: 'comment.created' }
      });
    }
  } catch {}
  res.status(201).json(comment);
}

export async function deleteComment(req, res) {
  const c = await Comment.findByIdAndDelete(req.params.id);
  if (!c) return res.status(404).json({ message: 'Comment not found' });
  try {
    const task = await Task.findById(c.task).select('assignedTo title');
    if (task?.assignedTo) {
      await createAndDispatchNotification({
        user: task.assignedTo,
        type: 'comment',
        title: 'Comment Deleted',
        message: `A comment was removed from: ${task.title}`,
        icon: 'chat',
        color: 'warning',
        task: task._id,
        actor: req.user?._id,
        meta: { event: 'comment.deleted' }
      });
    }
  } catch {}
  res.json({ message: 'Comment deleted' });
}
