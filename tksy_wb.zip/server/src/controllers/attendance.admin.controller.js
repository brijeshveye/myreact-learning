import User from '../models/user.model.js';
import { AttendanceDay } from '../models/attendance.model.js';
import { WindowsTracker } from '../models/windowsTracker.model.js';
import Task from '../models/task.model.js';

function ok(res, data) { return res.status(200).json({ is_success: true, data }); }
function fail(res, status, message, errors) { return res.status(status).json({ is_success: false, message, ...(errors ? { errors } : {}) }); }

function pad(n) { return String(n).padStart(2, '0'); }
function toDateKey(dt) { return `${dt.getFullYear()}-${pad(dt.getMonth() + 1)}-${pad(dt.getDate())}`; }
function parseDateLoose(input) {
  if (!input) return null;
  const parts = String(input).trim().split(/[ T]/);
  const d = (parts[0] || '').split('-');
  const t = (parts[1] || '').split(':');
  const dt = new Date(Number(d[0]), Number(d[1] || 1) - 1, Number(d[2] || 1), Number(t[0] || 0), Number(t[1] || 0), Number(t[2] || 0));
  return isNaN(dt.getTime()) ? null : dt;
}

export async function adminGetAttendanceDay(req, res) {
  try {
    const { user_id, date } = req.query || {};
    const errors = {};
    if (!user_id) errors.user_id = ['The user_id field is required.'];
    if (!date) errors.date = ['The date field is required.'];
    if (Object.keys(errors).length) return fail(res, 422, 'Validation failed.', errors);

    const user = await User.findById(user_id).select('firstName lastName companyOfficialEmail');
    if (!user) return fail(res, 404, 'User not found');

    const day = parseDateLoose(date);
    if (!day) return fail(res, 422, 'Validation failed.', { date: ['Invalid date'] });
    const dateKey = toDateKey(day);
    const start = new Date(day); start.setHours(0,0,0,0);
    const end = new Date(day); end.setHours(23,59,59,999);

    const atts = await AttendanceDay.find({ user: user._id, dateKey }).lean();
    const clockInAt = atts.length ? new Date(Math.min(...atts.map(a => new Date(a.clockInAt).getTime()))) : null;
    const clockOutAt = atts.filter(a => a.clockOutAt).length ? new Date(Math.max(...atts.filter(a=>a.clockOutAt).map(a => new Date(a.clockOutAt).getTime()))) : null;

    const breaks = [];
    const idles = [];
    for (const a of atts) {
      for (const b of (a.breaks || [])) {
        const seg = { start: b.start, end: b.end || null, duration_seconds: b.end ? Math.max(0, Math.floor((new Date(b.end) - new Date(b.start)) / 1000)) : null, workspace_id: a.workspaceId };
        breaks.push(seg);
      }
      for (const i of (a.idles || [])) {
        const seg = { id: String(i._id), start: i.start, end: i.end || null, duration_seconds: i.end ? Math.max(0, Math.floor((new Date(i.end) - new Date(i.start)) / 1000)) : null, tracker_id: i.trackerId || null, workspace_id: a.workspaceId };
        idles.push(seg);
      }
    }
    breaks.sort((x,y)=> new Date(x.start) - new Date(y.start));
    idles.sort((x,y)=> new Date(x.start) - new Date(y.start));

    // Windows tracker sessions for that day
    const sessions = await WindowsTracker.find({ user: user._id, startedAt: { $gte: start, $lte: end } }).sort({ startedAt: 1 }).lean();
    const taskIds = Array.from(new Set(sessions.map(s => String(s.task))));
    const tasks = await Task.find({ _id: { $in: taskIds } }).select('title').lean();
    const titleMap = new Map(tasks.map(t => [String(t._id), t.title]));
    const trackers = sessions.map(s => {
      const started = new Date(s.startedAt);
      const ended = s.endedAt ? new Date(s.endedAt) : null;
      const dur = ended ? Math.max(0, Math.floor((ended - started) / 1000)) : null;
      return { id: String(s._id), task_id: String(s.task), task_name: titleMap.get(String(s.task)) || 'Task', started_at: started.toISOString().replace('T',' ').slice(0,19), ended_at: ended ? ended.toISOString().replace('T',' ').slice(0,19) : null, duration_seconds: dur, is_billable: !!s.isBillable };
    });

    const tasksCovered = Array.from(new Set(trackers.map(t => `${t.task_id}|${t.task_name}`))).map(x => {
      const [id, name] = x.split('|');
      return { id, name };
    });

    return ok(res, {
      user: { id: String(user._id), name: user.firstName ? `${user.firstName} ${user.lastName||''}`.trim() : (user.companyOfficialEmail || '-') },
      date: dateKey,
      clock_in_at: clockInAt ? clockInAt.toISOString().replace('T',' ').slice(0,19) : null,
      clock_out_at: clockOutAt ? clockOutAt.toISOString().replace('T',' ').slice(0,19) : null,
      breaks,
      idles,
      trackers,
      tasks_covered: tasksCovered,
    });
  } catch (err) {
    return fail(res, 500, err.message || 'Failed to load attendance day');
  }
}

export default { adminGetAttendanceDay };
