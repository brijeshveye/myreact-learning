import Task from '../models/task.model.js';
import { createAndDispatchNotification } from '../services/notification.service.js';

export async function listTasks(req, res) {
  const { assignedTo, status, rawStatus, q, page = 1, limit = 20, dateStart, dateEnd, scope = 'all', carryOver } = req.query;
  const user = req.user;

  // Admin / management visibility: if user has elevated permissions allow scope=all
  // We infer elevation if they possess create/delete/approve task permissions injected earlier into req.user.permissions (if available)
  const elevated = (() => {
    const perms = user?.permissions || [];
    return perms.includes('task.delete') || perms.includes('task.create') || perms.includes('task.approve') || user?.userGroup === 'Super Admin' || user?.userGroup === 'Super Management' || user?.userGroup === 'Management';
  })();

  let baseFilter = {};

  // Explicit self scoping: assignedTo=self forces only tasks directly assigned to current user
  if (assignedTo === 'self') {
    baseFilter.assignedTo = user?._id;
  } else {
    if (elevated && (scope === 'all' || (!assignedTo && !status && !q && !dateStart && !dateEnd))) {
      // Elevated user requesting all tasks (default to all if no specific filters and no assignedTo specified)
      // If assignedTo provided we still honor it.
      if (assignedTo) baseFilter.assignedTo = assignedTo;
    } else {
      const orParts = [];
      // Explicit assignedTo filter overrides own
      if (assignedTo) {
        orParts.push({ assignedTo });
      } else if (user?._id) {
        orParts.push({ assignedTo: user._id });
      }
      // Department shared tasks
      if (user?.department) {
        orParts.push({ assignedType: 'Department', assignedDepartment: user.department });
      }
      if (orParts.length === 1) baseFilter = orParts[0];
      else if (orParts.length > 1) baseFilter = { $or: orParts };
    }
  }

  // Apply status/text filters
  if (status) baseFilter.status = status;
  if (rawStatus) baseFilter.rawStatus = rawStatus;
  if (q) baseFilter.$text = { $search: q };

  // Enhanced date logic (skipped if carryOver flag used):
  // If a single-day (today style) filter is requested (dateStart provided and dateEnd omitted OR both equal),
  // show tasks that (a) start/expectedEnd/created today OR (b) are older unfinished (Pending/Ongoing).
  // Otherwise fall back to original range inclusion semantics.
  if (!carryOver && (dateStart || dateEnd)) {
    const singleDay = !!dateStart && (!dateEnd || dateEnd === dateStart);
    if (singleDay && !status) { // only apply carry-over logic when not explicitly filtering by status
      const day = dateStart;
      const dayStart = new Date(`${day}T00:00:00`);
      const dayEnd = new Date(`${day}T23:59:59.999`);

      const inToday = [
        { dateStart: { $gte: dayStart, $lte: dayEnd } },
        { dateExpectedEnd: { $gte: dayStart, $lte: dayEnd } },
        { $and: [ { dateStart: { $exists: false } }, { dateExpectedEnd: { $exists: false } }, { createdAt: { $gte: dayStart, $lte: dayEnd } } ] }
      ];
      const carryOverLogic = {
        $and: [
          { $or: [
            { dateStart: { $lt: dayStart } },
            { dateExpectedEnd: { $lt: dayStart } },
            { $and: [ { dateStart: { $exists: false } }, { dateExpectedEnd: { $exists: false } }, { createdAt: { $lt: dayStart } } ] }
          ] },
            { status: { $in: ['Pending','Ongoing'] } }
        ]
      };
      const dateFilter = { $or: [ ...inToday, carryOverLogic ] };
      if (baseFilter.$or) {
        baseFilter.$and = [{ $or: baseFilter.$or }, dateFilter];
        delete baseFilter.$or;
      } else if (Object.keys(baseFilter).length) {
        baseFilter.$and = [ { ...Object.fromEntries(Object.entries(baseFilter).filter(([k]) => !k.startsWith('$'))) }, dateFilter ];
        // remove non-operator keys copied above
        for (const k of Object.keys(baseFilter)) {
          if (!k.startsWith('$') && k !== '$and') delete baseFilter[k];
        }
      } else {
        Object.assign(baseFilter, dateFilter);
      }
    } else {
      // Original (range) logic: include tasks with dateExpectedEnd or (fallback) dateStart inside window
      const range = {};
      if (dateStart) range.$gte = new Date(`${dateStart}T00:00:00`);
      const endRef = dateEnd || dateStart;
      if (endRef) range.$lte = new Date(`${endRef}T23:59:59.999`);
      const dateOr = [
        { dateExpectedEnd: range },
        { $and: [ { dateExpectedEnd: { $exists: false } }, { dateStart: range } ] },
        { $and: [ { dateExpectedEnd: { $exists: false } }, { dateStart: { $exists: false } }, { createdAt: range } ] }
      ];
      if (baseFilter.$or) {
        baseFilter.$and = [{ $or: baseFilter.$or }, { $or: dateOr }];
        delete baseFilter.$or;
      } else {
        baseFilter.$or = dateOr;
      }
    }
  }

  // Dedicated carry-over server filter (older tasks with approved/additional and specific statuses)
  if (carryOver) {
    const today = new Date();
    today.setHours(0,0,0,0);
    const olderClause = {
      $or: [
        { dateStart: { $lt: today } },
        { $and: [ { dateStart: { $exists: false } }, { dateExpectedEnd: { $lt: today } } ] }
      ]
    };
    const carryFilter = {
      $and: [
        { status: { $in: ['Pending','Ongoing','Hold'] } },
        { $or: [ { rawStatus: 'Approved' }, { additionalTask: true } ] },
        olderClause
      ]
    };
    if (Object.keys(baseFilter).length) {
      if (baseFilter.$and || baseFilter.$or || Object.keys(baseFilter).some(k => k.startsWith('$'))) {
        baseFilter = { $and: [ baseFilter, carryFilter ] };
      } else {
        baseFilter = { $and: [ { ...baseFilter }, carryFilter ] };
      }
    } else {
      baseFilter = carryFilter;
    }
  }

  const tasks = await Task.find(baseFilter)
    .skip((page - 1) * limit)
    .limit(Number(limit))
    .populate('assignedTo assignedBy assignedDepartment');
  const total = await Task.countDocuments(baseFilter);
  res.json({ data: tasks, total });
}

// Admin-wide task listing (no user restriction). Supports same filters: status, q, dateStart, dateEnd, pagination.
export async function listAllTasks(req, res) {
  const { status, rawStatus, q, page = 1, limit = 50, dateStart, dateEnd } = req.query;
  const filter = {};
  if (status) filter.status = status;
  if (rawStatus) filter.rawStatus = rawStatus;
  if (q) filter.$text = { $search: q };
  if (dateStart || dateEnd) {
    const dateRange = {};
    if (dateStart) dateRange.$gte = new Date(dateStart);
    if (dateEnd) { const e = new Date(dateEnd); e.setHours(23,59,59,999); dateRange.$lte = e; }
    filter.$or = [
      { dateExpectedEnd: dateRange },
      { $and: [ { dateExpectedEnd: { $exists: false } }, { dateStart: dateRange } ] }
    ];
  }
  const tasks = await Task.find(filter)
    .skip((page - 1) * limit)
    .limit(Number(limit))
    .populate('assignedTo assignedBy assignedDepartment');
  const total = await Task.countDocuments(filter);
  res.json({ data: tasks, total, page: Number(page), limit: Number(limit) });
}

export async function getTask(req, res) {
  const task = await Task.findById(req.params.id).populate('assignedTo assignedBy assignedDepartment');
  if (!task) return res.status(404).json({ message: 'Task not found' });
  res.json(task);
}

export async function createTask(req, res) {
  const body = { ...req.body };
  // Normalize assignedType + assignedTo from provided form fields
  let assignedType = body.assignedType;
  let assignedTo = req.user?._id;

  let assignedDepartment = null;
  if (assignedType === 'Department') {
    // frontend may send department via department or assignedToDepartment
    const deptId = body.department || body.assignedToDepartment;
    if (deptId) {
      assignedDepartment = deptId; // store department id
      try {
        const Department = await import('../models/department.model.js').then(mod => mod.default);
        const dept = await Department.findById(deptId).select('head1');
        if (dept?.head1) assignedTo = dept.head1; // assign to head for ownership tracking
      } catch (e) { /* ignore */ }
    }
  } else if (assignedType === 'Employee') {
    if (body.assignee || body.assignedTo) assignedTo = body.assignee || body.assignedTo;
    else assignedType = 'Employee';
  }

  // Fallback if no explicit type
  if (!assignedType) assignedType = 'Employee';

  const task = await Task.create({
    title: body.title,
    description: body.description,
    priority: (() => {
      const p = body.priority;
      if (typeof p === 'number' && !Number.isNaN(p)) return p;
      if (typeof p === 'string') {
        const labels = ['Normal','High','Low','Critical','Urgent'];
        if (/^\d+$/.test(p)) return Number(p);
        const idx = labels.findIndex(l => l.toLowerCase() === p.toLowerCase());
        return idx === -1 ? 0 : idx;
      }
      return 0;
    })(),
    status: body.status,
    rawStatus: body.rawStatus || 'Pending',
    additionalTask: body.additionalTask === true,
    dateExpectedEnd: body.endDate || body.dateExpectedEnd,
    assignedType,
    assignedDepartment,
    assignedBy: req.user?._id,
    assignedTo,
  });
  try {
    await createAndDispatchNotification({
      user: assignedTo,
      type: 'task',
      title: 'New Task Assigned',
      message: `${req.user?.name || 'Someone'} assigned you a task: ${body.title}`,
      icon: 'assignment',
      color: 'primary',
      task: task._id,
      actor: req.user?._id,
      meta: { event: 'task.created' }
    });
  } catch {}
  res.status(201).json(task);
}

export async function updateTask(req, res) {
  const existing = await Task.findById(req.params.id);
  if (!existing) return res.status(404).json({ message: 'Task not found' });

  const body = { ...req.body };
  const prevAssignedTo = existing.assignedTo ? String(existing.assignedTo) : null;

  // Handle possible reassignment
  if (body.assignedType === 'Department') {
    const deptId = body.department || body.assignedToDepartment;
    if (deptId) {
      existing.assignedDepartment = deptId;
      try {
        const Department = await import('../models/department.model.js').then(mod => mod.default);
        const dept = await Department.findById(deptId).select('head1');
        if (dept?.head1) {
          existing.assignedTo = dept.head1;
          existing.assignedType = 'Department';
        }
      } catch { /* ignore */ }
    }
  } else if (body.assignedType === 'Employee') {
    if (body.assignee || body.assignedTo) {
      existing.assignedTo = body.assignee || body.assignedTo;
      existing.assignedType = 'Employee';
    }
  }

  if (body.title !== undefined) existing.title = body.title;
  if (body.description !== undefined) existing.description = body.description;
  if (body.priority !== undefined) existing.priority = body.priority;
  if (body.priority !== undefined) {
    const p = body.priority;
    existing.priority = (() => {
      if (typeof p === 'number' && !Number.isNaN(p)) return p;
      if (typeof p === 'string') {
        const labels = ['Normal','High','Low','Critical','Urgent'];
        if (/^\d+$/.test(p)) return Number(p);
        const idx = labels.findIndex(l => l.toLowerCase() === p.toLowerCase());
        return idx === -1 ? 0 : idx;
      }
      return 0;
    })();
  }
  const prevStatus = existing.status;
  const prevRawStatus = existing.rawStatus;
  if (body.status !== undefined) existing.status = body.status;
  if (body.rawStatus !== undefined) existing.rawStatus = body.rawStatus;
  if (body.additionalTask !== undefined) existing.additionalTask = !!body.additionalTask;
  if (body.endDate !== undefined) existing.dateExpectedEnd = body.endDate;
  if (body.dateExpectedEnd !== undefined) existing.dateExpectedEnd = body.dateExpectedEnd;

  await existing.save();
  const task = await existing.populate('assignedTo assignedBy');
  if (!task) return res.status(404).json({ message: 'Task not found' });
  try {
    // Reassignment notifications
    const newAssignedTo = task.assignedTo ? String(task.assignedTo._id || task.assignedTo) : null;
    if (prevAssignedTo && newAssignedTo && prevAssignedTo !== newAssignedTo) {
      // Notify new assignee
      await createAndDispatchNotification({
        user: task.assignedTo,
        type: 'task',
        title: 'Task Assigned to You',
        message: `${req.user?.name || 'Someone'} assigned you: ${task.title}`,
        icon: 'assignment_ind',
        color: 'primary',
        task: task._id,
        actor: req.user?._id,
        meta: { event: 'task.reassigned', from: prevAssignedTo, to: newAssignedTo }
      });
      // Notify previous assignee
      await createAndDispatchNotification({
        user: prevAssignedTo,
        type: 'task',
        title: 'Task Reassigned',
        message: `Task reassigned from you: ${task.title}`,
        icon: 'swap_horiz',
        color: 'warning',
        task: task._id,
        actor: req.user?._id,
        meta: { event: 'task.reassigned', from: prevAssignedTo, to: newAssignedTo }
      });
    }
    if (prevStatus !== task.status) {
      await createAndDispatchNotification({
        user: task.assignedTo,
        type: 'task',
        title: 'Task Status Updated',
        message: `Status changed to ${task.status} for: ${task.title}`,
        icon: 'update',
        color: 'info',
        task: task._id,
        actor: req.user?._id,
        meta: { event: 'task.status_updated', from: prevStatus, to: task.status }
      });
      // If completed, notify the assigner as well
      if (task.status === 'Completed' && task.assignedBy) {
        await createAndDispatchNotification({
          user: task.assignedBy,
          type: 'task',
          title: 'Task Completed',
          message: `${task.assignedTo?.name || 'Assignee'} completed: ${task.title}`,
          icon: 'task_alt',
          color: 'success',
          task: task._id,
          actor: req.user?._id,
          meta: { event: 'task.completed' }
        });
      }
    }
    if (prevRawStatus !== task.rawStatus) {
      await createAndDispatchNotification({
        user: task.assignedTo,
        type: 'task',
        title: 'Task Approval Status Updated',
        message: `Approval changed to ${task.rawStatus} for: ${task.title}`,
        icon: 'rule',
        color: task.rawStatus === 'Approved' ? 'success' : task.rawStatus === 'Rejected' ? 'danger' : 'warning',
        task: task._id,
        actor: req.user?._id,
        meta: { event: 'task.raw_status_updated', from: prevRawStatus, to: task.rawStatus }
      });
      // Notify assigner when task gets approved or rejected
      if (task.assignedBy && (task.rawStatus === 'Approved' || task.rawStatus === 'Rejected')) {
        await createAndDispatchNotification({
          user: task.assignedBy,
          type: 'task',
          title: `Task ${task.rawStatus}`,
          message: `${task.title} has been ${task.rawStatus.toLowerCase()}.`,
          icon: task.rawStatus === 'Approved' ? 'check_circle' : 'cancel',
          color: task.rawStatus === 'Approved' ? 'success' : 'danger',
          task: task._id,
          actor: req.user?._id,
          meta: { event: 'task.approval_updated', to: task.rawStatus }
        });
      }
    }
  } catch {}
  res.json(task);
}

export async function deleteTask(req, res) {
  const task = await Task.findByIdAndDelete(req.params.id);
  if (!task) return res.status(404).json({ message: 'Task not found' });
  try {
    await createAndDispatchNotification({
      user: task.assignedTo,
      type: 'task',
      title: 'Task Deleted',
      message: `Task deleted: ${task.title}`,
      icon: 'delete',
      color: 'danger',
      task: task._id,
      actor: req.user?._id,
      meta: { event: 'task.deleted' }
    });
  } catch {}
  res.json({ message: 'Task deleted' });
}
