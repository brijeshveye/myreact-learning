import { analyticsGet, CrmError } from '../services/crm.service.js';

function passthrough(handler) {
  return async function(req, res) {
    try {
      const data = await handler(req);
      return res.json(data);
    } catch (err) {
      if (err instanceof CrmError) {
        return res.status(err.status || 502).json({ message: err.message });
      }
      return res.status(500).json({ message: err.message || 'CRM analytics request failed' });
    }
  };
}

export const getUsersSummary = passthrough(async (req) => {
  return analyticsGet('/users/summary', { params: req.query });
});

export const getUsersRegistrations = passthrough(async (req) => {
  return analyticsGet('/users/registrations', { params: req.query });
});

export const getLeadsByUser = passthrough(async (req) => {
  return analyticsGet('/leads/by-user', { params: req.query });
});

export const getLeadsCountsByUser = passthrough(async (req) => {
  return analyticsGet('/leads/counts-by-user', { params: req.query });
});

export const getLeadsUpdatedByUser = passthrough(async (req) => {
  return analyticsGet('/leads/updated-by-user', { params: req.query });
});

export const getLeadsStatusCounts = passthrough(async (req) => {
  return analyticsGet('/leads/status-counts', { params: req.query });
});

export const getLeadsStageCounts = passthrough(async (req) => {
  return analyticsGet('/leads/stage-counts', { params: req.query });
});

export const getLeadsSourceCounts = passthrough(async (req) => {
  return analyticsGet('/leads/source-counts', { params: req.query });
});

export const getLeadsTypeCounts = passthrough(async (req) => {
  return analyticsGet('/leads/type-counts', { params: req.query });
});

export const getLeadsValueSumByUser = passthrough(async (req) => {
  return analyticsGet('/leads/value-sum-by-user', { params: req.query });
});

export const getLeadsWonByUser = passthrough(async (req) => {
  return analyticsGet('/leads/won-by-user', { params: req.query });
});

export const getLeadsLostByUser = passthrough(async (req) => {
  return analyticsGet('/leads/lost-by-user', { params: req.query });
});

export const getActivitiesCallByUser = passthrough(async (req) => {
  return analyticsGet('/activities/call-by-user', { params: req.query });
});

export const getActivitiesCreatedByUser = passthrough(async (req) => {
  return analyticsGet('/activities/created-by-user', { params: req.query });
});

export const getActivitiesByType = passthrough(async (req) => {
  return analyticsGet('/activities/by-type', { params: req.query });
});

export const getActivitiesDoneByUser = passthrough(async (req) => {
  return analyticsGet('/activities/done-by-user', { params: req.query });
});

export const getActivitiesPendingByUser = passthrough(async (req) => {
  return analyticsGet('/activities/pending-by-user', { params: req.query });
});

export const getActivitiesTypesByUser = passthrough(async (req) => {
  return analyticsGet('/activities/types-by-user', { params: req.query });
});
