import { AttendanceDay } from '../models/attendance.model.js';

function ok(res, data) { return res.status(200).json({ is_success: true, data }); }
function fail(res, status, message, errors) { return res.status(status).json({ is_success: false, message, ...(errors ? { errors } : {}) }); }

function pad(n) { return String(n).padStart(2, '0'); }
function toDateKey(dt) {
  const y = dt.getFullYear();
  const m = pad(dt.getMonth() + 1);
  const d = pad(dt.getDate());
  return `${y}-${m}-${d}`;
}

// Accepts both padded and unpadded datetime components
function parseDateLoose(input) {
  if (!input) return null;
  const parts = String(input).trim().split(/[ T]/);
  if (parts.length === 0) return null;
  const d = (parts[0] || '').split('-');
  const t = (parts[1] || '').split(':');
  const year = Number(d[0]);
  const month = Number(d[1] || 1) - 1;
  const day = Number(d[2] || 1);
  const hour = Number(t[0] || 0);
  const minute = Number(t[1] || 0);
  const second = Number(t[2] || 0);
  const dt = new Date(year, month, day, hour, minute, second);
  return isNaN(dt.getTime()) ? null : dt;
}

function computeTotals(att) {
  if (!att) return { is_clocked_in: false, is_on_break: false, total_seconds: 0, total_break_seconds: 0, total_idle_seconds: 0 };
  const now = new Date();
  const start = att.clockInAt;
  const end = att.clockOutAt || now;
  let total = Math.max(0, Math.floor((end.getTime() - start.getTime()) / 1000));
  let breakTotal = 0;
  let idleTotal = 0;
  for (const br of att.breaks || []) {
    const bs = br.start;
    const be = br.end || now;
    if (bs && be && be > bs) {
      const seg = Math.max(0, Math.floor((be.getTime() - bs.getTime()) / 1000));
      breakTotal += seg;
      total -= seg;
    }
  }
  for (const id of att.idles || []) {
    const is = id.start;
    const ie = id.end || now;
    if (is && ie && ie > is) {
      const seg = Math.max(0, Math.floor((ie.getTime() - is.getTime()) / 1000));
      idleTotal += seg;
      total -= seg;
    }
  }
  const isOnBreak = !!(att.breaks || []).find(b => !b.end);
  const isClockedIn = !!att.clockInAt && !att.clockOutAt;
  return { is_clocked_in: isClockedIn, is_on_break: isOnBreak, total_seconds: Math.max(0, total), total_break_seconds: Math.max(0, breakTotal), total_idle_seconds: Math.max(0, idleTotal) };
}

export async function getAttendanceSummary(req, res) {
  try {
    const { date, workspace_id } = req.query || {};
    const errors = {};
    if (!date) errors.date = ['The date field is required.'];
    if (Object.keys(errors).length) return fail(res, 422, 'Validation failed.', errors);

    const day = parseDateLoose(String(date).trim());
    if (!day || isNaN(day.getTime())) return fail(res, 422, 'Validation failed.', { date: ['Invalid date format, expected YYYY-MM-DD'] });
    const dateKey = toDateKey(day);

    const breakQuota = Number(process.env.WIN_BREAK_QUOTA_SECONDS || 3600);

    if (workspace_id) {
      const att = await AttendanceDay.findOne({ user: req.user._id, workspaceId: String(workspace_id), dateKey });
      if (!att) return ok(res, { date, is_clocked_in: false, is_on_break: false, total_seconds: 0, total_break_seconds: 0, total_idle_seconds: 0, break_quota_seconds: breakQuota });
      const { is_clocked_in, is_on_break, total_seconds, total_break_seconds, total_idle_seconds } = computeTotals(att);
      return ok(res, { date, is_clocked_in, is_on_break, total_seconds, total_break_seconds, total_idle_seconds, break_quota_seconds: breakQuota });
    }

    // Aggregate across all workspaces for that day when workspace_id is omitted
    const atts = await AttendanceDay.find({ user: req.user._id, dateKey }).lean();
    if (!atts.length) return ok(res, { date, is_clocked_in: false, is_on_break: false, total_seconds: 0, total_break_seconds: 0, total_idle_seconds: 0, break_quota_seconds: breakQuota });
    let total_seconds = 0, total_break_seconds = 0, total_idle_seconds = 0;
    let is_clocked_in = false, is_on_break = false;
    for (const a of atts) {
      const { is_clocked_in: ic, is_on_break: ib, total_seconds: ts, total_break_seconds: tbs, total_idle_seconds: tis } = computeTotals(a);
      total_seconds += ts;
      total_break_seconds += tbs;
      total_idle_seconds += tis;
      if (ic) is_clocked_in = true;
      if (ib) is_on_break = true;
    }
    return ok(res, { date, is_clocked_in, is_on_break, total_seconds, total_break_seconds, total_idle_seconds, break_quota_seconds: breakQuota });
  } catch (err) {
    return fail(res, 500, err.message || 'Failed to load attendance summary');
  }
}

export async function clockIn(req, res) {
  try {
    const { time, workspaces_id } = req.body || {};
    const errors = {};
    if (!time) errors.time = ['The time field is required.'];
    if (!workspaces_id) errors.workspaces_id = ['The workspaces_id field is required.'];
    if (Object.keys(errors).length) return fail(res, 422, 'Validation failed.', errors);

    const at = parseDateLoose(time);
    if (!at) return fail(res, 422, 'Validation failed.', { time: ['Invalid time format'] });

    const dateKey = toDateKey(at);
    const wsId = String(workspaces_id);

    let existing = await AttendanceDay.findOne({ user: req.user._id, workspaceId: wsId, dateKey });
    if (existing) {
      if (existing.clockOutAt) {
        return fail(res, 409, 'Already clocked out for this day');
      }
      return fail(res, 409, 'Already clocked in');
    }

    const att = await AttendanceDay.create({ user: req.user._id, workspaceId: wsId, dateKey, clockInAt: at, clockOutAt: null, breaks: [] });
    return ok(res, { clock_in_at: time });
  } catch (err) {
    if (err?.code === 11000) return fail(res, 409, 'Already clocked in');
    return fail(res, 500, err.message || 'Failed to clock in');
  }
}

export async function clockOut(req, res) {
  try {
    const { time, workspaces_id } = req.body || {};
    const errors = {};
    if (!time) errors.time = ['The time field is required.'];
    if (!workspaces_id) errors.workspaces_id = ['The workspaces_id field is required.'];
    if (Object.keys(errors).length) return fail(res, 422, 'Validation failed.', errors);

    const at = parseDateLoose(time);
    if (!at) return fail(res, 422, 'Validation failed.', { time: ['Invalid time format'] });
    const dateKey = toDateKey(at);
    const wsId = String(workspaces_id);

  const att = await AttendanceDay.findOne({ user: req.user._id, workspaceId: wsId, dateKey });
    if (!att) return fail(res, 422, 'Validation failed.', { time: ['No clock-in found for this day'] });
    if (att.clockOutAt) {
      // idempotent return
      return ok(res, { clock_out_at: att.clockOutAt.toISOString().replace('T', ' ').slice(0, 19) });
    }
    // If currently on break, auto-end the break at clock-out time
    const lastBreak = (att.breaks || []).length ? att.breaks[att.breaks.length - 1] : null;
    if (lastBreak && !lastBreak.end) {
      lastBreak.end = at;
    }
    // If currently idle, auto-end the idle at clock-out time
    const lastIdle = (att.idles || []).length ? att.idles[att.idles.length - 1] : null;
    if (lastIdle && !lastIdle.end) {
      lastIdle.end = at;
    }
    att.clockOutAt = at;
    await att.save();
    return ok(res, { clock_out_at: time });
  } catch (err) {
    return fail(res, 500, err.message || 'Failed to clock out');
  }
}

export async function breakStart(req, res) {
  try {
    const { time, workspaces_id } = req.body || {};
    const errors = {};
    if (!time) errors.time = ['The time field is required.'];
    if (!workspaces_id) errors.workspaces_id = ['The workspaces_id field is required.'];
    if (Object.keys(errors).length) return fail(res, 422, 'Validation failed.', errors);

    const at = parseDateLoose(time);
    if (!at) return fail(res, 422, 'Validation failed.', { time: ['Invalid time format'] });
    const dateKey = toDateKey(at);
    const wsId = String(workspaces_id);

    const att = await AttendanceDay.findOne({ user: req.user._id, workspaceId: wsId, dateKey });
    if (!att || att.clockOutAt) return fail(res, 422, 'Validation failed.', { time: ['Not clocked in'] });
    const lastBreak = (att.breaks || []).length ? att.breaks[att.breaks.length - 1] : null;
    if (lastBreak && !lastBreak.end) return fail(res, 422, 'Validation failed.', { time: ['Already on break'] });

    // If currently idle, auto-end idle at break start
    const lastIdle = (att.idles || []).length ? att.idles[att.idles.length - 1] : null;
    if (lastIdle && !lastIdle.end) {
      lastIdle.end = at;
    }
    att.breaks.push({ start: at, end: null });
    await att.save();
    return ok(res, { break_start_at: time });
  } catch (err) {
    return fail(res, 500, err.message || 'Failed to start break');
  }
}

export async function idleStart(req, res) {
  try {
    const { time, workspaces_id, tracker_id } = req.body || {};
    const errors = {};
    if (!time) errors.time = ['The time field is required.'];
    if (!workspaces_id) errors.workspaces_id = ['The workspaces_id field is required.'];
    if (Object.keys(errors).length) return fail(res, 422, 'Validation failed.', errors);

    const at = parseDateLoose(time);
    if (!at) return fail(res, 422, 'Validation failed.', { time: ['Invalid time format'] });
    const dateKey = toDateKey(at);
    const wsId = String(workspaces_id);

    const att = await AttendanceDay.findOne({ user: req.user._id, workspaceId: wsId, dateKey });
    if (!att || att.clockOutAt) return fail(res, 422, 'Validation failed.', { state: ['User must be clocked in to start idle.'] });
    const lastBreak = (att.breaks || []).length ? att.breaks[att.breaks.length - 1] : null;
    if (lastBreak && !lastBreak.end) return fail(res, 422, 'Validation failed.', { state: ['Cannot start idle during a break.'] });
    const lastIdle = (att.idles || []).length ? att.idles[att.idles.length - 1] : null;
    if (lastIdle && !lastIdle.end) return fail(res, 422, 'Validation failed.', { overlap: ['An idle interval is already open.'] });

    att.idles.push({ start: at, end: null, trackerId: tracker_id ?? null });
    await att.save();
    const newly = att.idles[att.idles.length - 1];
    return ok(res, { id: String(newly._id), idle_start_at: time });
  } catch (err) {
    return fail(res, 500, err.message || 'Failed to start idle');
  }
}

export async function idleEnd(req, res) {
  try {
    const { time, workspaces_id, idle_id } = req.body || {};
    const errors = {};
    if (!time) errors.time = ['The time field is required.'];
    if (!workspaces_id) errors.workspaces_id = ['The workspaces_id field is required.'];
    if (Object.keys(errors).length) return fail(res, 422, 'Validation failed.', errors);

    const at = parseDateLoose(time);
    if (!at) return fail(res, 422, 'Validation failed.', { time: ['Invalid time format'] });
    const dateKey = toDateKey(at);
    const wsId = String(workspaces_id);

    const att = await AttendanceDay.findOne({ user: req.user._id, workspaceId: wsId, dateKey });
    if (!att || att.clockOutAt) return fail(res, 422, 'Validation failed.', { idle_id: ['No open idle interval found.'] });
    let target = null;
    if (idle_id) {
      target = (att.idles || []).find(i => String(i._id) === String(idle_id));
      if (!target) return fail(res, 422, 'Validation failed.', { idle_id: ['No open idle interval found.'] });
    } else {
      const lastIdle = (att.idles || []).length ? att.idles[att.idles.length - 1] : null;
      if (lastIdle && !lastIdle.end) target = lastIdle;
    }
    if (!target || target.end) return fail(res, 422, 'Validation failed.', { idle_id: ['No open idle interval found.'] });
    if (at <= target.start) return fail(res, 422, 'Validation failed.', { order: ['End time must be after start time.'] });
    target.end = at;
    await att.save();
    const duration = Math.max(0, Math.floor((target.end.getTime() - target.start.getTime()) / 1000));
    return ok(res, { idle_end_at: time, duration_seconds: duration });
  } catch (err) {
    return fail(res, 500, err.message || 'Failed to end idle');
  }
}

export async function breakEnd(req, res) {
  try {
    const { time, workspaces_id } = req.body || {};
    const errors = {};
    if (!time) errors.time = ['The time field is required.'];
    if (!workspaces_id) errors.workspaces_id = ['The workspaces_id field is required.'];
    if (Object.keys(errors).length) return fail(res, 422, 'Validation failed.', errors);

    const at = parseDateLoose(time);
    if (!at) return fail(res, 422, 'Validation failed.', { time: ['Invalid time format'] });
    const dateKey = toDateKey(at);
    const wsId = String(workspaces_id);

    const att = await AttendanceDay.findOne({ user: req.user._id, workspaceId: wsId, dateKey });
    if (!att || att.clockOutAt) return fail(res, 422, 'Validation failed.', { time: ['Not clocked in'] });
    const lastBreak = (att.breaks || []).length ? att.breaks[att.breaks.length - 1] : null;
    if (!lastBreak || lastBreak.end) return fail(res, 422, 'Validation failed.', { time: ['No active break to end'] });
    lastBreak.end = at;
    await att.save();
    return ok(res, { break_end_at: time });
  } catch (err) {
    return fail(res, 500, err.message || 'Failed to end break');
  }
}

export default { getAttendanceSummary, clockIn, clockOut, breakStart, breakEnd };
