import Notification from '../models/notification.model.js';
import httpStatus from 'http-status';

// List notifications for authenticated user
export async function listNotifications(req, res) {
  const { page = 1, limit = 20, unread, type } = req.query;
  const filter = { user: req.user._id };
  if (unread === 'true') filter.isRead = false;
  if (type) filter.type = type;

  const skip = (Number(page) - 1) * Number(limit);
  const [items, total, unreadCount] = await Promise.all([
    Notification.find(filter)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number(limit)),
    Notification.countDocuments(filter),
    Notification.countDocuments({ user: req.user._id, isRead: false })
  ]);

  res.json({
    page: Number(page),
    limit: Number(limit),
    total,
    unreadCount,
    items
  });
}
import { io } from '../server.js';
import User from '../models/user.model.js';
import { sendNotificationEmail } from '../services/email.service.js';

// Create a notification (system side). Only privileged roles could call this (enforce in route if needed)
export async function createNotification(req, res) {
  const payload = {
    user: req.body.user,
    type: req.body.type,
    title: req.body.title,
    message: req.body.message,
    icon: req.body.icon,
    color: req.body.color,
    task: req.body.task,
    comment: req.body.comment,
    actor: req.user?._id,
    meta: req.body.meta,
  };
  const n = await Notification.create(payload);
  // Emit to user room
  try {
    io.to(`user:${n.user.toString()}`).emit('notification:new', n);
  } catch (e) {
    // swallow emit errors (server still returns success)
  }
  // Fire-and-forget email (do not await for response latency)
  (async () => {
    try {
      const user = await User.findById(n.user).select('companyOfficialEmail personalEmail');
      if (user) await sendNotificationEmail(n, user);
    } catch (err) {
      // swallow email errors
    }
  })();
  res.status(httpStatus.CREATED).json(n);
}

// Mark one notification read/unread
export async function markNotificationRead(req, res) {
  const { id } = req.params;
  const { read = true } = req.body;
  const n = await Notification.findOne({ _id: id, user: req.user._id });
  if (!n) return res.status(404).json({ message: 'Notification not found' });
  n.isRead = Boolean(read);
  n.readAt = n.isRead ? new Date() : undefined;
  await n.save();
  res.json(n);
}

// Mark all notifications as read for user
export async function markAllNotificationsRead(req, res) {
  const result = await Notification.updateMany({ user: req.user._id, isRead: false }, { isRead: true, readAt: new Date() });
  res.json({ updated: result.modifiedCount });
}

// Delete (soft or hard). We'll do hard delete for now.
export async function deleteNotification(req, res) {
  const { id } = req.params;
  const n = await Notification.findOneAndDelete({ _id: id, user: req.user._id });
  if (!n) return res.status(404).json({ message: 'Notification not found' });
  res.json({ message: 'Notification deleted' });
}


// Send WebSocket notification to a user
export async function sendTestNotification(req, res) {
  const { userId, title, message } = req.params;
  if (!userId) return res.status(400).json({ message: 'userId is required' });

  // Verify user exists
  const user = await User.findById(userId).select('_id');
  if (!user) return res.status(404).json({ message: 'User not found' });
  const n = {
    user: user._id,
    type: 'info',
    title:  title || 'Test Notification',
    message: message || 'This is a test notification',
    icon: 'info',
    color: 'blue',
  };
  io.to(`user:${user._id.toString()}`).emit('notification:new', n);
  res.json({ message: 'notification sent' });
}

// Send a direct (non-persisted) notification with selectable delivery channels
export async function sendDirectNotification(req, res) {
  const { user: userId, title, message, icon, color, delivery = 'both', type = 'system' } = req.body || {};
  if (!userId) return res.status(400).json({ message: 'user is required' });
  if (!title || !message) return res.status(400).json({ message: 'title and message are required' });
  const target = await User.findById(userId).select('companyOfficialEmail personalEmail');
  if (!target) return res.status(404).json({ message: 'User not found' });

  const payload = {
    _id: `direct_${Date.now()}`, // ephemeral id
    user: target._id,
    type,
    title,
    message,
    icon: icon || 'notifications',
    color: color || 'primary',
    actor: req.user?._id,
    createdAt: new Date(),
    meta: { delivery, direct: true }
  };

  const mode = (delivery || 'both').toLowerCase();
  if (mode === 'both' || mode === 'socket') {
    try { io.to(`user:${target._id.toString()}`).emit('notification:direct', payload); } catch {}
  }
  if (mode === 'both' || mode === 'email') {
    (async () => {
      try { await sendNotificationEmail(payload, target); } catch {}
    })();
  }

  res.status(202).json({ delivered: true, delivery: mode });
}
