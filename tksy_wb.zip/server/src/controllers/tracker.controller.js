import axios from 'axios';
import httpStatus from 'http-status';
import User from '../models/user.model.js';

// GET /api/tracker/:userId/report?range=two_before|day_before|yesterday
// range maps to a target date relative to today (server time) unless a date param later added.
export async function getTrackerReport(req, res) {
    const { id } = req.params; // userId here expected to be company official email per spec
    const { range } = req.query; // expected: two_before | day_before | yesterday

    // Get email from User record if needed
    const user = await User.findById(id).select('companyOfficialEmail');

    const userEmail = user?.companyOfficialEmail;

    if (!userEmail) return res.status(400).json({ message: 'User Email required' });

    const base = process.env.TRACKER_API_BASE_URL;
    if (!base) return res.status(500).json({ message: 'TRACKER_API_BASE_URL not configured' });

    const apiKey = process.env.TRACKER_API_KEY;
    if (!apiKey) return res.status(500).json({ message: 'TRACKER_API_KEY not configured' });

    console.log('Fetching tracker report for', userEmail, 'range:', range || 'none');

    try {
        // External URL pattern: http://host:3000/employees/s2s/details/{company_official_email}
        const url = `${base.replace(/\/$/, '')}/employees/s2s/details/${encodeURIComponent(userEmail)}`;
        const params = {};
        if (range) params.date = range; // if supported by external service

        const { data: ext } = await axios.get(url, {
            params,
            timeout: 15000,
            headers: {
                'x-api-key': apiKey
            }
        });
        // Defensive parsing
        const payload = ext?.data || {};

        // Normalize arrays
        const breaks = Array.isArray(payload.breaks) ? payload.breaks : [];
        const powerEvents = Array.isArray(payload.power_events) ? payload.power_events : [];
        const stateEvents = Array.isArray(payload.state_events) ? payload.state_events : [];

        const normalized = {
            userId: payload.user_id || userId,
            date: payload.date,
            name: payload.name,
            email: payload.email,
            breaks,
            totalBreakTime: payload.total_break_time || '00:00:00',
            breakCount: payload.break_count ?? breaks.length,
            powerEvents: powerEvents.map(e => ({ id: e._id || e.id, event: e.event, timestamp: e.timestamp })),
            stateEvents: stateEvents.map(e => ({ id: e._id || e.id, event: e.event, timestamp: e.timestamp })),
            totalIdleTime: payload.total_idle_time || '00:00:00'
        };

        return res.json(normalized);
    } catch (err) {
        const status = err.response?.status || 500;
        return res.status(status).json({ message: 'Failed to fetch tracker report', detail: err.message });
    }
}
