import mongoose from 'mongoose';
import { WindowsScreenshot } from '../models/windowsScreenshot.model.js';
import { WindowsTracker } from '../models/windowsTracker.model.js';
import Task from '../models/task.model.js';

function toDateStart(d) {
  const dt = new Date(d);
  if (isNaN(dt)) return null;
  dt.setHours(0, 0, 0, 0);
  return dt;
}
function toDateEnd(d) {
  const dt = new Date(d);
  if (isNaN(dt)) return null;
  dt.setHours(23, 59, 59, 999);
  return dt;
}

function parseTimeToSeconds(t) {
  if (!t) return null;
  const [h, m] = String(t).split(':').map(Number);
  if (Number.isNaN(h) || Number.isNaN(m)) return null;
  return h * 3600 + m * 60;
}

function buildPublicUrl(fileName) {
  const base = process.env.BACKEND_URL || '';
  return base ? `${base}/uploads/shots/${encodeURIComponent(fileName)}` : `/uploads/shots/${encodeURIComponent(fileName)}`;
}

// GET /api/screenshots/timeline?user=<id>&from=YYYY-MM-DD&to=YYYY-MM-DD&startTime=HH:mm&endTime=HH:mm&limit=500
export async function getScreenshotTimeline(req, res) {
  try {
    const { user: userId, from, to, startTime, endTime } = req.query;
    // Accept task filter as CSV string or repeated query parameter (?task=a&task=b)
    const taskParam = req.query.task;
    let filterTaskIds = [];
    if (Array.isArray(taskParam)) {
      filterTaskIds = taskParam.map(String).filter(Boolean);
    } else if (typeof taskParam === 'string') {
      filterTaskIds = taskParam.split(',').map(s => s.trim()).filter(Boolean);
    }
    if (!userId) return res.status(400).json({ message: 'user is required' });

    // Authorization: allow self, or any admin/management roles
    const isSelf = req.user && String(req.user._id) === String(userId);
    const role = req.user?.userGroup;
    const allowedRoles = new Set(['Super Admin', 'Super Management', 'Management']);
    if (!isSelf && !allowedRoles.has(role)) return res.status(403).json({ message: 'Forbidden' });

    const rangeStart = from ? toDateStart(from) : toDateStart(new Date());
    const rangeEnd = to ? toDateEnd(to) : toDateEnd(new Date());
    if (!rangeStart || !rangeEnd) return res.status(400).json({ message: 'Invalid date range' });

    const limit = Math.min(parseInt(req.query.limit) || 500, 2000);

    const query = {
      user: new mongoose.Types.ObjectId(userId),
      capturedAt: { $gte: rangeStart, $lte: rangeEnd }
    };

    const shots = await WindowsScreenshot.find(query)
      .sort({ capturedAt: 1 })
      .limit(limit)
      .lean();

    // Optional time-of-day filtering
    const startSec = parseTimeToSeconds(startTime);
    const endSec = parseTimeToSeconds(endTime);
    const inTimeRange = (dt) => {
      if (startSec == null && endSec == null) return true;
      const s = dt.getHours() * 3600 + dt.getMinutes() * 60 + dt.getSeconds();
      if (startSec != null && endSec != null) {
        if (endSec >= startSec) return s >= startSec && s <= endSec; // normal window
        // overnight window (e.g., 22:00-02:00)
        return s >= startSec || s <= endSec;
      }
      if (startSec != null) return s >= startSec;
      if (endSec != null) return s <= endSec;
      return true;
    };

  let filtered = shots.filter(sh => inTimeRange(new Date(sh.capturedAt)));

    // Fetch tasks for enrichment
    const trackerIds = Array.from(new Set(filtered.map(s => String(s.tracker))));
    const trackers = await WindowsTracker.find({ _id: { $in: trackerIds } }).select('task').lean();
    const taskIds = Array.from(new Set(trackers.map(t => String(t.task))));
    const tasks = await Task.find({ _id: { $in: taskIds } }).select('title').lean();
    const trackerToTask = new Map(trackers.map(t => [String(t._id), String(t.task)]));
    const taskTitles = new Map(tasks.map(t => [String(t._id), t.title]));

    let items = filtered.map(s => {
      const taskId = trackerToTask.get(String(s.tracker));
      return {
        id: String(s._id),
        capturedAt: s.capturedAt,
        url: buildPublicUrl(s.fileName),
        size: s.size,
        tracker: String(s.tracker),
        task: taskId ? { id: taskId, title: taskTitles.get(taskId) || 'Task' } : null,
      };
    });

    // Apply task filter if provided
    if (filterTaskIds.length > 0) {
      const allow = new Set(filterTaskIds.map(String));
      items = items.filter(it => it.task && allow.has(String(it.task.id)));
    }

    // Group by date string for convenience
    const groups = items.reduce((acc, it) => {
      const k = new Date(it.capturedAt).toISOString().slice(0, 10);
      (acc[k] ||= []).push(it);
      return acc;
    }, {});

    // Build task options summary for UI filters
    const taskCounts = new Map();
    for (const it of items) {
      if (!it.task) continue;
      const key = String(it.task.id);
      const prev = taskCounts.get(key) || { id: key, title: it.task.title, count: 0 };
      prev.count += 1;
      taskCounts.set(key, prev);
    }
    const taskOptions = Array.from(taskCounts.values()).sort((a, b) => a.title.localeCompare(b.title));

    return res.json({ count: items.length, items, groups, taskOptions });
  } catch (err) {
    return res.status(500).json({ message: 'Failed to load screenshots', detail: err.message });
  }
}
