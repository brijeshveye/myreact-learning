import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import Joi from 'joi';
import User from '../models/user.model.js';
import Department from '../models/department.model.js';
import { randomAvatar, avatarPath } from '../utils/avatars.js';
import { buildAvatarUrl } from '../middlewares/upload.js';

function sign(user) {
  const payload = { sub: user._id.toString(), role: user.userGroup };
  const secret = process.env.JWT_SECRET || 'dev_secret';
  const expiresIn = '7d';
  return jwt.sign(payload, secret, { expiresIn });
}

const registerSchema = Joi.object({
  firstName: Joi.string().trim().required(),
  middleName: Joi.string().allow('', null),
  lastName: Joi.string().trim().required(),
  profilePicture: Joi.string().uri().allow('', null),
  dob: Joi.date().allow(null),
  gender: Joi.string().valid('Male', 'Female', 'Other').allow('', null),
  permanentAddress: Joi.string().allow('', null),
  currentAddress: Joi.string().allow('', null),
  designation: Joi.string().allow('', null),
  department: Joi.string().hex().length(24).allow(null),
  departmentName: Joi.string().trim().allow('', null),
  userGroup: Joi.string().valid('Super Admin', 'Super Management', 'Management', 'Employee').default('Employee'),
  employeeId: Joi.string().allow('', null),
  personalEmail: Joi.string().email().allow('', null),
  companyUnofficialGmail: Joi.string().email().allow('', null),
  companyOfficialEmail: Joi.string().email().required(),
  officePhone: Joi.string().allow('', null),
  personalPhone: Joi.string().allow('', null),
  status: Joi.string().valid('Normal', 'Banned', 'Suspended').default('Normal'),
  userType: Joi.string().valid('Active', 'Pending').default('Pending'),
  password: Joi.string().min(6).required(),
});

export async function register(req, res) {
  try {
  const input = await registerSchema.validateAsync(req.body, { abortEarly: false, stripUnknown: true });
    // Duplicate email check
    const exists = await User.findOne({ companyOfficialEmail: input.companyOfficialEmail });
    if (exists) return res.status(409).json({ message: 'Email already registered' });

    // Resolve department
    if (!input.department && input.departmentName) {
      const name = input.departmentName.trim();
      if (name) {
        let dept = await Department.findOne({ name });
        if (!dept) {
          dept = await Department.create({ name });
        }
        input.department = dept._id;
      }
    }

    // If file uploaded, override profilePicture
    if (req.file) {
      input.profilePicture = buildAvatarUrl(req.file.filename);
    } else {
      // Assign default avatar if none provided
      if (!input.profilePicture) {
        const chosen = randomAvatar(input.gender);
        if (chosen) input.profilePicture = avatarPath(chosen);
      }
    }

    const hashed = await bcrypt.hash(input.password, 10);
    // enforce pending status on self-registration
    input.status = 'Pending'; // require admin activation
    if (!input.userGroup || !['Super Admin', 'Super Management', 'Management', 'Employee'].includes(input.userGroup)) {
      input.userGroup = 'Employee'; // enforce employee role
    }
    const user = await User.create({ ...input, password: hashed });
    const token = sign(user);
    res.status(201).json({ token, user: { ...user.toObject(), password: undefined } });
  } catch (err) {
    if (err.isJoi) {
      return res.status(400).json({ message: 'Validation failed', details: err.details.map(d => d.message) });
    }
    return res.status(500).json({ message: 'Registration failed: ' + err.message });
  }
}

export async function login(req, res) {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ message: 'Email and password required' });
  const user = await User.findOne({ companyOfficialEmail: email });
  if (!user) return res.status(401).json({ message: 'Invalid credentials' });
  const ok = await bcrypt.compare(password, user.password);
  if (!ok) return res.status(401).json({ message: 'Invalid credentials' });
  const token = sign(user);
  res.json({ token, user: { ...user.toObject(), password: undefined } });
}

export async function me(req, res) {
  res.json({ user: req.user });
}
