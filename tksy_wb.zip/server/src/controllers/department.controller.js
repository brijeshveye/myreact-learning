import Department from '../models/department.model.js';

export async function listDepartments(req, res) {
  const depts = await Department.find().populate('head1 head2');
  res.json(depts);
}

export async function listDepartmentNames(req, res) {
  const depts = await Department.find().select(['name', '_id']);
  res.json(depts);
}

export async function createDepartment(req, res) {
  const dept = await Department.create(req.body);
  res.status(201).json(dept);
}

export async function getDepartment(req, res) {
  const dept = await Department.findById(req.params.id).populate('head1 head2');
  if (!dept) return res.status(404).json({ message: 'Department not found' });
  res.json(dept);
}

export async function updateDepartment(req, res) {
  const dept = await Department.findByIdAndUpdate(req.params.id, req.body, { new: true });
  if (!dept) return res.status(404).json({ message: 'Department not found' });
  res.json(dept);
}

export async function deleteDepartment(req, res) {
  const dept = await Department.findByIdAndDelete(req.params.id);
  if (!dept) return res.status(404).json({ message: 'Department not found' });
  res.json({ message: 'Department deleted' });
}
