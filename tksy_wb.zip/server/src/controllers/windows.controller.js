import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import path from 'path';
import fs from 'fs';
import User from '../models/user.model.js';
import Task from '../models/task.model.js';
import { WindowsTracker } from '../models/windowsTracker.model.js';
import { WindowsScreenshot } from '../models/windowsScreenshot.model.js';

// Helpers
function ok(res, data) { return res.status(200).json({ is_success: true, data }); }
function fail(res, status, message, errors) { return res.status(status).json({ is_success: false, message, ...(errors ? { errors } : {}) }); }

function signWindowsToken(user) {
  const payload = { sub: user._id.toString(), typ: 'windows' };
  const secret = process.env.JWT_SECRET || 'dev_secret';
  const expiresIn = '14d';
  return jwt.sign(payload, secret, { expiresIn });
}

// Accepts both padded and unpadded datetime components
function parseDateLoose(input) {
  if (!input) return null;
  // Try native Date parse as ISO or space format
  // Normalize: replace '-' or '/' inconsistencies and ensure padding
  const parts = String(input).trim().split(/[ T]/);
  if (parts.length === 0) return null;
  const d = (parts[0] || '').split('-');
  const t = (parts[1] || '').split(':');
  const year = Number(d[0]);
  const month = Number(d[1] || 1) - 1;
  const day = Number(d[2] || 1);
  const hour = Number(t[0] || 0);
  const minute = Number(t[1] || 0);
  const second = Number(t[2] || 0);
  const dt = new Date(year, month, day, hour, minute, second);
  return isNaN(dt.getTime()) ? null : dt;
}

export async function winLogin(req, res) {
  try {
    const { email, password } = req.body || {};
    const errors = {};
    if (!email) errors.email = ['The email field is required.'];
    if (!password) errors.password = ['The password field is required.'];
    if (Object.keys(errors).length) return fail(res, 422, 'Validation failed.', errors);

    const user = await User.findOne({ companyOfficialEmail: email });
    if (!user) return fail(res, 401, 'Invalid email or password.');
    const okPw = await bcrypt.compare(password, user.password);
    if (!okPw) return fail(res, 401, 'Invalid email or password.');

    const _token = signWindowsToken(user);

    const backendBase = process.env.BACKEND_URL || '';

    const settings = {
      shot_time: Number(process.env.WIN_SHOT_TIME_MIN || 8),
      show_shot: Number(process.env.WIN_SHOW_SHOT_SEC || 2),
      latest_version: process.env.WIN_LATEST_VERSION || '1.0.0',
    }

    const finalUser = {
      ...user.toObject(),
      name: user.fullName || user.firstName || 'User',
      avatar: user.profilePicture && /^(http|https):\/\//.test(user.profilePicture)
        ? user.profilePicture
        : (user.profilePicture && backendBase ? `${backendBase}${user.profilePicture}` : undefined),
    };

    const data = {
      token: _token,
      user_id: user._id.toString(),
      user_name: user.fullName || user.firstName || 'User',
      avatar: user.profilePicture && /^(http|https):\/\//.test(user.profilePicture)
        ? user.profilePicture
        : (user.profilePicture && backendBase ? `${backendBase}${user.profilePicture}` : undefined),
      user: finalUser,
      settings: settings
    };
    return ok(res, data);
  } catch (err) {
    return fail(res, 500, err.message || 'Login failed');
  }
}

export async function winLogout(req, res) {
  // Using stateless JWTs; client can simply discard token. Implement blacklist if needed.
  return res.status(200).json({ is_success: true });
}

// Public: App version info for Windows client
export async function winAppVersion(req, res) {
  try {
    const current = String(req.query.current || '').trim();
    const version = process.env.WIN_APP_VERSION || process.env.APP_VERSION || '1.0.0';
    const minVersion = process.env.WIN_MIN_APP_VERSION || process.env.MIN_APP_VERSION || '1.0.0';
    const forceUpdate = String(process.env.WIN_FORCE_UPDATE || 'false').toLowerCase() === 'true';
    const updateUrl = process.env.WIN_APP_UPDATE_URL || process.env.APP_UPDATE_URL || '';
    const notes = process.env.WIN_APP_CHANGELOG || process.env.APP_CHANGELOG || '';

    // Simple semver compare
    const parse = (v) => String(v || '0.0.0').split('.').map(n => parseInt(n, 10) || 0);
    const cmp = (a, b) => {
      const aa = parse(a), bb = parse(b);
      for (let i = 0; i < Math.max(aa.length, bb.length); i++) {
        const x = aa[i] || 0, y = bb[i] || 0;
        if (x > y) return 1; if (x < y) return -1;
      }
      return 0;
    };

    const needsUpdate = current ? (cmp(current, minVersion) < 0) : false;
    return ok(res, { version, min_version: minVersion, force_update: forceUpdate, update_url: updateUrl, notes, needs_update: needsUpdate });
  } catch (err) {
    return fail(res, 500, err.message || 'Failed to fetch app version');
  }
}

export async function getWorkspaces(req, res) {
  // There is no workspace model; emulate with a single workspace per company or default
  // For MVP, return a single workspace for the current user organization.

  const projects = [
    { id: 'proj-1', name: 'Project Alpha', tasks: [] },
    { id: 'proj-2', name: 'Project Beta', tasks: [] },
  ];

  const list = [
    { id: String(req.user._id).slice(-6), name: 'Default', slug: 'default' },
  ];

  const workspaces = {
    "default": "Default"
  }

  const resp = {
    workspaces: workspaces,
  }


  return ok(res, resp);
}

export async function getProjects(req, res) {
  const wsId = req.query.work_space;
  if (!wsId) return fail(res, 422, 'Validation failed.', { work_space: ['The work_space field is required.'] });

  const days = parseInt(req.query.days) || 5;

  const startDate = new Date();
  startDate.setHours(0, 0, 0, 0);
  startDate.setDate(startDate.getDate() - (days - 1));

  const query = {
    assignedTo: req.user._id,
    deletedAt: { $exists: false },
  };

  // Map tasks assigned to the user into pseudo-project buckets based on status
  const tasks = await Task.find(query)
    .select('title status createdAt')
    .lean();

  const projects = [];

  for (let i = 0; i < days; i++) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    const dateStr = date.toISOString().slice(0, 10);

    const tasksForDate = tasks.filter(task =>
      // console.log('Comparing', new Date(task.createdAt).toISOString().slice(0, 10), 'with', dateStr) ||
      new Date(task.createdAt).toISOString().slice(0, 10) == dateStr && task.status !== 'Completed'
    );

    projects.push({
      id: `proj-${dateStr}`,
      name: `Tasks on ${dateStr}`,
      tasks: tasksForDate
    });
  }


  const finalData = {
    projects: projects,
  }

  return ok(res, finalData);
}

export async function addTracker(req, res) {
  try {
    const body = req.body || {};
    const action = String(body.action || '').toLowerCase();
    const timeStr = body.time;
    const taskId = body.task_id;
    const workInOn = body.workin_on || '';
    const trackerId = body.traker_id ?? body.tracker_id ?? null; // accept both
    const wsId = body.workspaces_id;
    const isBillable = body.is_billable === true || body.is_billable === 1 || body.is_billable === '1';

    const errors = {};
    if (!['start', 'end'].includes(action)) errors.action = ['Action must be start or end'];
    if (!taskId) errors.task_id = ['Task is required'];
    if (!timeStr) errors.time = ['Time is required'];
    if (Object.keys(errors).length) return fail(res, 422, 'Validation failed.', errors);

    const at = parseDateLoose(timeStr);
    if (!at) return fail(res, 422, 'Validation failed.', { time: ['Invalid time format'] });

    // Ensure task exists and belongs to user
    const task = await Task.findOne({ _id: taskId, assignedTo: req.user._id });
    if (!task) return fail(res, 422, 'Validation failed.', { task_id: ['Task not found'] });

    if (action === 'start') {
      // End any open sessions for this user+task to keep consistency
      await WindowsTracker.updateMany({ user: req.user._id, task: task._id, endedAt: null }, { $set: { endedAt: at } });

      const doc = await WindowsTracker.create({
        user: req.user._id,
        task: task._id,
        workspaceId: wsId ?? null,
        isBillable,
        workNote: workInOn,
        startedAt: at,
        endedAt: null,
      });
      return ok(res, { id: doc._id.toString(), action: 'start', started_at: timeStr });
    } else {
      if (!trackerId) return fail(res, 422, 'Validation failed.', { traker_id: ['Unknown tracker session'] });
      const doc = await WindowsTracker.findOne({ _id: trackerId, user: req.user._id });
      if (!doc) return fail(res, 422, 'Validation failed.', { traker_id: ['Unknown tracker session'] });
      if (doc.endedAt) {
        // idempotent: return its final state
        const duration = Math.max(0, Math.floor((doc.endedAt.getTime() - doc.startedAt.getTime()) / 1000));
        return ok(res, {
          id: doc._id.toString(),
          action: 'end',
          started_at: formatDateTime(doc.startedAt),
          ended_at: formatDateTime(doc.endedAt),
          duration_seconds: duration,
          billable: !!doc.isBillable,
        });
      }
      await WindowsTracker.updateOne({ _id: doc._id }, { $set: { endedAt: at, isBillable, workNote: workInOn } });
      const ended = await WindowsTracker.findById(doc._id);
      const duration = Math.max(0, Math.floor((ended.endedAt.getTime() - ended.startedAt.getTime()) / 1000));
      return ok(res, {
        id: ended._id.toString(),
        action: 'end',
        started_at: formatDateTime(ended.startedAt),
        ended_at: timeStr,
        duration_seconds: duration,
        billable: !!ended.isBillable,
      });
    }
  } catch (err) {
    return fail(res, 500, err.message || 'Failed to update tracker');
  }
}

function ensureDirSync(dirPath) {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
}

function formatDateTime(dt) {
  const pad = (n) => String(n).padStart(2, '0');
  const y = dt.getFullYear();
  const m = pad(dt.getMonth() + 1);
  const d = pad(dt.getDate());
  const h = pad(dt.getHours());
  const mi = pad(dt.getMinutes());
  const s = pad(dt.getSeconds());
  return `${y}-${m}-${d} ${h}:${mi}:${s}`;
}

export async function uploadPhotos(req, res) {
  try {
    // Accept urlencoded or multipart fields
    const { img, imgName, time, tracker_id } = req.body || {};
    if (!img || !imgName || !tracker_id) {
      const errors = {};
      if (!img) errors.img = ['img is required'];
      if (!imgName) errors.imgName = ['imgName is required'];
      if (!tracker_id) errors.tracker_id = ['tracker_id is required'];
      return fail(res, 422, 'Validation failed.', errors);
    }

    // Validate tracker ownership
    const tr = await WindowsTracker.findOne({ _id: tracker_id, user: req.user._id });
    if (!tr) return fail(res, 422, 'Validation failed.', { tracker_id: ['Unknown tracker session'] });

    // Decode base64 (may have data URL prefix)
    const base64 = String(img).replace(/^data:image\/[a-zA-Z0-9+]+;base64,/, '');
    let buffer;
    try {
      buffer = Buffer.from(base64, 'base64');
    } catch (e) {
      return fail(res, 400, 'Malformed base64 image');
    }

    // Enforce size limit (2 MB default)
    const maxBytes = Number(process.env.WIN_SHOT_MAX_BYTES || 2 * 1024 * 1024);
    if (buffer.length > maxBytes) return fail(res, 413, `Image too large (max ${maxBytes} bytes)`);

    const shotsDir = path.join(process.cwd(), 'uploads', 'shots');
    ensureDirSync(shotsDir);

    // Sanitize filename
    const safeName = imgName.replace(/[^a-zA-Z0-9._-]/g, '_');
    const filePath = path.join(shotsDir, safeName);
    fs.writeFileSync(filePath, buffer);

    const shot = await WindowsScreenshot.create({
      tracker: tr._id,
      user: req.user._id,
      fileName: safeName,
      capturedAt: parseDateLoose(time) || new Date(),
      size: buffer.length,
      mime: 'image/jpeg',
    });

    const publicUrl = `${process.env.BACKEND_URL}/uploads/shots/${encodeURIComponent(safeName)}`;
    return ok(res, { id: shot._id.toString(), url: publicUrl });
  } catch (err) {
    return fail(res, 500, err.message || 'Upload failed');
  }
}

function formatHMS(totalSeconds) {
  const pad = (n) => String(n).padStart(2, '0');
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = totalSeconds % 60;
  return `${pad(h)}:${pad(m)}:${pad(s)}`;
}

export async function getDailyReports(req, res) {
  try {
    const { date, workspace_id } = req.query || {};
    const errors = {};
    if (!date) errors.date = ['The date field is required.'];
    if (!workspace_id) errors.workspace_id = ['The workspace_id field is required.'];
    if (Object.keys(errors).length) return fail(res, 422, 'Validation failed.', errors);

    // Parse day range
    const day = new Date(`${date}T00:00:00`);
    if (isNaN(day.getTime())) return fail(res, 422, 'Validation failed.', { date: ['Invalid date format, expected YYYY-MM-DD'] });
    const start = new Date(day);
    const end = new Date(day); end.setHours(23, 59, 59, 999);

    // Fetch sessions for user and workspace on that day
    const sessions = await WindowsTracker.find({
      user: req.user._id,
      workspaceId: String(workspace_id),
      startedAt: { $gte: start, $lte: end }
    }).sort({ startedAt: -1 }).lean();

    if (!sessions.length) {
      return ok(res, {
        total_seconds: 0,
        total_formatted: '00:00:00',
        date,
        entries: []
      });
    }

    // Load task titles
    const taskIds = Array.from(new Set(sessions.map(s => String(s.task))));
    const tasks = await Task.find({ _id: { $in: taskIds } }).select('title').lean();
    const taskTitles = new Map(tasks.map(t => [String(t._id), t.title]));

    const now = new Date();
    const entries = sessions.map(s => {
      const startedAt = new Date(s.startedAt);
      const endedAt = s.endedAt ? new Date(s.endedAt) : null;
      const dur = Math.max(0, Math.floor(((endedAt || now).getTime() - startedAt.getTime()) / 1000));
      return {
        id: String(s._id),
        task_name: taskTitles.get(String(s.task)) || 'Task',
        project_name: 'General',
        description: s.workNote || '',
        start_time: formatDateTime(startedAt),
        end_time: endedAt ? formatDateTime(endedAt) : null,
        duration_seconds: dur,
        is_billable: !!s.isBillable,
        workspace_name: 'Default'
      };
    });

    // Sort by start_time desc
    entries.sort((a, b) => (a.start_time < b.start_time ? 1 : a.start_time > b.start_time ? -1 : 0));

    // Exclude in-progress timers from total time calculation
    const totalSeconds = entries
      .filter(e => e.end_time !== null)
      .reduce((acc, e) => acc + (e.duration_seconds || 0), 0);
    return ok(res, {
      total_seconds: totalSeconds,
      total_formatted: formatHMS(totalSeconds),
      date,
      entries
    });
  } catch (err) {
    return fail(res, 500, err.message || 'Failed to load daily reports');
  }
}
