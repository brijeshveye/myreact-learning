import bcrypt from 'bcryptjs';
import User from '../models/user.model.js';
import { buildAvatarUrl } from '../middlewares/upload.js';

export async function listUsers(req, res) {
  const { q, userType, status, department, userGroup, page = 1, limit = 20 } = req.query;
  const filter = {};
  if (q) filter.$text = { $search: q };
  const statusFilter = status || userType; // allow either param name
  if (statusFilter) filter.status = statusFilter;
  if (department) filter.department = department;
  if (userGroup) filter.userGroup = userGroup;
  const users = await User.find(filter)
    .skip((page - 1) * limit)
    .limit(Number(limit))
    .select('-password')
    .populate('department');
  const total = await User.countDocuments(filter);
  res.json({ data: users, total, filterApplied: filter });
}

export async function getUser(req, res) {
  const user = await User.findById(req.params.id).select('-password').populate('department');
  if (!user) return res.status(404).json({ message: 'User not found' });
  res.json(user);
}

export async function createUser(req, res) {
  const body = { ...req.body };
  if (body.password) body.password = await bcrypt.hash(body.password, 10);
  const user = await User.create(body);
  res.status(201).json({ ...user.toObject(), password: undefined });
}

export async function updateUser(req, res) {
  const body = { ...req.body };
  if (body.password) body.password = await bcrypt.hash(body.password, 10);
  // Normalize userType -> status
  if (body.userType && !body.status) {
    body.status = body.userType;
    delete body.userType;
  }
  const user = await User.findByIdAndUpdate(req.params.id, body, { new: true }).select('-password');
  if (!user) return res.status(404).json({ message: 'User not found' });
  res.json(user);
}

export async function deleteUser(req, res) {
  const user = await User.findByIdAndDelete(req.params.id).select('-password');
  if (!user) return res.status(404).json({ message: 'User not found' });
  res.json({ message: 'User deleted' });
}

export async function setUserStatus(req, res) {
  const { status } = req.body;
  if (!['Active', 'Rejected', 'Banned', 'Suspended', 'Pending'].includes(status)) return res.status(400).json({ message: 'Invalid status' });
  const user = await User.findByIdAndUpdate(req.params.id, { status }, { new: true }).select('-password');
  if (!user) return res.status(404).json({ message: 'User not found' });
  res.json(user);
}

export async function updateAvatar(req, res) {
  try {
    if (!req.file) return res.status(400).json({ message: 'No file uploaded' });
    const profilePicture = buildAvatarUrl(req.file.filename);
    const user = await User.findByIdAndUpdate(req.params.id, { profilePicture }, { new: true }).select('-password');
    if (!user) return res.status(404).json({ message: 'User not found' });
    return res.json({ message: 'Avatar updated', user });
  } catch (e) {
    return res.status(500).json({ message: 'Failed to update avatar' });
  }
}
