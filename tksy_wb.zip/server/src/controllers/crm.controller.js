import { listLeadsByUserEmail, listActivitiesByUserEmail, CrmError } from '../services/crm.service.js';

function parseDateOnly(s) {
  if (!s) return null;
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return null;
  return d;
}

function startOfDay(d) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

function nextDay(d) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  x.setDate(x.getDate() + 1);
  return x;
}

function getRange(dateStart, dateEnd) {
  let start = parseDateOnly(dateStart);
  let end = parseDateOnly(dateEnd);
  if (start && !end) { end = start; }
  if (end && !start) { start = end; }
  if (!start && !end) return {};
  const gte = startOfDay(start);
  const lt = nextDay(end);
  return { gte, lt };
}

// GET /api/crm/analytics/metrics
export async function getCrmMetrics(req, res) {
  try {
    const { dateStart, dateEnd } = req.query;
    // const email = req.user?.companyOfficialEmail || req.user?.email;
    const email = 'sanjana@brsoftsol.com';
    if (!email) return res.status(400).json({ message: 'User email not found' });
    const [leads, acts] = await Promise.all([
      listLeadsByUserEmail(email),
      listActivitiesByUserEmail(email)
    ]);

    console.info('Leads fetched:', leads.length, 'Activities fetched:', acts.length);

    const totalAssigned = leads.length;
    let totalUpdated = 0;
    if (!dateStart && !dateEnd) totalUpdated = leads.length; else {
      const s = dateStart ? new Date(dateStart + 'T00:00:00') : null;
      const e = dateEnd ? new Date(dateEnd + 'T00:00:00') : null;
      totalUpdated = leads.filter(l => {
        const u = parseDateOnly(l?.updated_at);
        if (!u) return false; const su = startOfDay(u); return (!s || su >= startOfDay(s)) && (!e || su < nextDay(e));
      }).length;
    }
    const totalActivities = acts.length;
    const totalCallActivities = acts.filter(a => String(a?.type).toLowerCase() === 'call').length;
    res.json({ totalAssigned, totalUpdated, totalActivities, totalCallActivities });
  } catch (err) {
    if (err instanceof CrmError) {
      return res.status(err.status || 502).json({ message: err.message });
    }
    return res.status(500).json({ message: 'Failed to fetch CRM metrics' });
  }
}

// GET /api/crm/analytics/last7days
export async function getCrmLast7Days(req, res) {
  try {
    // const email = req.user?.companyOfficialEmail || req.user?.email;
    const email = 'atul@brsoftsol.com';
    if (!email) return res.status(400).json({ message: 'User email not found' });

    // Determine the 7-day window ending at endRef (inclusive of endRef day)
    const endRef = parseDateOnly(req.query.dateEnd) || new Date();
    const endDay = startOfDay(endRef);
    const startDay = new Date(endDay);
    startDay.setDate(endDay.getDate() - 6);

    const [leadsAll, actsAll] = await Promise.all([
      listLeadsByUserEmail(email),
      listActivitiesByUserEmail(email)
    ]);

    // Build day buckets
    const days = [];
    for (let i = 6; i >= 0; i--) {
      const day = new Date(endDay);
      day.setDate(endDay.getDate() - i);
      const gte = startOfDay(day);
      const lt = nextDay(day);
      days.push({ gte, lt, key: day.toISOString().slice(0, 10) });
    }

    const out = days.map(d => {
      const assigned = leadsAll.filter(l => {
        const c = parseDateOnly(l?.created_at);
        const u = parseDateOnly(l?.updated_at);
        return (c && c >= d.gte && c < d.lt) || (u && u >= d.gte && u < d.lt);
      }).length;

      const updated = leadsAll.filter(l => {
        const u = parseDateOnly(l?.updated_at);
        return u && u >= d.gte && u < d.lt;
      }).length;

      const actsInDay = actsAll.filter(a => {
        const c = parseDateOnly(a?.created_at) || parseDateOnly(a?.schedule_from) || parseDateOnly(a?.updated_at);
        return c && c >= d.gte && c < d.lt;
      });
      const activities = actsInDay.length;
      const callActivities = actsInDay.filter(a => String(a?.type).toLowerCase() === 'call').length;

      return { date: d.gte, assigned, updated, activities, callActivities };
    });

    res.json(out);
  } catch (err) {
    if (err instanceof CrmError) {
      return res.status(err.status || 502).json({ message: err.message });
    }
    return res.status(500).json({ message: 'Failed to fetch CRM last 7 days analytics' });
  }
}

export default { getCrmMetrics, getCrmLast7Days };
