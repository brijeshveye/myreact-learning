# MyLandingPage package

A public-facing landing site for ShopyJi with SEO-friendly pages, themes gallery, pricing, and legal pages, built as a Laravel package with blade views, shared layout, and static assets.

## Overview

MyLandingPage provides:
- Root landing pages: Home, Pricing, Themes, About, Contact
- Legal pages: Privacy Policy, Terms & Conditions, Refund Policy
- Reusable layout (`layouts/app.blade.php`) with SEO meta, JSON‑LD schema, Google Tag Manager and Microsoft Clarity hooks, and Bootstrap 5 + AOS
- Modular includes for header, navbar, footer, and meta tags
- Self-contained assets under `src/resources/assets` (CSS, images, icons, JS)

Routes are mounted under the default web middleware and are named with the `mylandingpage.` prefix.

## Features

- Rich landing layout with:
  - Canonical/meta tags via an `includes/meta_tags` partial
  - JSON‑LD schema (Corporation and LocalBusiness) in the layout
  - Google Tag Manager and Microsoft Clarity scripts
  - Bootstrap 5, Font Awesome, AOS animation library
- Themed sections and components for home (pricing, newsletter, FAQ, testimonials, etc.)
- Clean URL endpoints for static pages and themes listing
- Simple controller mapping each route to a Blade view
- Event service provider scaffolded (menus and settings listeners exist if you choose to use them)

## Requirements

- PHP 8.2+
- Laravel 11.x
- Web server must be able to serve package assets (see Assets note below)
- Optional: Any referenced classes under `Shopyji\LandingPage\Entities` from your core/landing module if you want dynamic menus/settings in the layout; otherwise override the layout to remove or replace them.

## Installation

This repository already includes the package as a local dependency and registers its service provider via auto‑discovery.

1) Auto-discovery
- Provider: `Shopyji\\MyLandingPage\\app\\Providers\\MyLandingPageServiceProvider`

2) Migrations and seeders
- There are no migrations required for this package.
- Optional: Seeders exist for permissions/marketplace listing if you use your app marketplace: `database/seeders/*`.

3) Clear caches (recommended)

```bash
php artisan optimize:clear
```

## Additional Setups for Auth Pages

# File: App\Http\Controllers\Auth\RegisteredUserController @ create
if (view()->exists('my-landing-page::auth.register')) {
    return view('my-landing-page::auth.register');
}

# File: App\Http\Controllers\Auth\AuthenticatedSessionController @ create
// Prefer MyLandingPage themed auth view if available
if (view()->exists('my-landing-page::auth.login')) {
    return view('my-landing-page::auth.login');
}


## Routes and controllers

Defined in `src/routes/web.php` and bound with the `web` middleware. All routes are named with the `mylandingpage.` prefix.

- `GET /` → `MyLandingPageController@index` → `my-landing-page::pages.home` (name: `mylandingpage.home`)
- `GET /pricing` → `pricing()` → `my-landing-page::pages.pricing` (name: `mylandingpage.pricing`)
- `GET /shopyji-themes` → `themes()` → `my-landing-page::pages.themes` (name: `mylandingpage.themes`)
- `GET /privacy-policy` → `privacy()` → `my-landing-page::pages.terms.privacy` (name: `mylandingpage.privacy`)
- `GET /terms-and-conditions` → `terms()` → `my-landing-page::pages.terms.terms` (name: `mylandingpage.terms`)
- `GET /refund-policy` → `refund()` → `my-landing-page::pages.terms.refund` (name: `mylandingpage.refund`)
- `GET /about-us` → `about()` → `my-landing-page::pages.about` (name: `mylandingpage.about`)
- `GET /contact-us` → `contact()` → `my-landing-page::pages.contact` (name: `mylandingpage.contact`)

Controller: `app/Http/Controllers/MyLandingPageController.php`

Views namespace: `my-landing-page` (e.g., `view('my-landing-page::pages.home')`).

## Layout and includes

- Layout: `resources/views/layouts/app.blade.php`
  - Includes meta tags: `includes/meta_tags.blade.php`
  - Header/nav/footer partials in `resources/views/includes`.
  - Loads CSS from `packages/shopyji/MyLandingPage/src/resources/assets/css/*.css`
  - Loads Bootstrap, Font Awesome, AOS from CDNs
  - Adds Google Tag Manager (GTM-K6233352) and Microsoft Clarity (`tborl5d62i`) scripts
  - Embeds JSON‑LD schema scripts for Corporation and LocalBusiness

To customize meta per page, use Blade sections in your page templates:

```blade
@section('title', 'ShopyJi — Create Your Store')
@section('canonical', url()->current())
@section('description', 'ShopyJi helps you create your online store instantly…')
@section('keywords', 'e‑commerce, storefront, mobile app, …')
```

## Assets note

By default, the layout references assets via URLs like:
- `/packages/shopyji/MyLandingPage/src/resources/assets/css/style.css`

Ensure your web server can serve these paths. If your document root is `public/`, you have two options:
- Create a web server alias or symlink from `public/packages` to the repository `packages` directory, or
- Publish/copy the assets into `public/vendor/my-landing-page` and update the layout to point there, or override the layout in `resources/views/vendor/my-landing-page/layouts/app.blade.php`.

## Customization

- Override any view by placing a copy under `resources/views/vendor/my-landing-page/...` in your main app.
- Update GTM/Clarity IDs by overriding the layout or editing `layouts/app.blade.php`.
- Add/edit sections under `resources/views/components` to customize homepage blocks.
- If you don’t use `Shopyji\\LandingPage\\Entities` for settings/menus in the layout, remove or replace those calls in your overridden layout.

## Configuration

- SEO: define per-page `@section` for `title`, `canonical`, `description`, `keywords`.
- Tracking: replace `GTM-K6233352` and `tborl5d62i` with your own IDs in your overridden layout.
- Theme color and right-to-left flags come from super admin settings (via helper `getSuperAdminAllSetting()`), which you can swap or hardcode in your override.

## Troubleshooting

- Assets return 404
  - Ensure `/packages/...` is web‑accessible (symlink/alias) or publish assets to `public/` and adjust paths.

- Landing settings classes not found
  - The layout references `Shopyji\\LandingPage\\Entities\\LandingPageSetting` and `OwnerMenuSetting`. Either install that package or override the layout to remove those references.

- Route conflicts at `/`
  - These routes register on `/`. If your main app already owns `/`, mount MyLandingPage under a prefix or comment out the root route.

## Internals at a glance

- Service provider: `app/Providers/MyLandingPageServiceProvider.php`
- Routes: `routes/web.php`, `routes/api.php`
- Controller: `app/Http/Controllers/MyLandingPageController.php`
- Views: `resources/views/pages/*`, `resources/views/layouts/app.blade.php`, `resources/views/includes/*`, `resources/views/components/*`
- Assets: `resources/assets/{css,js,img}/`
- Seeders: `database/seeders/*` (optional marketplace/permissions)
- Event wiring: `app/Providers/EventServiceProvider.php` with listeners in `app/Listeners/*`

## License

MIT

## Support

For issues or questions, contact ShopyJi support or the authors listed in `composer.json`.
