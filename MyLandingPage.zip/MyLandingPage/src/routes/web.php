<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use Illuminate\Support\Facades\Route;
use Shopyji\MyLandingPage\app\Http\Controllers\MyLandingPageController;

// Route::middleware(['auth', 'web', 'PlanModuleCheck:MyLandingPage'])->group(function () {
//     Route::prefix('mylandingpage')->group(function () {
//         //
//     });
// });

Route::middleware(['web'])->name('mylandingpage.')->group(function () {
    Route::get('/', [MyLandingPageController::class, 'index'])->name('home');
    Route::get('/pricing', [MyLandingPageController::class, 'pricing'])->name('pricing');
    Route::get('/shopyji-themes', [MyLandingPageController::class, 'themes'])->name('themes');
    Route::get('/privacy-policy', [MyLandingPageController::class, 'privacy'])->name('privacy');
    Route::get('/terms-and-conditions', [MyLandingPageController::class, 'terms'])->name('terms');
    Route::get('/refund-policy', [MyLandingPageController::class, 'refund'])->name('refund');
    Route::get('/about-us', [MyLandingPageController::class, 'about'])->name('about');
    Route::get('/contact-us', [MyLandingPageController::class, 'contact'])->name('contact');
});

