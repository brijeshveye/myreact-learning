<!-- ------- Meta Tags ------------- -->
<!-- Open Graph / Facebook -->
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="website" />
<meta property="og:type" content="website">
<meta property="og:url" content="https://www.shopyji.com">
<meta property="og:site_name" content="Shopy Ji" />
<meta property="og:title" content="Shopyji | Create Your Own Online Store in 2 Minutes">
<meta property="og:description" content="Shopyji helps you create your online store instantly with no coding required. Start your e-commerce business today at an affordable subscription cost.">
<meta property="og:image" content="https://shopyji.com/storage/uploads/shopyji-preview.png">

<!-- Twitter -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Shopyji | Create Your Own Online Store in 2 Minutes">
<meta name="twitter:description" content="Shopyji helps you create your online store instantly with no coding required. Start your e-commerce business today at an affordable subscription cost.">
<meta name="twitter:image" content="https://shopyji.com/storage/uploads/shopyji-preview.png">
