<!-- Top Nav -->
<nav class="py-3 position-relative" id="top-nav" >

    <button class="close-top-nav position-absolute top-50 translate-middle-y end-0 me-3 p-0 border-0 bg-transparent"
        id="close-top-nav" aria-label="Close" data-aos="zoom-in" data-aos-delay="200">
        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/cross.svg') }}" alt=" website">
    </button>

    <div class="container">
        <div class="content d-flex flex-wrap justify-content-center align-items-center gap-3 text-center text-md-start">
            <span class="tag px-3 py-1 fw-normal" data-aos="fade-right" data-aos-delay="300">Limited Time Offer</span>
            <p class="mb-0" data-aos="fade-up" data-aos-delay="400">
                Launch your online store in just 2 minutes — starting at ₹15,999/Year!
            </p>
            <a href="{{ route('register') }}" class="d-flex align-items-center text-decoration-none border-bottom ps-2" data-aos="fade-left" data-aos-delay="500">
                Get Started
                <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/right-arrow.svg') }}" alt=" Login" class="ms-2" style="width: 16px;">
            </a>
        </div>
    </div>
</nav>
