<!-- Footer Section Start -->
<section class="footer-section overflow-hidden">
    <div class="container">
        <div class="d-flex flex-wrap justify-content-between all-footer-links mb-5" data-aos="fade-up"
            data-aos-duration="1000">

            <!-- About Part -->
            <div class="footer-about flex-grow-1" data-aos="fade-up" data-aos-delay="200">
                <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/logo/shopyji-white-logo.svg') }}" alt="ShopyJi dark logo" class="mb-1">
                <p>Launch your ecommerce store in just 2 minutes — no code, no hassle. Powering next-gen online
                    businesses with speed, simplicity, and style.</p>
                <a href="#" class="custom-btn-new btn-2 d-inline-flex align-items-center mt1">
                    GET IN TOUCH <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/contact-email.svg') }}" alt="ShopyJi Contact" class="ms-2">
                </a>
            </div>

            <!-- Links Part -->
            <div class="d-flex flex-wrap flex-grow-1 justify-content-between" data-aos="fade-up" data-aos-delay="400">

                <!-- Quick Links -->
                <div class="footer-links">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="{{route('mylandingpage.about')}}">About Us</a></li>
                        <li><a href="#">Branding</a></li>
                        <li><a href="#">Affiliate Program</a></li>
                        <li><a href="#">Pricing</a></li>
                        <li><a href="#">Mobile App</a></li>
                        <li><a href="{{route('mylandingpage.contact')}}">Contact Us</a></li>
                    </ul>
                </div>

                <!-- Products -->
                <div class="footer-links">
                    <h5>Products</h5>
                    <ul class="list-unstyled">
                        <li><a href="{{route('mylandingpage.themes')}}">Available Themes</a></li>
                        <li><a href="#">Delivery</a></li>
                        <li><a href="#">Enterprises</a></li>
                        <li><a href="#">Plugins</a></li>
                    </ul>
                </div>

                <!-- resources -->
                <div class="footer-links">
                    <h5>resources</h5>
                    <ul class="list-unstyled">
                        <li><a href="#">Tools</a></li>
                        <li><a href="#">Help Center</a></li>
                        <li><a href="#">FAQs</a></li>
                        <li><a href="#">Blog</a></li>
                        <li><a href="#">Affiliate Program</a></li>
                    </ul>
                </div>
            </div>

            <!-- Contact Us -->
            <div class="footer-links contact-info" data-aos="fade-up" data-aos-delay="600">
                <h5>Contact Us</h5>
                <ul class="list-unstyled">
                    <li class="d-flex align-items-start mb-2">
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/location.svg') }}" alt="ShopyJi Address" class="me-2" style="width:20px;">
                        <span>Miet Incbation Center, NH-58, Baghpat Rd, Meerut, Uttar Pradesh, India - 250001</span>
                    </li>
                    <li class="d-flex align-items-start mb-2">
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/location.svg') }}" alt="ShopyJi Location" class="me-2" style="width:20px;">
                        <span>H-Block, Noida Sector 63, Uttar Pradesh, India - 201309</span>
                    </li>
                    <li class="d-flex align-items-center mb-2">
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/email.svg') }}" alt="ShopyJi Email" class="me-2" style="width:20px;">
                        <a href="mailto:support@shopyji.com">support@shopyji.com</a>
                    </li>
                    <li class="d-flex align-items-center">
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/call.svg') }}" alt="ShopyJi Contact Number" class="me-2" style="width:20px;">
                        <a href="tel:+918650876100">+91 8650876100</a>
                    </li>
                </ul>
            </div>
        </div>
        <hr>

        <!-- Join Community Part -->
        <div class="join-community-part d-flex align-items-center flex-column flex-lg-row">
            <h4>Join the community</h4>
            <div class="social-container">
                <!-- Social Items with Link -->
                <div class="social-list d-flex gap-2">
                    <a href="https://www.instagram.com/shopyji/" target="_blank" class="social-item d-flex align-items-center">
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/instagram.svg') }}" alt="ShopyJi Instagram">
                        <span class="social-text">Follow us on Instagram</span>
                    </a>
                    <a href="https://www.youtube.com/@mshopyji" target="_blank" class="social-item d-flex align-items-center">
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/youtube.svg') }}" alt="ShopyJi YouTube">
                        <span class="social-text">Subscribe us on YouTube</span>
                    </a>
                    <a href="https://www.linkedin.com/company/shopyji/" target="_blank" class="social-item d-flex align-items-center">
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/linkedin.svg') }}" alt="ShopyJi LinkedIn">
                        <span class="social-text">Connect with us on LinkedIn</span>
                    </a>
                    <a href="https://www.facebook.com/myshopyji/" target="_blank" class="social-item d-flex align-items-center">
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/facebook.svg') }}" alt="ShopyJi Facebook">
                        <span class="social-text">Like us on Facebook</span>
                    </a>
                    <a href="https://x.com/shopyji" target="_blank" class="social-item d-flex align-items-center">
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/twitter.svg') }}" alt="ShopyJi Twitter">
                        <span class="social-text">Follow us on Twitter</span>
                    </a>
                </div>
            </div>
            <!-- Follow us and Stay connected text -->
            <div class="follow-text">
                <p>Follow us and Stay connected.</p>
            </div>
        </div>
        <hr>

        <!-- Copyright Bar -->
        <div class="copyright-bar d-flex">
            <ul
                class="d-flex list-unstyled gap-3 flex-grow-1 flex-wrap justify-content-center justify-content-lg-start">
                <li><a href="{{route('mylandingpage.privacy')}}">Privacy Policy</a></li>
                <li><a href="{{route('mylandingpage.refund')}}">Refund Policy</a></li>
                <li><a href="{{route('mylandingpage.terms')}}">Terms and Conditions</a></li>
            </ul>
            <p class="copyright-text">© 2025 Shopy Ji. All rights reserved.</p>
        </div>
    </div>
</section>
<!-- Footer Section End -->
