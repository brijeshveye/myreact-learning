<!-- Main Nav -->
<header class="py-3" id="main-nav">
    <div class="container content d-flex flex-wrap justify-content-between align-items-center gap-3">
        <!-- Logo -->
        <a href="{{ url('/') }}">
            <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/logo/shopyji-white-logo.svg') }}" alt="Shmain Logo" title="Shmain" />
        </a>

        <!-- Menu -->
        <nav class="menu">
            <ul class="d-flex flex-wrap align-items-center gap-4 m-0 px-5">
                <li><a href="{{route('mylandingpage.home')}}" class="active">Home</a></li>

                <li class="dropdown">
                    <a href="#" class="dropdown-toggle">Products</a>
                    <ul class="dropdown-menu">
                        <li><a href="{{route('mylandingpage.themes')}}">Shp Themes</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle">Company</a>
                    <ul class="dropdown-menu">
                        <li><a href="{{route('mylandingpage.about')}}">About Us</a></li>
                        <li><a href="#">Careers</a></li>
                        <li><a href="#">Partners</a></li>
                    </ul>
                </li>

                <li><a href="{{route('mylandingpage.pricing')}}">Pricing</a></li>

                <li class="dropdown">
                    <a href="#" class="dropdown-toggle">Resources</a>
                    <ul class="dropdown-menu">
                        <li><a href="#">Blog</a></li>
                        <li><a href="{{ route('mylandingpage.contact') }}">Help Center</a></li>
                        <li><a href="#">Guides</a></li>
                    </ul>
                </li>
            </ul>
        </nav>

        <!-- Buttons -->
        <div class="nav-buttons d-flex flex-wrap align-items-center gap-3">
            <a href="{{ route('login') }}" class="custom-btn-new btn-2">
                Login <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/contact-email.svg') }}" alt=" Login">
            </a>
            <a href="{{ route('mylandingpage.contact') }}" class="custom-btn-new btn-1">Contact Us</a>
        </div>
        <!-- This inside your header nav -->
        <button class="menu-toggle" onclick="togglePanel()">☰</button>

    </div>
</header>

<!-- Overlay and Sidebar -->
<div id="overlay" class="overlay" onclick="togglePanel()"></div>

<aside class="side-panel" id="sidePanel">
    <!-- Header -->
    <div class="head-part d-flex justify-content-between pb-3">
        <a href="{{ url('/') }}">
            <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/logo/shopyji-white-logo.svg') }}" alt="Shmain" title="Shmain" />
        </a>
        <button class="close-btn" onclick="togglePanel()">
            <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/cross.svg') }}" alt="Close">
        </button>
    </div>

    <ul class="sidebar-menu flex-column gap-3 mt-4">
        <li><a href="{{ url('/') }}" class="active">Home</a></li>

        <li class="dropdown">
            <a href="#" class="dropdown-toggle" onclick="toggleDropdown(event)">Products</a>
            <ul class="dropdown-menu">
                <li><a href="{{ route('mylandingpage.themes') }}">Shmain Themes</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" class="dropdown-toggle" onclick="toggleDropdown(event)">Company</a>
            <ul class="dropdown-menu">
                <li><a href="{{ route('mylandingpage.about') }}">About Us</a></li>
                <li><a href="#">Careers</a></li>
                <li><a href="#">Partners</a></li>
            </ul>
        </li>

        <li><a href="{{ route('mylandingpage.pricing') }}">Pricing</a></li>

        <li class="dropdown">
            <a href="#" class="dropdown-toggle" onclick="toggleDropdown(event)">resources</a>
            <ul class="dropdown-menu">
                <li><a href="#">Blog</a></li>
                <li><a href="{{ route('mylandingpage.contact') }}">Help Center</a></li>
                <li><a href="#">Guides</a></li>
            </ul>
        </li>
    </ul>

    <div class="nav-buttons d-flex flex-column gap-3 mt-4">
        <a href="{{ route('login') }}" class="custom-btn-new btn-2">Login</a>
        <a href="{{ route('register') }}" class="custom-btn-new btn-1">Start Free</a>
    </div>
</aside>
