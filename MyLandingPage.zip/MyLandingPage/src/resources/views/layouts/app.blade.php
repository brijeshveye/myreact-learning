@php
    $settings = \Shopyji\LandingPage\Entities\LandingPageSetting::settings();
    $logo = get_file('storage/uploads/landing_page_image');

    $sup_logo = get_file('storage/uploads/logo');
    $superadmin = \App\Models\User::where('type', 'super admin')->first();
    $setting = getSuperAdminAllSetting();
    $SITE_RTL = $setting['SITE_RTL'] ?? 'off';

    // $color = !empty($setting['color']) ? $setting['color'] : 'theme-3';

    if (!isset($setting['color'])) {
        $color = 'theme-3';
    } elseif (isset($setting['color_flag']) && $setting['color_flag'] == 'true') {
        $color = 'custom-color';
    } else {
        if (
            !in_array($setting['color'], [
                'theme-1',
                'theme-2',
                'theme-3',
                'theme-4',
                'theme-5',
                'theme-6',
                'theme-7',
                'theme-8',
                'theme-9',
                'theme-10',
            ])
        ) {
            $color = 'custom-color' ?? 'theme-3';
        } else {
            $color = $setting['color'] ?? 'theme-3';
        }
    }
    $menusettings = \Shopyji\LandingPage\Entities\OwnerMenuSetting::where('created_by', $superadmin->id)->first();

    if (isset($menusettings) && $menusettings->menus_id) {
        $topNavItems = \Shopyji\LandingPage\Entities\OwnerMenuSetting::get_ownernav_menu($menusettings->menus_id);
    }
@endphp

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport"
        content="width=device-width, initial-scale=1.0, user-scalable=yes, maximum-scale=5.0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>
        @yield('title', 'SSHP | inutes')
    </title>

    <link rel="canonical" href="@yield('canonical', 'https://www.sshp.com')" />
    <meta name="description" content="@yield('description', 'Shopyji helps you create your online store instantly with no coding required. Start your e-commerce business today at an affordable subscription cost.')" />
    <meta name="keywords" content="@yield('keywords', 'SSHP, online store, e-commerce, website, mobile app, online business, create online store, sshp.com, digital marketing, online shopping, e-commerce platform, online selling, online store builder, online dukaan, online store creation, online store development, online store design, online store management, online store solution, online store software, online store platform, online store website, online store app, online store mobile app, online store mobile application, online store mobile application development, online store mobile app development, e-commerce website development, e-commerce website design, e-commerce website builder, e-commerce website platform, e-commerce website software')" />

    <meta name="author" content="SSHP" />
    <meta name="publisher" content="SSHP" />
    <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1" />
    <meta name="allow-search" content="yes" />
    <meta name="base-url" content="{{ URL::to('/') }}">

    <meta name="theme-color" content="#ef5f06ff" />

    {{-- Favicon icon --}}
    <link rel="icon" href="https://shopyji.com/storage/uploads/logo/favicon.ico" type="image/x-icon/png" />

    <link rel="image_src" type="image/jpeg/svg" href="https://shopyji.com/storage/uploads/shopyji-preview.png" />

    {{-- <link rel="icon" href="{{ get_file($setting['favicon'] . '?timestamp=' . time()) }}"
        type="image/x-icon" /> --}}

    @include('my-landing-page::includes.meta_tags')

    <!-- Bootstrap 5 CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Google Fonts (Optional, customize this if needed) -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">

    <!-- Font Awesome (Icons) -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

    <!-- AOS Animation Plugin -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" rel="stylesheet">

    <!-- Custom Styles -->
    <link rel="stylesheet" href="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/css/style.css') }}" />
    <link rel="stylesheet"
        href="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/css/responsive.css') }}" />

    <!-- JS (if required before body load) -->
    {{-- <script src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/js/main.js') }}" defer></script> --}}

    <!-- Google Tag Manager -->
    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-K6233352');
    </script>
    <!-- End Google Tag Manager -->

    <script type="text/javascript">
        (function(c, l, a, r, i, t, y) {
            c[a] = c[a] || function() {
                (c[a].q = c[a].q || []).push(arguments)
            };
            t = l.createElement(r);
            t.async = 1;
            t.src = "https://www.clarity.ms/tag/" + i;
            y = l.getElementsByTagName(r)[0];
            y.parentNode.insertBefore(t, y);
        })(window, document, "clarity", "script", "tborl5d62i");
    </script>

    <!--------------Schema Tags -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "Corporation",
      "name": "ShopyJi | Get Ecommerce Store",
      "alternateName": "Best Ecommerce Store Builder Platform",
      "url": "https://www.shopyji.com/",
      "logo": "https://www.shopyji.com/packages/shopyji/MyLandingPage/src/resources/assets/img/logo/shopyji-dark-logo.svg",
      "contactPoint": [{
        "@type": "ContactPoint",
        "telephone": "+91 8650876100",
        "contactType": "customer service",
        "contactOption": ["HearingImpairedSupported","TollFree"],
        "areaServed": "IN",
        "availableLanguage": ["en","Hindi"]
      },"address": {
          "@type": "PostalAddress",
          "streetAddress": "MIET Business Incubation Centre, NH-58, Baghpat Rd",
          "addressLocality": "Meerut",
          "postalCode": "250005",
          "addressCountry": "IN"
        },{
        "@type": "ContactPoint",
        "telephone": "+91 8650876100",
        "contactType": "Sales",
        "email": "info@shopyji.com",
        "contactOption": "HearingImpairedSupported",
        "areaServed": "IN",
        "availableLanguage": ["en","Hindi"]
      }],
      "sameAs": [
          "https://www.facebook.com/myshopyji/",
          "https://x.com/shopyji",
          "https://www.instagram.com/shopyji/",
          "https://www.youtube.com/@mshopyji",
          "https://www.linkedin.com/company/shopyji/",
          "https://www.shopyji.com"
        ]
    }
    </script>

    <script type="application/ld+json">
      {
        "@context": "https://schema.org",
        "@type": "LocalBusiness",
        "name": "ShopyJi | Get Ecommerce Store",
        "image": "https://www.shopyji.com/packages/shopyji/MyLandingPage/src/resources/assets/img/logo/shopyji-dark-logo.svg",
        "@id": "",
        "url": "https://www.shopyji.com",
        "telephone": "+91 8650876100",
        "priceRange": "Start from Rs 9999/year",
        "address": {
          "@type": "PostalAddress",
          "streetAddress": "MIET Business Incubation Centre, NH-58, Baghpat Rd",
          "addressLocality": "Meerut",
          "postalCode": "250005",
          "addressCountry": "IN"
        },
        "geo": {
          "@type": "GeoCoordinates",
          "latitude": 28.9727923,
          "longitude": 77.6385871
        },
        "openingHoursSpecification": {
          "@type": "OpeningHoursSpecification",
          "dayOfWeek": [
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday",
            "Saturday",
            "Sunday"
          ],
          "opens": "00:00",
          "closes": "23:59"
        },
        "sameAs": [
          "https://www.facebook.com/myshopyji/",
          "https://x.com/shopyji",
          "https://www.instagram.com/shopyji/",
          "https://www.youtube.com/@mshopyji",
          "https://www.linkedin.com/company/shopyji/",
          "https://www.shopyji.com"
        ]
      }
      </script>
</head>

<body>

    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-K6233352" height="0" width="0"
            style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-T392DNDM1G"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'G-T392DNDM1G');
    </script>

    @include('my-landing-page::includes.header')

    @yield('content')

    @include('my-landing-page::includes.footer')

    <!-- Essential JS Libraries -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/js/all.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>

    <!-- AOS Init (Optional) -->
    <script>
        AOS.init({
            duration: 800, // animation duration in ms
            once: true, // animate only once per scroll
        });
    </script>

    <!-- Custom JS -->
    <script src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/js/main.js') }}"></script>
</body>

</html>
