hello from superadmin setting of mylandingpage
