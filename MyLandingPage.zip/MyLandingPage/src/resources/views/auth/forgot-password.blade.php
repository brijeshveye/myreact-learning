@php
    $adminSetting = getSuperAdminAllSetting();
    config([
        'captcha.secret' => $adminSetting['NOCAPTCHA_SECRET'] ?? '',
        'captcha.sitekey' => $adminSetting['NOCAPTCHA_SITEKEY'] ?? '',
        'options' => [ 'timeout' => 30 ],
    ]);
@endphp

@extends('my-landing-page::layouts.app')

@section('title', 'Forgot Password | ShpMain')
@section('canonical'){{ trim(route('password.request')) }}@endsection
@section('description', 'Request a password reset link for your ShpMain account.')

@section('content')
    <main>
        <style>
            .auth-hero { position: relative; background: radial-gradient(1200px 600px at -10% -10%, rgba(136, 82, 255, 0.25), transparent 50%), radial-gradient(1000px 500px at 110% -10%, rgba(255, 99, 132, 0.18), transparent 50%), linear-gradient(180deg, #0b1020 0%, #0e1428 100%); color: #fff; overflow: hidden; }
            .auth-hero::before { content:""; position:absolute; inset:0; background: linear-gradient(180deg, rgba(5,8,20,.68) 0%, rgba(5,8,20,.56) 40%, rgba(5,8,20,.70) 100%); pointer-events:none; z-index:0; }
            .auth-hero > .container { position: relative; z-index: 1; }
            .auth-illustration { min-height: 520px; display: flex; align-items: center; justify-content: center; position: relative; }
            .glass-card { background: rgba(10,15,30,.72); border: 1px solid rgba(255,255,255,.12); box-shadow: 0 20px 50px rgba(0,0,0,.45), inset 0 1px 0 rgba(255,255,255,.05); backdrop-filter: blur(14px); -webkit-backdrop-filter: blur(14px); border-radius: 16px; }
            .tilt:hover { transform: translateY(-4px); transition: transform .3s ease; }
            .shape { position: absolute; filter: blur(14px); opacity: .45; }
            .shape.s1 { width: 220px; height: 220px; left: -60px; top: -60px; background: radial-gradient(circle at 30% 30%, #9b5cff, #5b2dff); border-radius: 50%; }
            .shape.s2 { width: 180px; height: 180px; right: -40px; top: 20px; background: radial-gradient(circle at 50% 50%, #ff7ab6, #ff3d6e); border-radius: 50%; }
            .shape.s3 { width: 260px; height: 260px; right: -70px; bottom: -70px; background: radial-gradient(circle at 30% 30%, #2dd4bf, #0ea5e9); border-radius: 50%; }
            .feature-badge { display: inline-flex; align-items: center; gap: 8px; padding: 8px 12px; border-radius: 999px; background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.18); font-size: 12px; }
            .input-with-icon { position: relative; }
            .input-with-icon .icon { position: absolute; left: 12px; top: 73%; transform: translateY(-50%); color: #7a8499; }
            .input-with-icon input { padding-left: 40px; }
            .glass-card .form-control { background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.18); color:#fff; }
            .glass-card .form-control::placeholder { color: rgba(255,255,255,0.65); }
            .glass-card .form-control:focus { background: rgba(255,255,255,0.12); border-color: rgba(56,189,248,0.5); box-shadow: 0 0 0 .2rem rgba(56,189,248,0.15); color: #fff; }
            .glass-card .form-label { color: rgba(255,255,255,0.92); }
            .recaptcha-container { background: rgba(255,255,255,0.92); border-radius: 12px; padding: 6px; display: inline-block; }
        </style>
        <section class="auth-hero py-5 py-lg-0">
            <div class="container py-4 py-lg-5">
                <div class="row g-4 g-lg-5 align-items-lg-start">
                    <div class="col-lg-6 order-2 order-lg-1 text-white">
                        <span class="feature-badge mb-3" data-aos="fade-up"><i class="fa-solid fa-key"></i> {{ __('Reset your password securely') }}</span>
                        <div class="auth-illustration d-none d-lg-flex mt-4">
                            <div class="shape s1"></div>
                            <div class="shape s2"></div>
                            <div class="shape s3"></div>
                            <svg width="360" height="260" viewBox="0 0 360 260" fill="none" xmlns="http://www.w3.org/2000/svg" style="z-index:1">
                                <defs>
                                    <linearGradient id="g1" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#60a5fa"/><stop offset="100%" stop-color="#a78bfa"/></linearGradient>
                                    <linearGradient id="g2" x1="1" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#34d399"/><stop offset="100%" stop-color="#0ea5e9"/></linearGradient>
                                </defs>
                                <g filter="url(#f1)">
                                    <rect x="40" y="40" rx="18" width="280" height="160" fill="url(#g1)"/>
                                    <rect x="70" y="20" rx="14" width="140" height="40" fill="url(#g2)"/>
                                    <rect x="220" y="190" rx="10" width="110" height="30" fill="url(#g2)"/>
                                </g>
                                <defs><filter id="f1" x="0" y="0" width="360" height="260" filterUnits="userSpaceOnUse"><feDropShadow dx="0" dy="20" stdDeviation="20" flood-opacity="0.25"/></filter></defs>
                            </svg>
                        </div>
                    </div>
                    <div class="col-lg-6 order-1 order-lg-2" data-aos="fade-left">
                        <div class="glass-card tilt p-4 p-md-5">
                            <h1 class="h4 mb-3 fw-semibold text-center text-white">{{ __('Forgot Password') }}</h1>
                            <p class="text-white-50 text-center mb-4">{{ __('Forgot your password? No problem. Just let us know your email address and we will email you a password reset link.') }}</p>

                                <x-auth-session-status class="mb-3" :status="session('status')" />
                                <x-auth-validation-errors class="mb-3" :errors="$errors" />

                                <form method="POST" action="{{ route('password.email') }}">
                                    @csrf
                                    <div class="mb-3">
                                        <label for="email" class="form-label">{{ __('Email') }}</label>
                                        <div class="input-with-icon">
                                            <i class="fa-regular fa-envelope icon"></i>
                                            <input id="email" class="form-control" type="email" name="email" value="{{ old('email') }}" required autofocus placeholder="{{ __('Enter email address') }}" />
                                        </div>
                                    </div>

                                    @if (isset($adminSetting['RECAPTCHA_MODULE']) && $adminSetting['RECAPTCHA_MODULE'] == 'yes')
                                        <div class="mb-3">
                                            @if (isset($adminSetting['NOCAPTCHA_VERSON']) && $adminSetting['NOCAPTCHA_VERSON'] == 'v2')
                                                <div class="recaptcha-container">
                                                    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
                                                    <div class="g-recaptcha" data-sitekey="{{ $adminSetting['NOCAPTCHA_SITEKEY'] }}"></div>
                                                </div>
                                            @else
                                                <input type="hidden" id="g-recaptcha-response" name="g-recaptcha-response" class="form-control">
                                            @endif
                                            @error('g-recaptcha-response')
                                                <span class="error small text-danger" role="alert"><strong>{{ $message }}</strong></span>
                                            @enderror
                                        </div>
                                    @endif

                                    <div class="d-grid mt-2">
                                        <button class="custom-btn-new btn-1" type="submit">{{ __('Send Password Reset Link') }}</button>
                                    </div>
                                    <div class="mt-3 text-center text-white-50">
                                        <a class="text-decoration-none text-white" href="{{ route('login') }}">{{ __('Back to') }} <span class="text-primary">{{ __('Login') }}</span></a>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
@endsection

@push('scripts')
    @if (isset($adminSetting['RECAPTCHA_MODULE']) && $adminSetting['RECAPTCHA_MODULE'] == 'yes')
        @if (isset($adminSetting['NOCAPTCHA_VERSON']) && $adminSetting['NOCAPTCHA_VERSON'] == 'v3')
            <script src="https://www.google.com/recaptcha/api.js?render={{ $adminSetting['NOCAPTCHA_SITEKEY'] }}"></script>
            <script>
                document.addEventListener('DOMContentLoaded', function () {
                    grecaptcha.ready(function () {
                        grecaptcha.execute('{{ $adminSetting['NOCAPTCHA_SITEKEY'] }}', { action: 'submit' }).then(function (token) {
                            var el = document.getElementById('g-recaptcha-response');
                            if (el) el.value = token;
                        });
                    });
                });
            </script>
        @endif
    @endif
@endpush
