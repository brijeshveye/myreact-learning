 <section class="page contact-us container pt-3 pb-5">
        <div class="top-heading text-center pb-3" data-aos="fade-up" data-aos-delay="200">
            <span>Contact Us</span>
            <h1 class="pt-3" data-aos="fade-up" data-aos-delay="400">Let’s talk about your ecommerce journey.</h1>
            <p data-aos="fade-up" data-aos-delay="500">Have questions, feedback, or need help getting started? We’re
                here for you.</p>
        </div>
        <div class="middle-content row gx-5 mt-3 container" data-aos="fade-right" data-aos-delay="600">
            <div class="col-md-6 col-sm-12 image-part">
                <img src="{{url('packages/shopyji/MyLandingPage/src/resources/assets/img/page/contact-us.webp')}}" alt="ShopyJi Panel" class="img-fluid ">
            </div>
            <div class="col-md-6 col-sm-12 form-part">
                <form action="">
                    <!-- Interested Section -->
                    <div class="interested-part mb-4">
                        <h3 class="mb-3">I'm interested in...</h3>
                        <div class="d-flex flex-wrap gap-2">

                            <input type="radio" class="btn-check" name="interest" id="ecommerce" autocomplete="off">
                            <label class="btn-outline-select" for="ecommerce">E-commerce Store</label>

                            <input type="radio" class="btn-check" name="interest" id="web" autocomplete="off">
                            <label class="btn-outline-select" for="web">Web Development</label>

                            <input type="radio" class="btn-check" name="interest" id="marketing" autocomplete="off">
                            <label class="btn-outline-select" for="marketing">Digital Marketing</label>

                            <input type="radio" class="btn-check" name="interest" id="partner" autocomplete="off">
                            <label class="btn-outline-select" for="partner">Partnership</label>

                            <input type="radio" class="btn-check" name="interest" id="general" autocomplete="off">
                            <label class="btn-outline-select" for="general">General</label>

                            <input type="radio" class="btn-check" name="interest" id="other" autocomplete="off">
                            <label class="btn-outline-select" for="other">Other</label>
                        </div>
                    </div>

                    <!-- Contact Info -->
                    <div class="contact-info">
                        <h3 class="mb-3">My contact info:</h3>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <input type="text" class="custom-input" placeholder="Full Name *" required>
                            </div>
                            <div class="col-md-6">
                                <input type="email" class="custom-input" placeholder="Email Address *" required>
                            </div>
                            <div class="col-md-6">
                                <input type="number" class="custom-input" placeholder="Phone *" required>
                            </div>
                            <div class="col-md-6">
                                <input type="text" class="custom-input" placeholder="Business Name (Optional)">
                            </div>
                            <div class="col-md-6">
                                <input type="text" class="custom-input" placeholder="Website URL (if available)">
                            </div>
                            <div class="col-md-6">
                                <input type="text" class="custom-input" placeholder="Country *" required>
                            </div>
                            <div class="col-md-12">
                                <input type="text" class="custom-input" placeholder="Address Information">
                            </div>
                            <div class="col-md-12">
                                <input type="text" class="custom-input" placeholder="Please share the details. *"
                                    required>
                            </div>
                        </div>

                        <button type="submit" class="custom-btn-new btn-1 mt-4">Submit</button>
                    </div>
                </form>

            </div>

        </div>
    </section>
