<!--Pricing Section Start -->
<section class="pricing-section position-relative overflow-hidden">
    <div class="container py-5">
        <!-- Top Content -->
        <div class="top-content text-center pb-5" data-aos="fade-up">
            <h2>Pricing plans for everyone</h2>
            {{-- <div class="btns-part d-flex justify-content-center gap-2 pt-3">
                <button class="toggle-plan monthly-plan custom-btn-new" data-plan="monthly">Monthly</button>
                <button class="toggle-plan yearly-plan custom-btn-new active" data-plan="yearly">Yearly
                    <span>Save up to 30%</span></button>
            </div> --}}
        </div>

        <!-- Middle Content - Pricing Cards -->
        <div class="middle-content row gy-4 justify-content-center">
            <div class="col-12 col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="200">
                <div class="shopyji-pricing-card h-100 d-flex flex-column">
                    <div class="top-head d-flex justify-content-between align-items-center mb-1">
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/basic-plan.svg') }}"
                            alt="">
                        <div class="d-none">Best Offer</div>
                    </div>
                    <h4 class="pt-4">Basic</h4>
                    <p>Perfect for new start-up businesses getting online</p>
                    <div class="price-tag">
                        {{-- <div class="monthly-price  d-none">₹ 999 <span>/Per Month</span></div> --}}
                        {{-- <div class="yearly-price">₹ 9,999 <span>/Per Year</span></div> --}}
                        <div class="yearly-price">₹ 15,999 <span>/Per Year</span></div>
                    </div>
                    <h5 class="pt-3 pb-1">Features</h6>
                        <ul class="feature-list list-unstyled">
                            <li class="d-flex align-center gap-2 py-1"><img
                                    src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/ul-tick.svg') }}"
                                    alt="">
                                <p>Stores Up to 1 </p>
                            </li>
                            <li class="d-flex align-center gap-2 py-1"><img
                                    src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/ul-tick.svg') }}"
                                    alt="">
                                <p>List Products Up to 100 </p>
                            </li>
                            <li class="d-flex align-center gap-2 py-1"><img
                                    src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/ul-tick.svg') }}"
                                    alt="">
                                <p>Custom Domain Included </p>
                            </li>
                            <li class="d-flex align-center gap-2 py-1"><img
                                    src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/ul-tick.svg') }}"
                                    alt="">
                                <p>Store Setup Included </p>
                            </li>
                            <li class="d-flex align-center gap-2 py-1"><img
                                    src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/ul-tick.svg') }}"
                                    alt="">
                                <p>Initial Traning</p>
                            </li>
                            <li class="d-flex align-center gap-2 py-1 extra-feature d-none"><img
                                    src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/ul-tick.svg') }}"
                                    alt="">
                                <p>POS & Inventory Management </p>
                            </li>
                            <li class="d-flex align-center gap-2 py-1 extra-feature d-none"><img
                                    src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/ul-tick.svg') }}"
                                    alt="">
                                <p>Staff User Up to 1 </p>
                            </li>
                            <a href="#" class="show-more mt-2 d-block ">Show More</a>
                        </ul>
                        <div class="btn-part flex-grow-1 d-flex flex-column align-items-center justify-content-end">
                            <a href="{{ route('register') }}" class="custom-btn-new get-started">Get Started</a>
                            <p>Limited Offer</p>
                        </div>
                </div>
            </div>

            <div class="col-12 col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="400">
                <div class="shopyji-pricing-card h-100 d-flex flex-column active">
                    <div class="top-head d-flex justify-content-between align-items-center mb-1">
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/premium-plan.svg') }}"
                            alt="">
                        <div class="d-none">Best Offer</div>
                    </div>
                    <h4 class="pt-4 second-card">Premium</h4>
                    <p>For growing brands that need advanced features</p>
                    <div class="price-tag">
                        {{-- <div class="monthly-price  d-none">₹ 1,499 <span>/Per Month</span></div> --}}
                        {{-- <div class="yearly-price">₹ 15,999 <span>/Per Year</span></div> --}}
                        <div class="yearly-price">₹ 24,999 <span>/Per Year</span></div>
                    </div>
                    <h5 class="pt-3 pb-1">Features</h6>
                        <ul class="feature-list list-unstyled">
                            <li class="d-flex align-center gap-2 py-1"><img
                                    src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/ul-tick.svg') }}"
                                    alt="">
                                <p>Stores Up to 2 </p>
                            </li>
                            <li class="d-flex align-center gap-2 py-1"><img
                                    src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/ul-tick.svg') }}"
                                    alt="">
                                <p>List Products Up to 200 </p>
                            </li>
                            <li class="d-flex align-center gap-2 py-1"><img
                                    src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/ul-tick.svg') }}"
                                    alt="">
                                <p>Custom Domain Included </p>
                            </li>
                            <li class="d-flex align-center gap-2 py-1"><img
                                    src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/ul-tick.svg') }}"
                                    alt="">
                                <p>Store Setup Included </p>
                            </li>
                            <li class="d-flex align-center gap-2 py-1"><img
                                    src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/ul-tick.svg') }}"
                                    alt="">
                                <p>Initial Traning</p>
                            </li>
                            <li class="d-flex align-center gap-2 py-1 extra-feature d-none"><img
                                    src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/ul-tick.svg') }}"
                                    alt="">
                                <p>POS & Inventory Management </p>
                            </li>
                            <li class="d-flex align-center gap-2 py-1 extra-feature d-none"><img
                                    src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/ul-tick.svg') }}"
                                    alt="">
                                <p>Staff User Up to 3 </p>
                            </li>
                            <a href="#" class="show-more mt-2 d-block ">Show More</a>
                        </ul>
                        <div class="btn-part flex-grow-1 d-flex flex-column align-items-center justify-content-end">
                            <a href="{{ route('register') }}" class="custom-btn-new get-started">Get Started</a>
                            <p>Limited Offer</p>
                        </div>
                </div>
            </div>

            <div class="col-12 col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="600">
                <div class="shopyji-pricing-card h-100 d-flex flex-column">
                    <div class="top-head d-flex justify-content-between align-items-center mb-1">
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/exterprises-plan.svg') }}"
                            alt="">
                        <div class="d-none">Best Offer</div>
                    </div>
                    <h4 class="pt-4 third-card">Enterprises</h4>
                    <p>For serious sellers and high-volume businesses</p>
                    <div class="price-tag">
                        {{-- <div class="monthly-price  d-none">₹ 2,499 <span>/Per Month</span></div> --}}
                        {{-- <div class="yearly-price">₹ 24,999 <span>/Per Year</span></div> --}}
                        <div class="yearly-price">Custom <span>/Per Year</span></div>
                    </div>
                    <h5 class="pt-3 pb-1">Features</h6>
                        <ul class="feature-list list-unstyled">
                            <li class="d-flex align-center gap-2 py-1"><img
                                    src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/ul-tick.svg') }}"
                                    alt="">
                                <p>Stores Up to 10 </p>
                            </li>
                            <li class="d-flex align-center gap-2 py-1"><img
                                    src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/ul-tick.svg') }}"
                                    alt="">
                                <p>List Products Up to Unlimited </p>
                            </li>
                            <li class="d-flex align-center gap-2 py-1"><img
                                    src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/ul-tick.svg') }}"
                                    alt="">
                                <p>Custom Domain Included </p>
                            </li>
                            <li class="d-flex align-center gap-2 py-1"><img
                                    src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/ul-tick.svg') }}"
                                    alt="">
                                <p>Store Setup Included </p>
                            </li>
                            <li class="d-flex align-center gap-2 py-1"><img
                                    src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/ul-tick.svg') }}"
                                    alt="">
                                <p>Initial Traning</p>
                            </li>
                            <li class="d-flex align-center gap-2 py-1 extra-feature d-none"><img
                                    src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/ul-tick.svg') }}"
                                    alt="">
                                <p>POS & Inventory Management </p>
                            </li>
                            <li class="d-flex align-center gap-2 py-1 extra-feature d-none"><img
                                    src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/ul-tick.svg') }}"
                                    alt="">
                                <p>Staff User Up to 10 </p>
                            </li>
                            <a href="#" class="show-more mt-2 d-block ">Show More</a>
                        </ul>
                        <div class="btn-part flex-grow-1 d-flex flex-column align-items-center justify-content-end">
                            <a href="{{ route('mylandingpage.contact') }}" class="custom-btn-new get-started">Contact Us</a>
                            <p>Limited Offer</p>
                        </div>
                </div>
            </div>

        </div>
    </div>
</section>
<!--Pricing Section End -->
