<!-- FAQs Section Start -->
<section class="faqs-section position-relative overflow-hidden">
    <div class="container py-5">
        <!-- Top Content -->
        <div class="top-content text-center pb-3" data-aos="fade-up" data-aos-duration="1000">
            <h2>Have a question?</h2>
            <p class="mx-auto">Now it’s your turn to create a stunning Ecommerce website with Shopy Ji! Let us know
                if you have any questions — we’re here to help.</p>
        </div>

        <div class="faq-card">
            <ul>
                <!-- FAQ Item 1 -->
                <li class="faq-item" data-aos="fade-up" data-aos-delay="100">
                    <div class="question d-flex align-items-center justify-content-between"
                        onclick="toggleAnswer(this)">
                        <h5>What is Shopy Ji?</h5>
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/faq-plus.svg') }}" alt="Arrow" class="arrow-icon">
                    </div>
                    <div class="answer">
                        <p>Shopy Ji is a SaaS platform that allows you to create and manage your own online store
                            easily. It offers a range of features to help you sell products online.</p>
                    </div>
                </li>

                <!-- FAQ Item 2 -->
                <li class="faq-item" data-aos="fade-up" data-aos-delay="200">
                    <div class="question d-flex align-items-center justify-content-between"
                        onclick="toggleAnswer(this)">
                        <h5>How does Shopy Ji work?</h5>
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/faq-plus.svg') }}" alt="Arrow" class="arrow-icon">
                    </div>
                    <div class="answer">
                        <p>Shopy Ji provides an intuitive platform where you can design your store, add products,
                            and manage transactions in a few simple steps.</p>
                    </div>
                </li>

                <!-- FAQ Item 3 -->
                <li class="faq-item" data-aos="fade-up" data-aos-delay="300">
                    <div class="question d-flex align-items-center justify-content-between"
                        onclick="toggleAnswer(this)">
                        <h5>What are the benefits of using Shopy Ji?</h5>
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/faq-plus.svg') }}" alt="Arrow" class="arrow-icon">
                    </div>
                    <div class="answer">
                        <p>Shopy Ji offers a variety of benefits including ease of use, customizable store design,
                            secure payment integration, and detailed analytics to track your business performance.
                        </p>
                    </div>
                </li>

                <!-- FAQ Item 4 -->
                <li class="faq-item" data-aos="fade-up" data-aos-delay="400">
                    <div class="question d-flex align-items-center justify-content-between"
                        onclick="toggleAnswer(this)">
                        <h5>Is Shopy Ji mobile-friendly?</h5>
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/faq-plus.svg') }}" alt="Arrow" class="arrow-icon">
                    </div>
                    <div class="answer">
                        <p>Yes, Shopy Ji is fully mobile-responsive, allowing you to manage your store and sales
                            from any device, anytime.</p>
                    </div>
                </li>

                <!-- FAQ Item 5 -->
                <li class="faq-item" data-aos="fade-up" data-aos-delay="500">
                    <div class="question d-flex align-items-center justify-content-between"
                        onclick="toggleAnswer(this)">
                        <h5>Can I integrate Shopy Ji with my existing website?</h5>
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/faq-plus.svg') }}" alt="Arrow" class="arrow-icon">
                    </div>
                    <div class="answer">
                        <p>Yes, you can easily integrate Shopy Ji with your existing website using the provided
                            plugins and API options.</p>
                    </div>
                </li>

                <!-- FAQ Item 6 -->
                <li class="faq-item" data-aos="fade-up" data-aos-delay="600">
                    <div class="question d-flex align-items-center justify-content-between"
                        onclick="toggleAnswer(this)">
                        <h5>How do I get support for Shopy Ji?</h5>
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/faq-plus.svg') }}" alt="Arrow" class="arrow-icon">
                    </div>
                    <div class="answer">
                        <p>You can reach Shopy Ji support via email, live chat, or through the help center on the
                            website for any assistance.</p>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</section>
<!-- FAQs Section End -->
