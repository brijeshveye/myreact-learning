<!-- Testimonial Section Start -->
<section class="testimonial-section position-relative overflow-hidden py-4">
    <!-- Top Content -->
    <div class="top-content text-center py-4" data-aos="fade-up" data-aos-duration="1000">
        <h2>🛡️ Trusted by <span>Thousands</span></h2>
    </div>

    <!-- Swiper Slider -->
    <div class="swiper testimonial-slider">
        <div class="swiper-wrapper">
            <!-- Slide 1 -->
            <div class="swiper-slide">
                <div class="shopyji-testimonial-card">
                    <p>I had no tech background, but with Shopy Ji I launched my clothing store in minutes...
                    </p>
                    <hr>
                    <div class="bottom-part d-flex align-items-center gap-3">
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/shopyji-icon-dark.svg') }}"
                            alt="">
                        <div class="reviewer-info">
                            <h6>Riya Sharma</h6>
                            <p>Fashion Store Owner</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Slide 2 -->
            <div class="swiper-slide">
                <div class="shopyji-testimonial-card">
                    <p>Starting my store with Shopy Ji was incredibly easy. The support is fantastic...</p>
                    <hr>
                    <div class="bottom-part d-flex align-items-center gap-3">
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/shopyji-icon-dark.svg') }}"
                            alt="">
                        <div class="reviewer-info">
                            <h6>Amit Verma</h6>
                            <p>Electronics Store Owner</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Slide 3 -->
            <div class="swiper-slide">
                <div class="shopyji-testimonial-card">
                    <p>My bakery went online within a day, and Shopy Ji made the setup completely stress-free...</p>
                    <hr>
                    <div class="bottom-part d-flex align-items-center gap-3">
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/shopyji-icon-dark.svg') }}"
                            alt="">
                        <div class="reviewer-info">
                            <h6>Sandeep Gupta</h6>
                            <p>Bakery Owner</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-slide">
                <div class="shopyji-testimonial-card">
                    <p>With Shopy Ji’s subscription plan, I grew my furniture store online without heavy costs...</p>
                    <hr>
                    <div class="bottom-part d-flex align-items-center gap-3">
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/shopyji-icon-dark.svg') }}"
                            alt="">
                        <div class="reviewer-info">
                            <h6>Anjali Nair</h6>
                            <p>Furniture Store Owner</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-slide">
                <div class="shopyji-testimonial-card">
                    <p>My handmade crafts store looks professional, and Shopy Ji handled all the hard work...</p>
                    <hr>
                    <div class="bottom-part d-flex align-items-center gap-3">
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/shopyji-icon-dark.svg') }}"
                            alt="">
                        <div class="reviewer-info">
                            <h6>Deepak Yadav</h6>
                            <p>Handmade Crafts Owner</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-slide">
                <div class="shopyji-testimonial-card">
                    <p>I launched my mobile accessories shop the same day I signed up with Shopy Ji...</p>
                    <hr>
                    <div class="bottom-part d-flex align-items-center gap-3">
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/shopyji-icon-dark.svg') }}"
                            alt="">
                        <div class="reviewer-info">
                            <h6>Kavita Mishra</h6>
                            <p>Mobile Accessories Store</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-slide">
                <div class="shopyji-testimonial-card">
                    <p>Thanks to Shopy Ji, my organic food business now reaches customers across India...</p>
                    <hr>
                    <div class="bottom-part d-flex align-items-center gap-3">
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/shopyji-icon-dark.svg') }}"
                            alt="">
                        <div class="reviewer-info">
                            <h6>Rohit Khanna</h6>
                            <p>Organic Food Business</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-slide">
                <div class="shopyji-testimonial-card">
                    <p>My toy shop sales doubled after moving online with Shopy Ji’s simple platform...</p>
                    <hr>
                    <div class="bottom-part d-flex align-items-center gap-3">
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/shopyji-icon-dark.svg') }}"
                            alt="">
                        <div class="reviewer-info">
                            <h6>Meera Joshi</h6>
                            <p>Toy Shop Owner</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-slide">
                <div class="shopyji-testimonial-card">
                    <p>Running my jewelry store online became effortless once I joined Shopy Ji...</p>
                    <hr>
                    <div class="bottom-part d-flex align-items-center gap-3">
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/shopyji-icon-dark.svg') }}"
                            alt="">
                        <div class="reviewer-info">
                            <h6>Arun Singh</h6>
                            <p>Jewelry Store Owner</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- (Add more slides if needed) -->
        </div>
        <!-- Pagination Dots -->
        <div class="swiper-pagination"></div>
    </div>

    <div class="bottom-content pt-5 container" data-aos="fade-up" data-aos-duration="700" data-aos-delay="400">
        <hr>
        <div class="join-community-part d-flex align-items-center flex-column flex-lg-row">
            <h4>Join the community</h4>
            <div class="social-container">
                <!-- Social Items with Link -->
                <div class="social-list d-flex gap-2">
                    <a href="https://www.instagram.com/shopyji" target="_blank" class="social-item d-flex align-items-center">
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/instagram.svg') }}"
                            alt="Instagram">
                        <span class="social-text">Follow us on Instagram</span>
                    </a>
                    <a href="https://www.youtube.com/@mshopyji" target="_blank" class="social-item d-flex align-items-center">
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/youtube.svg') }}"
                            alt="YouTube">
                        <span class="social-text">Subscribe us on YouTube</span>
                    </a>
                    <a href="https://www.linkedin.com/company/shopyji/" target="_blank" class="social-item d-flex align-items-center">
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/linkedin.svg') }}"
                            alt="LinkedIn">
                        <span class="social-text">Connect with us on LinkedIn</span>
                    </a>
                    <a href="https://www.facebook.com/myshopyji/" target="_blank" class="social-item d-flex align-items-center">
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/facebook.svg') }}"
                            alt="Facebook">
                        <span class="social-text">Like us on Facebook</span>
                    </a>
                    <a href="https://x.com/shopyji" target="_blank" class="social-item d-flex align-items-center">
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/twitter.svg') }}"
                            alt="Twitter">
                        <span class="social-text">Follow us on Twitter</span>
                    </a>
                </div>
            </div>
            <!-- Follow us and Stay connected text -->
            <div class="follow-text">
                <p>Follow us and Stay connected.</p>
            </div>
        </div>
    </div>
</section>
<!-- Testimonial Section End -->
