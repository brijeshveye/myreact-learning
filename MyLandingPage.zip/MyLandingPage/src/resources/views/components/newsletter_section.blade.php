<!-- Newsletter Section Start -->
<section class="newsletter-section position-relative">
    <div class="girl-character-image-part position-absolute">
        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/home/girl-character.webp') }}" alt="" width="100%">
    </div>

    <div class="right-part py-3 mx-auto" data-aos="slide-left" data-aos-duration="1000">
        <div class="pb-3">
            <span class="d-block">Subscribe Newsletter</span>
            <h2 class="pt-1 pb-3">Stay updated with new features!</h2>
            <form action="">
                <div class="input-group mb-3 position-relative" data-aos="fade-up" data-aos-delay="200">
                    <input type="email" class="form-control subscribe-input" placeholder="Enter your email address"
                        required>
                    <button type="submit" class="btn btn-gradient text-white" data-aos="fade-up" data-aos-delay="400">
                        Subscribe Newsletter
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/subscribe-icon.svg') }}" alt="Arrow" class="me-2">
                    </button>
                </div>

                <p class="text-muted" data-aos="fade-up" data-aos-delay="600">We respect your privacy. Unsubscribe
                    at any time.</p>

                <div class="d-flex gap-2 mt-4" data-aos="fade-up" data-aos-delay="800">
                    <a href="{{ route('mylandingpage.contact') }}"
                        class="google-play-btn d-flex align-items-center justify-content-center rounded-pill p-2">
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/playstore.svg') }}" alt="" class="me-2">
                        <p class="mb-0">GOOGLE PLAY</p>
                    </a>
                    <a href="{{ route('mylandingpage.contact') }}"
                        class="apple-store-btn d-flex align-items-center justify-content-center rounded-pill p-2">
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/applestore.svg') }}" alt="" class="me-2">
                        <p class="mb-0">APP STORE</p>
                    </a>
                </div>
            </form>
        </div>
    </div>
</section>
<!-- Newsletter Section End -->
