<section class="policies-page container pt-3 pb-5">
    <div class="top-heading text-center pb-5">
        <span>About Us</span>
        <h1 class="pt-3">What is Shopyji?</h1>
        <p>Learn how Shopyji works, what we offer, and why thousands trust us for their online business needs.</p>
    </div>
    <div class="content row">
        <div class="col-12 col-md-8 mx-auto text-center">
            <p><b>Last updated:</b> April 20, 2025</p>
            <div class="d-flex flex-column align-items-center">
                <p>
                    <b>Welcome to ShopyJi</b>, your trusted destination for smart shopping and seamless experiences. We
                    are more than just an online store — we’re a platform built to bring convenience, affordability, and
                    quality together in one place.
                </p>
                <p>
                    At ShopyJi, our mission is simple: to make shopping easier, faster, and more reliable for everyone.
                    We combine a wide range of products, user-friendly technology, and dedicated customer support to
                    ensure that every order feels effortless from start to finish.
                </p>
                <p><b>What makes us different?</b></p>
                <p>
                    <b>Wide Selection</b> – From everyday essentials to premium collections, we bring you products that
                    match your lifestyle.<br>
                    <b>Affordable Prices</b> – We believe shopping should never be a burden, so we keep our prices fair
                    and transparent.<br>
                    <b>Customer-First Approach</b> – Your satisfaction drives everything we do. We listen, we improve,
                    and we always put you first.<br>
                    <b>Innovation-Driven</b> – With modern technology and continuous upgrades, we’re shaping the future
                    of digital shopping.
                </p>
                <p>
                    We are proud to serve our growing community of shoppers and businesses, creating a space where
                    quality meets trust. Whether you’re looking for the latest trends, essentials for your home, or
                    reliable business solutions, ShopyJi is here for you.
                </p>
                <p>
                    Because at ShopyJi, it’s not just shopping — it’s shopping made simple.
                </p>
                <h4 class="mt-4"><b>Contact Us</b></h4>
                <p>
                    <b>Have questions?</b><br>
                    📧 Email: <b>support@shopyji.com</b><br>
                    📞 Phone: <b>+91-8192002404</b>
                </p>
            </div>
        </div>
    </div>
</section>
