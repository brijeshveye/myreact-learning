@extends('my-landing-page::layouts.app')

@section('title', 'Privacy Policy | ShopyJi')
@section('canonical'){{ trim(route('mylandingpage.privacy')) }}@endsection
@section('description', 'Read Shopyji’s privacy policy to understand how we collect, use, and protect your personal
    information while you use our e-commerce platform.')
@section('keywords', 'shopyji privacy policy, ecommerce privacy, online store data policy, customer privacy protection')

@section('content')
    <main>

        <section class="policies-page container pt-3 pb-5">
            <div class="top-heading text-center pb-5">
                <span>Privacy Policy</span>
                <h1 class="pt-3">Your privacy matters to us.</h1>
                <p>Learn how Shopy Ji collects, uses, and protects your personal information while you build and grow your
                    ecommerce business.</p>
            </div>
            <div class="content row">
                <div class="col-12 col-md-8">
                    <p><b>Last updated:</b> April 20, 2025</p>
                    <p><b>Shopyji</b> ("us", "we", or "our") operates the Shopyji website (the "Service").</p>
                    <p>This page informs you of our policies regarding the collection, use, and disclosure of personal
                        data when you use our Service and the choices you have associated with that data.</p>
                    <p>We use your data to provide and improve the Service. By using the Service, you agree to the
                        collection and use of information in accordance with this policy.</p>

                    <h4>1. Information We Collect</h4>
                    <p>We may collect the following information:</p>
                    <ul>
                        <li>Name, email address, and phone number</li>
                        <li>Billing details and payment information</li>
                        <li>Store details, including products and orders</li>
                        <li>Usage data (device, browser, and activity logs)</li>
                    </ul>

                    <h4>2. How We Use Your Information</h4>
                    <p>We use your data to:</p>
                    <ul>
                        <li>Provide and maintain our services</li>
                        <li>Process payments and subscriptions</li>
                        <li>Improve user experience and platform performance</li>
                        <li>Send important updates, promotions, and support messages</li>
                    </ul>

                    <h4>3. Cookies & Tracking</h4>
                    <p>We use cookies and similar technologies to:</p>
                    <ul>
                        <li>Remember your preferences</li>
                        <li>Analyze usage and improve our website</li>
                        <li>Deliver relevant ads (optional)</li>
                    </ul>
                    <p>You can control cookies through your browser settings.</p>

                    <h4>4. Data Sharing & Third Parties</h4>
                    <p>We do not sell your personal data. We may share it with:</p>
                    <ul>
                        <li>Payment gateways (e.g., Razorpay, Stripe)</li>
                        <li>Cloud hosting and analytics providers</li>
                        <li>Legal authorities (if required by law)</li>
                    </ul>

                    <h4>5. Your Data, Your Rights</h4>
                    <p>You can:</p>
                    <ul>
                        <li>View or update your information</li>
                        <li>Request deletion of your account</li>
                        <li>Unsubscribe from promotional emails at any time</li>
                    </ul>
                    <p>To request access or changes, contact us at: <b>support@shopyji.com</b></p>

                    <h4>6. Data Security</h4>
                    <p>We take your data seriously. All sensitive information is encrypted and stored securely. We implement
                        industry-standard safeguards to prevent unauthorized access.</p>

                    <h4>7. Updates to This Policy</h4>
                    <p>We may update this Privacy Policy from time to time. When we do, we’ll notify you by email or via our
                        platform.</p>

                    <h4>8. Contact Us</h4>
                    <p>Have questions?<br>
                        📧 Email: <b>support@shopyji.com</b><br>
                        📞 Phone: <b>+91-8650876100</b></p>
                </div>
            </div>
        </section>

    </main>
@endsection
