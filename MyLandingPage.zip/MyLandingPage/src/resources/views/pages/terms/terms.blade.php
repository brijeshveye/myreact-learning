@extends('my-landing-page::layouts.app')

@section('title', 'Terms & Conditions | ShopyJi')
@section('canonical'){{ trim(route('mylandingpage.terms')) }}@endsection
@section('description', 'Read Shopyji’s terms and conditions before using our platform. Learn about user agreements,
    subscription terms, and responsibilities.')
@section('keywords', 'shopyji terms, ecommerce terms and conditions, online store usage policy, subscription agreement')

@section('content')
    <main>
        <section class="policies-page container pt-3 pb-5">
            <div class="top-heading text-center pb-5">
                <span>Terms & Conditions</span>
                <h1 class="pt-3">Please read these terms carefully before using Shopy Ji.</h1>
                <p>By accessing our platform, you agree to follow our rules and use our services responsibly.</p>
            </div>
            <div class="content row">
                <div class="col-12 col-md-8">
                    <p><b>Effective Date:</b> 20 April, 2025</p>

                    <h4>1. Introduction</h4>
                    <p>These Terms and Conditions (“Terms”) govern your access to and use of the Shopy Ji platform,
                        including our website, mobile app, and any associated services. By using Shopy Ji, you agree to
                        comply with these Terms.</p>

                    <h4>2. User Responsibilities</h4>
                    <p>You agree to:</p>
                    <ul>
                        <li>Provide accurate information during registration</li>
                        <li>Use Shopy Ji only for lawful ecommerce business purposes</li>
                        <li>Maintain the confidentiality of your account credentials</li>
                        <li>Not misuse the platform in any way (e.g., spamming, hacking, or illegal activities)</li>
                    </ul>

                    <h4>3. Account Suspension or Termination</h4>
                    <p>We reserve the right to suspend or terminate accounts that:</p>
                    <ul>
                        <li>Violate our Terms or policies</li>
                        <li>Involve fraud or illegal activity</li>
                        <li>Cause harm to our systems or users</li>
                    </ul>

                    <h4>4. Payments & Subscriptions</h4>
                    <p>All subscriptions are billed according to the selected plan (monthly or yearly). Failure to pay may
                        result in restricted access or account suspension.</p>

                    <h4>5. Intellectual Property</h4>
                    <p>All content, branding, themes, and code within Shopy Ji are the intellectual property of Shopy Ji.
                        You may not duplicate, resell, or modify our platform without permission.</p>

                    <h4>6. Limitation of Liability</h4>
                    <p>Shopy Ji is not responsible for:</p>
                    <ul>
                        <li>Loss of sales or profits due to downtime or issues</li>
                        <li>User-generated content or actions taken by third-party integrations</li>
                    </ul>
                    <p>Use of the platform is at your own risk.</p>

                    <h4>7. Changes to Terms</h4>
                    <p>We may update these Terms from time to time. Continued use of the platform after changes means you
                        agree to the new terms.</p>

                    <h4>8. Contact Us</h4>
                    <p>If you have any questions about these Terms:<br>
                        📧 <a href="mailto:support@shopyji.com">support@shopyji.com</a></p>
                </div>
            </div>
        </section>
    </main>
@endsection
