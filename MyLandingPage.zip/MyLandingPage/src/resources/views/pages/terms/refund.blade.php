@extends('my-landing-page::layouts.app')

@section('title', 'Refund Policy | ShopyJi')
@section('canonical'){{ trim(route('mylandingpage.refund')) }}@endsection
@section('description', 'Review Shopyji’s refund policy for subscription cancellations and payment-related queries. Clear and simple guidelines for our users.')
@section('keywords', 'shopyji refund policy, ecommerce subscription refund, online store payment refund')

@section('content')

    <main>
        <section class="policies-page container pt-3 pb-5">
            <div class="top-heading text-center pb-5">
                <span>Refund Policy</span>
                <h1 class="pt-3">We believe in transparency and customer satisfaction.</h1>
                <p>Here’s everything you need to know about our refund process.</p>
            </div>
            <div class="content row">
                <div class="col-12 col-md-8">
                    <p><b>Effective Date:</b> 20 April, 2025</p>

                    <h4>1. Eligibility for Refund</h4>
                    <p>We offer refunds only under the following conditions:</p>
                    <ul>
                        <li>You face a technical issue that we’re unable to resolve.</li>
                        <li>You request a refund within 3 days of your initial subscription.</li>
                        <li>You have not heavily customized or used premium features extensively.</li>
                    </ul>

                    <h4>2. Non-Refundable Cases</h4>
                    <p>We do not offer refunds in the following cases:</p>
                    <ul>
                        <li>You changed your mind after purchase.</li>
                        <li>You fail to use the service as intended.</li>
                        <li>You request a refund after 3 days of purchase.</li>
                        <li>You’ve used premium plugins or themes extensively.</li>
                    </ul>

                    <h4>3. How to Request a Refund</h4>
                    <p>To request a refund, please email us at <a href="mailto:support@shopyji.com">support@shopyji.com</a>
                        with:</p>
                    <ul>
                        <li>Your registered email address</li>
                        <li>Order/Transaction ID</li>
                        <li>Reason for the refund</li>
                    </ul>
                    <p>Our team will review your request within 3-5 business days and get back to you.</p>

                    <h4>4. Refund Timeline</h4>
                    <p>If approved, refunds will be processed within 7–10 business days to your original payment method.</p>

                    <h4>5. Need Help?</h4>
                    <p>Have questions about our policy?<br>
                        Contact our support team anytime: <br>
                        📧 <a href="mailto:support@shopyji.com">support@shopyji.com</a></p>
                </div>
            </div>
        </section>
    </main>

@endsection
