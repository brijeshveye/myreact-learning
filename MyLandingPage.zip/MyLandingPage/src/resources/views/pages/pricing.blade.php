@extends('my-landing-page::layouts.app')

@section('title', 'ShopyJi Pricing | Affordable Online Store Plans')
@section('canonical'){{ trim(route('mylandingpage.pricing')) }}@endsection
@section('description', 'Choose ShopyJi affordable subscription plans to start your e-commerce store. No hidden charges,
    just simple monthly or yearly pricing.')
@section('keywords', 'Shopy Ji, online store, e-commerce, ecommerce pricing plans, online store subscription, ecommerce
    packages, affordable ecommerce website, Shopyji pricing')

@section('content')
    <main>

        @include('my-landing-page::components.pricing_section')

        @include('my-landing-page::components.testimonial_section')

        @include('my-landing-page::components.faq_section')

        @include('my-landing-page::components.newsletter_section')

    </main>
@endsection
