@extends('my-landing-page::layouts.app')

@section('title', 'Shpmain | minutes')
@section('canonical'){{ trim(route('mylandingpage.home')) }}@endsection
@section('description', 'Shpmain helps you create your online store instantly with no coding required. Start your
    e-commerce business today at an affordable subscription cost.')
@section('keywords', 'Shpmain, online store, e-commerce, website, mobile app, online business, create online store,
    shpmain.com, digital marketing, online shopping, e-commerce platform, online selling, online store builder, online
    dukaan, online store creation, online store development, online store design, online store management, online store
    solution, online store software, online store platform, online store website, online store app, online store mobile app,
    online store mobile application, online store mobile application development, online store mobile app development,
    e-commerce website development, e-commerce website design, e-commerce website builder, e-commerce website platform,
    e-commerce website software')

@section('content')
    <main class=" overflow-hidden">
        <!-- Hero Section Start -->
        <section class="hero-section overflow-hidden">
            <div class="content py-5 container d-flex flex-column">
                <!-- Top Content -->
                <div class="top-content pb-5" data-aos="fade-down" data-aos-delay="100">
                    <p class="d-inline-flex align-items-center">
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/new-text-icon.svg') }}"
                            alt="ShopyJi New Icon" class="me-2">
                        <span>Next-generation of Ecommerce Website.</span>
                    </p>
                </div>

                <!-- Middle Content -->
                <div class="middle-content text-center py-5" data-aos="fade-up" data-aos-delay="200">
                    <h1>Launch your business <br> in just 2 minutes</h1>
                    <p>Take your ecommerce experience to the next level and boost your sales & productivity effortlessly.
                    </p>

                    <!-- Download Buttons -->
                    <div class="download-btns d-flex flex-wrap justify-content-center gap-3" data-aos="zoom-in"
                        data-aos-delay="300">
                        <a href="{{ route('mylandingpage.contact') }}"><img
                                src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/home/play-store-download.webp') }}"
                                alt="Download ShopyJi App by Play Store" class="store-btn" style="height: 40px;"></a>
                        <a href="{{ route('mylandingpage.contact') }}"><img
                                src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/home/apple-store-download.webp') }}"
                                alt="Download ShopyJi App by Apple Store" class="store-btn" style="height: 40px;"></a>
                    </div>

                    <!-- CTA Button -->
                    <a href="{{ route('register') }}" class="custom-btn-new btn-1 mt-4" data-aos="fade-up"
                        data-aos-delay="400">Get Started</a>
                </div>

                <!-- Bottom Features -->
                <div class="bottom-content pt-3 w-100">
                    <ul class="features-list d-flex flex-wrap justify-content-center gap-4 gap-md-5 list-unstyled">
                        <li class="d-flex align-items-center gap-2" data-aos="fade-up" data-aos-delay="500">
                            <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/instant-store-setup.svg') }}"
                                alt="ShopyJi Instant Store Setup">
                            <span>Instant Store Setup</span>
                        </li>
                        <li class="d-flex align-items-center gap-2" data-aos="fade-up" data-aos-delay="600">
                            <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/easy-manage.svg') }}"
                                alt="ShopyJi is Easily Manage by App">
                            <span>Easily Manage by App</span>
                        </li>
                        <li class="d-flex align-items-center gap-2" data-aos="fade-up" data-aos-delay="700">
                            <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/professional-themes.svg') }}"
                                alt="ShopyJi has all Professional Themes">
                            <span>Professional Themes</span>
                        </li>
                    </ul>
                </div>
            </div>
        </section>
        <!-- Hero Section End -->

        <!-- Why Shopyji Section Start -->
        <section class="why-shopyji overflow-hidden">
            <div class="content py-5 container d-flex flex-column">
                <div class="top-content text-center pb-5" data-aos="fade-up">
                    <h2>Why Shopy Ji?</h2>
                </div>

                <div class="row gy-4">
                    <!-- Column A (col-md-3) -->
                    <div class="col-12 col-md-3 d-flex flex-column gap-3">
                        <div class="shopyji-card theme-card flex-grow-1 h-100" data-aos="fade-right" data-aos-delay="100">
                        </div>

                        <div class="shopyji-card text-card-1 flex-grow-1 h-100" data-aos="fade-right" data-aos-delay="200">
                            <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/shopyji-icon-dark.svg') }}"
                                alt="ShopyJi Icon Dark">
                            <h4>Looking for an Ecommerce solution to kickstart your business? Check out
                                <a href="{{ route('mylandingpage.themes') }}"><span>Shopy Ji.</span></a>
                            </h4>
                        </div>
                    </div>

                    <!-- Column B (col-md-6) -->
                    <div class="col-12 col-md-6 d-flex flex-column gap-3">
                        <!-- Row 1 -->
                        <div class="row g-3">
                            <div class="col-6">
                                <div class="shopyji-card high-performance h-100" data-aos="zoom-in" data-aos-delay="150">
                                    <h4>Ultra-High <br><span>Performance</span></h4>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="shopyji-card exclusive-plugins h-100" data-aos="zoom-in" data-aos-delay="250">
                                    <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/home/why-shopyji-03.webp') }}"
                                        alt=" ShopyJi has Exclusive Plugins" class="img-fluid w-50">
                                    <h4>Exclusive Plugins</h4>
                                </div>
                            </div>
                        </div>

                        <!-- Row 2 -->
                        <div class="shopyji-card text-card-2 h-100" data-aos="fade-up" data-aos-delay="300">
                            <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/icons/color-dots.svg') }}"
                                alt="Meet ShopyJi Icon">
                            <h2>Meet Shopy Ji — a revolutionary platform built with modern automation and smart integrations
                                to elevate your ecommerce game.
                            </h2>
                        </div>

                        <!-- Row 3: Auto Sliders -->
                        <div class="shopyji-card slider-card h-100" data-aos="fade-up" data-aos-delay="400">
                            <div class="slider-wrapper">
                                <div class="slider-track scroll-right d-flex gap-3">
                                    <div class="slide-card">GDPR Compliant</div>
                                    <div class="slide-card">Lifetime Updates</div>
                                    <div class="slide-card">AI Recommendations</div>
                                    <div class="slide-card">Multilingual Support</div>
                                    <div class="slide-card">WooCommerce Ready</div>
                                    <div class="slide-card">Free Support</div>
                                    <div class="slide-card">Sleek UI Animations</div>
                                    <div class="slide-card">Prebuilt Page Sections</div>
                                </div>
                            </div>
                            <div class="slider-wrapper mt-3">
                                <div class="slider-track scroll-left d-flex gap-3">
                                    <div class="slide-card">Order Management</div>
                                    <div class="slide-card">Customer Management</div>
                                    <div class="slide-card">Products & Category</div>
                                    <div class="slide-card">Google Merchant</div>
                                    <div class="slide-card">Google Indexing</div>
                                    <div class="slide-card">Privacy Focused</div>
                                    <div class="slide-card">User Friendly</div>
                                    <div class="slide-card">Reliable Service</div>
                                    <div class="slide-card">Quality Products</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Column C (col-md-3) -->
                    <div class="col-12 col-md-3 d-flex flex-column gap-3">
                        <div class="shopyji-card customizer h-100" data-aos="fade-left" data-aos-delay="200">
                            <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/home/why-shopyji-04.webp') }}"
                                alt="ShopyJi Eccommerce is Fully Store Customizer" class="img-fluid w-50">
                            <h4>Fully Store Customizer</h4>
                        </div>

                        <div class="shopyji-card shopping-online h-100" data-aos="fade-left" data-aos-delay="300"></div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Why Shopyji Section End -->

        <!-- Start you Ecommerce Section Start -->
        <section class="start-ecommerce position-relative overflow-hidden">
            <div class="content py-5 d-flex flex-column">

                <!-- Top Content -->
                <div class="top-content text-center pb-5" data-aos="fade-up" data-aos-delay="300">
                    <h2>Start your Ecommerce Platform</h2>
                    <div class="tag-btn" data-aos="fade-up" data-aos-delay="300">Excited for ShopyJi? <a
                            href="{{ route('register') }}">Register
                            Now!</a></div>
                </div>

                <!-- Boy character image -->
                <div class="boy-character-image d-none d-md-block" data-aos="slide-left">
                    <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/home/boy-character.webp') }}"
                        alt="ShopyJi Male Mascot Character" class="img-fluid">
                </div>

                <!-- Main content -->
                <div class="middle-content row gx-0" data-aos="fade-up" data-aos-delay="500">
                    <div class="col-xl-5 col-md-12 col-sm-12 content-part">
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/logo/shopyji-white-logo.svg') }}"
                            alt="ShopyJi logo" class="img-fluid" style="width: 30%;" data-aos="fade-right"
                            data-aos-delay="1000">
                        <h3 class="pt-3" data-aos="fade-up" data-aos-delay="1200">All-in-one SaaS Platform for Your
                            Ecommerce <span>Journey</span></h3>
                        <p data-aos="fade-up" data-aos-delay="1300">Check out Shopy Ji — launch your online store in just
                            2
                            minutes, packed with features to help you sell smarter and grow faster.</p>
                        <a class="custom-btn-new btn-1" href="{{ route('register') }}" data-aos="fade-up"
                            data-aos-delay="1400">Get Set Ready</a>
                    </div>
                    <div class="col-xl-7 col-md-12 col-sm-12 image-part position-relative">
                        <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/home/shopyji-panel-01.webp') }}"
                            alt="ShopyJi Panel" class="img-fluid right-offset-img" data-aos="zoom-in"
                            data-aos-delay="900">
                    </div>
                </div>
            </div>
        </section>
        <!-- Start you Ecommerce Section End -->

        <!-- Our Themes Section Start -->
        <section class="our-themes position-relative overflow-hidden">
            <div class="container py-5">

                <!-- Top Content -->
                <div class="top-content text-center pb-5" data-aos="fade-up" data-aos-delay="200">
                    <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/home/demo-coming-soon-text.svg') }}"
                        alt="ShopyJi Demo" class="img-fluid mb-3">
                    <h2 data-aos="fade-up" data-aos-delay="400">Choose a Theme, Build Your <span>Dream Store</span></h2>
                    <p class="mx-auto" data-aos="fade-up" data-aos-delay="500">
                        Beautiful, ready-to-use themes — more coming soon! Launch your store with best-in-class designs
                        crafted for speed, performance, and style.
                    </p>
                    <div class="btns-part d-flex flex-wrap justify-content-center gap-3 pt-3">
                        <a href="{{ route('mylandingpage.themes') }}" class="custom-btn-new btn-2" data-aos="fade-up"
                            data-aos-delay="400">Explore More</a>
                        <a href="{{ route('mylandingpage.contact') }}" class="custom-btn-new btn-1" data-aos="fade-up"
                            data-aos-delay="500">Want Custom?</a>
                    </div>
                </div>

                <!-- Middle Content - Themes Scrolling -->
                <div class="middle-content">

                    <!-- Slider 1 -->
                    <div class="slider-wrapper mb-4" data-aos="fade-up" data-aos-delay="300" data-aos-duration="5000">
                        <div class="slider-track scroll-right d-flex gap-3">
                            <a href="{{ route('mylandingpage.contact') }}" class="theme-card">
                                <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/themes/fashion-theme-01.webp') }}"
                                    alt="ShopyJi Fashion and Apparel Theme" class="img-fluid">
                                <h4 class="pt-3">Fashion & Apparel</h4>
                            </a>
                            <a href="{{ route('mylandingpage.contact') }}" class="theme-card">
                                <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/themes/grocery-theme-01.webp') }}"
                                    alt="ShopyJi Grocery and Essentials Theme" class="img-fluid">
                                <h4 class="pt-3">Grocery & Essentials</h4>
                            </a>
                            <a href="{{ route('mylandingpage.contact') }}" class="theme-card">
                                <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/themes/electronics-theme-01.webp') }}"
                                    alt="ShopyJi Electronics and Gadgets Theme" class="img-fluid">
                                <h4 class="pt-3">Electronics & Gadgets</h4>
                            </a>
                            <a href="{{ route('mylandingpage.contact') }}" class="theme-card">
                                <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/themes/gifting-theme-01.webp') }}"
                                    alt="ShopyJi Gifting and Toys Theme" class="img-fluid">
                                <h4 class="pt-3">Gifting & Toys</h4>
                            </a>
                            <a href="{{ route('mylandingpage.contact') }}" class="theme-card">
                                <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/themes/furniture-theme-01.webp') }}"
                                    alt="ShopyJi Home and Furniture Theme" class="img-fluid">
                                <h4 class="pt-3">Home & Furniture</h4>
                            </a>
                            <a href="{{ route('mylandingpage.contact') }}" class="theme-card">
                                <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/themes/babycare-theme-01.webp') }}"
                                    alt="ShopyJi Beauty and Personal Care Theme" class="img-fluid">
                                <h4 class="pt-3">Beauty & Personal Care</h4>
                            </a>
                        </div>
                    </div>

                    <!-- Slider 2 -->
                    <div class="slider-wrapper" data-aos="fade-up" data-aos-delay="500" data-aos-duration="5000">
                        <div class="slider-track scroll-left d-flex gap-3">
                            <a href="{{ route('mylandingpage.contact') }}" class="theme-card">
                                <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/themes/gifting-theme-01.webp') }}"
                                    alt="ShopyJi Gifting and Toys Theme" class="img-fluid">
                                <h4 class="pt-3">Gifting & Toys</h4>
                            </a>
                            <a href="{{ route('mylandingpage.contact') }}" class="theme-card">
                                <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/themes/furniture-theme-01.webp') }}"
                                    alt="ShopyJi Home and Furniture Theme" class="img-fluid">
                                <h4 class="pt-3">Home & Furniture</h4>
                            </a>
                            <a href="{{ route('mylandingpage.contact') }}" class="theme-card">
                                <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/themes/babycare-theme-01.webp') }}"
                                    alt="ShopyJi Beauty and Personal Care Theme" class="img-fluid">
                                <h4 class="pt-3">Beauty & Personal Care</h4>
                            </a>
                            <a href="{{ route('mylandingpage.contact') }}" class="theme-card">
                                <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/themes/fashion-theme-01.webp') }}"
                                    alt="ShopyJi Fashion and Apparel Theme" class="img-fluid">
                                <h4 class="pt-3">Fashion & Apparel</h4>
                            </a>
                            <a href="{{ route('mylandingpage.contact') }}" class="theme-card">
                                <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/themes/grocery-theme-01.webp') }}"
                                    alt="ShopyJi Grocery and Essentials Theme" class="img-fluid">
                                <h4 class="pt-3">Grocery & Essentials</h4>
                            </a>
                            <a href="{{ route('mylandingpage.contact') }}" class="theme-card">
                                <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/themes/electronics-theme-01.webp') }}"
                                    alt="ShopyJi Electronics and Gadgets Theme" class="img-fluid">
                                <h4 class="pt-3">Electronics & Gadgets</h4>
                            </a>
                        </div>
                    </div>

                </div>

            </div>
        </section>
        <!-- Our Themes Section End -->

        @include('my-landing-page::components.pricing_section')

        @include('my-landing-page::components.testimonial_section')

        @include('my-landing-page::components.faq_section')

        @include('my-landing-page::components.newsletter_section')

    </main>
@endsection
