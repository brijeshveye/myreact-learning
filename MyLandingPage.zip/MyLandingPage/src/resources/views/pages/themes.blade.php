@extends('my-landing-page::layouts.app')

@section('title', 'ShopyJi Themes | Ready-to-Use Online Store Designs')
@section('canonical'){{ trim(route('mylandingpage.themes')) }}@endsection
@section('description',
    'Browse Shopyji themes and choose the perfect design for your online store. Mobile-friendly,
    customizable, and built for faster sales.')
@section('keywords', 'Shopy Ji, online store, e-commerce, ecommerce themes, online store templates, shopyji themes,
    ecommerce design, mobile responsive store themes, customizable online store design')

@section('content')
    <main class="overflow-hidden">

        <!-- Our Themes Section Start -->
        <section class="our-themes position-relative overflow-hidden">
            <div class="container py-5">
                <!-- Top Content -->
                <div class="top-content text-center pb-5" data-aos="fade-up" data-aos-delay="200">
                    <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/home/demo-coming-soon-text.svg') }}"
                        alt="ShopyJi Demo" class="img-fluid mb-3">
                    <h2 data-aos="fade-up" data-aos-delay="400">Choose a Theme, Build Your <span>Dream Store</span></h2>
                    <p class="mx-auto" data-aos="fade-up" data-aos-delay="500">
                        Beautiful, ready-to-use themes — more coming soon! Launch your store with best-in-class designs
                        crafted for speed, performance, and style.
                    </p>
                    <div class="btns-part d-flex flex-wrap justify-content-center gap-3 pt-3">
                        <a href="{{ route('mylandingpage.contact') }}" class="custom-btn-new btn-2" data-aos="fade-up"
                            data-aos-delay="400">Explore
                            More</a>
                        <a href="{{ route('mylandingpage.contact') }}" class="custom-btn-new btn-1" data-aos="fade-up"
                            data-aos-delay="500">Want
                            Custom?</a>
                    </div>
                </div>

                <!-- Middle Content - Themes Grid -->
                <div class="middle-content">
                    <div class="row g-4">
                        <div class="col-12 col-sm-6 col-lg-4">
                            <a href="{{ route('mylandingpage.contact') }}" class="theme-card text-center ">
                                <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/themes/fashion-theme-01.webp') }}"
                                    alt="ShopyJi Fashion and Apparel Theme" class="img-fluid">
                                <h4 class="pt-3">Fashion & Apparel</h4>
                            </a>
                        </div>

                        <div class="col-12 col-sm-6 col-lg-4">
                            <a href="{{ route('mylandingpage.contact') }}" class="theme-card text-center ">
                                <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/themes/grocery-theme-01.webp') }}"
                                    alt="ShopyJi Grocery and Essentials Theme" class="img-fluid">
                                <h4 class="pt-3">Grocery & Essentials</h4>
                            </a>
                        </div>

                        <div class="col-12 col-sm-6 col-lg-4">
                            <a href="{{ route('mylandingpage.contact') }}" class="theme-card text-center ">
                                <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/themes/electronics-theme-01.webp') }}"
                                    alt="ShopyJi Electronics and Gadgets Theme" class="img-fluid">
                                <h4 class="pt-3">Electronics & Gadgets</h4>
                            </a>
                        </div>

                        <div class="col-12 col-sm-6 col-lg-4">
                            <a href="{{ route('mylandingpage.contact') }}" class="theme-card text-center">
                                <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/themes/gifting-theme-01.webp') }}"
                                    alt="ShopyJi Gifting and Toys Theme" class="img-fluid">
                                <h4 class="pt-3">Gifting & Toys</h4>
                            </a>
                        </div>

                        <div class="col-12 col-sm-6 col-lg-4">
                            <a href="{{ route('mylandingpage.contact') }}" class="theme-card text-center">
                                <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/themes/furniture-theme-01.webp') }}"
                                    alt="ShopyJi Home and Furniture Theme" class="img-fluid">
                                <h4 class="pt-3">Home & Furniture</h4>
                            </a>
                        </div>

                        <div class="col-12 col-sm-6 col-lg-4">
                            <a href="{{ route('mylandingpage.contact') }}" class="theme-card text-center">
                                <img src="{{ url('packages/shopyji/MyLandingPage/src/resources/assets/img/themes/babycare-theme-01.webp') }}"
                                    alt="ShopyJi Beauty and Personal Care Theme" class="img-fluid">
                                <h4 class="pt-3">Beauty & Personal Care</h4>
                            </a>
                        </div>

                    </div>
                </div>

            </div>
        </section>
        <!-- Our Themes Section End -->

        @include('my-landing-page::components.testimonial_section')

        @include('my-landing-page::components.faq_section')

        @include('my-landing-page::components.newsletter_section')

    </main>
@endsection
