@extends('my-landing-page::layouts.app')

@section('title', 'About ShopyJi | Your Trusted Online Store Partner')
@section('canonical'){{ trim(route('mylandingpage.about')) }}@endsection
@section('description', 'ShopyJi is a subscription-based e-commerce solution helping businesses create online stores
    without coding. Learn more about our mission and story.')
@section('keywords', 'Shopy Ji, online store, e-commerce, website, about Shopyji, ecommerce company, online store
    builder India, ecommerce solution provider')

@section('content')
    <main>

        @include ('my-landing-page::components.about_section')

        @include('my-landing-page::components.testimonial_section')

        @include('my-landing-page::components.faq_section')

        @include('my-landing-page::components.newsletter_section')

    </main>
@endsection
