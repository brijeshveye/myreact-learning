@extends('my-landing-page::layouts.app')

@section('title', 'Contact ShopyJi | Get Support & Start Your Online Store')
@section('canonical'){{ trim(route('mylandingpage.contact')) }}@endsection
@section('description',
    'Have questions about starting your online store with Shopyji? Contact our team for support,
    inquiries, or demo requests.')
@section('keywords', 'Shopy Ji, online store, e-commerce, contact shopyji, ecommerce support, start online store,
    ecommerce help desk, shopyji support')

@section('content')
    <main>
        @include ('my-landing-page::components.contact_section')
    </main>
@endsection
