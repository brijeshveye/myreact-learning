hello from company setting of mylandingpage
