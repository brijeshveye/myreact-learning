// Close top nav
document.getElementById('close-top-nav').addEventListener('click', () => {
    document.getElementById('top-nav').style.display = 'none';
});

// Toggle side panel
function togglePanel() {
    const panel = document.getElementById('sidePanel');
    const overlay = document.getElementById('overlay');
    const isActive = panel.classList.contains('active');

    panel.classList.toggle('active', !isActive);
    overlay.classList.toggle('active', !isActive);

    panel.style.display = isActive ? 'none' : 'block';
    overlay.style.display = isActive ? 'none' : 'block';
}

// Toggle dropdown
function toggleDropdown(event) {
    event.preventDefault();
    event.target.closest('.dropdown').classList.toggle('open');
}

// Toggle Monthly/Yearly Plan
document.querySelectorAll('.toggle-plan').forEach((button) => {
    button.addEventListener('click', function () {
        document.querySelectorAll('.toggle-plan').forEach((btn) => btn.classList.remove('active'));
        this.classList.add('active');

        const isYearly = this.dataset.plan === 'yearly';
        document.querySelectorAll('.monthly-price').forEach((e) => e.classList.toggle('d-none', isYearly));
        document.querySelectorAll('.yearly-price').forEach((e) => e.classList.toggle('d-none', !isYearly));
    });
});

// Select all Show More buttons
const showMoreBtns = document.querySelectorAll('.show-more');

showMoreBtns.forEach((button) => {
    button.addEventListener('click', function (e) {
        e.preventDefault();

        const card = this.closest('.shopyji-pricing-card');
        const extraFeatures = card.querySelectorAll('.extra-feature');
        extraFeatures.forEach((feature) => feature.classList.toggle('d-none'));
        this.textContent = this.textContent.includes('More') ? 'Show Less' : 'Show More';
    });
});

// Testimonial Slider Setup (Swiper)
new Swiper('.testimonial-slider', {
    slidesPerView: 3,
    spaceBetween: 30,
    centeredSlides: true,
    loop: true,
    loopedSlides: 5,
    speed: 3000,
    autoplay: {
        delay: 2,
        disableOnInteraction: false,
    },
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
    },
    breakpoints: {
        0: { slidesPerView: 1, centeredSlides: false, freeMode: true, loopedSlides: 1 },
        768: { slidesPerView: 2, centeredSlides: true, freeMode: true, loopedSlides: 2 },
        992: { slidesPerView: 3, centeredSlides: true, freeMode: true, loopedSlides: 3 },
        1200: { slidesPerView: 4, centeredSlides: true, freeMode: false, loopedSlides: 4 },
        1400: { slidesPerView: 4, centeredSlides: false, freeMode: false, loopedSlides: 4 },
        1920: { slidesPerView: 5, centeredSlides: false, freeMode: false, loopedSlides: 5 },
    },
});

// Toggle FAQ Answer (Show/Hide)
function toggleAnswer(element) {
    const faqItem = element.closest('.faq-item');
    faqItem.classList.toggle('active');
}
