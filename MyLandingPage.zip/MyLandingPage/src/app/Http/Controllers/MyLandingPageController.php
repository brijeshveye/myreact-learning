<?php

namespace Shopyji\MyLandingPage\app\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

class MyLandingPageController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('my-landing-page::pages.home');
    }

    public function pricing()
    {
        return view('my-landing-page::pages.pricing');
    }

    public function themes()
    {
        return view('my-landing-page::pages.themes');
    }

    public function privacy()
    {
        return view('my-landing-page::pages.terms.privacy');
    }

    public function terms()
    {
        return view('my-landing-page::pages.terms.terms');
    }

    public function refund()
    {
        return view('my-landing-page::pages.terms.refund');
    }

    public function about()
    {
        return view('my-landing-page::pages.about');
    }

    public function contact()
    {
        return view('my-landing-page::pages.contact');
    }
}
