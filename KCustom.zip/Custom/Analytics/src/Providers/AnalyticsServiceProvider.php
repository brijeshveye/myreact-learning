<?php

namespace Custom\Analytics\Providers;

use Illuminate\Support\ServiceProvider;

class AnalyticsServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        $this->loadRoutesFrom(__DIR__ . '/../../routes/api/v1/routes.php');

        // Merge ACL entries so 'analytics.view' can be assigned via roles.
        $this->mergeConfigFrom(dirname(__DIR__) . '/Config/acl.php', 'acl');

        // Merge into admin menu
        $this->mergeConfigFrom(dirname(__DIR__) . '/Config/menu.php', 'menu.admin');

        // Load admin routes
        $this->loadRoutesFrom(__DIR__ . '/../Routes/Admin/routes.php');

        // Load views with a custom namespace
        $this->loadViewsFrom(__DIR__ . '/../Resources/views', 'custom-analytics');
    }

    public function register(): void
    {
        // Configs or bindings can be registered here later.
    }
}
