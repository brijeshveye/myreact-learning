<x-admin::layouts>
    <x-slot:title>
        Analytics
    </x-slot>

    <div class="mb-5 flex items-center justify-between gap-4 max-sm:flex-wrap">
        <div class="grid gap-1.5">
            <p class="text-2xl font-semibold dark:text-white">
                Analytics
            </p>
            <p class="text-gray-600 dark:text-gray-300">
                User & Leads metrics overview
            </p>
        </div>

    <!-- Filters -->
    <v-analytics-filters></v-analytics-filters>

    <!-- Charts controller (no UI, just hooks to $emitter) -->
    <v-analytics-charts></v-analytics-charts>
    </div>

    <div class="mt-3.5 flex flex-col gap-4">
        <div class="flex gap-4 max-xl:flex-wrap">
            <div class="flex-1 rounded-lg border bg-white p-4 dark:border-gray-800 dark:bg-gray-900 h-[340px] overflow-hidden">
                <h3 class="mb-4 text-lg font-medium">Leads by User</h3>
                <div class="h-[280px]">
                    <canvas id="chart-leads-by-user" class="block w-full h-full"></canvas>
                </div>
            </div>
        </div>

        <div class="flex gap-4 max-xl:flex-wrap">
            <div class="flex-1 rounded-lg border bg-white p-4 dark:border-gray-800 dark:bg-gray-900 h-[340px] overflow-hidden">
                <div class="mb-2 flex items-center justify-between">
                    <h3 class="text-lg font-medium">Leads Updated by User</h3>
                    <span class="text-xs text-gray-500">Based on update activities</span>
                </div>
                <div class="h-[280px]">
                    <canvas id="chart-leads-updated-by-user" class="block w-full h-full"></canvas>
                </div>
            </div>
        </div>

        <div class="flex gap-4 max-xl:flex-wrap">
            <div class="flex-1 rounded-lg border bg-white p-4 dark:border-gray-800 dark:bg-gray-900 h-[340px] overflow-hidden">
                <h3 class="mb-4 text-lg font-medium">Call Activities by User</h3>
                <div class="h-[280px]">
                    <canvas id="chart-calls-by-user" class="block w-full h-full"></canvas>
                </div>
            </div>
        </div>

        <div class="flex gap-4 max-xl:flex-wrap">
            <div class="flex-1 rounded-lg border bg-white p-4 dark:border-gray-800 dark:bg-gray-900 h-[340px] overflow-hidden">
                <div class="mb-2 flex items-center justify-between gap-2">
                    <h3 class="text-lg font-medium">Activities Created by User</h3>
                    <div class="flex items-center gap-2">
                        <label for="activity-type" class="text-sm text-gray-600 dark:text-gray-300">Type:</label>
                        <select id="activity-type" class="rounded border px-2 py-1 text-sm dark:border-gray-700 dark:bg-gray-900 dark:text-gray-200">
                            <option value="">All (exclude system)</option>
                            <option value="call">Call</option>
                            <option value="meeting">Meeting</option>
                            <option value="lunch">Lunch</option>
                            <option value="email">Email</option>
                            <option value="note">Note</option>
                        </select>
                    </div>
                </div>
                <div class="h-[280px]">
                    <canvas id="chart-activities-created-by-user" class="block w-full h-full"></canvas>
                </div>
            </div>
        </div>

        <!-- Additional analytics -->
        <div class="flex gap-4 max-xl:flex-wrap">
            <div class="flex-1 rounded-lg border bg-white p-4 dark:border-gray-800 dark:bg-gray-900 h-[340px] overflow-hidden">
                <h3 class="mb-4 text-lg font-medium">Leads by Status</h3>
                <div class="h-[280px]">
                    <canvas id="chart-leads-status" class="block w-full h-full"></canvas>
                </div>
            </div>
            <div class="flex-1 rounded-lg border bg-white p-4 dark:border-gray-800 dark:bg-gray-900 h-[340px] overflow-hidden">
                <h3 class="mb-4 text-lg font-medium">Leads by Stage</h3>
                <div class="h-[280px]">
                    <canvas id="chart-leads-stage" class="block w-full h-full"></canvas>
                </div>
            </div>
        </div>

        <div class="flex gap-4 max-xl:flex-wrap">
            <div class="flex-1 rounded-lg border bg-white p-4 dark:border-gray-800 dark:bg-gray-900 h-[340px] overflow-hidden">
                <h3 class="mb-4 text-lg font-medium">Leads by Source</h3>
                <div class="h-[280px]">
                    <canvas id="chart-leads-source" class="block w-full h-full"></canvas>
                </div>
            </div>
            <div class="flex-1 rounded-lg border bg-white p-4 dark:border-gray-800 dark:bg-gray-900 h-[340px] overflow-hidden">
                <h3 class="mb-4 text-lg font-medium">Leads by Type</h3>
                <div class="h-[280px]">
                    <canvas id="chart-leads-type" class="block w-full h-full"></canvas>
                </div>
            </div>
        </div>

        <div class="flex gap-4 max-xl:flex-wrap">
            <div class="flex-1 rounded-lg border bg-white p-4 dark:border-gray-800 dark:bg-gray-900 h-[340px] overflow-hidden">
                <h3 class="mb-4 text-lg font-medium">Lead Value Sum by User</h3>
                <div class="h-[280px]">
                    <canvas id="chart-leads-value-by-user" class="block w-full h-full"></canvas>
                </div>
            </div>
            <div class="flex-1 rounded-lg border bg-white p-4 dark:border-gray-800 dark:bg-gray-900 h-[340px] overflow-hidden">
                <h3 class="mb-4 text-lg font-medium">Leads Won by User</h3>
                <div class="h-[280px]">
                    <canvas id="chart-leads-won-by-user" class="block w-full h-full"></canvas>
                </div>
            </div>
        </div>

        <div class="flex gap-4 max-xl:flex-wrap">
            <div class="flex-1 rounded-lg border bg-white p-4 dark:border-gray-800 dark:bg-gray-900 h-[340px] overflow-hidden">
                <h3 class="mb-4 text-lg font-medium">Leads Lost by User</h3>
                <div class="h-[280px]">
                    <canvas id="chart-leads-lost-by-user" class="block w-full h-full"></canvas>
                </div>
            </div>
            <div class="flex-1 rounded-lg border bg-white p-4 dark:border-gray-800 dark:bg-gray-900 h-[340px] overflow-hidden">
                <h3 class="mb-4 text-lg font-medium">Activities by Type</h3>
                <div class="h-[280px]">
                    <canvas id="chart-activities-by-type" class="block w-full h-full"></canvas>
                </div>
            </div>
        </div>

        <div class="flex gap-4 max-xl:flex-wrap">
            <div class="flex-1 rounded-lg border bg-white p-4 dark:border-gray-800 dark:bg-gray-900 h-[340px] overflow-hidden">
                <h3 class="mb-4 text-lg font-medium">Activities Done by User</h3>
                <div class="h-[280px]">
                    <canvas id="chart-activities-done-by-user" class="block w-full h-full"></canvas>
                </div>
            </div>
            <div class="flex-1 rounded-lg border bg-white p-4 dark:border-gray-800 dark:bg-gray-900 h-[340px] overflow-hidden">
                <h3 class="mb-4 text-lg font-medium">Activities Pending by User</h3>
                <div class="h-[280px]">
                    <canvas id="chart-activities-pending-by-user" class="block w-full h-full"></canvas>
                </div>
            </div>
        </div>

        <div class="flex gap-4 max-xl:flex-wrap">
            <div class="flex-1 rounded-lg border bg-white p-4 dark:border-gray-800 dark:bg-gray-900 h-[340px] overflow-hidden">
                <h3 class="mb-4 text-lg font-medium">Activity Types by User</h3>
                <div class="h-[280px]">
                    <canvas id="chart-activity-types-by-user" class="block w-full h-full"></canvas>
                </div>
            </div>
        </div>
    </div>

    @pushOnce('scripts')
        <script
            type="module"
            src="{{ vite()->asset('js/chart.js') }}"
        ></script>
        <script>
            // Fallback to CDN if vite asset didn't load Chart
            (function ensureChartGlobal(){
                var tries = 0;
                var max = 20;
                var timer = setInterval(function(){
                    if (window.Chart) { clearInterval(timer); return; }
                    tries++;
                    if (tries === 5) { // after ~500ms try to load CDN
                        var s = document.createElement('script');
                        s.src = 'https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js';
                        s.async = true;
                        document.head.appendChild(s);
                    }
                    if (tries > max) clearInterval(timer);
                }, 100);
            })();
        </script>

        <script type="text/x-template" id="v-analytics-filters-template">
            <div class="flex gap-1.5">
                <x-admin::flat-picker.date class="!w-[140px]" ::allow-input="false">
                    <input
                        class="flex min-h-[39px] w-full rounded-md border px-3 py-2 text-sm text-gray-600 transition-all hover:border-gray-400 dark:border-gray-800 dark:bg-gray-900 dark:text-gray-300 dark:hover:border-gray-400"
                        v-model="filters.start"
                        placeholder="Start date"
                    />
                </x-admin::flat-picker.date>

                <x-admin::flat-picker.date class="!w-[140px]" ::allow-input="false">
                    <input
                        class="flex min-h-[39px] w-full rounded-md border px-3 py-2 text-sm text-gray-600 transition-all hover:border-gray-400 dark:border-gray-800 dark:bg-gray-900 dark:text-gray-300 dark:hover:border-gray-400"
                        v-model="filters.end"
                        placeholder="End date"
                    />
                </x-admin::flat-picker.date>
            </div>
        </script>

        <script type="module">
            // Simple helper
            const buildUrl = (base, path, params = {}) => {
                const url = new URL(base.replace(/\/$/, '') + '/' + path.replace(/^\//, ''), window.location.origin);
                Object.entries(params).forEach(([k, v]) => { if (v !== undefined && v !== null && v !== '') url.searchParams.set(k, v) });
                return url.toString();
            };

            // Dashboard registers components directly; follow same pattern

            function barColors(n) {
                const palette = ['#4f46e5','#06b6d4','#10b981','#f59e0b','#ef4444','#8b5cf6','#22c55e','#14b8a6','#eab308','#f97316'];
                return Array.from({length: n}, (_, i) => palette[i % palette.length]);
            }

            const base = '{{ url(config("app.admin_path")) }}';

            let charts = {
                leadsByUser: null,
                leadsUpdatedByUser: null,
                callsByUser: null,
                activitiesCreatedByUser: null,
                leadsStatus: null,
                leadsStage: null,
                leadsSource: null,
                leadsType: null,
                leadsValueByUser: null,
                leadsWonByUser: null,
                leadsLostByUser: null,
                activitiesByType: null,
                activitiesDoneByUser: null,
                activitiesPendingByUser: null,
                activityTypesByUser: null,
            };

            function normalizeSeries(labels, data) {
                if (!labels || labels.length === 0) {
                    return { labels: ['No data'], data: [0], placeholder: true };
                }
                return { labels, data, placeholder: false };
            }

            async function renderBarChart(ctxId, labels, data, label) {
                const norm = normalizeSeries(labels, data);
                const ctx = document.getElementById(ctxId).getContext('2d');
                const dataset = { label, data: norm.data, backgroundColor: barColors(norm.data.length), barPercentage: 0.8, categoryPercentage: 0.7 };

                const noDataPlugin = {
                    id: 'noData',
                    afterDraw(chart, args, opts) {
                        const datasets = chart.data?.datasets || [];
                        const sum = datasets.reduce((s, ds) => s + (ds.data || []).reduce((a, b) => a + (+b || 0), 0), 0);
                        const isEmpty = !datasets.length || sum === 0;
                        if (!isEmpty) return;
                        const { ctx, chartArea } = chart;
                        if (!chartArea) return;
                        ctx.save();
                        ctx.font = '12px system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial';
                        ctx.fillStyle = '#6b7280';
                        ctx.textAlign = 'center';
                        ctx.textBaseline = 'middle';
                        const msg = (opts && opts.message) || 'No data';
                        ctx.fillText(msg, (chartArea.left + chartArea.right) / 2, (chartArea.top + chartArea.bottom) / 2);
                        ctx.restore();
                    }
                };

                // Set some safe defaults once Chart is available
                if (window.Chart) {
                    Chart.defaults.responsive = true;
                    Chart.defaults.maintainAspectRatio = false;
                    Chart.defaults.resizeDelay = 200;
                    Chart.defaults.animation = false;
                }

                const config = {
                    type: 'bar',
                    data: { labels: norm.labels, datasets: [dataset] },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        resizeDelay: 200,
                        animation: false,
                        plugins: {
                            legend: { display: false },
                            noData: { message: 'No data for selected range' }
                        },
                        scales: {
                            y: { beginAtZero: true, ticks: { precision: 0 } },
                            x: { ticks: { autoSkip: false } }
                        }
                    },
                    plugins: [noDataPlugin]
                };

                return new Chart(ctx, config);
            }

            async function renderStackedBarChart(ctxId, labels, datasets) {
                const ctx = document.getElementById(ctxId).getContext('2d');

                const noDataPlugin = {
                    id: 'noData',
                    afterDraw(chart, args, opts) {
                        const datasets = chart.data?.datasets || [];
                        const sum = datasets.reduce((s, ds) => s + (ds.data || []).reduce((a, b) => a + (+b || 0), 0), 0);
                        if (sum > 0) return;
                        const { ctx, chartArea } = chart;
                        if (!chartArea) return;
                        ctx.save();
                        ctx.font = '12px system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial';
                        ctx.fillStyle = '#6b7280';
                        ctx.textAlign = 'center';
                        ctx.textBaseline = 'middle';
                        ctx.fillText('No data for selected range', (chartArea.left + chartArea.right) / 2, (chartArea.top + chartArea.bottom) / 2);
                        ctx.restore();
                    }
                };

                if (window.Chart) {
                    Chart.defaults.responsive = true;
                    Chart.defaults.maintainAspectRatio = false;
                    Chart.defaults.resizeDelay = 200;
                    Chart.defaults.animation = false;
                }

                const config = {
                    type: 'bar',
                    data: { labels, datasets },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        resizeDelay: 200,
                        animation: false,
                        plugins: { legend: { display: true }, noData: { } },
                        scales: {
                            x: { stacked: true, ticks: { autoSkip: false } },
                            y: { stacked: true, beginAtZero: true, ticks: { precision: 0 } }
                        }
                    },
                    plugins: [noDataPlugin]
                };

                return new Chart(ctx, config);
            }

            function updateChart(chart, labels, data, label) {
                const norm = normalizeSeries(labels, data);
                chart.data.labels = norm.labels;
                chart.data.datasets[0].label = label;
                chart.data.datasets[0].data = norm.data;
                chart.data.datasets[0].backgroundColor = barColors(norm.data.length);
                chart.update('none');
            }

            async function fetchRows(path, params = {}) {
                const url = buildUrl(base, path, params);
                const res = await fetch(url, {
                    headers: { 'Accept': 'application/json' },
                    credentials: 'same-origin'
                });
                if (!res.ok) throw new Error('Request failed: ' + res.status + ' for ' + url);
                const contentType = res.headers.get('content-type') || '';
                if (!contentType.includes('application/json')) {
                    console.warn('Non-JSON response for', url);
                    return [];
                }
                const json = await res.json();
                return Array.isArray(json.rows) ? json.rows : [];
            }

            async function refreshAll(filters) {
                const { start, end } = filters;
                const activityType = document.getElementById('activity-type').value;

                // Leads by user
                const leadsRows = await fetchRows('analytics/data/leads/counts-by-user', { start, end });
                const leadsLabels = Array.isArray(leadsRows) ? leadsRows.map(r => r.user_name || ('User #' + r.user_id)) : [];
                const leadsData = Array.isArray(leadsRows) ? leadsRows.map(r => r.total) : [];
                if (!charts.leadsByUser) charts.leadsByUser = await renderBarChart('chart-leads-by-user', leadsLabels, leadsData, 'Leads');
                else updateChart(charts.leadsByUser, leadsLabels, leadsData, 'Leads');

                // Leads updated by user
                const updatedRows = await fetchRows('analytics/data/leads/updated-by-user', { start, end });
                const updatedLabels = Array.isArray(updatedRows) ? updatedRows.map(r => r.user_name || ('User #' + r.user_id)) : [];
                const updatedData = Array.isArray(updatedRows) ? updatedRows.map(r => r.total) : [];
                if (!charts.leadsUpdatedByUser) charts.leadsUpdatedByUser = await renderBarChart('chart-leads-updated-by-user', updatedLabels, updatedData, 'Updated Leads');
                else updateChart(charts.leadsUpdatedByUser, updatedLabels, updatedData, 'Updated Leads');

                // Calls by user
                const callRows = await fetchRows('analytics/data/activities/call-by-user', { start, end });
                const callLabels = Array.isArray(callRows) ? callRows.map(r => r.user_name || ('User #' + r.user_id)) : [];
                const callData = Array.isArray(callRows) ? callRows.map(r => r.total) : [];
                if (!charts.callsByUser) charts.callsByUser = await renderBarChart('chart-calls-by-user', callLabels, callData, 'Calls');
                else updateChart(charts.callsByUser, callLabels, callData, 'Calls');

                // Activities created by user
                const createdRows = await fetchRows('analytics/data/activities/created-by-user', { start, end, type: activityType });
                const createdLabels = Array.isArray(createdRows) ? createdRows.map(r => r.user_name || ('User #' + r.user_id)) : [];
                const createdData = Array.isArray(createdRows) ? createdRows.map(r => r.total) : [];
                if (!charts.activitiesCreatedByUser) charts.activitiesCreatedByUser = await renderBarChart('chart-activities-created-by-user', createdLabels, createdData, 'Activities');
                else updateChart(charts.activitiesCreatedByUser, createdLabels, createdData, 'Activities');

                // Leads by status
                const statusRows = await fetchRows('analytics/data/leads/status-counts', { start, end });
                const statusLabels = Array.isArray(statusRows) ? statusRows.map(r => r.status || 'Unknown') : [];
                const statusData = Array.isArray(statusRows) ? statusRows.map(r => r.total) : [];
                if (!charts.leadsStatus) charts.leadsStatus = await renderBarChart('chart-leads-status', statusLabels, statusData, 'Leads');
                else updateChart(charts.leadsStatus, statusLabels, statusData, 'Leads');

                // Leads by stage
                const stageRows = await fetchRows('analytics/data/leads/stage-counts', { start, end });
                const stageLabels = Array.isArray(stageRows) ? stageRows.map(r => r.stage_name || r.stage_code || ('Stage #' + r.stage_id)) : [];
                const stageData = Array.isArray(stageRows) ? stageRows.map(r => r.total) : [];
                if (!charts.leadsStage) charts.leadsStage = await renderBarChart('chart-leads-stage', stageLabels, stageData, 'Leads');
                else updateChart(charts.leadsStage, stageLabels, stageData, 'Leads');

                // Leads by source
                const sourceRows = await fetchRows('analytics/data/leads/source-counts', { start, end });
                const sourceLabels = Array.isArray(sourceRows) ? sourceRows.map(r => r.source_name || ('Source #' + r.source_id)) : [];
                const sourceData = Array.isArray(sourceRows) ? sourceRows.map(r => r.total) : [];
                if (!charts.leadsSource) charts.leadsSource = await renderBarChart('chart-leads-source', sourceLabels, sourceData, 'Leads');
                else updateChart(charts.leadsSource, sourceLabels, sourceData, 'Leads');

                // Leads by type
                const typeRows = await fetchRows('analytics/data/leads/type-counts', { start, end });
                const typeLabels = Array.isArray(typeRows) ? typeRows.map(r => r.type_name || ('Type #' + r.type_id)) : [];
                const typeData = Array.isArray(typeRows) ? typeRows.map(r => r.total) : [];
                if (!charts.leadsType) charts.leadsType = await renderBarChart('chart-leads-type', typeLabels, typeData, 'Leads');
                else updateChart(charts.leadsType, typeLabels, typeData, 'Leads');

                // Lead value sum by user
                const valueRows = await fetchRows('analytics/data/leads/value-sum-by-user', { start, end });
                const valueLabels = Array.isArray(valueRows) ? valueRows.map(r => r.user_name || ('User #' + r.user_id)) : [];
                const valueData = Array.isArray(valueRows) ? valueRows.map(r => r.total_value) : [];
                if (!charts.leadsValueByUser) charts.leadsValueByUser = await renderBarChart('chart-leads-value-by-user', valueLabels, valueData, 'Total Value');
                else updateChart(charts.leadsValueByUser, valueLabels, valueData, 'Total Value');

                // Leads won by user
                const wonRows = await fetchRows('analytics/data/leads/won-by-user', { start, end });
                const wonLabels = Array.isArray(wonRows) ? wonRows.map(r => r.user_name || ('User #' + r.user_id)) : [];
                const wonData = Array.isArray(wonRows) ? wonRows.map(r => r.total) : [];
                if (!charts.leadsWonByUser) charts.leadsWonByUser = await renderBarChart('chart-leads-won-by-user', wonLabels, wonData, 'Won');
                else updateChart(charts.leadsWonByUser, wonLabels, wonData, 'Won');

                // Leads lost by user
                const lostRows = await fetchRows('analytics/data/leads/lost-by-user', { start, end });
                const lostLabels = Array.isArray(lostRows) ? lostRows.map(r => r.user_name || ('User #' + r.user_id)) : [];
                const lostData = Array.isArray(lostRows) ? lostRows.map(r => r.total) : [];
                if (!charts.leadsLostByUser) charts.leadsLostByUser = await renderBarChart('chart-leads-lost-by-user', lostLabels, lostData, 'Lost');
                else updateChart(charts.leadsLostByUser, lostLabels, lostData, 'Lost');

                // Activities by type
                const abtRows = await fetchRows('analytics/data/activities/by-type', { start, end });
                const abtLabels = Array.isArray(abtRows) ? abtRows.map(r => r.type || 'Unknown') : [];
                const abtData = Array.isArray(abtRows) ? abtRows.map(r => r.total) : [];
                if (!charts.activitiesByType) charts.activitiesByType = await renderBarChart('chart-activities-by-type', abtLabels, abtData, 'Activities');
                else updateChart(charts.activitiesByType, abtLabels, abtData, 'Activities');

                // Activities done by user
                const doneRows = await fetchRows('analytics/data/activities/done-by-user', { start, end });
                const doneLabels = Array.isArray(doneRows) ? doneRows.map(r => r.user_name || ('User #' + r.user_id)) : [];
                const doneData = Array.isArray(doneRows) ? doneRows.map(r => r.total) : [];
                if (!charts.activitiesDoneByUser) charts.activitiesDoneByUser = await renderBarChart('chart-activities-done-by-user', doneLabels, doneData, 'Done');
                else updateChart(charts.activitiesDoneByUser, doneLabels, doneData, 'Done');

                // Activities pending by user
                const pendingRows = await fetchRows('analytics/data/activities/pending-by-user', { start, end });
                const pendingLabels = Array.isArray(pendingRows) ? pendingRows.map(r => r.user_name || ('User #' + r.user_id)) : [];
                const pendingData = Array.isArray(pendingRows) ? pendingRows.map(r => r.total) : [];
                if (!charts.activitiesPendingByUser) charts.activitiesPendingByUser = await renderBarChart('chart-activities-pending-by-user', pendingLabels, pendingData, 'Pending');
                else updateChart(charts.activitiesPendingByUser, pendingLabels, pendingData, 'Pending');

                // Activity types by user (stacked)
                const tbuRows = await fetchRows('analytics/data/activities/types-by-user', { start, end });
                const tbuLabels = Array.isArray(tbuRows) ? tbuRows.map(r => r.user_name || ('User #' + r.user_id)) : [];
                // Gather all types across rows to ensure consistent stacks
                const allTypes = Array.from(new Set([].concat(...(tbuRows.map(r => Object.keys(r.types || {}))))));
                const datasets = allTypes.map((type, idx) => ({
                    label: type,
                    data: tbuRows.map(r => (r.types && r.types[type]) ? r.types[type] : 0),
                    backgroundColor: barColors(allTypes.length)[idx % allTypes.length]
                }));
                if (!charts.activityTypesByUser) charts.activityTypesByUser = await renderStackedBarChart('chart-activity-types-by-user', tbuLabels, datasets);
                else {
                    charts.activityTypesByUser.data.labels = tbuLabels;
                    charts.activityTypesByUser.data.datasets = datasets;
                    charts.activityTypesByUser.update('none');
                }
            }

            // Vue component for filters
            app.component('v-analytics-filters', {
                template: '#v-analytics-filters-template',
                data() {
                    const end = new Date();
                    const start = new Date();
                    start.setDate(end.getDate() - 29);
                    const toYMD = (d) => d.toISOString().slice(0,10);
                    return { filters: { start: toYMD(start), end: toYMD(end) } };
                },
                watch: {
                    filters: {
                        handler() { this.$emitter.emit('analytics-filter-updated', this.filters); },
                        deep: true
                    }
                },
                mounted() {
                    // Emit after mount to avoid racing the charts listener
                    if (this.$nextTick) {
                        this.$nextTick(() => this.$emitter.emit('analytics-filter-updated', this.filters));
                    } else {
                        setTimeout(() => this.$emitter.emit('analytics-filter-updated', this.filters), 0);
                    }
                }
            });

            // Controller component to listen via this.$emitter (matches dashboard pattern)
            app.component('v-analytics-charts', {
                template: '<div></div>',
                data: () => ({ lastFilters: null, initTimer: null }),
                mounted() {
                    this.$emitter.on('analytics-filter-updated', (filters) => {
                        this.lastFilters = filters;
                        setTimeout(() => refreshAll(filters).catch(console.error), 0);
                    });

                    document.addEventListener('change', this.onTypeChange);

                    // Kickstart on first load in case filters emit fires before we subscribe
                    this.initTimer = setTimeout(() => {
                        if (!this.lastFilters) {
                            const end = new Date();
                            const start = new Date();
                            start.setDate(end.getDate() - 29);
                            const toYMD = (d) => d.toISOString().slice(0,10);
                            const initial = { start: toYMD(start), end: toYMD(end) };
                            this.lastFilters = initial;
                            refreshAll(initial).catch(console.error);
                        }
                    }, 0);
                },
                beforeUnmount() {
                    document.removeEventListener('change', this.onTypeChange);
                    if (this.initTimer) clearTimeout(this.initTimer);
                },
                methods: {
                    onTypeChange(e) {
                        if (e.target && e.target.id === 'activity-type' && this.lastFilters) {
                            refreshAll(this.lastFilters).catch(console.error);
                        }
                    }
                }
            });
        </script>
    @endPushOnce
</x-admin::layouts>
