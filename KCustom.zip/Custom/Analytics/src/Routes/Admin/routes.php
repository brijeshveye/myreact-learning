<?php

use Illuminate\Support\Facades\Route;
use Custom\Analytics\Http\Controllers\Admin\AnalyticsController;

Route::group(['middleware' => ['web', 'admin_locale', 'user'], 'prefix' => config('app.admin_path')], function () {
    Route::get('analytics', [AnalyticsController::class, 'index'])->name('admin.analytics.index');

    // Admin JSON endpoints (session-authenticated)
    Route::get('analytics/data/users/summary', [AnalyticsController::class, 'usersSummary'])->name('admin.analytics.data.users.summary');
    Route::get('analytics/data/users/registrations', [AnalyticsController::class, 'usersRegistrations'])->name('admin.analytics.data.users.registrations');
    Route::get('analytics/data/leads/by-user', [AnalyticsController::class, 'leadsByUser'])->name('admin.analytics.data.leads.by_user');
    Route::get('analytics/data/leads/counts-by-user', [AnalyticsController::class, 'leadsCountsByUser'])->name('admin.analytics.data.leads.counts_by_user');
    Route::get('analytics/data/leads/updated-by-user', [AnalyticsController::class, 'leadsUpdatedByUser'])->name('admin.analytics.data.leads.updated_by_user');
    Route::get('analytics/data/activities/call-by-user', [AnalyticsController::class, 'callActivitiesByUser'])->name('admin.analytics.data.activities.call_by_user');
    Route::get('analytics/data/activities/created-by-user', [AnalyticsController::class, 'activitiesCreatedByUser'])->name('admin.analytics.data.activities.created_by_user');
    Route::get('analytics/data/activities/types-by-user', [AnalyticsController::class, 'activitiesTypesByUser'])->name('admin.analytics.data.activities.types_by_user');

    // New analytics endpoints
    Route::get('analytics/data/leads/status-counts', [AnalyticsController::class, 'leadsStatusCounts'])->name('admin.analytics.data.leads.status_counts');
    Route::get('analytics/data/leads/stage-counts', [AnalyticsController::class, 'leadsStageCounts'])->name('admin.analytics.data.leads.stage_counts');
    Route::get('analytics/data/leads/source-counts', [AnalyticsController::class, 'leadsSourceCounts'])->name('admin.analytics.data.leads.source_counts');
    Route::get('analytics/data/leads/type-counts', [AnalyticsController::class, 'leadsTypeCounts'])->name('admin.analytics.data.leads.type_counts');
    Route::get('analytics/data/leads/value-sum-by-user', [AnalyticsController::class, 'leadsValueSumByUser'])->name('admin.analytics.data.leads.value_sum_by_user');
    Route::get('analytics/data/leads/won-by-user', [AnalyticsController::class, 'leadsWonByUser'])->name('admin.analytics.data.leads.won_by_user');
    Route::get('analytics/data/leads/lost-by-user', [AnalyticsController::class, 'leadsLostByUser'])->name('admin.analytics.data.leads.lost_by_user');
    Route::get('analytics/data/activities/by-type', [AnalyticsController::class, 'activitiesByType'])->name('admin.analytics.data.activities.by_type');
    Route::get('analytics/data/activities/done-by-user', [AnalyticsController::class, 'activitiesDoneByUser'])->name('admin.analytics.data.activities.done_by_user');
    Route::get('analytics/data/activities/pending-by-user', [AnalyticsController::class, 'activitiesPendingByUser'])->name('admin.analytics.data.activities.pending_by_user');
});
