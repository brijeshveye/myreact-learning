<?php

return [
    [
        'key'        => 'analytics',
        'name'       => 'Analytics',
        'route'      => 'admin.analytics.index',
        'sort'       => 9,
        'icon-class' => 'icon-activity',
    ],
];
