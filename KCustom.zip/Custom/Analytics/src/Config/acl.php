<?php

return [
    [
        'key'   => 'analytics',
        'name'  => 'Analytics',
        'route' => 'analytics',
        'sort'  => 7,
    ],
    [
        'key'   => 'analytics.view',
        'name'  => 'View Analytics',
        'route' => 'analytics.view',
        'sort'  => 1,
    ],
];
