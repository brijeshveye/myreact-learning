<?php

namespace Custom\Analytics\Http\Controllers\V1;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller as BaseController;
use Webkul\Lead\Models\Lead;
use Webkul\Lead\Models\Stage;
use Webkul\Lead\Models\Source;
use Webkul\Lead\Models\Type;
use Webkul\Activity\Models\Activity;
use Webkul\User\Models\Role;
use Webkul\User\Models\User;

class AnalyticsController extends BaseController
{
    private function authorizeAnalytics(Request $request): void
    {
        $user = $request->user();

        // If role/permissions system is enabled, require a permission like 'analytics.view'
        // if (method_exists($user, 'hasPermission')) {
        //     if (! $user->hasPermission('analytics.view')) {
        //         abort(403, 'Unauthorized');
        //     }
        // }
    }

    /**
     * Helper to get start/end Carbon dates from request; defaults to last N days.
     */
    private function getDateRange(Request $request, int $defaultDays = 30): array
    {
        $startParam = $request->query('start');
        $endParam = $request->query('end');

        if ($startParam && $endParam) {
            try {
                $start = Carbon::parse($startParam)->startOfDay();
                $end = Carbon::parse($endParam)->endOfDay();
                return [$start, $end];
            } catch (\Throwable $e) {
                // fall through to default
            }
        }

        $end = Carbon::today()->endOfDay();
        $start = Carbon::today()->subDays($defaultDays - 1)->startOfDay();
        return [$start, $end];
    }

    /**
     * GET /api/v1/analytics/users/summary
     */
    public function usersSummary(Request $request)
    {
        $this->authorizeAnalytics($request);
        $totalUsers = User::count();

        $active7d = User::where('updated_at', '>=', Carbon::now()->subDays(7))->count();
        $active30d = User::where('updated_at', '>=', Carbon::now()->subDays(30))->count();

        $byRole = Role::withCount('users')->get()->map(fn($r) => [
            'role' => $r->name,
            'count' => $r->users_count,
        ]);

        return response()->json([
            'total' => $totalUsers,
            'active_last_7d' => $active7d,
            'active_last_30d' => $active30d,
            'by_role' => $byRole,
        ]);
    }

    /**
     * GET /api/v1/analytics/users/registrations
     * Query: range=7|30|90 default 30
     */
    public function usersRegistrations(Request $request)
    {
        $this->authorizeAnalytics($request);
        $days = (int) ($request->query('range', 30));
        $days = in_array($days, [7, 30, 90]) ? $days : 30;

        $start = Carbon::today()->subDays($days - 1);

        $registrations = User::selectRaw('DATE(created_at) as date, COUNT(*) as count')
            ->where('created_at', '>=', $start)
            ->groupBy('date')
            ->orderBy('date')
            ->get()
            ->keyBy('date')
            ->map(fn($r) => (int) $r->count);

        $series = [];
        for ($i = 0; $i < $days; $i++) {
            $d = $start->copy()->addDays($i)->toDateString();
            $series[] = [
                'date' => $d,
                'count' => (int) ($registrations[$d] ?? 0),
            ];
        }

        return response()->json([
            'range_days' => $days,
            'series' => $series,
        ]);
    }

    /**
     * GET /api/v1/analytics/leads/by-user
     * Query: range=30|90|365 default 30
     */
    public function leadsByUser(Request $request)
    {
        $this->authorizeAnalytics($request);
        $days = (int) ($request->query('range', 30));
        $days = in_array($days, [30, 90, 365]) ? $days : 30;
        $since = Carbon::now()->subDays($days);

        $rows = Lead::selectRaw('user_id, COUNT(*) as total')
            ->where('created_at', '>=', $since)
            ->groupBy('user_id')
            ->with('user:id,name')
            ->orderByDesc('total')
            ->get()
            ->map(fn($r) => [
                'user_id' => $r->user_id,
                'user_name' => optional($r->user)->name,
                'total' => (int) $r->total,
            ]);

        return response()->json([
            'range_days' => $days,
            'rows' => $rows,
        ]);
    }

    /**
     * GET /api/v1/analytics/leads/counts-by-user?start=YYYY-MM-DD&end=YYYY-MM-DD
     */
    public function leadsCountsByUser(Request $request)
    {
        $this->authorizeAnalytics($request);

        [$start, $end] = $this->getDateRange($request, 30);

        $rows = Lead::selectRaw('user_id, COUNT(*) as total')
            ->when($start, fn($q) => $q->whereDate('created_at', '>=', $start))
            ->when($end, fn($q) => $q->whereDate('created_at', '<=', $end))
            ->groupBy('user_id')
            ->with('user:id,name')
            ->orderByDesc('total')
            ->get()
            ->map(fn($r) => [
                'user_id' => $r->user_id,
                'user_name' => optional($r->user)->name,
                'total' => (int) $r->total,
            ]);

        return response()->json(['rows' => $rows, 'start' => $start?->toDateString(), 'end' => $end?->toDateString()]);
    }

    /**
     * GET /api/v1/analytics/leads/updated-by-user?start=YYYY-MM-DD&end=YYYY-MM-DD
     * Count distinct leads that were updated (activities with additional JSON) by each user
     */
    public function leadsUpdatedByUser(Request $request)
    {
        $this->authorizeAnalytics($request);

        [$start, $end] = $this->getDateRange($request, 30);

        $rows = Activity::query()
            ->selectRaw('activities.user_id, COUNT(DISTINCT lead_activities.lead_id) as total')
            ->join('lead_activities', 'lead_activities.activity_id', '=', 'activities.id')
            ->whereNotNull('activities.user_id')
            ->whereNotNull('activities.additional')
            ->when($start, fn($q) => $q->whereDate('activities.created_at', '>=', $start))
            ->when($end, fn($q) => $q->whereDate('activities.created_at', '<=', $end))
            ->groupBy('activities.user_id')
            ->with('user:id,name')
            ->orderByDesc('total')
            ->get()
            ->map(fn($r) => [
                'user_id' => $r->user_id,
                'user_name' => optional($r->user)->name,
                'total' => (int) $r->total,
            ]);

        return response()->json(['rows' => $rows, 'start' => $start?->toDateString(), 'end' => $end?->toDateString()]);
    }

    /**
     * GET /api/v1/analytics/activities/call-by-user?start=YYYY-MM-DD&end=YYYY-MM-DD
     */
    public function callActivitiesByUser(Request $request)
    {
        $this->authorizeAnalytics($request);

        [$start, $end] = $this->getDateRange($request, 30);

        $rows = Activity::query()
            ->selectRaw('user_id, COUNT(*) as total')
            ->where('type', 'call')
            ->whereNotNull('user_id')
            ->when($start, fn($q) => $q->whereDate('created_at', '>=', $start))
            ->when($end, fn($q) => $q->whereDate('created_at', '<=', $end))
            ->groupBy('user_id')
            ->with('user:id,name')
            ->orderByDesc('total')
            ->get()
            ->map(fn($r) => [
                'user_id' => $r->user_id,
                'user_name' => optional($r->user)->name,
                'total' => (int) $r->total,
            ]);

        return response()->json(['rows' => $rows, 'start' => $start?->toDateString(), 'end' => $end?->toDateString()]);
    }

    /**
     * GET /api/v1/analytics/activities/created-by-user?start=YYYY-MM-DD&end=YYYY-MM-DD[&type=call]
     * By default excludes system-generated activities
     */
    public function activitiesCreatedByUser(Request $request)
    {
        $this->authorizeAnalytics($request);

        [$start, $end] = $this->getDateRange($request, 30);
        $type = $request->query('type');

        $query = Activity::query()
            ->selectRaw('user_id, COUNT(*) as total')
            ->whereNotNull('user_id')
            ->when($type, fn($q) => $q->where('type', $type), fn($q) => $q->where('type', '!=', 'system'))
            ->when($start, fn($q) => $q->whereDate('created_at', '>=', $start))
            ->when($end, fn($q) => $q->whereDate('created_at', '<=', $end))
            ->groupBy('user_id')
            ->with('user:id,name')
            ->orderByDesc('total');

        $rows = $query->get()->map(fn($r) => [
            'user_id' => $r->user_id,
            'user_name' => optional($r->user)->name,
            'total' => (int) $r->total,
        ]);

        return response()->json(['rows' => $rows, 'start' => $start?->toDateString(), 'end' => $end?->toDateString(), 'type' => $type]);
    }

    /**
     * GET /api/v1/analytics/leads/status-counts?start=YYYY-MM-DD&end=YYYY-MM-DD
     */
    public function leadsStatusCounts(Request $request)
    {
        $this->authorizeAnalytics($request);

        [$start, $end] = $this->getDateRange($request, 30);

        $rows = Lead::query()
            ->selectRaw('status, COUNT(*) as total')
            ->when($start, fn($q) => $q->whereDate('created_at', '>=', $start))
            ->when($end, fn($q) => $q->whereDate('created_at', '<=', $end))
            ->groupBy('status')
            ->orderByDesc('total')
            ->get()
            ->map(fn($r) => [
                'status' => (string) $r->status,
                'total'  => (int) $r->total,
            ]);

        return response()->json(['rows' => $rows, 'start' => $start?->toDateString(), 'end' => $end?->toDateString()]);
    }

    /**
     * GET /api/v1/analytics/leads/stage-counts?start=YYYY-MM-DD&end=YYYY-MM-DD
     */
    public function leadsStageCounts(Request $request)
    {
        $this->authorizeAnalytics($request);

        [$start, $end] = $this->getDateRange($request, 30);

        $rows = Lead::query()
            ->selectRaw('lead_pipeline_stage_id as stage_id, COUNT(*) as total')
            ->when($start, fn($q) => $q->whereDate('created_at', '>=', $start))
            ->when($end, fn($q) => $q->whereDate('created_at', '<=', $end))
            ->groupBy('lead_pipeline_stage_id')
            ->with(['stage:id,name,code'])
            ->orderByDesc('total')
            ->get()
            ->map(fn($r) => [
                'stage_id'   => $r->stage_id,
                'stage_name' => optional($r->stage)->name,
                'stage_code' => optional($r->stage)->code,
                'total'      => (int) $r->total,
            ]);

        return response()->json(['rows' => $rows, 'start' => $start?->toDateString(), 'end' => $end?->toDateString()]);
    }

    /**
     * GET /api/v1/analytics/leads/source-counts?start=YYYY-MM-DD&end=YYYY-MM-DD
     */
    public function leadsSourceCounts(Request $request)
    {
        $this->authorizeAnalytics($request);

        [$start, $end] = $this->getDateRange($request, 30);

        $rows = Lead::query()
            ->selectRaw('lead_source_id as source_id, COUNT(*) as total')
            ->when($start, fn($q) => $q->whereDate('created_at', '>=', $start))
            ->when($end, fn($q) => $q->whereDate('created_at', '<=', $end))
            ->groupBy('lead_source_id')
            ->with(['source:id,name'])
            ->orderByDesc('total')
            ->get()
            ->map(fn($r) => [
                'source_id'   => $r->source_id,
                'source_name' => optional($r->source)->name,
                'total'       => (int) $r->total,
            ]);

        return response()->json(['rows' => $rows, 'start' => $start?->toDateString(), 'end' => $end?->toDateString()]);
    }

    /**
     * GET /api/v1/analytics/leads/type-counts?start=YYYY-MM-DD&end=YYYY-MM-DD
     */
    public function leadsTypeCounts(Request $request)
    {
        $this->authorizeAnalytics($request);

        [$start, $end] = $this->getDateRange($request, 30);

        $rows = Lead::query()
            ->selectRaw('lead_type_id as type_id, COUNT(*) as total')
            ->when($start, fn($q) => $q->whereDate('created_at', '>=', $start))
            ->when($end, fn($q) => $q->whereDate('created_at', '<=', $end))
            ->groupBy('lead_type_id')
            ->with(['type:id,name'])
            ->orderByDesc('total')
            ->get()
            ->map(fn($r) => [
                'type_id'   => $r->type_id,
                'type_name' => optional($r->type)->name,
                'total'     => (int) $r->total,
            ]);

        return response()->json(['rows' => $rows, 'start' => $start?->toDateString(), 'end' => $end?->toDateString()]);
    }

    /**
     * GET /api/v1/analytics/leads/value-sum-by-user?start=YYYY-MM-DD&end=YYYY-MM-DD
     */
    public function leadsValueSumByUser(Request $request)
    {
        $this->authorizeAnalytics($request);

        [$start, $end] = $this->getDateRange($request, 30);

        $rows = Lead::query()
            ->selectRaw('user_id, COALESCE(SUM(lead_value),0) as total_value')
            ->when($start, fn($q) => $q->whereDate('created_at', '>=', $start))
            ->when($end, fn($q) => $q->whereDate('created_at', '<=', $end))
            ->groupBy('user_id')
            ->with('user:id,name')
            ->orderByDesc('total_value')
            ->get()
            ->map(fn($r) => [
                'user_id'    => $r->user_id,
                'user_name'  => optional($r->user)->name,
                'total_value'=> (float) $r->total_value,
            ]);

        return response()->json(['rows' => $rows, 'start' => $start?->toDateString(), 'end' => $end?->toDateString()]);
    }

    /**
     * GET /api/v1/analytics/leads/won-by-user?start=YYYY-MM-DD&end=YYYY-MM-DD
     */
    public function leadsWonByUser(Request $request)
    {
        $this->authorizeAnalytics($request);

        [$start, $end] = $this->getDateRange($request, 30);

        $rows = Lead::query()
            ->selectRaw('user_id, COUNT(*) as total')
            ->when($start, fn($q) => $q->whereDate('created_at', '>=', $start))
            ->when($end, fn($q) => $q->whereDate('created_at', '<=', $end))
            ->whereHas('stage', fn($q) => $q->where('code', 'won'))
            ->groupBy('user_id')
            ->with('user:id,name')
            ->orderByDesc('total')
            ->get()
            ->map(fn($r) => [
                'user_id'   => $r->user_id,
                'user_name' => optional($r->user)->name,
                'total'     => (int) $r->total,
            ]);

        return response()->json(['rows' => $rows, 'start' => $start?->toDateString(), 'end' => $end?->toDateString()]);
    }

    /**
     * GET /api/v1/analytics/leads/lost-by-user?start=YYYY-MM-DD&end=YYYY-MM-DD
     */
    public function leadsLostByUser(Request $request)
    {
        $this->authorizeAnalytics($request);

        [$start, $end] = $this->getDateRange($request, 30);

        $rows = Lead::query()
            ->selectRaw('user_id, COUNT(*) as total')
            ->when($start, fn($q) => $q->whereDate('created_at', '>=', $start))
            ->when($end, fn($q) => $q->whereDate('created_at', '<=', $end))
            ->whereHas('stage', fn($q) => $q->where('code', 'lost'))
            ->groupBy('user_id')
            ->with('user:id,name')
            ->orderByDesc('total')
            ->get()
            ->map(fn($r) => [
                'user_id'   => $r->user_id,
                'user_name' => optional($r->user)->name,
                'total'     => (int) $r->total,
            ]);

        return response()->json(['rows' => $rows, 'start' => $start?->toDateString(), 'end' => $end?->toDateString()]);
    }

    /**
     * GET /api/v1/analytics/activities/by-type?start=YYYY-MM-DD&end=YYYY-MM-DD
     */
    public function activitiesByType(Request $request)
    {
        $this->authorizeAnalytics($request);

        [$start, $end] = $this->getDateRange($request, 30);

        $rows = Activity::query()
            ->selectRaw('type, COUNT(*) as total')
            ->when($start, fn($q) => $q->whereDate('created_at', '>=', $start))
            ->when($end, fn($q) => $q->whereDate('created_at', '<=', $end))
            ->groupBy('type')
            ->orderByDesc('total')
            ->get()
            ->map(fn($r) => [
                'type'  => (string) $r->type,
                'total' => (int) $r->total,
            ]);

        return response()->json(['rows' => $rows, 'start' => $start?->toDateString(), 'end' => $end?->toDateString()]);
    }

    /**
     * GET /api/v1/analytics/activities/done-by-user?start=YYYY-MM-DD&end=YYYY-MM-DD
     */
    public function activitiesDoneByUser(Request $request)
    {
        $this->authorizeAnalytics($request);

        [$start, $end] = $this->getDateRange($request, 30);

        $rows = Activity::query()
            ->selectRaw('user_id, COUNT(*) as total')
            ->where('is_done', 1)
            ->whereNotNull('user_id')
            ->when($start, fn($q) => $q->whereDate('created_at', '>=', $start))
            ->when($end, fn($q) => $q->whereDate('created_at', '<=', $end))
            ->groupBy('user_id')
            ->with('user:id,name')
            ->orderByDesc('total')
            ->get()
            ->map(fn($r) => [
                'user_id'   => $r->user_id,
                'user_name' => optional($r->user)->name,
                'total'     => (int) $r->total,
            ]);

        return response()->json(['rows' => $rows, 'start' => $start?->toDateString(), 'end' => $end?->toDateString()]);
    }

    /**
     * GET /api/v1/analytics/activities/pending-by-user?start=YYYY-MM-DD&end=YYYY-MM-DD
     */
    public function activitiesPendingByUser(Request $request)
    {
        $this->authorizeAnalytics($request);

        [$start, $end] = $this->getDateRange($request, 30);

        $rows = Activity::query()
            ->selectRaw('user_id, COUNT(*) as total')
            ->where('is_done', 0)
            ->whereNotNull('user_id')
            ->when($start, fn($q) => $q->whereDate('created_at', '>=', $start))
            ->when($end, fn($q) => $q->whereDate('created_at', '<=', $end))
            ->groupBy('user_id')
            ->with('user:id,name')
            ->orderByDesc('total')
            ->get()
            ->map(fn($r) => [
                'user_id'   => $r->user_id,
                'user_name' => optional($r->user)->name,
                'total'     => (int) $r->total,
            ]);

        return response()->json(['rows' => $rows, 'start' => $start?->toDateString(), 'end' => $end?->toDateString()]);
    }

    /**
     * GET /api/v1/analytics/activities/types-by-user?start=YYYY-MM-DD&end=YYYY-MM-DD
     * Returns counts of each activity type grouped by user (excluding system type).
     */
    public function activitiesTypesByUser(Request $request)
    {
        $this->authorizeAnalytics($request);

        [$start, $end] = $this->getDateRange($request, 30);

        $rows = Activity::query()
            ->selectRaw('user_id, type, COUNT(*) as total')
            ->whereNotNull('user_id')
            ->where('type', '!=', 'system')
            ->when($start, fn($q) => $q->whereDate('created_at', '>=', $start))
            ->when($end, fn($q) => $q->whereDate('created_at', '<=', $end))
            ->groupBy('user_id', 'type')
            ->with('user:id,name')
            ->orderBy('user_id')
            ->get()
            ->groupBy('user_id')
            ->map(function ($group) {
                $first = $group->first();
                $types = [];
                foreach ($group as $r) {
                    $types[(string) $r->type] = (int) $r->total;
                }
                return [
                    'user_id'   => $first->user_id,
                    'user_name' => optional($first->user)->name,
                    'types'     => $types,
                    'total'     => array_sum($types),
                ];
            })
            ->values();

        return response()->json([
            'rows'  => $rows,
            'start' => $start?->toDateString(),
            'end'   => $end?->toDateString(),
        ]);
    }
}
