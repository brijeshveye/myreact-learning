# Custom Analytics Module for Krayin

This package adds versioned API endpoints that expose user and lead analytics for your Krayin CRM.

## Installation

1. Ensure PSR-4 autoloading is configured (added automatically to project's composer.json):

    Namespace: `Custom\\Analytics\\` -> `packages/Custom/Analytics/src`

2. Dump the autoloader:

    composer dump-autoload

3. The service provider auto-loads routes. No extra registration is needed.

## Endpoints (v1)

Base prefix: `/api/v1/analytics` (requires `auth:sanctum`)

- `GET /users/summary` — totals, active last 7/30 days, breakdown by role.
- `GET /users/registrations?range=7|30|90` — daily registrations for last N days.
- `GET /leads/by-user?range=30|90|365` — lead counts grouped by user for the range.

All endpoints require the permission `analytics.view` when the role permissions system is enabled.

## Example response

`GET /api/v1/analytics/users/summary`

```
{
  "total": 42,
  "active_last_7d": 18,
  "active_last_30d": 33,
  "by_role": [
    { "role": "Admin", "count": 3 },
    { "role": "Sales", "count": 22 }
  ]
}
```

## Notes
- Active users are approximated using `updated_at`. If you track logins, you can switch to that column.
- Routes use `auth:sanctum`; ensure tokens are issued for your users.
