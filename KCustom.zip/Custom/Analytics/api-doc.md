# Custom Analytics API v1

Last updated: 2025-10-25

This document describes all endpoints exposed by the Custom Analytics package under the API v1 namespace. These endpoints mirror the Admin analytics and are suitable for external or programmatic access.

## Base URL

- Prefix: `/api/v1/analytics`
- All endpoints listed below are relative to this prefix.

## Authentication

- Auth method: Laravel Sanctum
- Provide an API token via the HTTP Authorization header
  - `Authorization: Bearer <your_api_token>`
- Responses when not authenticated: `401 Unauthorized`
- Optional authorization: If your app enables a permission like `analytics.view`, a `403 Forbidden` may be returned when the user lacks permission.

## Common query parameters

Some endpoints accept an explicit date range while others use a fixed range parameter. When both `start` and `end` are not provided, the default is the last 30 days.

- `start` (string, optional) — inclusive start date in `YYYY-MM-DD`
- `end` (string, optional) — inclusive end date in `YYYY-MM-DD`
- `range` (number, optional) — for some endpoints; allowed values differ per endpoint
- `type` (string, optional) — filter activity type for certain endpoints; when omitted, system-generated activities are excluded by default

Dates are interpreted in the server timezone. Invalid or missing dates fall back to the default last 30 days.

---

## Users

### GET /users/summary

Returns overall user totals and a breakdown by role.

Response

- `total` (number) — total number of users
- `active_last_7d` (number) — users updated in last 7 days
- `active_last_30d` (number) — users updated in last 30 days
- `by_role` (array of objects) — `{ role: string, count: number }`

Example response

```
{
  "total": 42,
  "active_last_7d": 18,
  "active_last_30d": 31,
  "by_role": [
    { "role": "Admin", "count": 3 },
    { "role": "Sales", "count": 25 },
    { "role": "Support", "count": 14 }
  ]
}
```

### GET /users/registrations?range=7|30|90

Returns new user registrations per day for the selected range.

Query

- `range` (number, optional) — one of `7`, `30`, or `90` (default `30`)

Response

- `range_days` (number)
- `series` (array of objects) — `{ date: YYYY-MM-DD, count: number }`

Example response

```
{
  "range_days": 30,
  "series": [
    { "date": "2025-10-01", "count": 2 },
    { "date": "2025-10-02", "count": 0 }
  ]
}
```

---

## Leads

### GET /leads/by-user?range=30|90|365

Counts leads created by each user within the selected trailing range.

Query

- `range` (number, optional) — one of `30`, `90`, or `365` (default `30`)

Response

- `range_days` (number)
- `rows` (array of objects) — `{ user_id: number, user_name: string|null, total: number }`

### GET /leads/counts-by-user?start=YYYY-MM-DD&end=YYYY-MM-DD

Counts leads created by each user within the explicit date range.

Response

- `rows` — `{ user_id, user_name, total }[]`
- `start` — resolved start date (YYYY-MM-DD)
- `end` — resolved end date (YYYY-MM-DD)

### GET /leads/updated-by-user?start=YYYY-MM-DD&end=YYYY-MM-DD

Counts distinct leads updated by each user based on lead-related activities that include additional payloads.

Response

- `rows` — `{ user_id, user_name, total }[]`
- `start`, `end`

### GET /leads/status-counts?start=YYYY-MM-DD&end=YYYY-MM-DD

Counts leads by status.

Response

- `rows` — `{ status: string, total: number }[]`
- `start`, `end`

### GET /leads/stage-counts?start=YYYY-MM-DD&end=YYYY-MM-DD

Counts leads by pipeline stage.

Response

- `rows` — `{ stage_id: number|null, stage_name: string|null, stage_code: string|null, total: number }[]`
- `start`, `end`

### GET /leads/source-counts?start=YYYY-MM-DD&end=YYYY-MM-DD

Counts leads by source.

Response

- `rows` — `{ source_id: number|null, source_name: string|null, total: number }[]`
- `start`, `end`

### GET /leads/type-counts?start=YYYY-MM-DD&end=YYYY-MM-DD

Counts leads by type.

Response

- `rows` — `{ type_id: number|null, type_name: string|null, total: number }[]`
- `start`, `end`

### GET /leads/value-sum-by-user?start=YYYY-MM-DD&end=YYYY-MM-DD

Sums lead_value for leads created by each user.

Response

- `rows` — `{ user_id: number, user_name: string|null, total_value: number }[]`
- `start`, `end`

### GET /leads/won-by-user?start=YYYY-MM-DD&end=YYYY-MM-DD

Counts leads in the `won` stage grouped by user.

Response

- `rows` — `{ user_id, user_name, total }[]`
- `start`, `end`

### GET /leads/lost-by-user?start=YYYY-MM-DD&end=YYYY-MM-DD

Counts leads in the `lost` stage grouped by user.

Response

- `rows` — `{ user_id, user_name, total }[]`
- `start`, `end`

---

## Activities

### GET /activities/call-by-user?start=YYYY-MM-DD&end=YYYY-MM-DD

Counts activities with type `call` by user.

Response

- `rows` — `{ user_id, user_name, total }[]`
- `start`, `end`

### GET /activities/created-by-user?start=YYYY-MM-DD&end=YYYY-MM-DD[&type=<activityType>]

Counts activities created by each user. When `type` is omitted, system-generated activities are excluded by default.

Query

- `type` (string, optional) — e.g., `call`, `email`, etc.

Response

- `rows` — `{ user_id, user_name, total }[]`
- `start`, `end`, `type`

### GET /activities/by-type?start=YYYY-MM-DD&end=YYYY-MM-DD

Counts all activities grouped by activity type.

Response

- `rows` — `{ type: string, total: number }[]`
- `start`, `end`

### GET /activities/done-by-user?start=YYYY-MM-DD&end=YYYY-MM-DD

Counts completed activities (is_done=1) grouped by user.

Response

- `rows` — `{ user_id, user_name, total }[]`
- `start`, `end`

### GET /activities/pending-by-user?start=YYYY-MM-DD&end=YYYY-MM-DD

Counts pending activities (is_done=0) grouped by user.

Response

- `rows` — `{ user_id, user_name, total }[]`
- `start`, `end`

### GET /activities/types-by-user?start=YYYY-MM-DD&end=YYYY-MM-DD

Returns, for each user, the distribution of activity counts by type (excluding `system`) and the per-user total.

Response

- `rows` — array of objects with:
  - `user_id` (number)
  - `user_name` (string|null)
  - `types` (object) — key-value pairs `{ <type>: number }`, e.g., `{ "call": 5, "email": 2 }`
  - `total` (number) — sum of all type counts for that user
- `start`, `end`

---

## Error responses

- 400 — Malformed query parameters (rare; most invalid dates fall back to defaults)
- 401 — Missing or invalid authentication
- 403 — Authenticated but not authorized (if permission gates are enabled)
- 500 — Unhandled server error

---

## Examples

Below are minimal HTTP examples. Replace `<HOST>` with your domain and `<TOKEN>` with a valid Sanctum token.

Fetch leads by user in past 90 days

GET https://<HOST>/api/v1/analytics/leads/by-user?range=90
Authorization: Bearer <TOKEN>

Fetch activities created by user between dates, filtered to calls only

GET https://<HOST>/api/v1/analytics/activities/created-by-user?start=2025-10-01&end=2025-10-25&type=call
Authorization: Bearer <TOKEN>

Fetch activity types by user for the last 30 days (defaults applied)

GET https://<HOST>/api/v1/analytics/activities/types-by-user
Authorization: Bearer <TOKEN>

---

## Versioning

- API namespace: `v1`
- Backward-compatible additions may occur (new fields/endpoints). Breaking changes will be released under a new version path.

## Notes

- All responses are JSON.
- Numeric IDs may be `null` when related records are missing; names will also be `null` in those cases.
- When there is no data, arrays are returned empty; date echoes `start`/`end` reflect the resolved range.
