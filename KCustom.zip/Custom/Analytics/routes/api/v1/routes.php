<?php

use Illuminate\Support\Facades\Route;
use Custom\Analytics\Http\Controllers\V1\AnalyticsController;

Route::middleware(['api', 'auth:sanctum'])
    ->prefix('api/v1/analytics')
    ->group(function () {
        Route::get('users/summary', [AnalyticsController::class, 'usersSummary']);
        Route::get('users/registrations', [AnalyticsController::class, 'usersRegistrations']);
        Route::get('leads/by-user', [AnalyticsController::class, 'leadsByUser']);
        Route::get('leads/counts-by-user', [AnalyticsController::class, 'leadsCountsByUser']);
        Route::get('leads/updated-by-user', [AnalyticsController::class, 'leadsUpdatedByUser']);
        Route::get('leads/status-counts', [AnalyticsController::class, 'leadsStatusCounts']);
        Route::get('leads/stage-counts', [AnalyticsController::class, 'leadsStageCounts']);
        Route::get('leads/source-counts', [AnalyticsController::class, 'leadsSourceCounts']);
        Route::get('leads/type-counts', [AnalyticsController::class, 'leadsTypeCounts']);
        Route::get('leads/value-sum-by-user', [AnalyticsController::class, 'leadsValueSumByUser']);
        Route::get('leads/won-by-user', [AnalyticsController::class, 'leadsWonByUser']);
        Route::get('leads/lost-by-user', [AnalyticsController::class, 'leadsLostByUser']);

        Route::get('activities/call-by-user', [AnalyticsController::class, 'callActivitiesByUser']);
        Route::get('activities/created-by-user', [AnalyticsController::class, 'activitiesCreatedByUser']);
        Route::get('activities/by-type', [AnalyticsController::class, 'activitiesByType']);
        Route::get('activities/done-by-user', [AnalyticsController::class, 'activitiesDoneByUser']);
        Route::get('activities/pending-by-user', [AnalyticsController::class, 'activitiesPendingByUser']);
        Route::get('activities/types-by-user', [AnalyticsController::class, 'activitiesTypesByUser']);
    });
