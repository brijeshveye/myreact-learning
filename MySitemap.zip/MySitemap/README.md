# MySitemap package

Generate and manage XML sitemaps per store. Provides an admin UI to create, list, download, view, and delete sitemaps, powered by Spatie's sitemap generator.

## Overview

MySitemap adds a "Sitemap Manager" under the company menu so admins can:
- Generate a fresh sitemap for the current store
- See stats for the latest sitemap (total URLs, file size, last updated)
- Browse previously generated sitemap files
- Download, view in browser, or delete existing sitemaps

Sitemaps are saved under the public storage disk at:
- storage/app/public/sitemap/store_{storeId}/sitemap_YYYYMMDDhhmmss.xml

The module is store-aware (via `getCurrentStore()`), so each store maintains its own set of sitemap files.

## Features

- One-click sitemap generation (per store)
- Past sitemap history (with file size, timestamps, URLs count)
- Actions: View, Download, Delete (single or bulk)
- Status indicator for the latest sitemap
- Menu integration for Company and Super Admin
- Laravel package auto-discovery and route/view wiring

## Requirements

- PHP 8.2+
- Laravel 11.x
- Storage "public" disk configured and web-accessible
- Package dependency: `spatie/laravel-sitemap` (provides `Spatie\Sitemap\SitemapGenerator`)

## Installation

1) Ensure Spatie sitemap is installed at the application level:

```bash
composer require spatie/laravel-sitemap
```

2) Ensure the public storage symlink exists so files are accessible:

```bash
php artisan storage:link
```

3) Clear caches (recommended):

```bash
php artisan optimize:clear
```

4) (Optional) Seeders (permissions/marketplace entries) if you manage them centrally:

```bash
php artisan db:seed --class="Shopyji\\MySitemap\\database\\seeders\\PermissionTableSeeder"
php artisan db:seed --class="Shopyji\\MySitemap\\database\\seeders\\MarketPlaceSeederTableSeeder"
```

The package's service provider is auto-discovered:
- `Shopyji\\MySitemap\\app\\Providers\\MySitemapServiceProvider`

## Routes and UI

All admin routes are behind `web`, `auth`, and `PlanModuleCheck:MySitemap` and prefixed with `/mysitemap` (route name prefix `mysitemap.`):

- `GET /mysitemap` → Sitemap dashboard (name: `mysitemap.index`)
- `GET /mysitemap/system/sitemap-generator` → Settings/Generator view (name: `mysitemap.sitemap_generator`)
- `POST /mysitemap/system/generate-sitemap` → Generate a new sitemap (name: `mysitemap.generate_sitemap`)
- `POST /mysitemap/system/delete-sitemap` → Delete a sitemap file (name: `mysitemap.delete_sitemap`)
- `POST /mysitemap/system/download-old-sitemap` → Download a past sitemap (name: `mysitemap.download_old_sitemap`)
- `GET /mysitemap/system/sitemap-item-add/{item}` → Route is defined but handler is not implemented in controller (name: `mysitemap.sitemap_item_add`)

Views use the namespace `my-sitemap` (e.g., `view('my-sitemap::index')`). The main UI (`resources/views/index.blade.php`) includes:
- Quick actions (Generate, Settings, Download current)
- Stats cards (Total URLs, Files Count, File Size, Last Update)
- Past sitemaps table with actions

## How it works

Controller: `app/Http/Controllers/MySiteMapController.php`
- `index()` collects per-store sitemap stats from storage and renders the dashboard
- `SitemapGenerator()` renders the index view with file info
- `DoSitemapGenerate()` uses `Spatie\Sitemap\SitemapGenerator::create($baseUrl)` and writes the file to the public disk under `sitemap/store_{store}`
- `DeleteSitemapFile()` deletes a selected file for the current store
- `DownloadSingleSitemapFile()` returns a download response for the selected file
- Helper method `countUrlsInSitemap()` parses the XML and counts `<url>` entries

Files are stored using the `public` disk and organized per store. The UI exposes a direct view/download link for each file.

## Configuration

- No DB migrations are required; files are persisted on disk.
- Ensure the `public` filesystem disk is correctly configured in `config/filesystems.php`.
- Confirm the storage symlink exists (`php artisan storage:link`).
- The menu entries are wired via events in the host app:
  - Company menu: `app/Listeners/CompanyStoreMenuListener.php`, `CompanyMenuListener.php`
  - Super Admin menu: `app/Listeners/SuperAdminMenuListener.php`
  - Company/SuperAdmin settings listeners exist but are currently commented out in the module's `EventServiceProvider`.

## Usage

- Navigate to `mysitemap.index` (e.g., `/mysitemap`) from the company store menu.
- Click Generate to create a new sitemap. On success, a new `sitemap_YYYYMMDDhhmmss.xml` is added for the current store.
- Use the actions in the Past Sitemaps table to view, download, or delete files.

Notes:
- Generation uses the application's base URL (`URL('/')`) as the starting point for crawling.
- If you need to include/exclude specific routes or collections, extend the generator setup accordingly in `DoSitemapGenerate()`.

## Troubleshooting

- Class "Spatie\\Sitemap\\SitemapGenerator" not found
  - Install `spatie/laravel-sitemap` and clear caches.

- Generated file not accessible in browser
  - Ensure `php artisan storage:link` was run, and the web server serves the symlinked `public/storage` path.

- No URLs or incorrect counts
  - The crawler relies on your app being accessible at `URL('/')`. Verify routes are reachable and not blocked by auth/middleware.

- Route exists but function missing (`mysitemap.sitemap_item_add`)
  - The route is defined in `Routes/web.php` but has no corresponding controller method; it’s currently a stub.

## Internals at a glance

- Provider: `app/Providers/MySitemapServiceProvider.php`
- Routes: `src/routes/web.php`, `src/routes/api.php`
- Controller: `app/Http/Controllers/MySiteMapController.php`
- Views: `resources/views/index.blade.php`, plus basic marketplace and settings stubs
- Event wiring: `app/Providers/EventServiceProvider.php` with menu listeners under `app/Listeners`
- Seeders: `database/seeders/*` for permissions/marketplace entries

## License

MIT

## Support

For issues or questions, contact ShopyJi support or the authors listed in `composer.json`.
