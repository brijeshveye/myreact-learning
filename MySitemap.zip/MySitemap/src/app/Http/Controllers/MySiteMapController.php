<?php

namespace Shopyji\MySitemap\app\Http\Controllers;

use Carbon\Carbon;
use Exception;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Storage;
use Spatie\Sitemap\SitemapGenerator;

class MySiteMapController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $currentStore = getCurrentStore();

        $sitemapData = [];

        $sitemapData['store'] = $currentStore;
        $sitemapData['pastSitemaps'] = $this->getSitemapsFromStorage();

        $sitemapData['totalSitemaps'] = count($sitemapData['pastSitemaps']);

        if ($sitemapData['totalSitemaps'] > 0) {
            $lastGenerated = $sitemapData['pastSitemaps'][0];

            $sitemapData['totalUrls'] = $lastGenerated['urls_count'] ?? 0;
            $sitemapData['fileSize'] = $lastGenerated['file_size'] ?? '0 KB';
            $sitemapData['lastUpdated'] = Carbon::parse($lastGenerated['last_modified'] ?? 'now')->diffForHumans();

            $sitemapData['sitemapUrl'] = $lastGenerated['view_url'] ?? '';
            $sitemapData['storeEnabled'] = true;
            $sitemapData['status'] = $lastGenerated['status'] ?? 'archived';
        }


        return view('my-sitemap::index', compact('sitemapData'));
    }


    /*
    Method for sitemap view load
    */
    public function SitemapGenerator(){
        $currentStore = getCurrentStore();

        $file_info = array();
        $files = Storage::disk('public')->allFiles('sitemap/store_'.$currentStore);
        foreach($files as $key => $file){
            $file_info[$key]['file_name'] = $file;
            $file_info[$key]['file_size'] = number_format((int)Storage::disk('public')->size($file)/1024, 2)  . ' KB';
            $file_info[$key]['last_modified'] = Carbon::createFromTimestamp(Storage::disk('public')->lastModified($file))->format('d-m-Y h:i:s');
            $file_info[$key]['mime_type'] = mime_content_type(storage_path('app/public/' . $file));
            $file_info[$key]['url'] = '/storage/app/public/'.$file;
        }

        return view('my-sitemap::index', compact('file_info'))->render();
    }


    private function getSitemapsFromStorage(){
        $currentStore = getCurrentStore();

        $file_info = array();
        $files = Storage::disk('public')->allFiles('sitemap/store_'.$currentStore);

        foreach($files as $key => $file){
            $file_info[$key]['file_name'] = str_replace('sitemap/store_'.$currentStore.'/', '', $file);
            $file_info[$key]['file_size'] = number_format((int)Storage::disk('public')->size($file)/1024, 2)  . ' KB';
            $file_info[$key]['created_at'] = Carbon::createFromTimestamp(Storage::disk('public')->lastModified($file))->format('d-m-Y h:i:s');
            $file_info[$key]['last_modified'] = Carbon::createFromTimestamp(Storage::disk('public')->lastModified($file))->format('d-m-Y h:i:s');
            $file_info[$key]['mime_type'] = mime_content_type(storage_path('app/public/' . $file));

            $file_info[$key]['time_ago'] = Carbon::createFromTimestamp(Storage::disk('public')->lastModified($file))->diffForHumans();
            $file_info[$key]['urls_count'] = $this->countUrlsInSitemap(storage_path('app/public/' . $file));

            $file_info[$key]['download_url'] = '/storage/app/public/'.$file;
            $file_info[$key]['view_url'] = '/storage/app/public/'.$file;

            $file_info[$key]['status'] =  ($file_info[$key]['urls_count'] > 0) ? 'active' : 'archived';
        }

        return array_reverse($file_info);
    }

    private function countUrlsInSitemap($filePath){
        if (!file_exists($filePath)) {
            return 0;
        }

        $xmlContent = file_get_contents($filePath);
        $xml = simplexml_load_string($xmlContent);

        if ($xml === false) {
            return 0;
        }

        $namespaces = $xml->getNamespaces(true);
        if (isset($namespaces[''])) {
            $xml->registerXPathNamespace('ns', $namespaces['']);
            $urlElements = $xml->xpath('//ns:url');
        } else {
            $urlElements = $xml->xpath('//url');
        }

        return is_array($urlElements) ? count($urlElements) : 0;
    }


    /*
    Method for sitemap generation and download
    */
    public function DoSitemapGenerate(){

        Artisan::call('optimize:clear');

        $currentStore = getCurrentStore();

        $base_url = URL('/');

        $filename = 'sitemap_'.Date("Ymdhis").'.xml';

        $filename = 'sitemap/store_'.$currentStore.'/'.$filename;

        try{
            SitemapGenerator::create($base_url)->getSitemap()->writeToDisk('public', $filename, true);

            if(!Storage::disk('public')->exists($filename)){
                return redirect()->back()->with('error', __('Sitemap generation failed.'));
            }

            $filePath = storage_path('app/public/' . $filename);

            if (!file_exists($filePath)) {
                return redirect()->back()->with('error', __('Sitemap file not found.'));
            }

            // dd($filePath);

            return redirect()->back()->with('success', __('Sitemap generated successfully.'));

            // return response()->download($filePath);
        }
        catch(Exception $ex)
        {
            throw $ex;
        }
    }


    /*
    Method for delete file
    */
    public function DeleteSitemapFile(Request $request){

        if(isset($request->file_name) && !empty($request->file_name)){

            $currentStore = getCurrentStore();

            $filePath = 'sitemap/store_'.$currentStore.'/'.$request->file_name;

            if(Storage::disk('public')->exists($filePath)){

                Storage::disk('public')->delete($filePath);
                return redirect()->back()->with('success', __('File deleted successfully.'));

            }else{

                return redirect()->back()->with('error', __('File not found.'));
            }
        }
    }


    /*
    Method for download single file
    */
    public function DownloadSingleSitemapFile(Request $request){

        if(isset($request->file_name) && !empty($request->file_name)){

            $currentStore = getCurrentStore();

            $filePath = storage_path('app/public/sitemap/store_'.$currentStore.'/' . $request->file_name);

            if (!file_exists($filePath)) {
                return redirect()->back()->with('error', __('File not found.'));
            }

            return response()->download($filePath);
        }
    }
}
