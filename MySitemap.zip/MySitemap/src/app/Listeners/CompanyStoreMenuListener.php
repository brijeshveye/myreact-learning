<?php

namespace Shopyji\MySitemap\app\Listeners;

use App\Events\CompanyStoreMenuEvent;

class CompanyStoreMenuListener
{
    /**
     * Handle the event.
     */
    public function handle(CompanyStoreMenuEvent $event): void
    {
        $module = 'MySitemap';
        $menu = $event->menu;
        $menu->add([
            'title' => 'MySitemap',
            'icon' => 'home',
            'name' => 'mysitemap',
            'parent' => null,
            'order' => 2,
            'ignore_if' => [],
            'depend_on' => [],
            'route' => '',
            'module' => $module,
            'permission' => ''
        ]);

        $menu->add([
            'title' => __('Sitemap Generator'),
            'icon' => 'sitemap',
            'name' => 'sitemap_generator',
            'parent' => 'mysitemap',
            'order' => 231,
            'ignore_if' => [],
            'depend_on' => [],
            'route' => 'mysitemap.index',
            'module' => $module,
            'permission' => ''
        ]);
    }
}
