<?php

namespace Shopyji\MySitemap\app\Listeners;
use App\Events\SuperAdminMenuEvent;

class SuperAdminMenuListener
{
    /**
     * Handle the event.
     */
    public function handle(SuperAdminMenuEvent $event): void
    {
        $module = 'MySitemap';
        $menu = $event->menu;
        $menu->add([
            'title' => 'MySitemap',
            'icon' => 'home',
            'name' => 'mysitemap',
            'parent' => null,
            'order' => 2,
            'ignore_if' => [],
            'depend_on' => [],
            'route' => 'home',
            'module' => $module,
            'permission' => 'manage-dashboard'
        ]);
    }
}
