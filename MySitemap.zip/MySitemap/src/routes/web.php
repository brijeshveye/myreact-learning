<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Routes and Events - make s capital

use Illuminate\Support\Facades\Route;
use Shopyji\MySitemap\app\Http\Controllers\MySiteMapController;

Route::middleware(['auth', 'web', 'PlanModuleCheck:MySitemap'])->group(function () {
    Route::prefix('mysitemap')->name('mysitemap.')->group(function () {
        Route::get('/', [MySiteMapController::class, 'index'])->name('index');
        Route::get('/system/sitemap-generator', [MySiteMapController::class, 'SitemapGenerator'])->name('sitemap_generator');
        Route::post('/system/generate-sitemap', [MySiteMapController::class, 'DoSitemapGenerate'])->name('generate_sitemap');
        Route::post('/system/delete-sitemap', [MySiteMapController::class, 'DeleteSitemapFile'])->name('delete_sitemap');
        Route::post('/system/download-old-sitemap', [MySiteMapController::class, 'DownloadSingleSitemapFile'])->name('download_old_sitemap');

        Route::get('/system/sitemap-item-add/{item}', [MySiteMapController::class, 'SitemapItems'])->name('sitemap_item_add');
    });
});
