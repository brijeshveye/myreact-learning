@extends('layouts.app')
@section('page-title')
    {{ __('Sitemap Manager') }}
@endsection
@section('page-breadcrumb')
    {{ __('Sitemap Manager') }}
@endsection

@push('css')
    <style>
        /* Hero section styling */
        .sitemap-hero-wrap {
            position: relative;
            overflow: hidden;
            border-radius: 12px;
            background: linear-gradient(135deg, #f0f9ff, #ecfdf5);
            padding: 20px;
        }
        .sitemap-hero-bg {
            position: absolute;
            inset: 0;
            background-size: cover;
            background-position: center;
            opacity: 0.05;
            filter: blur(2px);
        }
        .sitemap-hero {
            display: flex;
            align-items: center;
            gap: 16px;
        }
        .sitemap-icon {
            width: 64px;
            height: 64px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 12px;
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
            box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
        }
        .status-indicator {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 4px 8px;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 600;
        }
        .status-active {
            background: #dcfce7;
            color: #166534;
        }
        .status-pending {
            background: #fef3c7;
            color: #92400e;
        }
        .status-error {
            background: #fee2e2;
            color: #991b1b;
        }
        .quick-actions {
            margin-left: auto;
            display: flex;
            align-items: center;
            gap: 8px;
            z-index: 1;
        }
        .quick-action-center {
            z-index: 1;
        }
        .icon-btn {
            width: 36px;
            height: 36px;
            border-radius: 8px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border: 1px solid #e5e7eb;
            background: #fff;
            color: #374151;
            text-decoration: none;
            transition: all .15s ease;
        }
        .icon-btn:hover {
            background: #f9fafb;
            border-color: #d1d5db;
            transform: translateY(-1px);
        }
        .icon-btn:active {
            transform: translateY(0);
        }

        /* Table styling */
        .sitemap-table {
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        .sitemap-table th {
            background: #f8fafc;
            font-weight: 600;
            color: #374151;
            border-bottom: 1px solid #e5e7eb;
        }
        .sitemap-table td {
            vertical-align: middle;
        }
        .file-size {
            font-family: 'Courier New', monospace;
            font-size: 13px;
            color: #6b7280;
        }
        .action-btn {
            padding: 4px 8px;
            font-size: 12px;
            border-radius: 4px;
        }

        /* Toast and modal styling */
        #toast {
            position: fixed;
            z-index: 1060;
            bottom: 20px;
            right: 20px;
            background: #111827;
            color: #fff;
            padding: 12px 16px;
            border-radius: 8px;
            display: none;
            box-shadow: 0 10px 25px rgba(0,0,0,0.3);
        }
        #confirmModal {
            position: fixed;
            z-index: 1065;
            inset: 0;
            background: rgba(17,24,39,0.6);
            display: none;
            align-items: center;
            justify-content: center;
            padding: 16px;
        }
        .modal-card {
            background: #fff;
            border-radius: 12px;
            max-width: 440px;
            width: 100%;
            box-shadow: 0 25px 50px rgba(0,0,0,0.25);
        }
        .modal-card .modal-header {
            padding: 16px 20px;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .modal-card .modal-body {
            padding: 20px;
            color: #374151;
        }
        .modal-card .modal-footer {
            padding: 16px 20px;
            display: flex;
            justify-content: flex-end;
            gap: 8px;
            border-top: 1px solid #e5e7eb;
        }

        /* Stats cards */
        .stats-card {
            background: linear-gradient(135deg, #fff, #f8fafc);
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            padding: 16px;
            text-align: center;
        }
        .stats-number {
            font-size: 24px;
            font-weight: 700;
            color: #1f2937;
        }
        .stats-label {
            font-size: 13px;
            color: #6b7280;
            margin-top: 4px;
        }
    </style>
@endpush

@section('content')
    <div class="row">
        <!-- Sitemap Details Section -->
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="sitemap-hero-wrap">
                        <div class="sitemap-hero-bg" style="background-image:url('data:image/svg+xml,<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 100 100\"><circle cx=\"20\" cy=\"20\" r=\"3\" fill=\"%2310b981\" opacity=\"0.3\"/><circle cx=\"80\" cy=\"30\" r=\"2\" fill=\"%2310b981\" opacity=\"0.2\"/><circle cx=\"60\" cy=\"70\" r=\"4\" fill=\"%2310b981\" opacity=\"0.15\"/></svg>')"></div>
                        <div class="sitemap-hero z-1">
                            <div class="sitemap-icon">
                                <i class="ti ti-sitemap" style="font-size: 32px;"></i>
                            </div>
                            <div class="quick-action-center">
                                <h3 class="mb-1">{{ __('Sitemap Status') }}</h3>
                                <div class="d-flex align-items-center gap-2 mb-2">
                                    @php
                                        $status = $sitemapData['status'] ?? 'pending';
                                        $statusClass = $status === 'active' ? 'status-active' : ($status === 'error' ? 'status-error' : 'status-pending');
                                    @endphp
                                    <span class="status-indicator {{ $statusClass }}" id="status-indicator">
                                        <i class="ti ti-{{ $status === 'active' ? 'check' : ($status === 'error' ? 'alert-circle' : 'clock') }}"></i>
                                        {{ $status === 'active' ? __('Active') : ($status === 'error' ? __('Error') : __('Generating')) }}
                                    </span>
                                    <span class="badge bg-light text-dark">{{ __('Last Updated') }}: {{ $sitemapData['lastGenerated'] ?? __('Never') }}</span>
                                </div>
                                <div class="d-flex align-items-center gap-3">
                                    <span class="text-muted">{{ __('Store Sitemap') }}:
                                        @if (!empty($sitemapData['storeEnabled']))
                                            <span class="text-success">{{ __('Enabled') }}</span>
                                        @else
                                            <span class="text-danger">{{ __('Disabled') }}</span>
                                        @endif
                                    </span>
                                    @if (!empty($sitemapData['sitemapUrl']))
                                        <a href="{{ $sitemapData['sitemapUrl'] }}" target="_blank" class="text-primary text-decoration-none">
                                            <i class="ti ti-external-link"></i> {{ __('View Sitemap') }}
                                        </a>
                                    @endif
                                </div>
                            </div>
                            <div class="quick-actions z-2">
                                <button type="button" class="icon-btn" id="btn-generate" title="{{ __('Generate New Sitemap') }}" aria-label="{{ __('Generate New Sitemap') }}">
                                    <i class="ti ti-refresh"></i>
                                </button>
                                <button type="button" class="icon-btn" id="btn-settings" title="{{ __('Sitemap Settings') }}" aria-label="{{ __('Sitemap Settings') }}">
                                    <i class="ti ti-settings"></i>
                                </button>
                                <button type="button" class="icon-btn" id="btn-download" title="{{ __('Download Current Sitemap') }}" aria-label="{{ __('Download Current Sitemap') }}">
                                    <i class="ti ti-download"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Statistics Cards -->
        <div class="col-md-3 col-sm-6 mb-3">
            <div class="stats-card">
                <div class="stats-number">{{ $sitemapData['totalUrls'] ?? 0 }}</div>
                <div class="stats-label">{{ __('Total URLs') }}</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6 mb-3">
            <div class="stats-card">
                <div class="stats-number">{{ $sitemapData['totalSitemaps'] ?? 0 }}</div>
                <div class="stats-label">{{ __('Generated Sitemaps') }}</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6 mb-3">
            <div class="stats-card">
                <div class="stats-number">{{ $sitemapData['fileSize'] ?? '0 KB' }}</div>
                <div class="stats-label">{{ __('Current File Size') }}</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6 mb-3">
            <div class="stats-card">
                <div class="stats-number">{{ $sitemapData['lastUpdated'] ?? __('Never') }}</div>
                <div class="stats-label">{{ __('Last Update') }}</div>
            </div>
        </div>

        <!-- Past Sitemaps Table -->
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex align-items-center justify-content-between">
                    <h5 class="mb-0">{{ __('Past Sitemaps') }}</h5>
                    <div class="d-flex gap-2">
                        <button type="button" class="btn btn-outline-danger btn-sm" id="btn-delete-all">
                            <i class="ti ti-trash"></i> {{ __('Delete All') }}
                        </button>
                        <button type="button" class="btn btn-primary btn-sm" id="btn-refresh-table">
                            <i class="ti ti-refresh"></i> {{ __('Refresh') }}
                        </button>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table sitemap-table mb-0">
                            <thead>
                                <tr>
                                    <th style="width: 40px;">
                                        <input type="checkbox" class="form-check-input" id="selectAll">
                                    </th>
                                    <th>{{ __('Generated Date') }}</th>
                                    <th>{{ __('File Name') }}</th>
                                    <th>{{ __('URLs Count') }}</th>
                                    <th>{{ __('File Size') }}</th>
                                    <th>{{ __('Status') }}</th>
                                    <th style="width: 120px;">{{ __('Actions') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                @php
                                    $pastSitemaps = $sitemapData['pastSitemaps'] ?? [];
                                @endphp
                                @if (empty($pastSitemaps))
                                    <tr>
                                        <td colspan="7" class="text-center py-4 text-muted">
                                            <i class="ti ti-folder-open" style="font-size: 48px; opacity: 0.3;"></i>
                                            <div class="mt-2">{{ __('No past sitemaps found') }}</div>
                                            <small>{{ __('Generate your first sitemap to see it here') }}</small>
                                        </td>
                                    </tr>
                                @else
                                    @foreach ($pastSitemaps as $sitemap)
                                        <tr>
                                            <td>
                                                <input type="checkbox" class="form-check-input sitemap-checkbox" value="{{ $sitemap['file_name'] }}">
                                            </td>
                                            <td>
                                                <div class="fw-medium">{{ $sitemap['created_at'] }}</div>
                                                <small class="text-muted">{{ $sitemap['time_ago'] }}</small>
                                            </td>
                                            <td>
                                                <div class="d-flex align-items-center gap-2">
                                                    <i class="ti ti-file-text text-primary"></i>
                                                    <span class="fw-medium">{{ $sitemap['file_name'] }}</span>
                                                </div>
                                            </td>
                                            <td>
                                                <span class="badge bg-light text-dark">{{ number_format($sitemap['urls_count']) }}</span>
                                            </td>
                                            <td>
                                                <span class="file-size">{{ $sitemap['file_size'] }}</span>
                                            </td>
                                            <td>
                                                @if ($sitemap['status'] === 'active')
                                                    <span class="badge bg-success">{{ __('Current') }}</span>
                                                @elseif ($sitemap['status'] === 'archived')
                                                    <span class="badge bg-secondary">{{ __('Archived') }}</span>
                                                @else
                                                    <span class="badge bg-warning">{{ __('Old') }}</span>
                                                @endif
                                            </td>
                                            <td>
                                                <div class="d-flex gap-1">
                                                    <a href="{{ $sitemap['download_url'] }}" class="btn btn-outline-primary action-btn" title="{{ __('Download') }}">
                                                        <i class="ti ti-download"></i>
                                                    </a>
                                                    @if ($sitemap['view_url'])
                                                        <a href="{{ $sitemap['view_url'] }}" target="_blank" class="btn btn-outline-info action-btn" title="{{ __('View') }}">
                                                            <i class="ti ti-eye"></i>
                                                        </a>
                                                    @endif
                                                    <button type="button" class="btn btn-outline-danger action-btn delete-sitemap" data-id="{{ $sitemap['file_name'] }}" title="{{ __('Delete') }}">
                                                        <i class="ti ti-trash"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Toast -->
    <div id="toast" role="status" aria-live="polite"></div>

    <!-- Confirm Modal -->
    <div id="confirmModal" role="dialog" aria-modal="true" aria-labelledby="confirmTitle">
        <div class="modal-card">
            <div class="modal-header">
                <h6 id="confirmTitle" class="mb-0">{{ __('Confirm Action') }}</h6>
                <button type="button" class="icon-btn" id="confirmClose" aria-label="{{ __('Close') }}">
                    <i class="ti ti-x"></i>
                </button>
            </div>
            <div class="modal-body">
                <p id="confirmMessage">{{ __('Are you sure you want to proceed?') }}</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" id="btn-cancel">{{ __('Cancel') }}</button>
                <button type="button" class="btn btn-danger" id="btn-confirm">{{ __('Confirm') }}</button>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
    <script>
        // Utilities
        function showToast(msg, type = 'success') {
            const toast = document.getElementById('toast');
            if (!toast) return;
            toast.textContent = msg;
            toast.style.background = type === 'error' ? '#dc2626' : '#111827';
            toast.style.display = 'block';
            setTimeout(() => { toast.style.display = 'none'; }, 3000);
        }

        function showConfirm(title, message, callback) {
            const modal = document.getElementById('confirmModal');
            const titleEl = document.getElementById('confirmTitle');
            const messageEl = document.getElementById('confirmMessage');
            const confirmBtn = document.getElementById('btn-confirm');

            titleEl.textContent = title;
            messageEl.textContent = message;
            modal.style.display = 'flex';

            confirmBtn.onclick = function() {
                modal.style.display = 'none';
                callback();
            };
        }

        // Modal controls
        document.getElementById('confirmClose')?.addEventListener('click', function() {
            document.getElementById('confirmModal').style.display = 'none';
        });
        document.getElementById('btn-cancel')?.addEventListener('click', function() {
            document.getElementById('confirmModal').style.display = 'none';
        });
        document.getElementById('confirmModal')?.addEventListener('click', function(e) {
            if (e.target === this) this.style.display = 'none';
        });

        // Quick actions
        document.getElementById('btn-generate')?.addEventListener('click', function() {
            showConfirm(
                "{{ __('Generate New Sitemap') }}",
                "{{ __('This will generate a new sitemap. Continue?') }}",
                function() {
                    showToast("{{ __('Generating new sitemap...') }}");
                    // Add your sitemap generation logic here

                    // Disabe buttons during generation
                    document.getElementById('btn-generate').disabled = true;
                    document.getElementById('btn-settings').disabled = true;

                    document.getElementById('status-indicator').classList.add('loading');

                    $.ajax({
                        url: "{{ route('mysitemap.generate_sitemap') }}",
                        method: 'POST',
                        data: {
                            _token: "{{ csrf_token() }}"
                        },
                        success: function(response) {
                            showToast("{{ __('Sitemap generated successfully!') }}");
                            location.reload();
                        },
                        error: function() {
                            showToast("{{ __('Failed to generate sitemap.') }}", 'error');
                        },
                        complete: function() {
                            // Re-enable buttons
                            document.getElementById('btn-generate').disabled = false;
                            document.getElementById('btn-settings').disabled = false;
                            document.getElementById('status-indicator').classList.remove('loading');
                        }
                    });

                    // setTimeout(() => {
                    //     showToast("{{ __('Sitemap generated successfully!') }}");
                    //     location.reload();
                    // }, 2000);
                }
            );
        });

        document.getElementById('btn-settings')?.addEventListener('click', function() {
            // Navigate to sitemap settings
            window.location.href = "{{ route('mysitemap.sitemap_generator', ['tab' => 'sitemap']) }}";
        });

        document.getElementById('btn-download')?.addEventListener('click', function() {
            @if (!empty($sitemapData['sitemapUrl']))
                window.open("{{ $sitemapData['sitemapUrl'] }}", '_blank');
                showToast("{{ __('Downloading sitemap...') }}");
            @else
                showToast("{{ __('No sitemap available for download') }}", 'error');
            @endif
        });

        // Table actions
        document.getElementById('selectAll')?.addEventListener('change', function() {
            const checkboxes = document.querySelectorAll('.sitemap-checkbox');
            checkboxes.forEach(cb => cb.checked = this.checked);
        });

        document.getElementById('btn-delete-all')?.addEventListener('click', function() {
            const selected = document.querySelectorAll('.sitemap-checkbox:checked');
            if (selected.length === 0) {
                showToast("{{ __('Please select sitemaps to delete') }}", 'error');
                return;
            }

            showConfirm(
                "{{ __('Delete Selected Sitemaps') }}",
                `{{ __('Are you sure you want to delete') }} ${selected.length} {{ __('selected sitemaps? This action cannot be undone.') }}`,
                function() {
                    const ids = Array.from(selected).map(cb => cb.value);
                    // Add your bulk delete logic here
                    showToast(`{{ __('Deleted') }} ${ids.length} {{ __('sitemaps successfully') }}`);
                    location.reload();
                }
            );
        });

        document.getElementById('btn-refresh-table')?.addEventListener('click', function() {
            showToast("{{ __('Refreshing...') }}");
            location.reload();
        });

        // Individual delete buttons
        document.querySelectorAll('.delete-sitemap').forEach(btn => {
            btn.addEventListener('click', function() {
                const id = this.dataset.id;
                showConfirm(
                    "{{ __('Delete Sitemap') }}",
                    "{{ __('Are you sure you want to delete this sitemap? This action cannot be undone.') }}",
                    function() {
                        // Add your individual delete logic here
                        showToast("{{ __('Sitemap deleted successfully') }}");
                        location.reload();
                    }
                );
            });
        });
    </script>
@endpush
