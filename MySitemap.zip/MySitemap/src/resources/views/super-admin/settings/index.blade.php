hello from superadmin setting of mysitemap
