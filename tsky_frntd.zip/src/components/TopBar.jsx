import React, { useEffect, useRef, useState, useCallback } from 'react';
import { resolveUserAvatar } from '../utils/avatars.js';
import { useNavigate } from 'react-router-dom';
import { useTheme } from '../context/ThemeContext';
import { fetchNotifications } from '../api/notifications';
import InstallPWA from './InstallPWA';

export default function TopBar() {
  const { theme, toggleTheme } = useTheme();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const menuRef = useRef(null);
  const user = (() => {
    try { return JSON.parse(localStorage.getItem('user') || 'null'); } catch { return null; }
  })();

  const displayName = [user?.firstName, user?.lastName].filter(Boolean).join(' ') || 'User';
  const email = user?.companyOfficialEmail || user?.personalEmail || 'user@example.com';
  const userGroup = user?.userGroup || 'Employee';
  const avatarUrl = resolveUserAvatar(user);

  // Girl Image Url: https://lh3.googleusercontent.com/aida-public/AB6AXuB3PaYDTLbi2LTX0kBFMTOJic17MIM3Vr8smGQHF3-Q5dwtaLXtn6Vlkr5ehFYXDE_SWaJMq9rYFzHkO9lhczBCvl2ZodP1jYuvuf1ttPdi8MSIML06m5YZwAqlo7XyR3v8VgdN869IZ2CVYqndJbzUy-PXhJd9o24JcX5HoQgN6xJ2NeKN1H_zyBmwS2Lx84ZtAqXFXV8hR5x0BizKb2rKVi0WWNX2dLAC_hH2oY2uQ6ytfjAdOhVaZFgOvU5h3pVuudm0EFy-zsQ
  
  useEffect(() => {
    function onDocClick(e) {
      if (!menuRef.current) return;
      if (!menuRef.current.contains(e.target)) setOpen(false);
    }
    function onEsc(e) { if (e.key === 'Escape') setOpen(false); }
    document.addEventListener('mousedown', onDocClick);
    document.addEventListener('keydown', onEsc);
    return () => {
      document.removeEventListener('mousedown', onDocClick);
      document.removeEventListener('keydown', onEsc);
    };
  }, []);

  // Fetch unread notifications count
  const loadUnread = useCallback(async () => {
    try {
      const res = await fetchNotifications({ page:1, limit: 1, unread: true });
      // API may return array or {data:[], total:number}
      if (Array.isArray(res)) {
        // If array, we don't know total so rely on length > 0
        setUnreadCount(res.length);
      } else {
        const total = res?.total ?? (Array.isArray(res?.data) ? res.data.length : 0);
        setUnreadCount(total);
      }
    } catch {
      // swallow errors silently (network/auth) for badge
    }
  }, []);

  useEffect(() => {
    loadUnread();
    const id = setInterval(loadUnread, 60_000); // poll every minute
    return () => clearInterval(id);
  }, [loadUnread]);

  // Realtime: listen to global events (connection managed in Layout)
  const [socketStatus, setSocketStatus] = useState('idle'); // idle | connected | disconnected
  useEffect(() => {
    const onNew = () => setUnreadCount(c => c + 1);
    const onStatus = (e) => setSocketStatus(e.detail || 'idle');
    window.addEventListener('notifications:new', onNew);
    window.addEventListener('socket:status', onStatus);
    return () => {
      window.removeEventListener('notifications:new', onNew);
      window.removeEventListener('socket:status', onStatus);
    };
  }, []);

  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setOpen(false);
    navigate('/login');
  };

  const handleUserGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good Morning';
    if (hour < 15) return 'Good Afternoon';
    return 'Good Evening';
  }

  return (
    <header className="bg-header d-flex align-items-center justify-content-between px-4" style={{height:64}}>
      <p className="mb-0 fs-6 fw-light text-heading">{handleUserGreeting()}, {displayName}</p>
      <div className="d-flex align-items-center gap-3 position-relative">
        <div className="position-relative">
          <span className="material-symbols-outlined position-absolute" style={{left:12, top:'50%', transform:'translateY(-50%)', color:'var(--color-text-soft)'}}>search</span>
          <input className="form-control ps-5 input-custom border-0" style={{width:220}} type="text" placeholder="Search" />
        </div>
        <button
          className="btn position-relative rounded-circle p-2"
          onClick={toggleTheme}
          aria-label="Toggle light/dark mode"
          title={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
        >
          <span className="material-symbols-outlined">{theme === 'dark' ? 'light_mode' : 'dark_mode'}</span>
        </button>
        <InstallPWA />
        <button
          className="btn position-relative rounded-circle p-2"
          onClick={() => { navigate('/notifications'); setUnreadCount(0); }}
          aria-label="Notifications"
          title={unreadCount > 0 ? `${unreadCount} unread notifications` : 'Notifications'}
        >
          <span className="material-symbols-outlined">notifications</span>
          {unreadCount > 0 && (
            <span className="notification-dot" style={{ background: 'var(--danger-color, #dc3545)' }} />
          )}
        </button>
        <div className="position-relative" ref={menuRef}>
          <button className="p-0 border-0 bg-transparent position-relative" onClick={() => setOpen(o => !o)} aria-haspopup="menu" aria-expanded={open}>
            <div className="profile-img" style={{backgroundImage:`url('${avatarUrl}')`}} />
            <span
              aria-label={socketStatus === 'connected' ? 'Online' : socketStatus === 'disconnected' ? 'Offline' : 'Connecting'}
              title={socketStatus === 'connected' ? 'Realtime connected' : socketStatus === 'disconnected' ? 'Realtime disconnected' : 'Connecting...'}
              style={{
                position: 'absolute',
                bottom: 2,
                right: 2,
                width: 12,
                height: 12,
                borderRadius: '50%',
                border: '0px solid var(--color-bg, #111)',
                backgroundColor: socketStatus === 'connected' ? '#16a34a' : socketStatus === 'disconnected' ? '#dc2626' : '#6b7280',
                boxShadow: '0 0 0 2px var(--color-bg, #111)'
              }}
            />
          </button>
          {open && (
            <div className="position-absolute end-0 mt-2" style={{ minWidth: 280, zIndex: 1000 }} role="menu">
              <div className="bg-card rounded shadow overflow-hidden" style={{ border: '1px solid var(--color-border-alt)' }}>
                <div className="d-flex align-items-center gap-3 p-3" style={{ borderBottom: '1px solid var(--color-border-alt)' }}>
                  <div className="profile-img" style={{backgroundImage:`url('${resolveUserAvatar(user)}')`}} />
                  <div className="text-start">
                    <div className="text-heading fw-semibold">{displayName}</div>
                    <div className="text-soft small">{email}</div>
                    <span className="badge mt-1" style={{ background: 'var(--primary-color)', color:'#fff' }}>{userGroup}</span>
                  </div>
                </div>
                <div className="d-flex flex-column py-1">
                  <button className="dropdown-item d-flex align-items-center gap-2 px-3 py-2 text-start bg-transparent border-0 text-heading" onClick={() => { setOpen(false); navigate('/profile'); }}>
                    <span className="material-symbols-outlined">person</span>
                    <span>Edit profile</span>
                  </button>
                  <button className="dropdown-item d-flex align-items-center gap-2 px-3 py-2 text-start bg-transparent border-0 text-red-custom" onClick={logout}>
                    <span className="material-symbols-outlined">logout</span>
                    <span>Logout</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
