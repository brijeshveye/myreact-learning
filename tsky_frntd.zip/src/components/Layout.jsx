import React, { useEffect, useState, useCallback } from 'react';
import { Outlet, NavLink, useNavigate, useLocation, Navigate } from 'react-router-dom';
import TopBar from './TopBar';
import { usePermission } from '../context/PermissionContext.jsx';
import { PERMISSIONS } from '../utils/permissions.js';
import PendingApproval from '../pages/PendingApproval';
import { useNotificationStream } from '../hooks/useNotificationStream.js';

import VeyeLogo from '/assets/images/veye-icon-new.png'

// Admin navigation items with associated permission required to see (lowest meaningful permission)
const adminNavItems = [
  { to: '/admin/dashboard', icon: 'dashboard', label: 'Dashboard', perm: PERMISSIONS.TASK_READ },
  { to: '/admin/reports/detailed', icon: 'task_alt', label: 'Reports', perm: PERMISSIONS.TASK_READ },
  { to: '/admin/users', icon: 'group', label: 'User Management', perm: PERMISSIONS.USER_READ },
  { to: '/admin/departments', icon: 'apartment', label: 'Departments', perm: PERMISSIONS.DEPARTMENT_READ },
  { to: '/admin/tasks', icon: 'assignment', label: 'Task Management', perm: PERMISSIONS.TASK_READ },
];

const navItems = [
  { to: '/dashboard', icon: 'dashboard', label: 'My Dashboard' },
  { to: '/tasks', icon: 'task_alt', label: 'Tasks' },
  { to: '/tracker', icon: 'track_changes', label: 'Time Tracker' },
  { to: '/crm-analytics', icon: 'insights', label: 'CRM Analytics' },
  { to: '/download', icon: 'download', label: 'Download App' },
  // '/reports' not defined for employee in routes; keeping minimal set
];

export default function Layout() {
  const navigate = useNavigate();
  const { has } = usePermission();
  const location = useLocation();
  // user: undefined => not yet checked; null => checked & unauthenticated; object => authenticated
  const [user, setUser] = useState(undefined);
  const [checked, setChecked] = useState(false);
  const handleIncomingNotification = useCallback((n) => {
    window.dispatchEvent(new CustomEvent('notifications:new', { detail: n }));
  }, []);

  useNotificationStream({
    onNotification: handleIncomingNotification,
    onStatusChange: (s) => window.dispatchEvent(new CustomEvent('socket:status', { detail: s }))
  });

  useEffect(() => {
    try {
      const stored = localStorage.getItem('user');
      if (stored) {
        setUser(JSON.parse(stored));
      } else {
        setUser(null);
      }
    } catch (error) {
      console.error("Error reading user from localStorage", error);
      setUser(null);
    } finally {
      setChecked(true);
    }
  }, [location.pathname]);

  // While loading auth state, optionally render nothing (could show spinner)
  if (!checked) {
    return <div className="d-flex vh-100 align-items-center justify-content-center text-soft small">Loading…</div>;
  }

  // If not authenticated, redirect to login (login/register routes are outside Layout so no loop)
  if (checked && user === null) {
    return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  }

  // If user is pending, block app pages and show pending notice
  if (user?.userType === 'Pending') {
    return (
      <div className="d-flex vh-100">
        <div className="flex-grow-1 d-flex flex-column overflow-hidden">
          <TopBar />
          <main className="flex-grow-1 overflow-auto p-4 app-main">
            <PendingApproval />
          </main>
        </div>
      </div>
    );
  }

  // Filter admin items strictly by permission set instead of role branching
  const adminItems = adminNavItems.filter(item => has(item.perm));
  const roleLabel = user?.userGroup === 'Super Admin'
    ? 'Super Admin'
    : user?.userGroup === 'Super Management'
    ? 'Super Management'
    : user?.userGroup === 'Management'
    ? 'Management'
    : null;

  return (
    <div className="d-flex vh-100">
      <aside className="sidebar d-flex flex-column flex-shrink-0">
  <div className="d-flex align-items-center px-4 py-3" style={{ height: 64, borderBottom: '1px solid var(--color-border-alt)' }}>
          {/* <div style={{ color: 'var(--primary-color)' }}>
            <svg fill="currentColor" height="24" viewBox="0 0 256 256" width="24" xmlns="http://www.w3.org/2000/svg"><path d="M216.49,100.49l-80-80a12,12,0,0,0-17,0l-80,80a12,12,0,0,0,17,17L128,45.31l71.51,72.18a12,12,0,0,0,17-17ZM128,112a12,12,0,0,0-12,12v88a12,12,0,0,0,24,0V124A12,12,0,0,0,128,112ZM208,124a12,12,0,0,1-12-12c0-1.2,0-2.38.16-3.55L138,49.8a4,4,0,0,0-5.92,0L48,134.18a12,12,0,1,1-17.06-17.06l84.18-84.34a20,20,0,0,1,28.32,0l58.1,58.2A43.8,43.8,0,0,1,220,112a12,12,0,0,1-12,12Z"></path></svg>
          </div> */}
          <img src={VeyeLogo} alt="Logo" style={{width:26, height:26}} />
          <h1 className="ms-1 mb-0 fs-4 fw-bold text-heading">Tasker</h1>
        </div>
        <nav className="flex-grow-1 px-3 py-4 d-flex flex-column gap-1">
          <div className="text-soft text-uppercase small fw-bold px-3 mb-2">My Personal</div>
          {navItems.map(item => (
            <NavLink key={item.to} to={item.to} className={({ isActive }) => `d-flex align-items-center gap-2 px-3 py-2 rounded fw-semibold ${isActive ? 'active' : ''}`}>
              <span className="material-symbols-outlined">{item.icon}</span>
              <span>{item.label}</span>
            </NavLink>
          ))}
          {['Super Admin', 'Super Management', 'Management'].includes(roleLabel) && adminItems.length > 0 && (
            <>
              <div className="text-soft text-uppercase small fw-bold px-3 mt-4 mb-2">{roleLabel || 'Admin'}</div>
              {adminItems.map(item => (
                <NavLink key={item.to} to={item.to} className={({ isActive }) => `d-flex align-items-center gap-2 px-3 py-2 rounded fw-semibold ${isActive ? 'active' : ''}`}>
                  <span className="material-symbols-outlined">{item.icon}</span>
                  <span>{item.label}</span>
                </NavLink>
              ))}
            </>
          )}
        </nav>
      </aside>
      <div className="flex-grow-1 d-flex flex-column overflow-hidden">
        <TopBar />
        <main className="flex-grow-1 overflow-auto p-4 app-main">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
