import React from 'react';
import { resolveUserAvatar } from '../utils/avatars.js';

export function UserAvatar({ user, size = 40, className = '', rounded = true, alt }) {
  const url = resolveUserAvatar(user);
  const style = { width: size, height: size, objectFit: 'cover' };
  const cls = `${rounded ? 'rounded-circle' : ''} ${className}`.trim();
  return <img src={url} alt={alt || user?.fullName || user?.name || user?.email || 'User'} style={style} className={cls} />;
}
export default UserAvatar;
