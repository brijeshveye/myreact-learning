import React from 'react';
import { Link, useLocation } from 'react-router-dom';

export default function ReportTabs() {
  const location = useLocation();
  const normalize = (p) => (p || '').replace(/\/+$/, '');
  const tabs = [
    { to: '/admin/reports/detailed', label: 'Detailed' },
    { to: '/admin/reports/absolute', label: 'Absolute' },
    { to: '/admin/reports/performance', label: 'Performance' },
  ];

  return (
    <div className="mb-3 mb-sm-4">
      <ul className="nav nav-pills gap-2 flex-wrap">
        {tabs.map(t => (
          <li className="nav-item" key={t.to}>
            {(() => {
              const path = normalize(location.pathname);
              const target = normalize(t.to);
              const active = path === target || path.startsWith(target + '/');
              return (
                <Link
                  to={t.to}
                  className={`nav-link px-3 py-1 fw-semibold rounded ${active ? 'active bg-primary text-white' : 'text-soft'}`}
                >
                  {t.label}
                </Link>
              );
            })()}
          </li>
        ))}
      </ul>
    </div>
  );
}
