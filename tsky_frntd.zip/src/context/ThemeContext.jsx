import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';

// Simple theme context to toggle between light & dark and persist preference
const ThemeContext = createContext({ theme: 'dark', toggleTheme: () => {} });

export const ThemeProvider = ({ children }) => {
  const getPreferred = () => {
    const stored = typeof window !== 'undefined' ? localStorage.getItem('theme') : null;
    if (stored === 'light' || stored === 'dark') return stored;
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches) return 'light';
    return 'dark';
  };

  const [theme, setTheme] = useState(getPreferred);

  const applyTheme = useCallback((t) => {
    const body = document.body;
    body.classList.remove('theme-light', 'theme-dark');
    body.classList.add(`theme-${t}`);
    // Set a color-scheme hint for built-in form controls
    body.style.colorScheme = t;
  }, []);

  useEffect(() => { applyTheme(theme); }, [theme, applyTheme]);

  const toggleTheme = useCallback(() => {
    setTheme(prev => {
      const next = prev === 'dark' ? 'light' : 'dark';
      localStorage.setItem('theme', next);
      return next;
    });
  }, []);

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => useContext(ThemeContext);
