import React, { createContext, useContext, useMemo } from 'react';
import { buildPermissionSet, roleHasPermission } from '../utils/permissions';

const PermissionContext = createContext({
  role: null,
  permissions: new Set(),
  has: () => false,
  any: () => false
});

export function PermissionProvider({ role, children }) {
  const value = useMemo(() => {
    const set = buildPermissionSet(role);
    return {
      role,
      permissions: set,
      has: (perm) => set.has(perm),
      any: (perms) => perms.some(p => set.has(p))
    };
  }, [role]);

  return <PermissionContext.Provider value={value}>{children}</PermissionContext.Provider>;
}

export function usePermission() {
  return useContext(PermissionContext);
}

export function useCan(perm) {
  const { has } = usePermission();
  return has(perm);
}

export function useAny(perms) {
  const { any } = usePermission();
  return any(perms);
}
