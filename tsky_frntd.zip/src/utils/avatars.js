// Frontend avatar utility: chooses deterministic or random default avatar based on gender.
// Mirrors server logic file names located under /assets/images.

const boyAvatars = [
  'boy-default-avatar.png',
  'boy-default-avatar_2.png'
];
const girlAvatars = [
  'girl-default-avatar.png',
  'girl-default-avatar_2.png',
  'girl-default-avatar_3.png',
  'girl-default-avatar_4.png',
  'girl-default-avatar_5.png'
];

function poolForGender(g) {
  const gender = (g || '').toLowerCase();
  if (gender === 'male') return boyAvatars;
  if (gender === 'female') return girlAvatars;
  return boyAvatars.concat(girlAvatars);
}

export function randomAvatar(gender) {
  const pool = poolForGender(gender);
  return `/assets/images/${pool[Math.floor(Math.random() * pool.length)]}`;
}

// Deterministic selection using user id or email hash for consistent UI across renders
export function deterministicAvatar(gender, seedSource) {
  const pool = poolForGender(gender);
  const seedStr = String(seedSource || '').trim();
  if (!seedStr) return randomAvatar(gender);
  let hash = 0;
  for (let i = 0; i < seedStr.length; i++) {
    hash = (hash * 31 + seedStr.charCodeAt(i)) >>> 0;
  }
  return `/assets/images/${pool[hash % pool.length]}`;
}

export function resolveUserAvatar(user) {
  if (!user) return randomAvatar();
  if (user.profilePicture) return user.avatarUrl;
  const seed = user._id || user.id || user.email || user.companyOfficialEmail;
  return deterministicAvatar(user.gender, seed);
}
