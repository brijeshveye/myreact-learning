// Frontend mirror of backend permissions & role mapping.
// Keep in sync with server/src/utils/permissions.js

export const ROLES = {
  SUPER_ADMIN: 'Super Admin',
  SUPER_MANAGEMENT: 'Super Management',
  MANAGEMENT: 'Management',
  EMPLOYEE: 'Employee'
};

export const PERMISSIONS = {
  USER_CREATE: 'user.create',
  USER_READ: 'user.read',
  USER_UPDATE: 'user.update',
  USER_DELETE: 'user.delete',

  TASK_CREATE: 'task.create',
  TASK_READ: 'task.read',
  TASK_UPDATE: 'task.update',
  TASK_DELETE: 'task.delete',

  DEPARTMENT_CREATE: 'department.create',
  DEPARTMENT_READ: 'department.read',
  DEPARTMENT_UPDATE: 'department.update',
  DEPARTMENT_DELETE: 'department.delete'
};

// Role -> permissions (must match backend). This allows optimistic UI gating.
export const ROLE_PERMISSIONS = {
  [ROLES.SUPER_ADMIN]: Object.values(PERMISSIONS),
  [ROLES.SUPER_MANAGEMENT]: [
    PERMISSIONS.USER_CREATE,
    PERMISSIONS.USER_READ,
    PERMISSIONS.USER_UPDATE,
    PERMISSIONS.USER_DELETE,
    PERMISSIONS.TASK_CREATE,
    PERMISSIONS.TASK_READ,
    PERMISSIONS.TASK_UPDATE,
    PERMISSIONS.TASK_DELETE,
    PERMISSIONS.DEPARTMENT_CREATE,
    PERMISSIONS.DEPARTMENT_READ,
    PERMISSIONS.DEPARTMENT_UPDATE,
    PERMISSIONS.DEPARTMENT_DELETE
  ],
  [ROLES.MANAGEMENT]: [
    PERMISSIONS.USER_READ,
    PERMISSIONS.TASK_CREATE,
    PERMISSIONS.TASK_READ,
    PERMISSIONS.TASK_UPDATE,
    PERMISSIONS.DEPARTMENT_READ
  ],
  [ROLES.EMPLOYEE]: [
    PERMISSIONS.TASK_READ
  ]
};

export function roleHasPermission(role, permission) {
  return ROLE_PERMISSIONS[role]?.includes(permission) || false;
}

export function buildPermissionSet(role) {
  return new Set(ROLE_PERMISSIONS[role] || []);
}
