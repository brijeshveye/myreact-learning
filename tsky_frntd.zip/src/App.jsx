import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Dashboard from './pages/admin/Dashboard';
import DetailedTaskReport from './pages/admin/reports/DetailedTaskReport';
import AbsoluteReport from './pages/admin/reports/AbsoluteReport';
import PerformanceReport from './pages/admin/reports/PerformanceReport';
import Login from './pages/Login';
import Register from './pages/Register';
import Layout from './components/Layout';
import MyProfile from './pages/MyProfile';
import UserProfile from './pages/admin/UserProfile';
import UserManagement from './pages/admin/UserManagement';
import Departments from './pages/admin/Departments';
import DepartmentForm from './pages/admin/DepartmentForm';
import UserDetailReview from './pages/admin/UserDetailReview';
import ErrorPage from './pages/ErrorPage';
import EmployeeUserDashboard from './pages/employee/UserDashboard';
import TaskManagement from './pages/admin/TaskManagement';
import TaskDetail from './pages/admin/TaskDetail';
import UserRegister from './pages/admin/UserRegister';
import MyTaskDetail from './pages/employee/MyTaskDetail';
import MyTaskManagement from './pages/employee/MyTaskManagement';
import AdminUserDashboard from './pages/admin/AdminUserDashboard';
import UserTaskManagement from './pages/admin/UserTaskManagement';
import PendingApproval from './pages/PendingApproval';
import Notifications from './pages/Notifications';
import TrackerReportPage from './pages/employee/TrackerReportPage';
import ScreenshotTimeline from './pages/admin/ScreenshotTimeline';
import CrmAnalytics from './pages/employee/CrmAnalytics';
import AdminAttendancePage from './pages/admin/Attendance';
import Download from './pages/Download';

function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/download" element={<Download />} />

      <Route element={<Layout />}> {/* protected layout wrapper (auth check can be added) */}
        <Route index element={<Navigate to="/dashboard" replace />} />

        {/* Employee routes */}
        <Route path="/dashboard" element={<EmployeeUserDashboard />} />
        <Route path="/tasks" element={<MyTaskManagement />} />
        <Route path="/tasks/:taskId" element={<MyTaskDetail />} />

        <Route path="/tracker" element={<TrackerReportPage />} />
  <Route path="/crm-analytics" element={<CrmAnalytics />} />


        {/* Common routes */}
        <Route path="/profile" element={<MyProfile />} />
        <Route path="/notifications" element={<Notifications />} />


        {/* Admin routes */}
        <Route path="/admin/dashboard" element={<Dashboard />} />

        <Route path="/admin/reports/detailed" element={<DetailedTaskReport />} />
        <Route path="/admin/reports/absolute" element={<AbsoluteReport />} />
        <Route path="/admin/reports/performance" element={<PerformanceReport />} />

        <Route path="/admin/users" element={<UserManagement />} />
        <Route path="/admin/users/view/:userId" element={<AdminUserDashboard />} />
  <Route path="/admin/users/attendance/:userId" element={<AdminAttendancePage />} />
        <Route path="/admin/users/tasks/:userId" element={<UserTaskManagement />} />
  <Route path="/admin/users/screenshots/:userId" element={<ScreenshotTimeline />} />
        <Route path="/admin/users/new" element={<UserRegister />} />
        <Route path="/admin/users/edit/:userId" element={<UserProfile />} />
        <Route path="/admin/users/review/:userId" element={<UserDetailReview />} />

        <Route path="/admin/departments" element={<Departments />} />
        <Route path="/admin/departments/new" element={<DepartmentForm />} />
        <Route path="/admin/departments/:deptId" element={<DepartmentForm />} />

        <Route path="/admin/tasks" element={<TaskManagement />} />
        <Route path="/admin/tasks/:taskId" element={<TaskDetail />} />

      </Route>

      <Route path="/pending" element={<PendingApproval />} />
      <Route path="/error" element={<ErrorPage />} />
      <Route path="*" element={<ErrorPage />} />

    </Routes>
  );
}

export default App;
