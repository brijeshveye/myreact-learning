import { api } from './client';

const API_BASE = '/notifications'; // api client already prefixes /api

// Ensure single 401 redirect logic (idempotent)
let interceptorAttached = false;
function attach401Handler() {
  if (interceptorAttached) return;
  api.interceptors.response.use(r => r, err => {
    const status = err?.response?.status;
    if (status === 401) {
      try {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
      } catch { /* ignore */ }
      if (typeof window !== 'undefined' && window.location.pathname !== '/login') {
        window.location.replace('/login');
      }
    }
    return Promise.reject(err);
  });
  interceptorAttached = true;
}
attach401Handler();

export async function fetchNotifications({ page = 1, limit = 20, unread, type } = {}) {
  const params = { page, limit };
  if (unread !== undefined) params.unread = unread;
  if (type) params.type = type;
  const { data } = await api.get(API_BASE, { params });
  return data;
}

export async function markAllNotificationsRead() {
  const { data } = await api.post(`${API_BASE}/mark-all-read`);
  return data;
}

export async function markNotificationRead(id, read = true) {
  const { data } = await api.patch(`${API_BASE}/${id}/read`, { read });
  return data;
}

export async function deleteNotification(id) {
  const { data } = await api.delete(`${API_BASE}/${id}`);
  return data;
}

export async function createNotification(payload) {
  const { data } = await api.post(API_BASE, payload);
  return data;
}

export async function sendDirectNotification(payload) {
  const { data } = await api.post(`${API_BASE}/direct`, payload);
  return data;
}
