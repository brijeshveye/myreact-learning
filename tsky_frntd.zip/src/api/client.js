import axios from 'axios';

export const api = axios.create({
  baseURL: '/api',
});

api.interceptors.response.use(r => r, err => {
  // simple global error hook
  return Promise.reject(err);
});

// Attach token if present
api.interceptors.request.use(config => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});
