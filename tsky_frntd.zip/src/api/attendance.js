import { api } from './client';

export async function fetchAdminAttendanceDay({ userId, date }) {
  const params = { user_id: userId, date };
  const { data } = await api.get('/attendance/admin/day', { params });
  return data?.data || data;
}

export default { fetchAdminAttendanceDay };
