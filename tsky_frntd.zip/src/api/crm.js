import { api } from './client';

// Fetch aggregate metrics for CRM analytics for the current user (scope=self)
// params: { dateStart?: 'YYYY-MM-DD', dateEnd?: 'YYYY-MM-DD' }
export async function fetchCrmMetrics(params = {}) {
  const { data } = await api.get('/crm/analytics/metrics', { params: { ...params, scope: 'self' } });
  return data;
}

// Fetch last 7 days analytics rows for chart/table for the current user (scope=self)
// params: { dateEnd?: 'YYYY-MM-DD' } // if not provided, server should default to today
export async function fetchCrmLast7Days(params = {}) {
  const { data } = await api.get('/crm/analytics/last7days', { params: { ...params, scope: 'self' } });
  return data;
}

// Optional: fetch recent activities list if needed in future
export async function fetchCrmActivities(params = {}) {
  const { data } = await api.get('/crm/activities', { params: { ...params, scope: 'self' } });
  return data;
}

// New Analytics API (proxied via backend)
export async function fetchAnalyticsUsersSummary(params = {}) {
  const { data } = await api.get('/crm/analytics/users/summary', { params });
  return data;
}

export async function fetchAnalyticsUsersRegistrations(params = {}) {
  const { data } = await api.get('/crm/analytics/users/registrations', { params });
  return data;
}

export async function fetchAnalyticsLeadsByUser(params = {}) {
  const { data } = await api.get('/crm/analytics/leads/by-user', { params });
  return data;
}

export async function fetchAnalyticsActivitiesCreatedByUser(params = {}) {
  const { data } = await api.get('/crm/analytics/activities/created-by-user', { params });
  return data;
}

export async function fetchAnalyticsActivitiesByType(params = {}) {
  const { data } = await api.get('/crm/analytics/activities/by-type', { params });
  return data;
}

export async function fetchAnalyticsActivitiesTypesByUser(params = {}) {
  const { data } = await api.get('/crm/analytics/activities/types-by-user', { params });
  return data;
}

export async function fetchAnalyticsLeadsUpdatedByUser(params = {}) {
  const { data } = await api.get('/crm/analytics/leads/updated-by-user', { params });
  return data;
}
