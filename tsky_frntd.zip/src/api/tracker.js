import { api } from './client';

// range tokens: 'yesterday' | 'day_before' | 'two_before' (client mapping from labels)
export async function fetchTrackerReport(userId, rangeToken) {
  if (!userId) throw new Error('userId required');
  const params = {};
  if (rangeToken) params.range = rangeToken;
  const { data } = await api.get(`/tracker/report/${encodeURIComponent(userId)}`, { params });
  return data;
}
