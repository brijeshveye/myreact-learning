import { useEffect, useState, useCallback } from 'react';
import { api } from '../api/client';

export function useTasks(params = {}) {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchTasks = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const res = await api.get('/tasks', { params });
      const payload = res?.data;
      const list = Array.isArray(payload)
        ? payload
        : (payload?.data || payload?.items || payload?.tasks || []);
      setData(list);
    } catch (e) {
      setError(e);
    } finally { setLoading(false); }
  }, [JSON.stringify(params)]);

  useEffect(() => { fetchTasks(); }, [fetchTasks]);

  return { tasks: data, loading, error, refetch: fetchTasks };
}
