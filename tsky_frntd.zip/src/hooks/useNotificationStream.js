import { useEffect, useRef } from 'react';
import { io } from 'socket.io-client';
import { toast } from 'react-toastify';

/**
 * useNotificationStream
 * Establishes a socket connection using stored JWT token (localStorage 'token')
 * Listens for 'notification:new' events and displays toast + invokes optional callback.
 */
export function useNotificationStream({ onNotification, onStatusChange } = {}) {
  const socketRef = useRef(null);
  const notifRef = useRef(onNotification);
  const statusRef = useRef(onStatusChange);
  const audioRef = useRef(null);
  const lastPlayAtRef = useRef(0);

  // Keep latest callbacks without re-initializing socket
  useEffect(() => { notifRef.current = onNotification; }, [onNotification]);
  useEffect(() => { statusRef.current = onStatusChange; }, [onStatusChange]);

  useEffect(() => {
    // Prepare notification sound
    try {
      const a = new Audio('/assets/sounds/message.wav');
      a.preload = 'auto';
      a.volume = 0.7; // gentle default volume
      audioRef.current = a;
    } catch { /* ignore */ }

    let token = localStorage.getItem('token');
    if (!token) return; // no auth token - skip
    if (typeof token === 'string' && token.startsWith('Bearer ')) {
      token = token.slice('Bearer '.length);
    }

    const baseURL = (import.meta.env.VITE_WS_BASE?.replace(/\/$/, '')) || 'http://localhost:4000';
    const s = io(baseURL, {
      auth: { token },
      transports: ['websocket', 'polling'], // allow fallback if WS blocked
      upgrade: true,
      rememberUpgrade: false,
      reconnection: true,
      reconnectionAttempts: 12,
      reconnectionDelay: 750,
      reconnectionDelayMax: 6000,
      timeout: 12000,
      path: '/socket.io'
    });
    socketRef.current = s;

    s.on('connect', () => {
      if (statusRef.current) statusRef.current('connected');
    });

    s.io.on('reconnect_attempt', (attempt) => {
      // console.debug('Socket reconnect attempt', attempt);
    });

    let firstConnectErrorToasted = false;
    s.on('connect_error', (err) => {
      console.warn('[socket] connect_error', err.message);
      if (!firstConnectErrorToasted) {
        // toast.warn(`Realtime connection issue: ${err.message}`);
        firstConnectErrorToasted = true;
      }
      if (statusRef.current) statusRef.current('disconnected');
    });

    s.io.on('reconnect_failed', () => {
      // toast.error('Realtime connection failed after retries');
    });

    s.on('error', (err) => {
      console.warn('Socket error', err);
    });

    const handleToast = (notif) => {
      // Throttled sound play to avoid overlapping tones on bursts
      const now = Date.now();
      if (audioRef.current && now - lastPlayAtRef.current > 400) {
        try {
          const audio = audioRef.current;
          // restart from beginning for rapid consecutive notifications
          audio.pause();
          audio.currentTime = 0;
          audio.play().catch(() => {/* autoplay policy may block; ignore */});
          lastPlayAtRef.current = now;
        } catch { /* ignore */ }
      }

      const title = notif?.title || '';
      const message = notif?.message || '';
      toast.info(`${title}\n${message}`, { autoClose: 6000 });
      if (notifRef.current) notifRef.current(notif);
    };

    s.on('notification:new', handleToast);
    s.on('notification:direct', handleToast);

    s.on('disconnect', (reason) => {
      if (statusRef.current) statusRef.current('disconnected');
      if (reason === 'io server disconnect') {
        // manual re-connect if server disconnected us intentionally
        setTimeout(() => s.connect(), 1500);
      }
    });

    return () => {
      s.close();
    };
  }, []);

  return socketRef;
}
