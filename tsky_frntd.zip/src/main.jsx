import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import { ThemeProvider } from './context/ThemeContext';
import { PermissionProvider } from './context/PermissionContext.jsx';
import ToastRoot from './components/ToastRoot.jsx';
// import '../public/app.css';
// import '/app.css';
import 'bootstrap/dist/css/bootstrap.min.css';

function resolveRole() {
  try {
    const raw = localStorage.getItem('user');
    if (!raw) return null;
    const obj = JSON.parse(raw);
    return obj?.userGroup || null;
  } catch (e) { return null; }
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <ThemeProvider>
      <PermissionProvider role={resolveRole()}>
        <BrowserRouter>
          <ToastRoot />
          <App />
        </BrowserRouter>
      </PermissionProvider>
    </ThemeProvider>
  </React.StrictMode>
);

// Register service worker for PWA (vite-plugin-pwa auto injects /sw.js on build)
if ('serviceWorker' in navigator) {
  window.addEventListener('load', async () => {
    try {
      await navigator.serviceWorker.register('/sw.js');
      // optional: listen for updates and prompt user to refresh
    } catch (e) {
      // silent
    }
  });
}
