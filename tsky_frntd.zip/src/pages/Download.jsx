import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api/client';

export default function Download() {
  const [info, setInfo] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fallbackUrl = import.meta.env.VITE_WINDOWS_APP_DOWNLOAD_URL || '';

  useEffect(() => {
    let mounted = true;
    async function load() {
      setLoading(true); setError('');
      try {
        const { data } = await api.get('/app-version');
        const payload = data?.data || data || {};
        if (mounted) setInfo(payload);
      } catch (e) {
        if (mounted) { setInfo(null); setError(e?.response?.data?.message || e.message || 'Failed to load app version'); }
      } finally {
        if (mounted) setLoading(false);
      }
    }
    load();
    return () => { mounted = false; };
  }, []);

  const downloadUrl = useMemo(() => {
    return info?.update_url || fallbackUrl || '';
  }, [info, fallbackUrl]);

  const canDownload = !!downloadUrl;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(downloadUrl);
      alert('Download link copied');
    } catch {
      // ignore
    }
  };

  return (
    <div className="min-vh-100 d-flex flex-column" style={{background:"radial-gradient(1200px 600px at 10% -10%, rgba(99,102,241,0.25), transparent 60%), radial-gradient(1000px 500px at 100% 0%, rgba(16,185,129,0.18), transparent 50%)"}}>
      {/* Header */}
      <header className="container-xl d-flex align-items-center justify-content-between py-4 px-3">
        <div className="d-flex align-items-center gap-2">
          <div className="rounded-circle d-inline-flex align-items-center justify-content-center" style={{width:36, height:36, background:'var(--primary-color)'}}>
            <span className="material-symbols-outlined text-white">task_alt</span>
          </div>
          <h1 className="h5 mb-0 fw-bold text-heading">Tasker</h1>
        </div>
        <div className="d-flex align-items-center gap-2">
          <Link className="btn btn-link text-heading" to="/login">Sign in</Link>
        </div>
      </header>

      {/* Hero */}
      <section className="container-xl px-3">
        <div className="row align-items-center g-4" style={{minHeight: '52vh'}}>
          <div className="col-lg-7">
            <h2 className="display-6 fw-extrabold text-heading mb-3">Supercharge your productivity with our Windows Task Manager</h2>
            <p className="lead text-soft mb-4">Track time, view analytics, and manage tasks effortlessly. Built for teams that value clarity and performance.</p>
            <div className="d-flex flex-wrap gap-2 align-items-center">
              <a className={`btn btn-primary-custom d-flex align-items-center gap-2 ${canDownload ? '' : 'disabled'}`} href={canDownload ? downloadUrl : undefined} target="_blank" rel="noreferrer">
                <span className="material-symbols-outlined">download</span>
                <span>Download for Windows</span>
              </a>
              <button className="btn btn-secondary-custom d-flex align-items-center gap-2" onClick={handleCopy} disabled={!canDownload}>
                <span className="material-symbols-outlined">content_copy</span>
                <span>Copy link</span>
              </button>
              {loading && <span className="text-soft small ms-2">Checking latest version…</span>}
              {!loading && error && <span className="text-red-custom small ms-2">{error}</span>}
              {!loading && info?.version && (
                <span className="badge bg-secondary-subtle text-soft fw-semibold ms-2">Latest: v{info.version}</span>
              )}
            </div>
            {info?.notes && (
              <div className="mt-3 small text-soft" style={{maxWidth:600}}>
                <div className="fw-semibold text-heading mb-1">What’s new</div>
                <div style={{whiteSpace:'pre-wrap'}}>{info.notes}</div>
              </div>
            )}
          </div>
          <div className="col-lg-5">
            <div className="card p-3 shadow" style={{backdropFilter:'blur(8px)'}}>
              <div className="d-flex align-items-center gap-3">
                <div className="rounded-circle d-inline-flex align-items-center justify-content-center" style={{width:48, height:48, background:'var(--color-card)'}}>
                  <span className="material-symbols-outlined">windows</span>
                </div>
                <div>
                  <div className="text-heading fw-bold">Windows Application</div>
                  <div className="text-soft small">Windows 10/11 • 64-bit</div>
                </div>
              </div>
              <ul className="mt-3 mb-0 text-soft small ps-3">
                <li>One-click timer start/stop with task selection</li>
                <li>Automatic screenshot capture with privacy controls</li>
                <li>Offline support and upload retries</li>
                <li>Seamless sync with Tasker web</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Features grid */}
      <section className="container-xl px-3 py-5">
        <div className="row g-3">
          {[
            { icon:'schedule', title:'Smart Time Tracking', desc:'Accurate work logs with idle detection and break awareness.'},
            { icon:'lock', title:'Secure by default', desc:'Data transmitted over HTTPS with role-based access control.'},
            { icon:'bolt', title:'Fast & Lightweight', desc:'Optimized for minimal CPU and memory usage while tracking.'},
            { icon:'insights', title:'Actionable Insights', desc:'Understand productivity trends with daily and weekly reports.'},
          ].map((f) => (
            <div className="col-md-6 col-lg-3" key={f.title}>
              <div className="card h-100 p-3">
                <div className="d-flex align-items-center gap-2 mb-2 text-soft">
                  <span className="material-symbols-outlined">{f.icon}</span>
                  <span className="small">{f.title}</span>
                </div>
                <div className="fw-semibold text-heading">{f.title}</div>
                <div className="text-soft small mt-1">{f.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-auto py-4">
        <div className="container-xl px-3 d-flex flex-wrap align-items-center justify-content-between gap-3">
          <div className="text-soft small">© {new Date().getFullYear()} Tasker. All rights reserved.</div>
          <div className="d-flex align-items-center gap-3 small">
            <Link to="/login" className="text-soft">Sign in</Link>
            <a href="mailto:support@example.com" className="text-soft">Support</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
