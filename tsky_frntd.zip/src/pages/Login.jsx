import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { api } from '../api/client';
import { toast } from 'react-toastify';

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit(e){
    e.preventDefault();
    setSubmitting(true);
    setError('');
    try {
      const { data } = await api.post('/auth/login', { email, password });
      localStorage.setItem('token', data.token);
      if (data?.user) localStorage.setItem('user', JSON.stringify(data.user));
      toast.success('Logged in successfully');
      const u = data?.user || {};
      if (u.userType === 'Pending') {
        navigate('/pending');
      } else if (u.userGroup && u.userGroup !== 'Employee') {
        navigate('/admin/dashboard');
      } else {
        navigate('/dashboard');
      }
    } catch (err) {
      const msg = err?.response?.data?.message || 'Login failed';
      setError(msg);
      toast.error(msg);
    } finally {
      setSubmitting(false);
    }
  }
  return (
    <div className="min-vh-100 d-flex align-items-center justify-content-center">
      <div className="w-100" style={{maxWidth:420}}>
        <div className="card-login">
          <div className="p-4 p-sm-5">
            <div className="text-center mb-4">
              <svg className="svg-icon mb-3" style={{width:64,height:64}} fill="none" stroke="var(--primary-color)" strokeWidth="1.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" strokeLinecap="round" strokeLinejoin="round"></path>
              </svg>
              <h1 className="fs-2 fw-bold text-heading mb-1">Welcome Back</h1>
              <p className="text-secondary mb-0">Sign in to continue to your dashboard.</p>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="mb-3 position-relative">
                <span className="material-symbols-outlined input-icon">person</span>
                <input className="form-control" placeholder="Email" type="email" value={email} onChange={e=>setEmail(e.target.value)} required />
              </div>
              <div className="mb-3 position-relative">
                <span className="material-symbols-outlined input-icon">lock</span>
                <input className="form-control" placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} required />
              </div>
              <div className="mb-3 text-end">
                <a className="text-primary text-decoration-none fw-medium" href="#">Forgot Password?</a>
              </div>
              {error && (
                <div className="alert alert-danger" role="alert">{error}</div>
              )}
              <div className="mb-2">
                <button className="btn btn-primary-custom w-100 d-flex align-items-center justify-content-center" type="submit" disabled={submitting}>
                  <span>{submitting ? 'Signing in…' : 'Login'}</span>
                  <span className="material-symbols-outlined ms-2">arrow_forward</span>
                </button>
              </div>
            </form>
          </div>
          <div className="card-footer px-4 py-3 text-center">
            <span>Don't have an account? <Link className="fw-medium text-primary text-decoration-none" to="/register">Sign up</Link></span>
          </div>
        </div>
      </div>
    </div>
  );
}
