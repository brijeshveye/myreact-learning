import React from 'react';
import { useNavigate } from 'react-router-dom';

export default function ErrorPage() {
  const navigate = useNavigate();
  const goDashboard = (e) => {
    e.preventDefault();
    navigate('/dashboard', { replace: true });
  };
  const reload = () => window.location.reload();

  return (
    <div className="min-vh-100 d-flex flex-column bg-body text-white">
      {/* Header (self-contained, outside app Layout) */}
      <header className="bg-header border-bottom" style={{ borderColor: '#283039' }}>
        <div className="container-fluid px-4 py-3 d-flex align-items-center justify-content-between">
          <div className="d-flex align-items-center gap-3">
            <svg style={{ width: 24, height: 24, color: 'var(--primary-color)' }} fill="none" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
              <path d="M6 6H42L36 24L42 42H6L12 24L6 6Z" fill="currentColor"></path>
            </svg>
            <h1 className="h5 fw-bold mb-0">TaskMaster</h1>
          </div>
          <div className="d-flex align-items-center gap-3">
            <nav className="d-none d-md-flex align-items-center gap-3">
              <a className="text-decoration-none fw-medium text-white" href="#">Dashboard</a>
              <a className="text-decoration-none fw-medium text-white-50" href="#">Tasks</a>
              <a className="text-decoration-none fw-medium text-white-50" href="#">Projects</a>
              <a className="text-decoration-none fw-medium text-white-50" href="#">Reports</a>
              <a className="text-decoration-none fw-medium text-white-50" href="#">People</a>
            </nav>
            <button className="btn btn-dark rounded-circle position-relative p-2 d-flex align-items-center justify-content-center" style={{ width: 40, height: 40 }}>
              <span className="material-symbols-outlined">notifications</span>
            </button>
            <div
              className="profile-img"
              style={{
                backgroundImage:
                  "url('https://lh3.googleusercontent.com/aida-public/AB6AXuCookLWBpvQjfSM-ENHHtl-bqhvxOjHrZUTg8y0iFvMQiNiwjp3_VoWOcUacaq72RIDAKcwyYpxzfznwtUV639AzsptJDyDxMDlzYD5OL6PrMYVyPocNUh-MlkNe31oQokYTufgGJcDy5_mmP1tuUGcJ2i6kVbt0OUFZhBIsoEYN7VftlNwnkie6Rp2MwDYnAUXwxvc7d3haOWb1c5-sGEne-tTvth0-wAboun7fOFByVH3CSY5lpMm1twpzJLOi2WuIZoGif9N69w')",
              }}
            />
          </div>
        </div>
      </header>

      {/* Main */}
      <main className="flex-grow-1 d-flex align-items-center justify-content-center">
        <div className="w-100" style={{ maxWidth: 640 }}>
          <div className="text-center px-4 py-5">
            <div className="mb-3">
              <span className="material-symbols-outlined" style={{ fontSize: 88, color: 'var(--primary-color)' }}>
                error_outline
              </span>
            </div>
            <p className="text-secondary fs-6 mb-1">Error 404</p>
            <h2 className="display-6 fw-bold text-white mb-3">Page Not Found</h2>
            <p className="text-secondary mx-auto mb-4" style={{ maxWidth: 520 }}>
              Sorry, we couldn't find the page you're looking for. It might have been moved, deleted, or maybe you just
              mistyped the URL.
            </p>
            <div className="d-flex flex-column flex-sm-row align-items-stretch align-items-sm-center justify-content-center gap-3">
              <a href="#" onClick={goDashboard} className="btn btn-primary d-inline-flex align-items-center gap-2 px-4 py-3 fw-semibold">
                <span className="material-symbols-outlined">dashboard</span>
                Go to Dashboard
              </a>
              <button type="button" onClick={reload} className="btn btn-outline-secondary d-inline-flex align-items-center gap-2 px-4 py-3 fw-semibold">
                <span className="material-symbols-outlined">refresh</span>
                Reload Page
              </button>
            </div>
            <div className="mt-4 text-secondary">
              <p className="mb-0">
                If you believe this is a mistake, please{' '}
                <a className="text-decoration-none fw-semibold" style={{ color: 'var(--primary-color)' }} href="#">
                  contact support
                </a>
                .
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
