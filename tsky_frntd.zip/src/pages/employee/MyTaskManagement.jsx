import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../../api/client';
import { useTasks } from '../../hooks/useTasks';
import { toast } from 'react-toastify';

export default function MyTaskManagement() {
  const [activeTab, setActiveTab] = useState('all'); // all | pendingApproval
  // Added filter state defaults to today
  const todayStr = new Date().toISOString().slice(0,10);
  const [taskFilters, setTaskFilters] = useState({ status: '', dateStart: todayStr, dateEnd: todayStr, today: true });
  // Build query params for server. When Pending Approval tab active include rawStatus=Pending
  const queryParams = useMemo(() => {
    const qp = { assignedTo: 'self' }; // force backend to scope to current user only
    if (taskFilters.status) qp.status = taskFilters.status;
    if (taskFilters.dateStart) qp.dateStart = taskFilters.dateStart;
    if (taskFilters.dateEnd) qp.dateEnd = taskFilters.dateEnd;
    if (activeTab === 'pendingApproval') qp.rawStatus = 'Pending';
    if (activeTab === 'carryOver') qp.carryOver = '1';
    return qp;
  }, [taskFilters, activeTab]);

  const hook = useTasks(queryParams);
  const tasks = Array.isArray(hook.tasks) ? hook.tasks : [];
  const { loading, error, refetch } = hook;

  // Create task form state
  const [form, setForm] = useState({
    title: '',
    description: '',
    priority: '0', // numeric string matching select option
    status: 'Pending',
    endDate: '',
    additionalTask: false,
  });
  const [creating, setCreating] = useState(false);
  const [createError, setCreateError] = useState('');
  const [deletingId, setDeletingId] = useState(null);

  // Edit modal state
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingTask, setEditingTask] = useState(null);
  const [editForm, setEditForm] = useState({ title: '', description: '', priority: '0', status: 'Pending', endDate: '', additionalTask: false });
  const [editSaving, setEditSaving] = useState(false);
  const [editError, setEditError] = useState('');

  const priorityLabel = (p) => {
    if (p === null || p === undefined) return 'Normal';
    const labels = ['Normal','High','Low','Critical','Urgent'];
    if (typeof p === 'number' && !Number.isNaN(p)) return labels[p] || 'Normal';
    if (typeof p === 'string') {
      if (/^\d+$/.test(p)) return labels[Number(p)] || 'Normal';
      const idx = labels.findIndex(l => l.toLowerCase() === p.toLowerCase());
      return idx === -1 ? 'Normal' : labels[idx];
    }
    return 'Normal';
  };
  const priorityBadge = (pRaw) => {
    const p = priorityLabel(pRaw);
    switch (p) {
      case 'High': return 'badge-priority-high';
      case 'Low': return 'badge-priority-low';
      case 'Critical': return 'badge-priority-critical';
      case 'Urgent': return 'badge-priority-urgent';
      default: return 'badge-priority-normal';
    }
  };
  const statusBadge = (s) => {
    switch (s) {
      case 'Completed': return 'badge-status-completed';
      case 'Ongoing': return 'badge-status-inprogress';
      case 'Hold': return 'badge-status-hold';
      case 'Suspended': return 'badge-status-suspended';
      case 'Pending':
      default: return 'badge-status-pending';
    }
  };

  const getTaskId = (t) => (t?._id || t?.id || t?.taskId || null);

  // Helpers for filtering
  const isLongPending = (t) => {
    if (t.status !== 'Pending') return false;
    const end = new Date(t.endDate);
    const now = new Date();
    const diffDays = Math.floor((now - end) / (1000 * 60 * 60 * 24));
    return diffDays > 7; // pending and overdue by more than a week
  };

  const fmtDate = (d) => {
    if (!d) return '-';
    try { return new Date(d).toLocaleDateString(); } catch { return '-'; }
  };

  const filteredTasks = useMemo(() => {
    const getRaw = (t) => (t.rawStatus || t.raw_status || t.rawstatus);
    const today = new Date(todayStr + 'T00:00:00');
    if (activeTab === 'pendingApproval') {
      return tasks.filter(t => getRaw(t) === 'Pending');
    }
    if (activeTab === 'carryOver') {
      // Server already applied carryOver filtering; trust backend to reduce payload
      return tasks;
    }
    // All tab (spec): rawStatus === 'Approved' OR additionalTask true
    return tasks.filter(t => (t.additionalTask || t.isAdditional) || (getRaw(t) === 'Approved'));
  }, [activeTab, tasks, todayStr]);
  const rows = Array.isArray(filteredTasks) ? filteredTasks : [];

  // Approve (set rawStatus to Approved)
  const [approvingId, setApprovingId] = useState(null);
  const approveTask = async (task) => {
    const id = getTaskId(task); if (!id) return;
    try { setApprovingId(id); await api.patch(`/tasks/${id}`, { rawStatus: 'Approved' }); await refetch(); toast.success('Task approved'); }
    catch (e) { toast.error(e?.response?.data?.message || e.message || 'Approve failed'); }
    finally { setApprovingId(null); }
  };
  const approveAllPending = async () => {
    const pending = tasks.filter(t => (t.rawStatus || t.raw_status || t.rawstatus) === 'Pending');
    if (!pending.length) return;
    if (!window.confirm(`Approve ${pending.length} tasks?`)) return;
    try { setApprovingId('bulk'); await Promise.all(pending.map(t => api.patch(`/tasks/${getTaskId(t)}`, { rawStatus: 'Approved' }))); await refetch(); toast.success('All pending tasks approved'); }
    catch (e) { toast.error(e?.response?.data?.message || e.message || 'Bulk approve failed'); }
    finally { setApprovingId(null); }
  };

  const onFormChange = (e) => {
    const { name, value } = e.target;
    setForm((f) => ({ ...f, [name]: value }));
  };

  const toggleAdditionalTask = () => {
    setForm(f => {
      const next = !f.additionalTask;
      return {
        ...f,
        additionalTask: next,
        // When not an additional task force back to Pending (was Pending Approval previously)
        status: next ? f.status : 'Pending'
      };
    });
  };

  const onCreateTask = async (e) => {
    e.preventDefault();
    setCreating(true);
    setCreateError('');
    try {
      const pr = Number(form.priority);
      const payload = {
        title: form.title?.trim(),
        description: form.description?.trim() || '',
        // Ensure priority is numeric (fallback 0)
        priority: Number.isFinite(pr) ? pr : 0,
        status: form.additionalTask ? form.status : 'Pending',
        endDate: form.endDate || null,
        additionalTask: !!form.additionalTask,
      };
    await api.post('/tasks', payload);
  setForm({ title: '', description: '', priority: '0', status: 'Pending', endDate: '', additionalTask: false });
      await refetch();
      toast.success('Task created');
    } catch (err) {
      const msg = err?.response?.data?.message || err.message || 'Failed to create task';
      setCreateError(msg);
      toast.error(msg);
    } finally {
      setCreating(false);
    }
  };

  const onDelete = async (task) => {
  const id = getTaskId(task);
    if (!id) return;
    const ok = window.confirm('Delete this task?');
    if (!ok) return;
    try {
      setDeletingId(id);
      await api.delete(`/tasks/${id}`);
      await refetch();
      toast.success('Task deleted');
    } catch (err) {
      toast.error(err?.response?.data?.message || err.message || 'Failed to delete task');
    } finally {
      setDeletingId(null);
    }
  };

  const onEditFormChange = (e) => {
    const { name, value } = e.target;
    setEditForm((f) => ({ ...f, [name]: value }));
  };

  const toggleEditAdditionalTask = () => {
    setEditForm(f => {
      const next = !f.additionalTask;
      return {
        ...f,
        additionalTask: next,
        status: next ? f.status : 'Pending'
      };
    });
  };

  const onUpdateTask = async (e) => {
    e.preventDefault();
    if (!editingTask) return;
  const id = getTaskId(editingTask);
    if (!id) return;
    setEditSaving(true);
    setEditError('');
    try {
      const pr = Number(editForm.priority);
      const payload = {
        title: editForm.title?.trim(),
        description: editForm.description?.trim() || '',
        // Ensure priority is numeric (fallback 0)
        priority: Number.isFinite(pr) ? pr : 0,
        status: editForm.additionalTask ? editForm.status : 'Pending',
        endDate: editForm.endDate || null,
        additionalTask: !!editForm.additionalTask,
      };
      await api.patch(`/tasks/${id}`, payload);
      setShowEditModal(false);
      setEditingTask(null);
      await refetch();
      toast.success('Task updated');
    } catch (err) {
      const msg = err?.response?.data?.message || err.message || 'Failed to update task';
      setEditError(msg);
      toast.error(msg);
    } finally {
      setEditSaving(false);
    }
  };

  return (
    <>
  {/* Helper to get a stable task id */}
  { /* eslint-disable-next-line */ }
  {false && getTaskId}
    <div className="p-4 p-lg-5 overflow-auto">
      <div className="mx-auto" style={{ maxWidth: 1200 }}>
        <div className="mb-4 d-flex align-items-center justify-content-between">
          <div>
            <h1 className="fs-2 fw-bold text-heading mb-1">My Task Management</h1>
            {/* Replaced hard-coded Bootstrap text color with theme-aware class */}
            <p className="text-soft">Manage your tasks here</p>
          </div>
        </div>

        <div className="d-flex flex-column gap-5">
          {/* Task Listings */}
          <section>
            <div className="mb-3 d-flex align-items-center justify-content-between">
              <h2 className="fs-5 fw-bold text-heading mb-0">Task Listings</h2>
              <div className="d-flex align-items-center gap-2">
                
                
                {/* Tabs */}
                <div className="btn-group ms-3" role="tablist">
                  <button
                    type="button"
                    className={`btn btn-custom px-3 py-1 ${activeTab === 'all' ? 'active' : ''}`}
                    onClick={() => setActiveTab('all')}
                    aria-selected={activeTab === 'all'}
                  >
                    All
                  </button>
                  <button
                    type="button"
                    className={`btn btn-custom px-3 py-1 ${activeTab === 'carryOver' ? 'active' : ''}`}
                    onClick={() => setActiveTab('carryOver')}
                    aria-selected={activeTab === 'carryOver'}
                  >
                    Carry Over
                  </button>
                  <button
                    type="button"
                    className={`btn btn-custom px-3 py-1 ${activeTab === 'pendingApproval' ? 'active' : ''}`}
                    onClick={() => setActiveTab('pendingApproval')}
                    aria-selected={activeTab === 'pendingApproval'}
                  >
                    Pending Approval
                  </button>
                </div>
                {activeTab === 'pendingApproval' && (
                  <button type="button" className="btn btn-primary btn-sm ms-2 d-flex align-items-center gap-1 d-none" onClick={approveAllPending} disabled={approvingId === 'bulk' || loading}>
                    <span className="material-symbols-outlined" style={{ fontSize:16 }}>done_all</span>
                    {approvingId === 'bulk' ? 'Approving…' : 'Approve All'}
                  </button>
                )}
              </div>
            </div>
            {error && (
              <div className="alert alert-danger mb-3">{error?.response?.data?.message || error?.message || 'Failed to load tasks'}</div>
            )}
            <div className="mb-3 bg-card p-3 rounded">
              <div className="row g-3 align-items-end">
                <div className="col-12 col-md-2">
                  <label className="form-label text-soft small mb-1">Status</label>
                  <select
                    className="form-select form-select-sm"
                    value={taskFilters.status}
                    onChange={(e) => setTaskFilters(f => ({ ...f, status: e.target.value }))}
                  >
                    <option value="">All</option>
                    <option value="Pending">Pending</option>
                    <option value="Ongoing">Ongoing</option>
                    <option value="Hold">Hold</option>
                    <option value="Suspended">Suspended</option>
                    <option value="Completed">Completed</option>
                  </select>
                </div>
                <div className="col-6 col-md-3">
                  <label className="form-label text-soft small mb-1">Start Date</label>
                  <input
                    type="date"
                    className="form-control form-control-sm"
                    value={taskFilters.dateStart}
                    onChange={(e) => setTaskFilters(f => ({ ...f, dateStart: e.target.value, today: false }))}
                  />
                </div>
                <div className="col-6 col-md-3">
                  <label className="form-label text-soft small mb-1">End Date</label>
                  <input
                    type="date"
                    className="form-control form-control-sm"
                    value={taskFilters.dateEnd}
                    onChange={(e) => setTaskFilters(f => ({ ...f, dateEnd: e.target.value, today: false }))}
                  />
                </div>
                <div className="col-12 col-md-4 d-flex flex-wrap gap-2">
                  <button
                    type="button"
                    className={`btn btn-sm ${taskFilters.today ? 'btn-secondary' : 'btn-outline-soft'}`}
                    onClick={() => setTaskFilters(f => ({ ...f, dateStart: todayStr, dateEnd: todayStr, today: true }))}
                  >
                    <span className="material-symbols-outlined align-middle me-1" style={{ fontSize: 18 }}>today</span>
                    Today
                  </button>
                  <button
                    type="button"
                    className="btn btn-outline-soft btn-sm"
                    onClick={() => setTaskFilters(f => ({ ...f, dateStart: '', dateEnd: '', today: false }))}
                    disabled={!taskFilters.dateStart && !taskFilters.dateEnd}
                  >
                    All Dates
                  </button>
                  <button
                    type="button"
                    className="btn btn-outline-soft btn-sm flex-grow-1"
                    onClick={() => setTaskFilters({ status: '', dateStart: todayStr, dateEnd: todayStr, today: true })}
                    disabled={!taskFilters.status && taskFilters.today}
                  >
                    Clear
                  </button>
                  <button
                    type="button"
                    className="btn btn-secondary btn-sm"
                    onClick={() => refetch()}
                  >
                    Refresh
                  </button>
                </div>
              </div>
            </div>
            <div className="table-responsive rounded bg-card p-2">
              <table className="table table-dark-custom align-middle mb-0 w-100">
                <thead>
                  <tr>
                    <th className="text-heading">Task Title</th>
                    <th className="text-heading">Priority</th>
                    <th className="text-heading">Status</th>
                    <th className="text-heading">Approval</th>
                    <th className="text-heading">Created At</th>
                    <th className="text-heading">Expected Close</th>
                    <th className="text-heading">End Date</th>
                    <th className="text-heading">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {loading && (
                    <tr>
                      <td colSpan={8} className="text-center text-secondary py-4">Loading…</td>
                    </tr>
                  )}
                  {!loading && rows.map((t, i) => (
                    <tr key={t._id || t.id || i}>
                      <td>
                        <Link to={`/tasks/${t._id || t.id}`} className="text-decoration-none text-heading">{t.title}</Link>
                        {t.assignedType == 'Department' ? t.assignedDepartment ? 
                            <>
                            <span className="badge bg-secondary" style={{ fontSize: '.6rem', verticalAlign: 'middle', color: 'var(--color-bg-body)' }}>
                              (To Dept: {t.assignedDepartment.name || 'N/A'})
                            </span>
                            </>
                             : '(Dept: N/A)' : ''}
                      </td>
                      <td><span className={priorityBadge(t.priority)}>{priorityLabel(t.priority)}</span></td>
                      <td>
                        { t.additionalTask == true || t.rawStatus == 'Approved' ? <span className={statusBadge(t.status)}>{t.status}</span> : '-' }
                        
                        { t.status != 'Completed' && (new Date(t.dateStart).setHours(0, 0, 0, 0) < new Date().setHours(0, 0, 0, 0)) ?
                            <><br />
                              <span className="text-secondary mx-auto" style={{ fontSize: '.7rem' }}>Carry Over of {fmtDate(t.dateStart)}</span>
                            </>
                          : null
                          }

                          { t.status != 'Completed' && t.dateExpectedEnd || t.dueDate ?
                            <>
                            <br />
                              { (new Date(t.dateExpectedEnd || t.dueDate).getTime() < Date.now()) ? <span className="text-danger mx-auto">Overdue</span> : <span className="text-warning mx-auto">Due Soon</span> }
                            </>
                          : null }
                        </td>
                      <td>
                        {
                            t.additionalTask == true ?
                            <>
                            <span className="badge bg-info" style={{ fontSize: '.6rem', verticalAlign: 'middle', color: 'var(--color-bg-body)' }}>
                              (Additional Task)
                            </span>
                            </>
                            : t.rawStatus != 'Approved' ? 
                            <><span className="badge bg-warning" style={{ fontSize: '.6rem', verticalAlign: 'middle', color: 'var(--color-bg-body)' }}>
                              (Pending Approval)
                            </span></>
                            : '✔️'
                          }
                      </td>
                      <td className="text-soft">{t.dateStart || t.createdAt ? fmtDate(t.dateStart || t.createdAt) : '-'}</td>
                      <td className="text-soft">{t.dateExpectedEnd || t.createdAt ? fmtDate(t.dateExpectedEnd || t.createdAt) : '-'}</td>
                      <td className="text-soft">{t.endDate || t.dueDate ? fmtDate(t.endDate || t.dueDate) : '-'}</td>
                      <td>
                        <Link to={`/tasks/${t._id || t.id}`} className="btn btn-link text-soft p-0" title="View"><span className="material-symbols-outlined">visibility</span></Link>
                        { t.status === 'Completed' ? null :
                        <button
                          className="btn btn-link text-soft p-0 ms-2"
                          title="Edit"
                          onClick={() => {
                            setEditingTask(t);
                            const pVal = (() => {
                              const p = t.priority;
                              if (typeof p === 'number' && !Number.isNaN(p)) return String(p);
                              if (['0','1','2','3','4'].includes(p)) return p;
                              switch (p) {
                                case 'High': return '1';
                                case 'Low': return '2';
                                case 'Critical': return '3';
                                case 'Urgent': return '4';
                                default: return '0';
                              }
                            })();
                            setEditForm({
                              title: t.title || '',
                              description: t.description || '',
                              priority: pVal,
                              status: ['Pending','Ongoing','Hold','Suspended','Completed'].includes(t.status) ? t.status : 'Pending',
                              endDate: (t.endDate || t.dateExpectedEnd || t.dueDate || '').slice(0, 10),
                              additionalTask: !!(t.additionalTask || t.isAdditional)
                            });
                            setEditError('');
                            setShowEditModal(true);
                          }}
                        >
                          <span className="material-symbols-outlined">edit</span>
                        </button>
                        }

                        {(t._id || t.id) && (
                          <>
                            {
                              (t.rawStatus == 'Pending' && !t.additionalTask) ? 
                              <button
                            className="btn btn-link text-soft p-0 ms-2"
                            title={deletingId === getTaskId(t) ? 'Deleting…' : 'Delete'}
                            onClick={() => onDelete(t)}
                            disabled={deletingId === getTaskId(t)}
                          >
                            <span className="material-symbols-outlined">{deletingId === getTaskId(t) ? 'hourglass_empty' : 'delete'}</span>
                          </button>
                          : null
                              
                            }
                          
                          </>
                          
                        )}
                        {activeTab === 'pendingApproval' && (
                          <button
                            className="btn btn-link text-soft p-0 ms-2 d-none"
                            title="Approve"
                            onClick={() => approveTask(t)}
                            disabled={approvingId === getTaskId(t)}
                          >
                            <span className="material-symbols-outlined">{approvingId === getTaskId(t) ? 'hourglass_empty' : 'check_circle'}</span>
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                  {!loading && rows.length === 0 && (
                    <tr>
                      <td colSpan={8} className="text-center text-secondary py-4">No tasks to display.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </section>

          {/* Task Creation */}
          <section>
            <h2 className="fs-5 fw-bold text-heading mb-3">Task Creation</h2>
            <div className="bg-card p-4 rounded">
              {createError && <div className="alert alert-danger mb-3">{createError}</div>}
              <form className="row g-3" onSubmit={onCreateTask}>
                <div className="col-12">
                  <label className="form-label" htmlFor="title">Title</label>
                  <input className="form-control" id="title" name="title" placeholder="Enter task title" type="text" value={form.title} onChange={onFormChange} required />
                </div>
                <div className="col-12">
                  <label className="form-label" htmlFor="description">Description (optional)</label>
                  <textarea className="form-control input-custom" id="description" name="description" placeholder="Enter task description" rows={3} value={form.description} onChange={onFormChange}></textarea>
                </div>
                <div className="col-md-6">
                  <label className="form-label" htmlFor="priority">Priority</label>
                  <select className="form-select" id="priority" name="priority" value={form.priority} onChange={onFormChange}>
                    <option value="0">Normal</option>
                    <option value="1">High</option>
                    <option value="2">Low</option>
                    <option value="3">Critical</option>
                    <option value="4">Urgent</option>
                  </select>
                </div>
                <div className="col-md-6">
                  <label className="form-label d-flex align-items-center justify-content-between" htmlFor="status">
                    <span>Status</span>
                    <button
                      type="button"
                      onClick={toggleAdditionalTask}
                      className={`btn btn-sm px-2 py-0 ${form.additionalTask ? 'btn-primary' : 'btn-outline-soft'}`}
                      style={{ fontSize: '.65rem', lineHeight: 1.2 }}
                    >
                      Additional Task {form.additionalTask ? '✓' : ''}
                    </button>
                  </label>
                  <select
                    className="form-select"
                    id="status"
                    name="status"
                    value={form.additionalTask ? form.status : 'Pending'}
                    onChange={onFormChange}
                    disabled={!form.additionalTask}
                  >
                    <option>Pending</option>
                    <option>Ongoing</option>
                    <option>Hold</option>
                    <option>Suspended</option>
                    <option>Completed</option>
                  </select>
                </div>
                <div className="col-md-6">
                  <label className="form-label" htmlFor="end-date">End Date (optional)</label>
                  <input className="form-control" id="end-date" name="endDate" type="date" value={form.endDate} onChange={onFormChange} />
                </div>
                {/* Assign To omitted for now; tasks created for current user */}
                <div className="col-12 d-flex justify-content-end">
                  <button className="btn btn-primary d-flex align-items-center gap-2 px-4 py-2 fw-bold" type="submit" disabled={creating}>
                    <span className="material-symbols-outlined">add</span> {creating ? 'Creating…' : 'Create Task'}
                  </button>
                </div>
              </form>
            </div>
          </section>
        </div>
      </div>
  </div>
  {showEditModal && (
      <div className="position-fixed top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center" style={{ zIndex: 1050 }}>
        <div className="position-absolute top-0 start-0 w-100 h-100" style={{ background: 'rgba(0,0,0,0.5)' }} onClick={() => { if (!editSaving) { setShowEditModal(false); setEditingTask(null); } }} />
        <div className="bg-card rounded shadow p-4 position-relative" style={{ width: '90%', maxWidth: 560 }} role="dialog" aria-modal="true" aria-labelledby="editTaskTitle">
          <div className="d-flex align-items-center justify-content-between mb-3">
            <h2 id="editTaskTitle" className="fs-5 fw-bold mb-0 text-heading">Edit Task</h2>
            <button className="btn btn-action" type="button" onClick={() => { if (!editSaving) { setShowEditModal(false); setEditingTask(null); } }} aria-label="Close">
              <span className="material-symbols-outlined">close</span>
            </button>
          </div>
          {(editingTask?.rawStatus === 'Approved') && (
            <div className="alert alert-warning mb-3">
              Note: Editing an approved task will send it to your manager for approval again.
            </div>
          )}
          {editError && <div className="alert alert-danger mb-3">{editError}</div>}
          <form className="row g-3" onSubmit={onUpdateTask}>
            <div className="col-12">
              <label className="form-label" htmlFor="edit-title">Title</label>
              <input className="form-control" id="edit-title" name="title" type="text" value={editForm.title} onChange={onEditFormChange} required />
            </div>
            <div className="col-12">
              <label className="form-label" htmlFor="edit-description">Description</label>
              <textarea className="form-control input-custom" id="edit-description" name="description" rows={3} value={editForm.description} onChange={onEditFormChange}></textarea>
            </div>
            <div className="col-md-6">
              <label className="form-label" htmlFor="edit-priority">Priority</label>
              <select className="form-select" id="edit-priority" name="priority" value={editForm.priority} onChange={onEditFormChange}>
                <option value="0">Normal</option>
                <option value="1">High</option>
                <option value="2">Low</option>
                <option value="3">Critical</option>
                <option value="4">Urgent</option>
              </select>
            </div>
            <div className="col-md-6">
              <label className="form-label d-flex align-items-center justify-content-between" htmlFor="edit-status">
                <span>Status</span>
                <button
                  type="button"
                  onClick={toggleEditAdditionalTask}
                  className={`btn btn-sm px-2 py-0 d-none ${editForm.additionalTask ? 'btn-primary' : 'btn-outline-soft'}`}
                  style={{ fontSize: '.65rem', lineHeight: 1.2 }}
                >
                  Additional Task {editForm.additionalTask ? '✓' : ''}
                </button>
              </label>
              <select
                className="form-select"
                id="edit-status"
                name="status"
                value={editForm.additionalTask ? editForm.status : 'Pending'}
                onChange={onEditFormChange}
                disabled={!editForm.additionalTask}
              >
                <option>Pending</option>
                <option>Ongoing</option>
                <option>Hold</option>
                <option>Suspended</option>
                <option>Completed</option>
              </select>
            </div>
            <div className="col-md-6">
              <label className="form-label" htmlFor="edit-end-date">End Date</label>
              <input className="form-control" id="edit-end-date" name="endDate" type="date" value={editForm.endDate} onChange={onEditFormChange} />
            </div>
            <div className="col-12 d-flex justify-content-end gap-2 pt-2">
              <button type="button" className="btn btn-secondary-custom px-4" disabled={editSaving} onClick={() => { setShowEditModal(false); setEditingTask(null); }}>
                Cancel
              </button>
              <button type="submit" className="btn btn-primary-custom px-4 d-flex align-items-center gap-2" disabled={editSaving}>
                <span className="material-symbols-outlined">save</span>
                <span>{editSaving ? 'Saving…' : 'Save Changes'}</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    )}
    </>
  );
}
