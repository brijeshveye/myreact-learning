import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { api } from '../../api/client';
import { Link, useNavigate } from 'react-router-dom';

export default function UserDashboard() {
  // State
  const [user, setUser] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [refreshing, setRefreshing] = useState(false);

  // Filters
  const [statusFilter, setStatusFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [dateMode, setDateMode] = useState('today'); // today | range | all
  const [start, setStart] = useState(() => new Date().toISOString().slice(0, 10));
  const [end, setEnd] = useState(() => new Date().toISOString().slice(0, 10));

  const navigate = useNavigate();

  const buildQuery = (assignedId) => {
    const params = new URLSearchParams();
    if (statusFilter !== 'all') params.set('status', statusFilter);
    if (search.trim()) params.set('q', search.trim());
    if (dateMode === 'today') {
      const d = new Date().toISOString().slice(0, 10); params.set('dateStart', d); params.set('dateEnd', d);
    } else if (dateMode === 'range') {
      if (start) params.set('dateStart', start); if (end) params.set('dateEnd', end);
    }
    params.set('limit', '500');
    if (assignedId) params.set('assignedTo', assignedId); else params.set('mine', '1');
    return params.toString();
  };

  const fetchDashboard = useCallback(async () => {
    setLoading(true); setError('');
    try {
      const { data: uRes } = await api.get('/auth/me').catch(() => ({ data: null }));
      const extractedUser = uRes?.data?.user || uRes?.user || uRes?.data || uRes || null;
      setUser(extractedUser);
      const assignedId = extractedUser?._id || extractedUser?.id || null;
      const { data: tRes } = await api.get(`/tasks?${buildQuery(assignedId)}`);
      const list = Array.isArray(tRes?.data) ? tRes.data : Array.isArray(tRes) ? tRes : (tRes?.items || []);
      setTasks(list);
    } catch (e) {
      setError(e?.response?.data?.message || e.message || 'Failed to load dashboard');
    } finally { setLoading(false); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [statusFilter, search, dateMode, start, end]);

  useEffect(() => { fetchDashboard(); }, [fetchDashboard]);

  const onRefresh = async () => { setRefreshing(true); await fetchDashboard(); setRefreshing(false); };

  // Derived metrics
  const metrics = useMemo(() => {
    if (!tasks.length) return { completed: 0, overdue: 0, efficiency: 0 };
    let completed = 0, overdue = 0, total = tasks.length;
    const now = Date.now();
    tasks.forEach(t => {
      if (t.status === 'Completed') completed++; else if (t.status !== 'Completed') {
        const due = new Date(t.dateExpectedEnd || t.dueDate).getTime();
        if (due && due < now && t.status !== 'Completed') overdue++;
      }
    });
    const efficiency = total ? Math.round((completed / total) * 100) : 0;
    return { completed, overdue, efficiency };
  }, [tasks]);

  // Today's focus: urgent (priority 1 or labeled urgent) due today; due soon: due within next 3 days not completed
  const todayStr = new Date().toISOString().slice(0, 10);
  const focus = useMemo(() => {
    const urgent = [];
    const soon = [];
    const now = Date.now();
    const threeDays = 3 * 24 * 60 * 60 * 1000;
    tasks.forEach(t => {
      const dueRaw = t.dateExpectedEnd || t.dueDate;
      const due = dueRaw ? new Date(dueRaw) : null;
      const dueISO = due ? due.toISOString().slice(0, 10) : null;
      if (t.status === 'Completed') return;
      const priority = t.priority; // numeric or text
      const isUrgentPriority = priority === 3 || priority === 'Urgent' || priority === 'High' || priority === 1; // adapt mapping
      if (dueISO === todayStr && isUrgentPriority) urgent.push(t);
      else if (due && (due.getTime() - now) <= threeDays && (due.getTime() - now) > 0) soon.push(t);
    });
    return { urgent: urgent.slice(0, 2), soon: soon.slice(0, 2) };
  }, [tasks, todayStr]);

  // Assigned (table) after filters
  const filteredTable = useMemo(() => {
    return tasks.filter(t => {
      if (statusFilter !== 'all' && t.status !== statusFilter) return false;
      if (search.trim() && !(t.title || '').toLowerCase().includes(search.toLowerCase())) return false;
      return true;
    }).slice(0, 100); // limit display
  }, [tasks, statusFilter, search]);

  // Notifications (simple derivation from tasks changes: recently created or status changes)
  const notifications = useMemo(() => {
    const recent = [...tasks].filter(t => t.createdAt || t.updatedAt).sort((a, b) => new Date(b.updatedAt || b.createdAt) - new Date(a.updatedAt || a.createdAt)).slice(0, 5);
    return recent.map(t => ({
      id: t._id,
      type: t.status === 'Completed' ? 'check_circle' : 'assignment',
      title: t.title,
      when: (() => { try { return new Date(t.updatedAt || t.createdAt).toLocaleDateString(); } catch { return ''; } })()
    }));
  }, [tasks]);

  const fmtDate = (d) => { if (!d) return '-'; try { return new Date(d).toLocaleDateString(); } catch { return '-'; } };
  const statusBadge = (s) => s === 'Completed' ? 'badge-status-completed' : s === 'In Progress' ? 'badge-status-inprogress' : s === 'Pending Approval' ? 'badge-status-review' : s === 'Planning' ? 'badge-status-planning' : 'badge-status-pending';
  const priorityBadge = (p) => {
    const label = typeof p === 'number' ? (p === 1 ? 'High' : p === 2 ? 'Low' : p === 3 ? 'Urgent' : 'Normal') : p;
    return label === 'High' ? 'badge-priority-high' : label === 'Low' ? 'badge-priority-low' : label === 'Urgent' ? 'badge-priority-urgent' : 'badge-priority-normal';
  };

  const disableRange = dateMode !== 'range';
  const displayName = (u) => {
    if (!u) return '';
    return u.name || u.fullName || u.firstName && u.lastName ? `${u.firstName || ''} ${u.lastName || ''}`.trim() : u.companyOfficialEmail || u.email || 'User';
  };

  return (
    <div className="container-fluid py-4" style={{ maxWidth: 1400 }}>
      <div className="row g-4">
        <div className="col-lg-8">
          <div className="d-flex flex-column gap-4">
            <section>
              <div className="d-flex flex-wrap align-items-start justify-content-between gap-3 mb-2">
                <div>
                  <h1 className="fs-2 fw-bold mb-1">My Dashboard</h1>
                  <p className="mb-0 text-secondary">{user ? `Welcome back, ${displayName(user)}.` : 'Loading user...'}</p>
                </div>
                <div className="d-flex flex-wrap align-items-center gap-2">
                  <div className="d-flex align-items-center gap-2">
                    <select className="form-select form-select-sm" value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
                      <option value="all">All Statuses</option>
                      <option>Pending</option>
                      <option>In Progress</option>
                      <option>Completed</option>
                      <option>Planning</option>
                    </select>
                    <input className="form-control form-control-sm" placeholder="Search tasks" value={search} onChange={e => setSearch(e.target.value)} />
                    <select className="form-select form-select-sm" value={dateMode} onChange={e => setDateMode(e.target.value)}>
                      <option value="today">Today</option>
                      <option value="range">Range</option>
                      <option value="all">All</option>
                    </select>
                    <input type="date" className="form-control form-control-sm" value={start} disabled={disableRange} onChange={e => setStart(e.target.value)} />
                    <input type="date" className="form-control form-control-sm" value={end} disabled={disableRange} onChange={e => setEnd(e.target.value)} />
                  </div>
                  <button className="btn btn-custom d-flex align-items-center gap-1 px-3 py-2" onClick={onRefresh} disabled={refreshing || loading}><span className="material-symbols-outlined" style={{ fontSize: 18 }}>refresh</span>{refreshing ? 'Refreshing' : 'Refresh'}</button>
                  <button className="btn btn-primary-custom d-flex align-items-center gap-2 px-3 py-2" onClick={() => navigate('/tasks')}>
                    <span className="material-symbols-outlined">add</span> Create Task
                  </button>
                </div>
              </div>
              {error && <div className="alert alert-danger mb-0 mt-2">{error}</div>}
            </section>

            <section>
              <h2 className="fs-5 fw-bold mb-3">Today's Focus</h2>
              {loading && <div className="text-secondary">Loading focus…</div>}
              {!loading && focus.urgent.length === 0 && focus.soon.length === 0 && <div className="text-secondary">No urgent or upcoming tasks.</div>}
              <div className="row g-3">
                {focus.urgent.map(t => (
                  <div className="col-md-6" key={t._id}>
                    <div className="bg-card p-4 h-100">
                      <span className="text-uppercase fw-semibold" style={{ fontSize: '.75rem', color: 'var(--danger-400)' }}>Urgent</span>
                      <Link to={`/tasks/${t._id}`} className="text-decoration-none text-dark">
                        <h3 className="fs-6 fw-bold mb-1">{t.title}</h3>
                      </Link>

                      <p className="mb-2 text-secondary">Due Today</p>
                      <div className="d-flex gap-2">
                        <Link to={`/my-tasks/${t._id}`} className="btn btn-primary-custom btn-sm">View Details</Link>
                      </div>
                    </div>
                  </div>
                ))}
                {focus.soon.map(t => (
                  <div className="col-md-6" key={t._id}>
                    <div className="bg-card p-4 h-100">
                      <span className="text-uppercase fw-semibold" style={{ fontSize: '.75rem', color: 'var(--warning-400)' }}>Due Soon</span>

                      <Link to={`/tasks/${t._id}`} className="text-decoration-none text-dark">
                        <h3 className="fs-6 fw-bold mb-1">{t.title}</h3>
                      </Link>
                      <p className="mb-2 text-secondary">Due {fmtDate(t.dateExpectedEnd || t.dueDate)}</p>
                      <div className="d-flex gap-2">
                        <Link to={`/tasks/${t._id}`} className="btn btn-primary-custom btn-sm">View Details</Link>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            <section>
              <h2 className="fs-5 fw-bold mb-3">Your Metrics</h2>
              <div className="row g-3">
                <div className="col-sm-4">
                  <div className="bg-card p-4 text-center">
                    <p className="fs-1 fw-bold mb-0">{metrics.completed}</p>
                    <p className="mb-0 text-secondary">Tasks Completed</p>
                  </div>
                </div>
                <div className="col-sm-4">
                  <div className="bg-card p-4 text-center">
                    <p className="fs-1 fw-bold mb-0">{metrics.overdue}</p>
                    <p className="mb-0 text-secondary">Tasks Overdue</p>
                  </div>
                </div>
                <div className="col-sm-4">
                  <div className="bg-card p-4 text-center">
                    <p className="fs-1 fw-bold mb-0">{metrics.efficiency}%</p>
                    <p className="mb-0 text-secondary">Efficiency</p>
                  </div>
                </div>
              </div>
            </section>

            <section>
              <h2 className="fs-5 fw-bold mb-3">Assigned Tasks</h2>
              {loading && <div className="text-secondary mb-2">Loading tasks…</div>}
              {!loading && filteredTable.length === 0 && <div className="text-secondary mb-2">No tasks found.</div>}
              <div className="table-responsive rounded bg-card p-2">
                <table className="table table-dark-custom table-borderless align-middle mb-0 w-100">
                  <thead>
                    <tr>
                      <th className="text-secondary">Task</th>
                      <th className="text-secondary">Priority</th>
                      <th className="text-secondary text-center">Status</th>
                      <th className="text-secondary">Created</th>
                      <th className="text-secondary">Due Date</th>
                      <th className="text-secondary">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredTable.map(t => (
                      <tr key={t._id}>
                        <td>
                          <Link to={`/tasks/${t._id}`} className="text-decoration-none text-heading">
                            {t.title} {t.assignedType == 'Department' ? t.assignedDepartment ? 
                            <>
                            <span className="badge bg-secondary" style={{ fontSize: '.6rem', verticalAlign: 'middle', color: 'var(--color-bg-body)' }}>
                              (To Dept: {t.assignedDepartment.name || 'N/A'})
                            </span>
                            </>
                             : '(Dept: N/A)' : ''}
                          </Link>
                        </td>
                        <td><span className={priorityBadge(t.priority)}>{typeof t.priority === 'number' ? (t.priority === 1 ? 'High' : t.priority === 2 ? 'Low' : t.priority === 3 ? 'Urgent' : 'Normal') : t.priority}</span></td>
                        <td className='text-center'>
                          { t.additionalTask == true || t.rawStatus == 'Approved' ? <span className={statusBadge(t.status)}>{t.status}</span> : '-' }
                          {
                            t.additionalTask == true ?
                            <>
                            <br />
                            <span className="badge bg-info" style={{ fontSize: '.6rem', verticalAlign: 'middle', color: 'var(--color-bg-body)' }}>
                              (Additional Task)
                            </span>
                            </>
                            : t.rawStatus != 'Approved' ? 
                            <><br /><span className="badge bg-warning" style={{ fontSize: '.6rem', verticalAlign: 'middle', color: 'var(--color-bg-body)' }}>
                              (Pending Approval)
                            </span></>
                            : null
                          }
                          
                          { t.status != 'Completed' && (new Date(t.dateStart).setHours(0, 0, 0, 0) < new Date().setHours(0, 0, 0, 0)) ?
                            <><br />
                              <span className="text-secondary mx-auto" style={{ fontSize: '.7rem' }}>Carry Over of {fmtDate(t.dateStart)}</span>
                            </>
                          : null
                          }

                          { t.status != 'Completed' && t.dateExpectedEnd || t.dueDate ?
                            <>
                            <br />
                              { (new Date(t.dateExpectedEnd || t.dueDate).getTime() < Date.now()) ? <span className="text-danger mx-auto">Overdue</span> : <span className="text-warning mx-auto">Due Soon</span> }
                            </>
                          : null }
                        </td>
                        <td>{fmtDate(t.dateStart || t.createdAt)}</td>
                        <td>{fmtDate(t.dateExpectedEnd || t.dueDate)}</td>
                        <td>
                          <Link className="btn btn-link text-dark-50 p-0" to={`/tasks/${t._id}`}><span className="material-symbols-outlined">visibility</span></Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          </div>
        </div>

        <div className="col-lg-4 d-flex flex-column gap-4">
          <section className="bg-card p-4">
            <h2 className="fs-5 fw-bold mb-3">Notifications</h2>
            {loading && <div className="text-secondary">Loading…</div>}
            {!loading && notifications.length === 0 && <div className="text-secondary">No recent updates.</div>}
            <ul className="list-unstyled mb-0">
              {notifications.map(n => (
                <li className="d-flex align-items-start gap-3 mb-3" key={n.id}>
                  <span className="material-symbols-outlined text-secondary">{n.type}</span>
                  <div>
                    <p className="mb-0 fw-medium">{n.title}</p>
                    <p className="mb-0 text-secondary" style={{ fontSize: '.7rem' }}>{n.when}</p>
                  </div>
                </li>
              ))}
            </ul>
          </section>

          <section className="bg-card p-4">
            <h2 className="fs-5 fw-bold mb-3">Pending Tasks</h2>
            {loading && <div className="text-secondary">Loading…</div>}
            {!loading && tasks.filter(t => t.status !== 'Completed').length === 0 && <div className="text-secondary">No pending tasks.</div>}
            <ul className="list-unstyled mb-0">
              {tasks.filter(t => t.status !== 'Completed').sort((a, b) => new Date(a.dateExpectedEnd || a.dueDate) - new Date(b.dateExpectedEnd || b.dueDate)).slice(0, 6).map(t => (
                <li className="d-flex align-items-center justify-content-between mb-2" key={t._id}>
                  <p className="mb-0 fw-medium" style={{ maxWidth: '60%', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.title}</p>
                  { t.dateExpectedEnd || t.dueDate ? 
                  <>
                  <p className="mb-0" style={{ fontSize: '.7rem', color: 'var(--warning-400)' }}>Due: {fmtDate(t.dateExpectedEnd || t.dueDate)}</p>
                  </> : ''
                   }
                  
                </li>
              ))}
            </ul>
          </section>
        </div>
      </div>
    </div>
  );
}
