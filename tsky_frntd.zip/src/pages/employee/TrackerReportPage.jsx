import React, { useState, useEffect, useCallback } from 'react';
import { toast } from 'react-toastify';
import { fetchTrackerReport } from '../../api/tracker';

export default function TrackerReportPage() {
    const [range, setRange] = useState('Yesterday');
    const rangeOptions = ['Yesterday', 'Day before Yesterday', '2 day before Yesterday'];
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [report, setReport] = useState(null);

    // Derive userId from localStorage user (fallback to placeholder)
    const currentUser = (()=>{ try { return JSON.parse(localStorage.getItem('user')||'null'); } catch { return null; } })();
    const employeeName = report?.name || currentUser?.fullName || currentUser?.companyOfficialEmail || currentUser?.email || 'User';
    const userId = currentUser?.employeeCode || currentUser?._id || currentUser?.username || 'unknown';

    const rangeToken = (() => {
        if (range === 'Yesterday') return 'yesterday';
        if (range === 'Day before Yesterday') return 'day_before';
        if (range === '2 day before Yesterday') return 'two_before';
        return 'yesterday';
    })();

    const loadReport = useCallback(async () => {
        if (!userId) return;
        setLoading(true); setError('');
        try {
            const data = await fetchTrackerReport(userId, rangeToken);
            setReport(data);
        } catch (e) {
            const msg = e?.response?.data?.message || e.message || 'Failed to load tracker report';
            setError(msg);
            toast.error(msg);
            setReport(null);
        } finally { setLoading(false); }
    }, [userId, rangeToken]);

    useEffect(()=>{ loadReport(); }, [loadReport]);

    const breaks = report?.breaks || [];
    const breakTime = report?.totalBreakTime || '00:00:00';
    const idleTime = report?.totalIdleTime || report?.totalIdleTime || '00:00:00';
    const breakCount = report?.breakCount ?? breaks.length;
    const deviceStates = (report?.stateEvents || []).map(e => ({ time: formatTime(e.timestamp), state: mapStateEvent(e.event) }));
    const logins = (report?.powerEvents || []).map(e => formatTime(e.timestamp));

    function formatTime(ts) {
        if (!ts) return '-';
        try { const d = new Date(ts); return d.toLocaleTimeString([], { hour: '2-digit', minute:'2-digit' }); } catch { return '-'; }
    }
    function mapStateEvent(ev) {
        if (!ev) return 'Unknown';
        const low = ev.toLowerCase();
        // Check more specific 'unlock' before generic 'lock' to avoid substring collision
        if (low.includes('unlock')) return 'Unlocked';
        if (low.includes('lock')) return 'Locked';
        if (low.includes('away')) return 'Away';
        if (low.includes('idle')) return 'Idle';
        return ev; // fallback to raw event text
    }

    const deviceClass = (state) => {
        if (!state) return 'device-badge device-active';
        const k = state.toLowerCase();
        if (k.includes('unlock') || k === 'unlocked' || k === 'active') return 'device-badge device-active';
        if (k.includes('lock') || k === 'locked') return 'device-badge device-locked';
        if (k.includes('away') || k.includes('idle')) return 'device-badge device-away';
        return 'device-badge device-active';
    };

    return (
        <div className="px-3 py-4">
            <div className="container-xl">
                <div className="d-flex flex-wrap align-items-start justify-content-between gap-3 mb-4">
                    <div>
                        <h1 className="mb-1 fs-2 fw-bold text-heading">Time Tracker Report</h1>
                        <p className="text-soft mb-0 small">Review time tracking data for {employeeName}.</p>
                    </div>
                    <div className="d-flex align-items-center gap-2">
                        <div className="d-flex align-items-center gap-2 rounded-md bg-panel-alt px-3 py-2">
                            <span className="material-symbols-outlined text-soft">calendar_today</span>
                            <select
                                className="form-select form-select-sm bg-transparent border-0 p-0"
                                style={{ width: 'auto' }}
                                value={range}
                                onChange={(e) => setRange(e.target.value)}
                            >
                                {rangeOptions.map(o => <option key={o} value={o}>{o}</option>)}
                            </select>
                        </div>
                        <div className="d-flex align-items-center gap-2 bg-panel-alt rounded-md px-3 py-2">
                            <span className="small text-soft">Employee:</span>
                            <span className="fw-semibold">{employeeName}</span>
                        </div>
                    </div>
                </div>

                {error && <div className="alert alert-danger py-2 px-3 mb-4 small">{error}</div>}
                <div className="row g-4 mb-4">
                    <div className="col-sm-6 col-lg-3">
                        <div className="stat-card h-100">
                            <div className="text-soft small fw-medium text-uppercase" style={{letterSpacing:'.5px'}}>Idle Time</div>
                            <h4 className="mt-1" style={{fontSize:'1.9rem'}}>{loading ? '—' : idleTime}</h4>
                            <div className="small text-muted-custom">Across selected range</div>
                        </div>
                    </div>
                    <div className="col-sm-6 col-lg-3">
                        <div className="stat-card h-100">
                            <div className="text-soft small fw-medium text-uppercase" style={{letterSpacing:'.5px'}}>Break Time</div>
                            <h4 className="mt-1" style={{fontSize:'1.9rem'}}>{loading ? '—' : breakTime}</h4>
                            <div className="small text-muted-custom">All breaks</div>
                        </div>
                    </div>
                    <div className="col-sm-6 col-lg-3">
                        <div className="stat-card h-100">
                            <div className="text-soft small fw-medium text-uppercase" style={{letterSpacing:'.5px'}}>Breaks Count</div>
                            <h4 className="mt-1" style={{fontSize:'1.9rem'}}>{loading ? '—' : breakCount}</h4>
                            <div className="small text-muted-custom">Recorded</div>
                        </div>
                    </div>
                    <div className="col-sm-6 col-lg-3">
                        <div className="stat-card h-100">
                            <div className="text-soft small fw-medium text-uppercase" style={{letterSpacing:'.5px'}}>Login Sessions</div>
                            <h4 className="mt-1" style={{fontSize:'1.9rem'}}>{loading ? '—' : logins.length}</h4>
                            <div className="small text-muted-custom">Detected</div>
                        </div>
                    </div>
                </div>

                <div className="row g-4">
                    <div className="col-xl-8 d-flex flex-column gap-4">
                        <div className="card p-4">
                            <div className="d-flex align-items-center justify-content-between mb-3">
                                <h2 className="h6 fw-bold mb-0 text-heading">Break Listing</h2>
                            </div>
                            <div className="table-responsive">
                                <table className="table table-dark-custom table-borderless mb-0 align-middle">
                                    <thead>
                                        <tr>
                                            <th className="text-uppercase small text-soft fw-semibold">Type</th>
                                            <th className="text-uppercase small text-soft fw-semibold">Start</th>
                                            <th className="text-uppercase small text-soft fw-semibold">End</th>
                                            <th className="text-uppercase small text-soft fw-semibold">Duration</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {!loading && breaks.map((b,i)=>(
                                            <tr key={i}>
                                                <td className="small text-soft">{b.break_type || '-'}</td>
                                                <td className="small text-soft">{b.start || '-'}</td>
                                                <td className="small text-soft">{b.end || '-'}</td>
                                                <td className="small text-soft">{b.duration || '-'}</td>
                                            </tr>
                                        ))}
                                        {!loading && breaks.length===0 && <tr><td colSpan={3} className="text-center small text-soft py-3">No breaks recorded.</td></tr>}
                                        {loading && <tr><td colSpan={3} className="text-center small text-soft py-3">Loading…</td></tr>}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div className="card p-4">
                            <div className="d-flex align-items-center justify-content-between mb-3">
                                <h2 className="h6 fw-bold mb-0 text-heading">Login Times</h2>
                            </div>
                            <div className="table-responsive">
                                <table className="table table-dark-custom table-borderless mb-0 align-middle">
                                    <thead>
                                        <tr>
                                            <th className="text-uppercase small text-soft fw-semibold">Time</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {!loading && logins.map((t,i)=>(
                                            <tr key={i}>
                                                <td className="small text-soft">{t}</td>
                                            </tr>
                                        ))}
                                        {!loading && logins.length===0 && <tr><td className="text-center small text-soft py-3">No login sessions.</td></tr>}
                                        {loading && <tr><td className="text-center small text-soft py-3">Loading…</td></tr>}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div className="col-xl-4 d-flex flex-column gap-4">
                        <div className="card p-4">
                            <div className="d-flex align-items-center justify-content-between mb-3">
                                <h2 className="h6 fw-bold mb-0 text-heading">Device State Log</h2>
                            </div>
                            <div className="table-responsive">
                                <table className="table table-dark-custom table-borderless mb-0 align-middle">
                                    <thead>
                                        <tr>
                                            <th className="text-uppercase small text-soft fw-semibold">Time</th>
                                            <th className="text-uppercase small text-soft fw-semibold">State</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {!loading && deviceStates.map((d,i)=>(
                                            <tr key={i}>
                                                <td className="small text-soft">{d.time}</td>
                                                <td className="small"><span className={deviceClass(d.state)}>{d.state}</span></td>
                                            </tr>
                                        ))}
                                        {!loading && deviceStates.length===0 && <tr><td colSpan={2} className="text-center small text-soft py-3">No states recorded.</td></tr>}
                                        {loading && <tr><td colSpan={2} className="text-center small text-soft py-3">Loading…</td></tr>}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
