import React, { useCallback, useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api } from '../../api/client';
import { resolveUserAvatar } from '../../utils/avatars.js';
import { usePermission } from '../../context/PermissionContext.jsx';
import { PERMISSIONS } from '../../utils/permissions.js';
import { toast } from 'react-toastify';

export default function MyTaskDetail() {
  // Route in App.jsx uses :taskId so extract that
  const { taskId } = useParams();
  const id = taskId; // keep local variable name used below
  const [task, setTask] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [savingStatus, setSavingStatus] = useState(false);

  // Comments state
  const [comments, setComments] = useState([]);
  const [commentsLoading, setCommentsLoading] = useState(false);
  const [commentError, setCommentError] = useState('');
  const [newComment, setNewComment] = useState('');
  const [addingComment, setAddingComment] = useState(false);
  const { has } = usePermission();
  const currentUserId = (() => { try { return JSON.parse(localStorage.getItem('user'))?._id || null; } catch { return null; } })();

  const fetchTask = useCallback(async () => {
    if (!id) {
      return;
    }
    setLoading(true);
    setError('');
    try {
      const { data } = await api.get(`/tasks/${id}`);
      setTask(data);
    } catch (e) {
      setError(e?.response?.data?.message || e.message || 'Failed to load task');
      toast.error(e?.response?.data?.message || e.message || 'Failed to load task');
    } finally {
      setLoading(false);
    }
  }, [id]);

  const fetchComments = useCallback(async () => {
    if (!id) return;
    setCommentsLoading(true);
    setCommentError('');
    try {
      const { data } = await api.get(`/comments?taskId=${id}`);
      // ensure chronological oldest -> newest
      const sorted = Array.isArray(data) ? [...data].sort((a,b)=> new Date(a.createdAt) - new Date(b.createdAt)) : [];
      setComments(sorted);
    } catch (e) {
      setCommentError(e?.response?.data?.message || e.message || 'Failed to load comments');
      toast.error(e?.response?.data?.message || e.message || 'Failed to load comments');
    } finally {
      setCommentsLoading(false);
    }
  }, [id]);

  useEffect(() => { fetchTask(); fetchComments(); }, [fetchTask, fetchComments]);

  const priorityLabel = (p) => {
    if (p === 1) return 'High';
    if (p === 2) return 'Low';
    if (p === 3) return 'Urgent';
    return 'Normal';
  };
  const priorityBadgeClass = (p) => {
    const label = priorityLabel(p);
    return label === 'High' ? 'badge-priority-high' : label === 'Low' ? 'badge-priority-low' : label === 'Urgent' ? 'badge-priority-urgent' : 'badge-priority-normal';
  };

  const fmtDate = (d) => {
    if (!d) return '-';
    try { return new Date(d).toLocaleDateString(); } catch { return '-'; }
  };

  const onStatusChange = async (e) => {
    if (!task) return;
    const newStatus = e.target.value;
    setSavingStatus(true);
    try {
      const { data } = await api.patch(`/tasks/${task._id}`, { status: newStatus });
      setTask(data);
      toast.success('Task status updated');
    } catch (err) {
      toast.error(err?.response?.data?.message || err.message || 'Failed to update status');
    } finally {
      setSavingStatus(false);
    }
  };

  const onAddComment = async () => {
    if (!newComment.trim()) return;
    setAddingComment(true);
    setCommentError('');
    try {
      await api.post('/comments', { comment: newComment.trim(), task: task._id });
      setNewComment('');
      await fetchComments();
      toast.success('Comment added');
    } catch (e) {
      setCommentError(e?.response?.data?.message || e.message || 'Failed to add comment');
      toast.error(e?.response?.data?.message || e.message || 'Failed to add comment');
    } finally {
      setAddingComment(false);
    }
  };

  // Avatar helpers for comments
  const commentDisplayName = (c) => {
    const u = c?.commentBy || {}; // backend may populate commentBy
    return (
      u.name || u.fullName || [u.firstName, u.lastName].filter(Boolean).join(' ') || u.email || 'User'
    );
  };
  const commentAvatarUrl = (c) => {
    const u = c?.commentBy || {};
    if (u.profilePicture) return u.profilePicture;
    return resolveUserAvatar(u);
  };
  const initialsOf = (name) => {
    if (!name) return 'U';
    const parts = name.trim().split(/\s+/).slice(0,2);
    return parts.map(p=>p[0]?.toUpperCase()).join('') || 'U';
  };

  return (
    <div className="p-4 p-lg-5 overflow-auto">
      <div className="container-fluid" style={{ maxWidth: 900 }}>
        <div className="mb-3 d-flex align-items-center justify-content-between">
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb mb-0">
              <li className="breadcrumb-item"><Link to="/tasks" className="text-decoration-none text-soft">Tasks</Link></li>
              <li className="breadcrumb-item active text-heading" aria-current="page">Task Details</li>
            </ol>
          </nav>
          <button type="button" className="btn btn-sm btn-secondary-custom" onClick={fetchTask} disabled={loading}><span className="material-symbols-outlined" style={{ fontSize: 18 }}>refresh</span></button>
        </div>

  {loading && <div className="bg-card p-3 rounded text-soft">Loading task…</div>}
  {error && !loading && <div className="bg-card p-3 rounded text-red-custom">{error}</div>}
        {!loading && !error && task && (
          <div className="d-flex flex-column gap-4">
            <div className="bg-card p-4 mb-3">
              <div className="mb-3">
                <h1 className="fs-2 fw-bold text-heading mb-0">{task.title}</h1>
              </div>
              <div className="row g-4">
                <div className="col-md-6">
                  <h2 className="fs-5 fw-semibold text-heading mb-2">Description</h2>
                  <p className="mb-0 text-soft" style={{ whiteSpace: 'pre-wrap' }}>{task.description || 'No description provided.'}</p>
                </div>
                <div className="col-md-6 d-flex flex-column gap-3">
                  <div>
                    <label className="form-label" htmlFor="priority">Priority</label><br />
                    <span className={priorityBadgeClass(task.priority)}>{priorityLabel(task.priority)}</span>
                  </div>
                  <div>
                    <label className="form-label" htmlFor="status">Status</label>
                    <select className="form-select" id="status" name="status" value={task.status} onChange={onStatusChange} disabled={savingStatus || task.status === 'Completed'}>
                      <option>Pending</option>
                      <option>In Progress</option>
                      <option>Completed</option>
                    </select>
                    {task.status === 'Completed' && (
                      <div className="text-soft mt-1" style={{ fontSize: '.7rem' }}>
                        Completed tasks can’t be edited.
                      </div>
                    )}
                  </div>
                  {task.additionalTask ? 
                  <>
                  <div>
                    <label className="form-label" htmlFor="assigned-to">Task Approval</label>
                    <span className="d-block mt-0 bg-card px-3 py-0 rounded text-soft">
                      {
                            task.additionalTask == true ?
                            <>
                            <span className="badge bg-info" style={{ fontSize: '.65rem', verticalAlign: 'middle', color: 'var(--color-bg-body)' }}>
                              (Additional Task)
                            </span>
                            </>
                            : task.rawStatus != 'Approved' ? 
                            <><span className="badge bg-warning" style={{ fontSize: '.65rem', verticalAlign: 'middle', color: 'var(--color-bg-body)' }}>
                              (Pending Approval)
                            </span></>
                            : '✔️'
                          }
                    </span>
                  </div>
                  </>
                  : <>
                  <div>
                    <label className="form-label" htmlFor="assigned-to">Task Approval State</label>
                    <span className="d-block mt-0 bg-card px-3 py-0 rounded text-soft">{task.rawStatus || '-'}</span>
                  </div>
                  </>
                  }
                  
                  <div>
                    <label className="form-label" htmlFor="assigned-to">Assigned To</label>
                    {
                    task?.assignedType == 'Department' ? task?.assignedDepartment ? <>
                    <span className="d-block mt-0 bg-card px-3 py-0 rounded text-soft">{task.assignedDepartment.name || 'N/A'}</span>
                    </> : <span className="d-block mt-0 bg-card px-3 py-0 rounded text-soft">(Dept: N/A)</span>
                     : ''
                    }
                    <span className="d-block mt-0 bg-card px-3 py-0 rounded text-soft">{task?.assignedTo?.name || task?.assignedTo?.fullName || task?.assignedTo?._id || '-'}</span>
                  </div>
                  <div className="row g-2">
                    <div className="col">
                      <label className="form-label" htmlFor="start-date">Start Date</label>
                      <span className="d-block mt-0 bg-card px-3 py-0 rounded text-soft">{fmtDate(task.dateStart)}</span>
                    </div>
                    <div className="col">
                      <label className="form-label" htmlFor="start-date">Expected Close</label>
                      <span className="d-block mt-0 bg-card px-3 py-0 rounded text-soft">{fmtDate(task.dateExpectedEnd)}</span>
                    </div>
                    <div className="col">
                      <label className="form-label" htmlFor="end-date">End Date</label>
                      <span className="d-block mt-0 bg-card px-3 py-0 rounded text-soft">{fmtDate(task.dueDate)}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-card p-4 mb-3">
              <div className="d-flex align-items-center justify-content-between mb-3">
                <h2 className="fs-5 fw-semibold text-heading mb-0">Comments</h2>
                <button type="button" className="btn btn-sm btn-secondary-custom" onClick={fetchComments} disabled={commentsLoading}><span className="material-symbols-outlined" style={{ fontSize: 18 }}>refresh</span></button>
              </div>
              {commentError && <div className="bg-card p-3 rounded text-red-custom mb-3">{commentError}</div>}
              {commentsLoading && <div className="text-soft mb-3">Loading comments…</div>}
              {!commentsLoading && comments.length === 0 && <div className="text-soft mb-3">No comments yet.</div>}
              <div className="d-flex flex-column gap-3 mb-3">
                {comments.map(c => {
                  const name = commentDisplayName(c);
                  const avatar = commentAvatarUrl(c);
                  const canDelete = has(PERMISSIONS.TASK_UPDATE) || has(PERMISSIONS.TASK_DELETE) || (c.commentBy?._id === currentUserId);
                  return (
                    <div className="d-flex align-items-start gap-3" key={c._id}>
                      {avatar ? (
                        <img src={avatar} alt={name} className="profile-img" />
                      ) : (
                        <div className="profile-img d-flex align-items-center justify-content-center" style={{
                          background: 'var(--color-bg-surface-5)',
                          fontSize: '.7rem',
                          fontWeight: 600,
                          letterSpacing: '.5px',
                          color: 'var(--color-text-soft)'
                        }}>{initialsOf(name)}</div>
                      )}
                      <div className="flex-grow-1">
                        <div className="bg-card p-3 rounded border" style={{ borderColor: 'var(--color-border-alt)' }}>
                          <div className="d-flex align-items-center justify-content-between mb-1">
                            <p className="fw-semibold text-heading mb-0">{name}</p>
                            <p className="text-soft mb-0" style={{ fontSize: '0.75rem' }}>{fmtDate(c.createdAt)}</p>
                          </div>
                          <p className="mb-0 text-soft" style={{ fontSize: '0.95rem', whiteSpace: 'pre-wrap' }}>{c.comment}</p>
                        </div>
                      </div>
                        
                    </div>
                  );
                })}
              </div>
              <div className="d-flex align-items-start gap-3 pt-3 border-top" style={{ borderColor: 'var(--color-border-alt)' }}>
                <div className="flex-grow-1">
                  <textarea className="form-control w-100 mb-2" placeholder="Add a comment..." rows={3} value={newComment} onChange={(e)=>setNewComment(e.target.value)}></textarea>
                  <div className="d-flex justify-content-end gap-2">
                    <button type="button" className="btn btn-primary px-4 py-2 fw-semibold" onClick={onAddComment} disabled={addingComment || !newComment.trim()}>{addingComment ? 'Adding…' : 'Add Comment'}</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
