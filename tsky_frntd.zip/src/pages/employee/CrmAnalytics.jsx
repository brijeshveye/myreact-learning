import React, { useEffect, useMemo, useState } from 'react';
import {
  fetchAnalyticsUsersSummary,
  fetchAnalyticsLeadsByUser,
  fetchAnalyticsActivitiesCreatedByUser,
  fetchAnalyticsActivitiesByType,
  fetchAnalyticsUsersRegistrations,
  fetchAnalyticsActivitiesTypesByUser,
  fetchAnalyticsLeadsUpdatedByUser,
} from '../../api/crm';

export default function CrmAnalytics() {
  // Filters
  const todayStr = new Date().toISOString().slice(0, 10);
  const weekAgoStr = new Date(Date.now() - 6 * 86400000).toISOString().slice(0, 10);
  const [filters, setFilters] = useState({ start: weekAgoStr, end: todayStr, rangeDays: 30, type: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Data
  const [usersSummary, setUsersSummary] = useState(null);
  const [usersRegistrations, setUsersRegistrations] = useState(null);
  const [leadsByUser, setLeadsByUser] = useState(null);
  const [leadsUpdatedByUser, setLeadsUpdatedByUser] = useState(null);
  const [actsByUser, setActsByUser] = useState(null);
  const [actsByType, setActsByType] = useState(null);
  const [actsTypesByUser, setActsTypesByUser] = useState(null);

  const refresh = async () => {
    setLoading(true); setError('');
    try {
      const [us, ur, lb, lbu, ab, at, atu] = await Promise.all([
        fetchAnalyticsUsersSummary(),
        fetchAnalyticsUsersRegistrations({ range: Math.max(7, Math.min(90, filters.rangeDays)) }),
        fetchAnalyticsLeadsByUser({ range: Math.max(7, Math.min(365, filters.rangeDays)) }),
        fetchAnalyticsLeadsUpdatedByUser({ start: filters.start, end: filters.end }),
        fetchAnalyticsActivitiesCreatedByUser({ start: filters.start, end: filters.end, ...(filters.type ? { type: filters.type } : {}) }),
        fetchAnalyticsActivitiesByType({ start: filters.start, end: filters.end }),
        fetchAnalyticsActivitiesTypesByUser({ start: filters.start, end: filters.end })
      ]);
      setUsersSummary(us);
      setUsersRegistrations(ur);
      setLeadsByUser(lb);
      setLeadsUpdatedByUser(lbu);
      setActsByUser(ab);
      setActsByType(at);
      setActsTypesByUser(atu);
    } catch (e) {
      setError(e?.response?.data?.message || e.message || 'Failed to load analytics');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { refresh(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, []);

  const onChange = (key) => (e) => setFilters(f => ({ ...f, [key]: e.target.value }));
  const onQuick = (days) => () => {
    const end = new Date(); end.setHours(0,0,0,0);
    const start = new Date(end); start.setDate(end.getDate() - (days - 1));
    const fmt = (d) => d.toISOString().slice(0,10);
    setFilters(f => ({ ...f, start: fmt(start), end: fmt(end) }));
  };

  const number = (v, d=0) => typeof v === 'number' ? v : (Number(v) || d);
  const safeRows = (obj, key='rows') => Array.isArray(obj?.[key]) ? obj[key] : (Array.isArray(obj) ? obj : []);
  const unionKeys = (rows, fn) => {
    const set = new Set();
    rows.forEach(r => Object.keys(fn(r) || {}).forEach(k => set.add(k)));
    return Array.from(set).sort();
  };

  return (
    <div className="p-4 p-lg-5 overflow-auto">
      <div className="mx-auto" style={{ maxWidth: 1200 }}>
        <div className="mb-4 d-flex align-items-center justify-content-between">
          <div>
            <h1 className="fs-2 fw-bold text-heading mb-1">CRM Analytics</h1>
            <p className="text-soft">Powered by the latest CRM Analytics API</p>
          </div>
          <div className="d-none d-sm-block">
            <button className="btn btn-secondary" onClick={refresh} disabled={loading}>
              <span className="material-symbols-outlined align-middle me-1" style={{ fontSize: 18 }}>refresh</span>
              {loading ? 'Refreshing…' : 'Refresh'}
            </button>
          </div>
        </div>

        {error && (
          <div className="alert alert-danger" role="alert">{error}</div>
        )}

        {/* Filters */}
        <section className="mb-4 bg-card p-3 rounded">
          <div className="row g-3 align-items-end">
            <div className="col-6 col-md-3">
              <label className="form-label text-soft small mb-1">Start</label>
              <input type="date" className="form-control form-control-sm" value={filters.start} onChange={onChange('start')} />
            </div>
            <div className="col-6 col-md-3">
              <label className="form-label text-soft small mb-1">End</label>
              <input type="date" className="form-control form-control-sm" value={filters.end} onChange={onChange('end')} />
            </div>
            <div className="col-6 col-md-3">
              <label className="form-label text-soft small mb-1">Activity Type</label>
              <select className="form-select form-select-sm" value={filters.type} onChange={onChange('type')}>
                <option value="">All (exclude system)</option>
                <option value="call">Call</option>
                <option value="email">Email</option>
                <option value="meeting">Meeting</option>
                <option value="task">Task</option>
              </select>
            </div>
            <div className="col-6 col-md-3 d-flex flex-wrap gap-2">
              <button type="button" className="btn btn-outline-soft btn-sm" onClick={onQuick(7)}>Last 7d</button>
              <button type="button" className="btn btn-outline-soft btn-sm" onClick={onQuick(30)}>Last 30d</button>
              <button type="button" className="btn btn-secondary btn-sm ms-auto" onClick={refresh} disabled={loading}>Apply</button>
            </div>
          </div>
        </section>

        {/* Users Summary tiles */}
        <section className="mb-4">
          <div className="row g-3">
            {[{key:'total', label:'Total Users', icon:'group', color:'var(--primary-color)'}, {key:'active_last_7d', label:'Active (7d)', icon:'calendar_clock', color:'#16a34a'}, {key:'active_last_30d', label:'Active (30d)', icon:'event_upcoming', color:'#f59e0b'}].map(t => (
              <div className="col-12 col-sm-6 col-lg-4" key={t.key}>
                <div className="bg-card rounded p-3 d-flex align-items-center justify-content-between" style={{ border: '1px solid var(--color-border-alt)' }}>
                  <div>
                    <div className="text-soft small mb-1">{t.label}</div>
                    <div className="fs-3 fw-bold text-heading">{usersSummary ? number(usersSummary[t.key], 0) : (loading ? '…' : 0)}</div>
                  </div>
                  <div className="rounded-circle d-flex align-items-center justify-content-center" style={{ width: 44, height: 44, background: t.color, color: '#fff' }}>
                    <span className="material-symbols-outlined">{t.icon}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="table-responsive rounded bg-card p-2 mt-3">
            <table className="table table-dark-custom align-middle mb-0 w-100">
              <thead>
                <tr><th>Role</th><th>Users</th></tr>
              </thead>
              <tbody>
                {!usersSummary?.by_role?.length && <tr><td colSpan={2} className="text-center text-secondary py-3">No role data</td></tr>}
                {(usersSummary?.by_role || []).map(r => (
                  <tr key={r.role || 'unknown'}><td>{r.role || 'Unknown'}</td><td>{number(r.count,0)}</td></tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* Leads by User (range) */}
        <section className="mb-4">
          <div className="mb-2 d-flex align-items-center justify-content-between">
            <h2 className="fs-5 fw-bold text-heading mb-0">Leads by User</h2>
            <div className="d-flex align-items-center gap-2">
              <label className="text-soft small">Range</label>
              <select className="form-select form-select-sm" style={{width:110}} value={filters.rangeDays} onChange={onChange('rangeDays')}>
                {[7,30,90,365].map(n => <option key={n} value={n}>{n} days</option>)}
              </select>
            </div>
          </div>
          <div className="table-responsive rounded bg-card p-2">
            <table className="table table-dark-custom align-middle mb-0 w-100">
              <thead>
                <tr><th>User</th><th>Total Leads</th></tr>
              </thead>
              <tbody>
                {!safeRows(leadsByUser,'rows').length && <tr><td colSpan={2} className="text-center text-secondary py-4">No data</td></tr>}
                {safeRows(leadsByUser,'rows').map((r, i) => (
                  <tr key={r.user_id ?? i}><td>{r.user_name || '—'}</td><td>{number(r.total,0)}</td></tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* Leads Updated by User (date range) */}
        <section className="mb-4">
          <div className="mb-2 d-flex align-items-center justify-content-between">
            <h2 className="fs-5 fw-bold text-heading mb-0">Leads Updated by User</h2>
          </div>
          <div className="table-responsive rounded bg-card p-2">
            <table className="table table-dark-custom align-middle mb-0 w-100">
              <thead>
                <tr><th>User</th><th>Total Updated</th></tr>
              </thead>
              <tbody>
                {!safeRows(leadsUpdatedByUser,'rows').length && <tr><td colSpan={2} className="text-center text-secondary py-4">No data</td></tr>}
                {safeRows(leadsUpdatedByUser,'rows').map((r, i) => (
                  <tr key={r.user_id ?? i}><td>{r.user_name || '—'}</td><td>{number(r.total,0)}</td></tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* Activities Created by User (date range, optional type) */}
        <section className="mb-4">
          <div className="mb-2 d-flex align-items-center justify-content-between">
            <h2 className="fs-5 fw-bold text-heading mb-0">Activities Created by User</h2>
          </div>
          <div className="table-responsive rounded bg-card p-2">
            <table className="table table-dark-custom align-middle mb-0 w-100">
              <thead>
                <tr><th>User</th><th>Total</th></tr>
              </thead>
              <tbody>
                {!safeRows(actsByUser,'rows').length && <tr><td colSpan={2} className="text-center text-secondary py-4">No data</td></tr>}
                {safeRows(actsByUser,'rows').map((r,i) => (
                  <tr key={r.user_id ?? i}><td>{r.user_name || '—'}</td><td>{number(r.total,0)}</td></tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* Activities by Type (date range) */}
        <section className="mb-4">
          <div className="mb-2 d-flex align-items-center justify-content-between">
            <h2 className="fs-5 fw-bold text-heading mb-0">Activities by Type</h2>
          </div>
          <div className="table-responsive rounded bg-card p-2">
            <table className="table table-dark-custom align-middle mb-0 w-100">
              <thead>
                <tr><th>Type</th><th>Total</th></tr>
              </thead>
              <tbody>
                {!safeRows(actsByType,'rows').length && <tr><td colSpan={2} className="text-center text-secondary py-4">No data</td></tr>}
                {safeRows(actsByType,'rows').map((r,i) => (
                  <tr key={r.type ?? i}><td>{r.type || '—'}</td><td>{number(r.total,0)}</td></tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* Activity Types by User (date range) */}
        <section className="mb-4">
          <div className="mb-2 d-flex align-items-center justify-content-between">
            <h2 className="fs-5 fw-bold text-heading mb-0">Activity Types by User</h2>
          </div>
          <div className="table-responsive rounded bg-card p-2">
            <table className="table table-dark-custom align-middle mb-0 w-100">
              <thead>
                <tr>
                  <th>User</th>
                  {unionKeys(safeRows(actsTypesByUser,'rows'), r => r.types).map((t) => (
                    <th key={t} className="text-capitalize">{t}</th>
                  ))}
                  <th>Total</th>
                </tr>
              </thead>
              <tbody>
                {!safeRows(actsTypesByUser,'rows').length && (
                  <tr><td colSpan={2} className="text-center text-secondary py-4">No data</td></tr>
                )}
                {safeRows(actsTypesByUser,'rows').map((r, i) => {
                  const keys = unionKeys(safeRows(actsTypesByUser,'rows'), x => x.types);
                  return (
                    <tr key={r.user_id ?? i}>
                      <td>{r.user_name || '—'}</td>
                      {keys.map(k => <td key={k}>{number((r.types||{})[k],0)}</td>)}
                      <td>{number(r.total,0)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>

      </div>
    </div>
  );
}
