import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { resolveUserAvatar } from '../../utils/avatars.js';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { api } from '../../api/client';
import { sendDirectNotification } from '../../api/notifications.js';
import { toast } from 'react-toastify';

// NOTE: This is a static UI adaptation of AdminUserDashboard.html into Bootstrap-based markup.
// Theme relies on existing global classes (btn-primary-custom, card, bg-surface, etc.).

export default function AdminUserDashboard() {
  // In future we can drive user id / data from params or props
  const { userId } = useParams();
  const navigate = useNavigate();

  const [user, setUser] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [refreshing, setRefreshing] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [notifTitle, setNotifTitle] = useState('');
  const [notifMessage, setNotifMessage] = useState('');
  const [sending, setSending] = useState(false);
  const [delivery, setDelivery] = useState('socket');

  const analytics = useMemo(()=>{
    if (!tasks.length) return [];
    const completed = tasks.filter(t=>t.status==='Completed').length;
    const inProgress = tasks.filter(t=>t.status==='In Progress').length;
    const total = tasks.length || 1;
    const distribution = `${Math.round((inProgress/total)*100)}%`;
    const now = Date.now();
    const recent = tasks.filter(t=>{ const ts = new Date(t.updatedAt || t.createdAt || t.dateStart || 0).getTime(); return now - ts < 7*86400000; }).length;
    return [
      { label:'Tasks Completed', value: completed, note:`of ${total}` },
      { label:'Task Status Distribution', value: distribution, note:'In Progress' },
      { label:'Task Activity (Last 7 Days)', value: recent, note:'recent updates' },
    ];
  }, [tasks]);

  const statusBadgeClass = (s) => s === 'Completed' ? 'badge-status-completed' : s === 'In Progress' ? 'badge-status-inprogress' : s === 'Pending Approval' ? 'badge-status-review' : 'badge-status-pending';
  const priorityBadgeClass = (p) => {
    if (p === 1 || p === '1' || p === 'High') return 'badge-priority-high';
    if (p === 2 || p === '2' || p === 'Low') return 'badge-priority-low';
    if (p === 3 || p === '3' || p === 'Urgent') return 'badge-priority-urgent';
    return 'badge-priority-normal';
  };
  const fmtDate = (d) => { if(!d) return '-'; try { return new Date(d).toISOString().slice(0,10); } catch { return '-'; } };

  const fetchData = useCallback(async () => {
    if (!userId) return;
    setLoading(true); setError('');
    try {
      const [userRes, taskRes] = await Promise.all([
        api.get(`/users/${userId}`),
        api.get('/tasks', { params: { assignedTo: userId, limit: 500 } })
      ]);
      const u = userRes?.data?.user || userRes?.data || userRes || null;
      const raw = taskRes?.data;
      const list = Array.isArray(raw) ? raw : (raw?.data || raw?.items || raw?.tasks || []);
      setUser(u);
      setTasks(Array.isArray(list) ? list : []);
    } catch (e) {
      setError(e?.response?.data?.message || e.message || 'Failed to load dashboard data');
    } finally { setLoading(false); }
  }, [userId]);

  useEffect(()=>{ fetchData(); }, [fetchData]);
  const onRefresh = async () => { setRefreshing(true); await fetchData(); setRefreshing(false); };

  return (
    <>
    <div className="px-3 py-4">
      <div className="container-xl">
        <div className="d-flex flex-wrap align-items-start justify-content-between gap-3 mb-4">
          <div>
            <h1 className="mb-1 fs-2 fw-bold text-heading">User Analytics</h1>
            <p className="text-soft mb-0 small">
              {loading ? 'Loading user…' : user ?
              <>
                Detailed overview of{' '}
                <Link to={`/admin/users/tasks/${user._id}`} className='text-decoration-none'>
                  <span className='fw-bold' style={{ color: 'var(--primary-color)' }}>{(user.name || user.fullName || user.companyOfficialEmail || user.email || user._id)}</span>
                </Link>
                's activity and task performance.
              </>
              : 'User not found'}
            </p>
          </div>
          <div className="d-flex align-items-center gap-2">
            <button className="btn btn-secondary-custom d-flex align-items-center gap-1" onClick={onRefresh} disabled={refreshing || loading}>
              <span className="material-symbols-outlined">refresh</span>
              <span>{refreshing ? 'Refreshing…' : 'Refresh'}</span>
            </button>
            {user && (
              <button
                className="btn btn-primary-custom d-flex align-items-center gap-1"
                onClick={() => { setNotifOpen(true); setNotifTitle(''); setNotifMessage(''); setDelivery('socket'); }}
              >
                <span className="material-symbols-outlined">send</span>
                <span>Notify User</span>
              </button>
            )}
            {user && (
              <Link className="btn btn-secondary-custom d-flex align-items-center gap-1 d-none" to={`/admin/users/screenshots/${user._id}`}>
                <span className="material-symbols-outlined">image</span>
                <span>Screenshot Timeline</span>
              </Link>
            )}
            {user && (
              <Link className="btn btn-secondary-custom d-flex align-items-center gap-1" to={`/admin/users/attendance/${user._id}`}>
                <span className="material-symbols-outlined">schedule</span>
                <span>Attendance</span>
              </Link>
            )}
            <Link className="btn btn-primary-custom d-flex align-items-center gap-1" to="/admin/reports/performance">
              <span className="material-symbols-outlined">assessment</span>
              <span>Reports</span>
            </Link>
          </div>
        </div>
        {error && <div className="alert alert-danger py-2 px-3 mb-4">{error}</div>}
        <div className="row g-4">
          <div className="col-lg-4">
            <div className="card p-4 mb-4">
              {loading && !user && <div className="text-soft small">Loading profile…</div>}
              {!loading && !user && <div className="text-soft small">No user data.</div>}
              {user && (
                <div className="d-flex flex-column align-items-center text-center">
                  <div className="avatar-xl mb-3" style={{ backgroundImage:`url(${resolveUserAvatar(user)})` }} />
                  <h2 className="h4 fw-bold mb-1 text-heading">{user.name || user.fullName || [user.firstName, user.lastName].filter(Boolean).join(' ') || user.companyOfficialEmail || user.email || '—'}</h2>
                  <div className="text-soft small">{user.designation || '—'}</div>
                  <div className="text-muted-custom small">{user.department?.name || user.departmentName || '—'}</div>
                  <div className="mt-3 w-100 d-flex flex-column gap-2 small">
                    <div className="d-flex align-items-center justify-content-center gap-2 text-soft">
                      <span className="material-symbols-outlined fs-6">email</span>
                      <span className="text-truncate" style={{maxWidth:180}}>{user.companyOfficialEmail || user.email || '—'}</span>
                    </div>
                    <div className="d-flex align-items-center justify-content-center gap-2 text-soft">
                      <span className="material-symbols-outlined fs-6">call</span>
                      <span>{user.officePhone || user.personalPhone || '—'}</span>
                    </div>
                  </div>
                  <button className="btn btn-secondary-custom w-100 mt-4 d-flex align-items-center justify-content-center gap-1" onClick={() => user && navigate(`/admin/users/edit/${user._id}`)} disabled={!user}>
                    <span className="material-symbols-outlined">edit</span>
                    <span>Edit Profile</span>
                  </button>
                </div>
              )}
            </div>
            <div className="card p-4">
              <h3 className="h6 fw-bold mb-3 text-heading">Other Related Info</h3>
              <p className="text-soft small mb-0">{user?.adminComments || 'No additional notes.'}</p>
            </div>
          </div>
          <div className="col-lg-8">
            <div className="card mb-4">
              <div className="d-flex flex-wrap align-items-center justify-content-between gap-3 p-4 pb-3">
                <h2 className="h5 fw-bold mb-0 text-heading">Tasks List</h2>
                {user && <Link className="btn btn-secondary-custom d-flex align-items-center gap-1" to={`/admin/users/tasks/${user._id}`}>
                  <span>View All Tasks</span>
                  <span className="material-symbols-outlined">arrow_forward</span>
                </Link>}
              </div>
              <div className="table-responsive">
                <table className="table table-dark-custom mb-0">
                  <thead>
                    <tr>
                      <th>Task</th>
                      <th>Priority</th>
                      <th>Status</th>
                      <th>Due Date</th>
                      <th className="text-end">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {loading && <tr><td colSpan={5} className="text-center py-4 text-soft">Loading tasks…</td></tr>}
                    {!loading && tasks.slice(0,10).map(t => {
                      return (
                        <tr key={t._id} className="align-middle">
                          <td className="fw-medium text-heading"><Link to={`/admin/tasks/${t._id}`} className="text-decoration-none text-heading">{t.title}</Link></td>
                          <td><span className={priorityBadgeClass(t.priority)}>{typeof t.priority === 'number' ? (t.priority===1?'High':t.priority===2?'Low':t.priority===3?'Urgent':'Normal') : t.priority}</span></td>
                          <td><span className={statusBadgeClass(t.status)}>{t.status}</span></td>
                          <td className="text-soft">{fmtDate(t.dueDate || t.dateExpectedEnd)}</td>
                          <td className="text-end">
                            <Link to={`/admin/tasks/${t._id}`} className="btn-action btn-link text-decoration-none me-2">
                            <span className="material-symbols-outlined">visibility</span>
                            </Link>
                          </td>
                        </tr>
                      );
                    })}
                    {!loading && tasks.length === 0 && <tr><td colSpan={5} className="text-center py-4 text-soft">No tasks found.</td></tr>}
                  </tbody>
                </table>
              </div>
            </div>
            <div className="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-3">
              <h2 className="h5 fw-bold mb-0 text-heading">Analytics</h2>
            </div>
            <div className="row g-4 mb-4">
              {analytics.length === 0 && !loading && <div className="col-12 text-soft small">No analytics available.</div>}
              {analytics.map((a,i)=>{
                return (
                  <div className="col-md-4" key={i}>
                    <div className="card p-4 h-100">
                      <div className="text-soft small fw-medium text-uppercase" style={{letterSpacing:'.5px'}}>{a.label}</div>
                      <div className="fs-2 fw-bold text-heading mt-1">{a.value}</div>
                      <div className="d-flex align-items-baseline gap-2 mt-1">
                        {a.delta && <span className={`${a.deltaClass} small fw-semibold`}>{a.delta}</span>}
                        <span className="text-muted-custom text-uppercase" style={{fontSize:'.65rem'}}>{a.note}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="card p-4 d-none">
              <h3 className="h6 fw-bold mb-3 text-heading">Task Activity</h3>
              <div style={{height:'260px'}} className="w-100">
                <div className="h-100 d-flex align-items-center justify-content-center text-soft small">Chart Placeholder</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  {notifOpen && (
      <>
        {/* Backdrop */}
        <div
          onClick={() => !sending && setNotifOpen(false)}
          style={{
            position:'fixed', inset:0, background:'rgba(0,0,0,0.45)',
            zIndex:1040, backdropFilter:'blur(2px)'
          }}
        />
        {/* Modal Container */}
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="sendNotifTitle"
          style={{
            position:'fixed', inset:0, zIndex:1050,
            display:'flex', alignItems:'center', justifyContent:'center',
            padding:'1rem'
          }}
          onKeyDown={(e)=>{ if(e.key==='Escape' && !sending) setNotifOpen(false); }}
        >
          <div className="bg-card shadow-lg rounded-3" style={{width:'100%', maxWidth:520, border:'1px solid var(--color-border-alt)'}}>
            <div className="d-flex align-items-center justify-content-between px-4 py-3 border-bottom" style={{borderColor:'var(--color-border-alt)'}}>
              <h5 id="sendNotifTitle" className="mb-0 text-heading">Send Notification</h5>
              <button type="button" className="btn btn-sm btn-secondary-custom" onClick={()=>!sending && setNotifOpen(false)} aria-label="Close">✕</button>
            </div>
            <form onSubmit={async (e)=>{
              e.preventDefault();
              if (!user?._id) return;
              if (!notifTitle.trim() || !notifMessage.trim()) {
                toast.warn('Title and message are required');
                return;
              }
              setSending(true);
              try {
                await sendDirectNotification({
                  user: user._id,
                  title: notifTitle.trim(),
                  message: notifMessage.trim(),
                  type: 'admin',
                  delivery,
                  icon: 'notifications',
                  color: 'primary'
                });
                toast.success('Direct notification sent');
                setNotifOpen(false);
              } catch (err) {
                toast.error(err?.response?.data?.message || err.message || 'Failed to send');
              } finally { setSending(false); }
            }}>
              <div className="px-4 py-3">
                <div className="mb-3">
                  <label className="form-label small fw-semibold text-soft">Title</label>
                  <input
                    type="text"
                    className="form-control input-custom"
                    placeholder="Enter title"
                    value={notifTitle}
                    maxLength={120}
                    onChange={(e)=>setNotifTitle(e.target.value)}
                    disabled={sending}
                    required
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label small fw-semibold text-soft">Message</label>
                  <textarea
                    className="form-control input-custom"
                    placeholder="Enter message"
                    rows={5}
                    value={notifMessage}
                    maxLength={1000}
                    onChange={(e)=>setNotifMessage(e.target.value)}
                    disabled={sending}
                    required
                  />
                  <div className="form-text small text-soft">Instant in-app + email (if enabled).</div>
                </div>
                <div className="mb-3">
                  <label className="form-label small fw-semibold text-soft">Delivery</label>
                  <select
                    className="form-select input-custom"
                    value={delivery}
                    onChange={(e)=>setDelivery(e.target.value)}
                    disabled={sending}
                  >
                    <option value="both">Both (WS + Email)</option>
                    <option value="socket">Only WS</option>
                    <option value="email">Only Email</option>
                  </select>
                </div>
              </div>
              <div className="d-flex justify-content-end gap-2 px-4 py-3 border-top" style={{borderColor:'var(--color-border-alt)'}}>
                <button type="button" className="btn btn-secondary-custom" onClick={()=>!sending && setNotifOpen(false)} disabled={sending}>Cancel</button>
                <button type="submit" className="btn btn-primary-custom d-flex align-items-center gap-1" disabled={sending}>
                  <span className="material-symbols-outlined" style={{fontSize:18}}>{sending ? 'hourglass_top' : 'send'}</span>
                  <span>{sending ? 'Sending…' : 'Send'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      </>
    )}
    </>
  );
}
