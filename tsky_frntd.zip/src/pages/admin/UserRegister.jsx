import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../../api/client';
import { toast } from 'react-toastify';

export default function UserRegister() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    firstName: '',
    middleName: '',
    lastName: '',
    dob: '',
    gender: '',
    permanentAddress: '',
    currentAddress: '',
    designation: '',
    department: '', // store department _id
    employeeId: '',
    userGroup: '',
    companyOfficialEmail: '',
    companyUnofficialGmail: '',
    personalEmail: '',
    officePhone: '',
    personalPhone: '',
    password: '',
  });
  const [departments, setDepartments] = useState([]);
  const [profileFile, setProfileFile] = useState(null);
  const [deptLoading, setDeptLoading] = useState(false);
  const [deptError, setDeptError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit(e) {
    e.preventDefault();
    setSubmitting(true);
    setError('');
    try {
      const fd = new FormData();
      Object.entries({
        ...form,
        dob: form.dob ? new Date(form.dob).toISOString() : '',
        department: form.department || ''
      }).forEach(([k,v]) => {
        if (v !== undefined && v !== null) fd.append(k, v);
      });
      if (profileFile) fd.append('profilePicture', profileFile);
      const { data } = await api.post('/auth/register', fd, { headers: { 'Content-Type': 'multipart/form-data' }});
      if (data?.user) {
        toast.success('User registered successfully');
        navigate('/admin/users');
      }
      
    } catch (err) {
      const msg = err?.response?.data?.message || 'Registration failed';
      setError(msg);
      toast.error(msg);
    } finally {
      setSubmitting(false);
    }
  }

  const onChange = (e) => {
    const { name, value } = e.target;
    setForm((f) => ({ ...f, [name]: value }));
  };

  useEffect(()=>{
    const load = async () => {
      setDeptLoading(true); setDeptError('');
      try {
        const { data } = await api.get('/departments');
        const list = Array.isArray(data?.data) ? data.data : Array.isArray(data) ? data : [];
        setDepartments(list);
      } catch (e) { const msg = e?.response?.data?.message || e.message || 'Failed to load departments'; setDeptError(msg); toast.error(msg); }
      finally { setDeptLoading(false); }
    };
    load();
  }, []);

  return (
    <div className="min-vh-100 d-flex flex-column">
      <main className="flex-grow-1 px-4 px-sm-5 py-4">
        <div className="mx-auto" style={{ maxWidth: 900 }}>
          <div className="mb-4">
            <h1 className="fs-2 fw-bold mb-1 text-heading">New User Registration</h1>
            <p className="text-soft">Fill out the form to create a new user account.</p>
          </div>

          <form onSubmit={handleSubmit}>
            <div className="d-flex flex-column gap-4">
              {/* User Information */}
              <section className="form-section">
                <h3 className="form-section-title">User Information</h3>
                <div className="row g-3">
                  <div className="col-12 col-md-6 col-lg-4">
                    <label className="form-label">First Name</label>
                    <input className="form-control form-control-custom" name="firstName" value={form.firstName} onChange={onChange} placeholder="John" required />
                  </div>
                  <div className="col-12 col-md-6 col-lg-4">
                    <label className="form-label">Middle Name <span className="text-soft">(optional)</span></label>
                    <input className="form-control form-control-custom" name="middleName" value={form.middleName} onChange={onChange} placeholder="Michael" />
                  </div>
                  <div className="col-12 col-md-6 col-lg-4">
                    <label className="form-label">Last Name <span className="text-soft">(optional)</span></label>
                    <input className="form-control form-control-custom" name="lastName" value={form.lastName} onChange={onChange} placeholder="Doe" required />
                  </div>
                </div>
                <div className="row g-3 mt-2">
                  <div className="col-12 col-md-4">
                    <label className="form-label">Date of Birth</label>
                    <input className="form-control form-control-custom" type="date" name="dob" value={form.dob} onChange={onChange} />
                  </div>
                  <div className="col-12 col-md-4">
                    <label className="form-label">Gender</label>
                    <select className="form-select form-select-custom" name="gender" value={form.gender} onChange={onChange} defaultValue="">
                      <option value="" disabled>Select gender</option>
                      <option>Male</option>
                      <option>Female</option>
                      <option>Other</option>
                    </select>
                  </div>
                  <div className="col-12 col-md-4">
                    <label className="form-label">Profile Picture <span className="text-soft">(optional)</span></label>
                    <input className="form-control form-control-custom" type="file" accept="image/*" onChange={(e)=> setProfileFile(e.target.files?.[0] || null)} />
                    {profileFile && <div className="small text-soft mt-1">{profileFile.name}</div>}
                  </div>
                </div>
              </section>

              {/* Address Details */}
              <section className="form-section">
                <h3 className="form-section-title">Address Details</h3>
                <div className="row g-3">
                  <div className="col-12 col-md-6">
                    <label className="form-label">Permanent Address <span className="text-soft">(optional)</span></label>
                    <textarea className="form-control form-control-custom" name="permanentAddress" value={form.permanentAddress} onChange={onChange} placeholder="Meerut, Uttar Pradesh, India" />
                  </div>
                  <div className="col-12 col-md-6">
                    <label className="form-label">Current Address</label>
                    <textarea className="form-control form-control-custom" name="currentAddress" value={form.currentAddress} onChange={onChange} placeholder="Sector 48, Gurugram, India" />
                  </div>
                </div>
              </section>

              {/* Professional Details */}
              <section className="form-section">
                <h3 className="form-section-title">Professional Details</h3>
                <div className="row g-3">
                  <div className="col-12 col-md-6 col-lg-4">
                    <label className="form-label">Designation</label>
                    <input className="form-control form-control-custom" name="designation" value={form.designation} onChange={onChange} placeholder="Software Engineer" />
                  </div>
                  <div className="col-12 col-md-6 col-lg-4">
                    <label className="form-label">Department</label>
                    <select className="form-select form-select-custom" name="department" value={form.department} onChange={onChange} disabled={deptLoading}>
                      <option value="" disabled>{deptLoading ? 'Loading departments...' : 'Select department'}</option>
                      {departments.map(d => <option key={d._id} value={d._id}>{d.name}</option>)}
                    </select>
                    {deptError && <div className="text-danger small mt-1">{deptError}</div>}
                  </div>
                  <div className="col-12 col-md-6 col-lg-4">
                    <label className="form-label">Employee ID <span className="text-soft">(optional)</span></label>
                    <input className="form-control form-control-custom" name="employeeId" value={form.employeeId} onChange={onChange} placeholder="EMP12345" />
                  </div>
                </div>
                <div className="row g-3 mt-2">
                  <div className="col-12 col-md-4">
                    <label className="form-label">User Group</label>
                    <select className="form-select form-select-custom" name="userGroup" value={form.userGroup} onChange={onChange} defaultValue="">
                      <option value="" disabled>Select user group</option>
                      <option>Super Admin</option>
                      <option>Super Management</option>
                      <option>Management</option>
                      <option selected>Employee</option>
                    </select>
                  </div>
                </div>
              </section>

              {/* Contact Information */}
              <section className="form-section">
                <h3 className="form-section-title">Contact Information</h3>
                <div className="row g-3">
                  <div className="col-12 col-md-6">
                    <label className="form-label">Company Official Email</label>
                    <input className="form-control form-control-custom" name="companyOfficialEmail" value={form.companyOfficialEmail} onChange={onChange} placeholder="john.doe@veye.co.in" type="email" required />
                  </div>
                  <div className="col-12 col-md-6">
                    <label className="form-label">Company Unofficial Gmail</label>
                    <input className="form-control form-control-custom" name="companyUnofficialGmail" value={form.companyUnofficialGmail} onChange={onChange} placeholder="john.doe.veye@gmail.com" type="email" />
                  </div>
                  <div className="col-12 col-md-6">
                    <label className="form-label">Personal Email <span className="text-soft">(optional)</span></label>
                    <input className="form-control form-control-custom" name="personalEmail" value={form.personalEmail} onChange={onChange} placeholder="john.doe@personal.com" type="email" />
                  </div>
                  <div className="col-12 col-md-6">
                    <label className="form-label">Office Phone Number <span className="text-soft">(optional)</span></label>
                    <input className="form-control form-control-custom" name="officePhone" value={form.officePhone} onChange={onChange} placeholder="+91 123 654 4567" type="tel" />
                  </div>
                  <div className="col-12 col-md-6">
                    <label className="form-label">Personal Phone Number <span className="text-soft">(optional)</span></label>
                    <input className="form-control form-control-custom" name="personalPhone" value={form.personalPhone} onChange={onChange} placeholder="+91 987 654 3210" type="tel" />
                  </div>
                </div>
              </section>

              {/* Security */}
              <section className="form-section">
                <h3 className="form-section-title">Security</h3>
                <div className="row g-3">
                  <div className="col-12 col-md-6">
                    <label className="form-label">Password</label>
                    <input className="form-control form-control-custom" name="password" value={form.password} onChange={onChange} placeholder="••••••••" type="password" required />
                  </div>
                </div>
              </section>

              {error && (
                <div className="alert alert-danger" role="alert">
                  {error}
                </div>
              )}

              <div className="d-flex justify-content-end gap-2 pt-3">
                <button type="button" onClick={() => navigate(-1)} className="btn btn-secondary-custom px-4">Cancel</button>
                <button type="submit" className="btn btn-primary-custom px-4" disabled={submitting}>
                  {submitting ? 'Creating...' : 'Create User'}
                </button>
              </div>
            </div>
          </form>
        </div>
      </main>
    </div>
  );
}
