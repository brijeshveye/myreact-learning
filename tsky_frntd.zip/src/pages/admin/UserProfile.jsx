import React, { useEffect, useMemo, useState, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import { api } from '../../api/client';
import { toast } from 'react-toastify';

export default function MyProfile() {
  const params = useParams();
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [userId, setUserId] = useState(null);

  const initial = useMemo(() => ({
    firstName: '',
    middleName: '',
    lastName: '',
    dob: '',
    gender: '',
    permanentAddress: '',
    currentAddress: '',
    designation: '',
    department: '', // department id
    departmentName: '',
    userGroup: '',
    employeeId: '',
    companyOfficialEmail: '',
    personalEmail: '',
    companyUnofficialGmail: '',
    officePhone: '',
    personalPhone: '',
    status: '',
    adminComments: '',
    newPassword: '',
    confirmPassword: ''
  }), []);

  const [form, setForm] = useState(initial);
  const [passwordForm, setPasswordForm] = useState({ newPassword: '', confirmPassword: '' });
  const [passwordSaving, setPasswordSaving] = useState(false);
  const [passwordError, setPasswordError] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState('');
  const [original, setOriginal] = useState(initial);
  const [departments, setDepartments] = useState([]);
  const [deptError, setDeptError] = useState('');
  const [deptLoading, setDeptLoading] = useState(false);

  useEffect(() => {
    async function load() {
      setLoading(true);
      setError('');
      try {
        const routeId = params?.id || params?.userId;
        const queryId = new URLSearchParams(window.location.search).get('id');
        const targetId = routeId || queryId;
        if (!targetId) {
          throw new Error('User ID is required');
        }
        setUserId(targetId);
        const { data } = await api.get(`/users/${targetId}`);
        const u = data?.user || data || {};
        const mapped = {
          firstName: u.firstName || u.firstname || '',
          middleName: u.middleName || '',
          lastName: u.lastName || u.lastname || '',
          dob: (u.dob || '').slice(0, 10),
          gender: u.gender || '',
          permanentAddress: u.permanentAddress || u.addressPermanent || '',
          currentAddress: u.currentAddress || u.addressCurrent || '',
          designation: u.designation || '',
          department: u.department?._id || u.department || '',
          departmentName: u.department?.name || u.dept?.name || u.dept || '',
          userGroup: u.userGroup || '',
          employeeId: u.employeeId || u.empId || '',
          companyOfficialEmail: u.companyOfficialEmail || u.email || '',
          personalEmail: u.personalEmail || '',
          companyUnofficialGmail: u.companyUnofficialGmail || u.companyGmail || '',
          officePhone: u.officePhone || '',
          personalPhone: u.personalPhone || '',
          status: u.status || '',
          adminComments: u.adminComments || u.comments || '',
          newPassword: '',
          confirmPassword: ''
        };
        setForm(mapped);
        setOriginal(mapped);
      } catch (err) {
        const status = err?.response?.status;
        const msg = status === 404 ? 'User not found.' : (err?.response?.data?.message || err.message || 'Failed to load profile');
        setError(msg);
        toast.error(msg);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [params]);

  const onChange = (e) => {
    const { name, value } = e.target;
    setForm((f) => ({ ...f, [name]: value }));
  };
  const onPasswordChange = (e) => {
    const { name, value } = e.target;
    setPasswordForm(p => ({ ...p, [name]: value }));
  };

  const fetchDepartments = useCallback(async () => {
    setDeptLoading(true); setDeptError('');
    try {
      const { data } = await api.get('/departments');
      const list = data?.data || data?.departments || data || [];
      setDepartments(Array.isArray(list) ? list : []);
    } catch (err) { const msg = err?.response?.data?.message || 'Failed to load departments'; setDeptError(msg); toast.error(msg); }
    finally { setDeptLoading(false); }
  }, []);

  useEffect(()=>{ fetchDepartments(); }, [fetchDepartments]);

  const onSave = async (e) => {
    e?.preventDefault?.();
    setSaving(true);
    setError('');
    setSuccess('');
    try {
      if (!userId) throw new Error('User not loaded');
      const payload = {
        firstName: form.firstName?.trim() || '',
        middleName: form.middleName?.trim() || '',
        lastName: form.lastName?.trim() || '',
        dob: form.dob || null,
        gender: form.gender || '',
        permanentAddress: form.permanentAddress?.trim() || '',
        currentAddress: form.currentAddress?.trim() || '',
        designation: form.designation?.trim() || '',
        department: form.department || null,
        userGroup: form.userGroup || '',
        employeeId: form.employeeId?.trim() || '',
        companyOfficialEmail: form.companyOfficialEmail?.trim() || '',
        personalEmail: form.personalEmail?.trim() || '',
        companyUnofficialGmail: form.companyUnofficialGmail?.trim() || '',
        officePhone: form.officePhone?.trim() || '',
        personalPhone: form.personalPhone?.trim() || '',
        status: form.status || '',
        adminComments: form.adminComments?.trim() || '',
      };
      await api.patch(`/users/${userId}`, payload);
      setSuccess('Profile updated successfully.');
      toast.success('Profile updated successfully');
      // Update original snapshot after successful save
      setOriginal((prev) => ({ ...prev, ...payload }));
    } catch (err) {
      const msg = err?.response?.data?.message || err.message || 'Update failed';
      setError(msg);
      toast.error(msg);
    } finally {
      setSaving(false);
    }
  };

  const onPasswordSubmit = async (e) => {
    e?.preventDefault?.();
    setPasswordSaving(true);
    setPasswordError('');
    setPasswordSuccess('');
    try {
      if (!userId) throw new Error('User not loaded');
      if (!passwordForm.newPassword) throw new Error('New password is required');
      if (passwordForm.newPassword.length < 6) throw new Error('Password must be at least 6 characters');
      if (passwordForm.newPassword !== passwordForm.confirmPassword) throw new Error('Passwords do not match');
      await api.patch(`/users/${userId}`, { password: passwordForm.newPassword });
      setPasswordSuccess('Password updated successfully.');
      toast.success('Password updated successfully');
      setPasswordForm({ newPassword: '', confirmPassword: '' });
      setTimeout(()=> setShowPasswordModal(false), 1200);
    } catch (err) {
      const msg = err?.response?.data?.message || err.message || 'Password update failed';
      setPasswordError(msg);
      toast.error(msg);
    } finally {
      setPasswordSaving(false);
    }
  };

  // Admin view: no self password change here

  return (
    <div className="d-flex justify-content-center py-5 px-3">
      <div className="w-100" style={{ maxWidth: 1100 }}>
        <div className="mb-4">
          <h1 className="fs-2 fw-bold mb-1">Edit User Profile</h1>
          <p className="text-secondary-custom">Admin can update the selected user's information.</p>
        </div>

        {loading && <div className="alert alert-info">Loading…</div>}
        {error && <div className="alert alert-danger">{error}</div>}
        {success && <div className="alert alert-success">{success}</div>}

        <form className="row g-4" onSubmit={onSave}>
          {/* Left summary card */}
          <div className="col-12 col-lg-4">
            <div className="bg-secondary-custom rounded p-4 d-flex flex-column align-items-center text-center shadow">
              <div className="position-relative mb-2">
                <div
                  className="profile-img profile-lg"
                  style={{
                    backgroundImage:
                      "url('https://lh3.googleusercontent.com/aida-public/AB6AXuCnBX93YuqBJxPPp2Z6lNZdhjgIk8Az4rXiLTbb-NtgUpwxWeo8vaaJa4UtjOZ_Au5tR9fd6k0RPnUrqOPGWwtNTk2liWqm61ET9iIKLSWe1E4urmtnkN6qBnAaDhpF5c67F4qR4Q8hykhLcuSVNAkSKuFXzMiFve_JG4VoCLchUg1AJN_Vg3vC8-VuqRBaI4xtRNz_kde1Jb_-tfmoYeTulE80SiWTayflqEpKfhB1r8AuYYZv2cLDMG1Ur8rNaPvirU1C7Z-ws7k')",
                  }}
                />
                <button
                  className="btn btn-primary-custom position-absolute"
                  style={{ bottom: 8, right: 8, width: 32, height: 32, padding: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                  aria-label="Edit avatar"
                  type="button"
                >
                  <span className="material-symbols-outlined fs-5">edit</span>
                </button>
              </div>
              <h2 className="mt-2 fs-4 fw-bold mb-0">{[form.firstName, form.lastName].filter(Boolean).join(' ') || '—'}</h2>
              <p className="text-secondary-custom mb-0">{form.designation || '—'}</p>
              <p className="text-secondary-custom mb-2" style={{ fontSize: '0.95rem' }}>Employee ID: {form.employeeId || '—'}</p>
              <div className="w-100 mt-3">
                <button onClick={() => setShowPrivacyModal(true)} className="btn w-100 text-start py-2 px-3 rounded d-flex align-items-center gap-2 bg-transparent text-secondary-custom" style={{ transition: 'background 0.2s' }} type="button">
                  <span className="material-symbols-outlined fs-5">privacy_tip</span>
                  <span>Privacy Settings</span>
                </button>
                <button onClick={() => { setShowPasswordModal(true); setPasswordError(''); setPasswordSuccess(''); setPasswordForm({ newPassword: '', confirmPassword: '' }); }} className="btn w-100 text-start py-2 px-3 rounded d-flex align-items-center gap-2 bg-transparent text-secondary-custom" style={{ transition: 'background 0.2s' }} type="button">
                  <span className="material-symbols-outlined fs-5">lock_reset</span>
                  <span>Change Password</span>
                </button>
              </div>
            </div>
          </div>

          {/* Right detail forms */}
          <div className="col-12 col-lg-8">
            <div className="row g-4">
              <div className="col-12">
                <div className="bg-secondary-custom rounded p-4 shadow mb-4">
                  <h3 className="fs-5 fw-bold mb-3">Personal Information</h3>
                  <div className="row g-3">
                    <div className="col-12 col-sm-6">
                      <label className="form-label text-secondary-custom">First Name</label>
                      <input className="form-control input-custom" type="text" name="firstName" value={form.firstName} onChange={onChange} />
                    </div>
                    <div className="col-12 col-sm-6">
                      <label className="form-label text-secondary-custom">Middle Name</label>
                      <input className="form-control input-custom" type="text" name="middleName" value={form.middleName} onChange={onChange} />
                    </div>
                    <div className="col-12">
                      <label className="form-label text-secondary-custom">Last Name</label>
                      <input className="form-control input-custom" type="text" name="lastName" value={form.lastName} onChange={onChange} />
                    </div>
                    <div className="col-12 col-sm-6">
                      <label className="form-label text-secondary-custom">Date of Birth</label>
                      <input className="form-control input-custom" type="date" name="dob" value={form.dob} onChange={onChange} />
                    </div>
                    <div className="col-12 col-sm-6">
                      <label className="form-label text-secondary-custom">Gender</label>
                      <select className="form-select input-custom" name="gender" value={form.gender} onChange={onChange}>
                        <option value="">Select</option>
                        <option value="Female">Female</option>
                        <option value="Male">Male</option>
                        <option value="Other">Other</option>
                        <option value="Prefer not to say">Prefer not to say</option>
                      </select>
                    </div>
                    <div className="col-12">
                      <label className="form-label text-secondary-custom">Permanent Address</label>
                      <textarea className="form-control input-custom" name="permanentAddress" value={form.permanentAddress} onChange={onChange} rows={2} />
                    </div>
                    <div className="col-12">
                      <label className="form-label text-secondary-custom">Current Address</label>
                      <textarea className="form-control input-custom" name="currentAddress" value={form.currentAddress} onChange={onChange} rows={2} />
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-12">
                <div className="bg-secondary-custom rounded p-4 shadow mb-4">
                  <h3 className="fs-5 fw-bold mb-3">Professional Information</h3>
                  <div className="row g-3">
                    <div className="col-12 col-sm-6">
                      <label className="form-label text-secondary-custom">Designation</label>
                      <input className="form-control input-custom" type="text" name="designation" value={form.designation} onChange={onChange} />
                    </div>
                    <div className="col-12 col-sm-6">
                      <label className="form-label text-secondary-custom">Department</label>
                      <select className="form-select input-custom" name="department" value={form.department} onChange={onChange} disabled={deptLoading}>
                        <option value="">Select</option>
                        {departments.map(d => <option key={d._id || d.id} value={d._id || d.id}>{d.name}</option>)}
                      </select>
                      {deptError && <div className="text-danger small mt-1">{deptError}</div>}
                    </div>
                    <div className="col-12 col-sm-6">
                      <label className="form-label text-secondary-custom">User Group</label>
                      <select className="form-select input-custom" name="userGroup" value={form.userGroup} onChange={onChange}>
                        <option value="">Select</option>
                        <option value="Super Admin">Super Admin</option>
                        <option value="Super Management">Super Management</option>
                        <option value="Management">Management</option>
                        <option value="Employee">Employee</option>
                      </select>
                    </div>
                    <div className="col-12 col-sm-6">
                      <label className="form-label text-secondary-custom">Employee ID</label>
                      <input className="form-control input-custom" type="text" name="employeeId" value={form.employeeId} onChange={onChange} />
                    </div>
                    <div className="col-12 col-sm-6">
                      <label className="form-label text-secondary-custom">Status</label>
                      <select className="form-select input-custom" name="status" value={form.status} onChange={onChange}>
                        <option value="">Select</option>
                        <option value="Pending">Pending</option>
                        <option value="Active">Active</option>
                        <option value="Rejected">Rejected</option>
                        <option value="Banned">Banned</option>
                        <option value="Suspended">Suspended</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-12">
                <div className="bg-secondary-custom rounded p-4 shadow mb-4">
                  <h3 className="fs-5 fw-bold mb-3">Contact Information</h3>
                  <div className="row g-3">
                    <div className="col-12 col-sm-6">
                      <label className="form-label text-secondary-custom">Company Official Email</label>
                      <input className="form-control input-custom" type="email" name="companyOfficialEmail" value={form.companyOfficialEmail} onChange={onChange} />
                    </div>
                    <div className="col-12 col-sm-6">
                      <label className="form-label text-secondary-custom">Personal Email</label>
                      <input className="form-control input-custom" type="email" name="personalEmail" value={form.personalEmail} onChange={onChange} />
                    </div>
                    <div className="col-12 col-sm-6">
                      <label className="form-label text-secondary-custom">Company Unofficial Gmail</label>
                      <input className="form-control input-custom" type="email" name="companyUnofficialGmail" value={form.companyUnofficialGmail} onChange={onChange} />
                    </div>
                    <div className="col-12 col-sm-6">
                      <label className="form-label text-secondary-custom">Office Phone Number</label>
                      <input className="form-control input-custom" type="tel" name="officePhone" value={form.officePhone} onChange={onChange} />
                    </div>
                    <div className="col-12 col-sm-6">
                      <label className="form-label text-secondary-custom">Personal Phone Number</label>
                      <input className="form-control input-custom" type="tel" name="personalPhone" value={form.personalPhone} onChange={onChange} />
                    </div>
                  </div>
                </div>
              </div>

              {/* Moved below contact card */}
              <div className="col-12">
                <div className="bg-secondary-custom rounded p-4 shadow mb-4">
                  <h3 className="fs-5 fw-bold mb-3">Admin Comments</h3>
                  <label className="form-label text-secondary-custom d-flex justify-content-between">
                    <span>Notes</span>
                    <span className="small">{form.adminComments.length}/1000</span>
                  </label>
                  <textarea className="form-control input-custom" name="adminComments" value={form.adminComments} onChange={onChange} rows={3} maxLength={1000} />
                </div>
              </div>


              <div className="col-12 d-flex justify-content-end pt-2 gap-2">
                <button className="btn btn-secondary-custom px-4" type="button" onClick={() => setForm(original)} disabled={saving}>Cancel</button>
                <button className="btn btn-primary-custom d-flex align-items-center gap-2 px-4" type="submit" disabled={saving}>
                  <span className="material-symbols-outlined">save</span>
                  <span>{saving ? 'Saving…' : 'Save Changes'}</span>
                </button>
              </div>
            </div>
          </div>
        </form>
      </div>
      {/* Admin view: no password modal here */}

      {/* Privacy Settings Modal */}
      {showPrivacyModal && (
        <div className="position-fixed top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center" style={{ zIndex: 1050 }}>
          <div className="position-absolute top-0 start-0 w-100 h-100" onClick={() => setShowPrivacyModal(false)} style={{ background: 'rgba(0,0,0,0.5)' }} />
          <div className="bg-card rounded shadow p-3 p-sm-4 position-relative" style={{ width: '90%', maxWidth: 520 }} role="dialog" aria-modal="true" aria-labelledby="privacyTitle">
            <div className="d-flex align-items-center justify-content-between mb-3">
              <h2 id="privacyTitle" className="fs-5 fw-bold mb-0 text-heading">Privacy Settings</h2>
              <button className="btn btn-action" onClick={() => setShowPrivacyModal(false)} aria-label="Close">
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>
            <div className="d-flex flex-column gap-2">
              <label className="d-flex align-items-center gap-2">
                <input className="form-check-input" type="checkbox" defaultChecked />
                <span className="text-secondary-custom">Show my company email to team members</span>
              </label>
              <label className="d-flex align-items-center gap-2">
                <input className="form-check-input" type="checkbox" />
                <span className="text-secondary-custom">Enable two-factor authentication</span>
              </label>
              <label className="d-flex align-items-center gap-2">
                <input className="form-check-input" type="checkbox" defaultChecked />
                <span className="text-secondary-custom">Share activity status</span>
              </label>
            </div>
            <div className="d-flex justify-content-end gap-2 mt-4">
              <button className="btn btn-secondary-custom" onClick={() => setShowPrivacyModal(false)} type="button">Cancel</button>
              <button className="btn btn-primary-custom" type="button">Save</button>
            </div>
          </div>
        </div>
      )}

      {/* Change Password Modal */}
      {showPasswordModal && (
        <div className="position-fixed top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center" style={{ zIndex: 1050 }}>
          <div className="position-absolute top-0 start-0 w-100 h-100" onClick={() => !passwordSaving && setShowPasswordModal(false)} style={{ background: 'rgba(0,0,0,0.5)' }} />
          <form onSubmit={onPasswordSubmit} className="bg-card rounded shadow p-3 p-sm-4 position-relative" style={{ width: '90%', maxWidth: 480 }} role="dialog" aria-modal="true" aria-labelledby="passwordTitle">
            <div className="d-flex align-items-center justify-content-between mb-3">
              <h2 id="passwordTitle" className="fs-5 fw-bold mb-0 text-heading">Change Password</h2>
              <button className="btn btn-action" onClick={() => setShowPasswordModal(false)} type="button" disabled={passwordSaving} aria-label="Close">
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>
            {passwordError && <div className="alert alert-danger py-2 px-3 small mb-3">{passwordError}</div>}
            {passwordSuccess && <div className="alert alert-success py-2 px-3 small mb-3">{passwordSuccess}</div>}
            <div className="mb-3">
              <label className="form-label text-secondary-custom">New Password</label>
              <input className="form-control input-custom" type="password" name="newPassword" value={passwordForm.newPassword} onChange={onPasswordChange} autoComplete="new-password" disabled={passwordSaving} />
            </div>
            <div className="mb-3">
              <label className="form-label text-secondary-custom">Confirm Password</label>
              <input className="form-control input-custom" type="password" name="confirmPassword" value={passwordForm.confirmPassword} onChange={onPasswordChange} autoComplete="new-password" disabled={passwordSaving} />
            </div>
            <p className="small text-secondary-custom mb-3">Password must be at least 6 characters. This action updates only the password.</p>
            <div className="d-flex justify-content-end gap-2">
              <button className="btn btn-secondary-custom" type="button" onClick={() => setShowPasswordModal(false)} disabled={passwordSaving}>Cancel</button>
              <button className="btn btn-primary-custom d-flex align-items-center gap-2" type="submit" disabled={passwordSaving}>
                <span className="material-symbols-outlined">lock_reset</span>
                <span>{passwordSaving ? 'Updating…' : 'Update Password'}</span>
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
