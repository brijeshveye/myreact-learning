import React, { useEffect, useMemo, useState } from 'react';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import AsyncSelect from 'react-select/async';
import { toast } from 'react-toastify';
import { api } from '../../api/client';

export default function DepartmentForm() {
  const { deptId } = useParams();
  const navigate = useNavigate();
  const { state } = useLocation();

  const isEdit = Boolean(deptId);

  const initial = useMemo(() => ({ id: undefined, name: '', desc: '', head: null, status: 'Active' }), []);

  const [form, setForm] = useState(() => {
    if (state?.dept) {
      const d = state.dept;
      return {
        id: d._id || d.id,
        name: d.name || '',
        desc: d.description || d.desc || '',
        head: d.head1 ? { value: d.head1._id || d.head1.id, label: `${d.head1.firstName || ''} ${d.head1.lastName || ''}`.trim() } : null,
        status: 'Active',
      };
    }
    return initial;
  });
  const [touched, setTouched] = useState({});
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    async function load() {
      if (!isEdit || state?.dept) return;
      setLoading(true);
      setError('');
      try {
        const { data } = await api.get(`/departments/${deptId}`);
        const d = data || {};
        setForm({
          id: d._id,
          name: d.name || '',
          desc: d.description || '',
          head: d.head1 ? { value: d.head1._id || d.head1.id, label: `${d.head1.firstName || ''} ${d.head1.lastName || ''}`.trim() } : null,
          status: 'Active',
        });
      } catch (err) {
        const status = err?.response?.status;
        if (status === 401) navigate('/login');
        else if (status === 403) setError('You are not authorized to view this department.');
        else setError('Failed to load department.');
      } finally {
        setLoading(false);
      }
    }
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [deptId, isEdit]);

  const onChange = (e) => {
    const { name, value } = e.target;
    setForm((f) => ({ ...f, [name]: value }));
  };

  const onBlur = (e) => {
    const { name } = e.target;
    setTouched((t) => ({ ...t, [name]: true }));
  };

  const isValid = () => {
    return form.name?.trim();
  };

  // Theme-aware react-select styles using CSS variables defined in app.css
  const selectStyles = {
    control: (base, state) => ({
      ...base,
      backgroundColor: 'var(--color-bg-surface-5)',
      borderColor: state.isFocused ? 'var(--primary-color)' : 'var(--color-bg-surface-5)',
      minHeight: 40,
      boxShadow: state.isFocused ? '0 0 0 .15rem rgba(17,115,212,.35)' : 'none',
      ':hover': { borderColor: 'var(--primary-color)' },
      color: 'var(--color-text)',
      borderRadius: 'var(--radius-sm)'
    }),
    menu: (base) => ({ ...base, backgroundColor: 'var(--color-bg-surface-4)', color: 'var(--color-text)', zIndex: 30 }),
    option: (base, state) => ({
      ...base,
      backgroundColor: state.isFocused ? 'var(--color-bg-surface-3)' : 'transparent',
      color: 'var(--color-text)',
      ':active': { backgroundColor: 'var(--color-bg-surface-2)' },
      fontSize: '.9rem'
    }),
    singleValue: (base) => ({ ...base, color: 'var(--color-text)' }),
    input: (base) => ({ ...base, color: 'var(--color-text)' }),
    placeholder: (base) => ({ ...base, color: 'var(--color-text-soft)' }),
    menuPortal: base => ({ ...base, zIndex: 9999 })
  };

  // Async loader for user options
  const loadUserOptions = async (inputValue) => {
    try {
      const params = { limit: 18 };
      if (inputValue && inputValue.length >= 2) params.q = inputValue;
      const { data } = await api.get('/users', { params });
      const list = Array.isArray(data?.data) ? data.data : Array.isArray(data) ? data : (data?.users || []);
      return list
        .map((u) => ({
          value: u._id || u.id,
          label: `${(u.firstName || u.firstname || '')} ${(u.lastName || u.lastname || '')}`.trim() || (u.name || u.email || 'Unknown'),
        }))
        .filter((o) => o.value);
    } catch (err) {
      return [];
    }
  };

  const onSave = async (e) => {
    e.preventDefault();
    setTouched({ name: true });
    if (!isValid()) return;
    setSaving(true);
    setError('');
    try {
      const payload = { name: form.name.trim(), description: form.desc?.trim() || '' };
      if (form.head?.value) payload.head1 = form.head.value;
      if (isEdit) {
        await api.put(`/departments/${form.id || deptId}`, payload);
        toast.success('Department updated');
      } else {
        await api.post('/departments', payload);
        toast.success('Department created');
      }
      navigate('/admin/departments');
    } catch (err) {
      const msg = err?.response?.data?.message || 'Save failed';
      setError(msg);
      toast.error(msg);
    } finally {
      setSaving(false);
    }
  };

  const onCancel = () => navigate(-1);

  const onDelete = async () => {
    const id = form.id || deptId;
    if (!id) return;
    const confirmed = window.confirm('Delete this department?');
    if (!confirmed) return;
    try {
      await api.delete(`/departments/${id}`);
      toast.success('Department deleted');
      navigate('/admin/departments');
    } catch (err) {
      const msg = err?.response?.data?.message || 'Delete failed';
      setError(msg);
      toast.error(msg);
    }
  };

  return (
    <div className="px-3 py-4">
      <div className="container-xl">
        <div className="d-flex align-items-center justify-content-between flex-wrap gap-3 mb-4">
          <div className="d-flex align-items-center gap-2">
            <button type="button" className="btn btn-sm btn-outline-soft d-flex align-items-center" onClick={() => navigate(-1)}>
              <span className="material-symbols-outlined me-1">arrow_back</span>
              Back
            </button>
            <h1 className="mb-0 text-heading fs-2 fw-bold">{isEdit ? 'Edit Department' : 'Add Department'}</h1>
          </div>
          {isEdit && (
            <button type="button" className="btn btn-outline-danger d-flex align-items-center" onClick={onDelete}>
              <span className="material-symbols-outlined me-1">delete</span>
              Delete
            </button>
          )}
        </div>
        <form onSubmit={onSave} className="card bg-surface border border-surface p-3 p-md-4">
          {loading && (
            <div className="alert alert-info">Loading…</div>
          )}
          {error && (
            <div className="alert alert-danger">{error}</div>
          )}
          <div className="row g-3 g-md-4">
            <div className="col-12 col-md-6">
              <label className="form-label text-heading">Department Name<span className="text-danger">*</span></label>
              <input
                name="name"
                value={form.name}
                onChange={onChange}
                onBlur={onBlur}
                className={`form-control input-custom ${touched.name && !form.name?.trim() ? 'is-invalid' : ''}`}
                placeholder="e.g., Engineering"
                autoFocus
              />
              {touched.name && !form.name?.trim() && (
                <div className="invalid-feedback">Department name is required.</div>
              )}
            </div>

            <div className="col-12 col-md-6">
              <label className="form-label text-heading">Department Head</label>
              <AsyncSelect
                cacheOptions
                defaultOptions
                isClearable
                loadOptions={loadUserOptions}
                value={form.head}
                onChange={(opt) => setForm((f) => ({ ...f, head: opt }))}
                placeholder="Search and select a user (optional)"
                styles={selectStyles}
                classNamePrefix="rs"
              />
            </div>

            <div className="col-12">
              <label className="form-label text-heading">Description</label>
              <textarea
                name="desc"
                value={form.desc}
                onChange={onChange}
                rows={4}
                className="form-control input-custom"
                placeholder="Briefly describe the department's responsibilities"
              />
            </div>

            <div className="col-12 col-md-4">
              <label className="form-label text-heading">Status</label>
              <select
                name="status"
                value={form.status}
                onChange={onChange}
                className="form-select input-custom"
              >
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </select>
            </div>
          </div>

          <div className="d-flex justify-content-end gap-2 mt-4">
            <button type="button" className="btn btn-outline-light" onClick={onCancel}>Cancel</button>
            <button type="submit" className="btn btn-primary-custom d-flex align-items-center" disabled={saving}>
              <span className="material-symbols-outlined me-1">save</span>
              {saving ? 'Saving…' : 'Save'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
