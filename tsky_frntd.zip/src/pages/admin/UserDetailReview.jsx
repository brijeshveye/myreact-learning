import React, { useCallback, useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { api } from '../../api/client';
import { resolveUserAvatar } from '../../utils/avatars';
import { toast } from 'react-toastify';

export default function UserDetailReview() {
  const { userId } = useParams();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [savingField, setSavingField] = useState('');
  const [editingField, setEditingField] = useState('');
  const [fieldDraft, setFieldDraft] = useState('');
  const [comments, setComments] = useState('');
  const [commentSaving, setCommentSaving] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);
  const [departments, setDepartments] = useState([]);
  const [deptLoading, setDeptLoading] = useState(false);
  const [deptError, setDeptError] = useState('');

  const fetchUser = useCallback(async () => {
    if (!userId) return;
    setLoading(true); setError('');
    try {
      const { data } = await api.get(`/users/${userId}`);
      const u = data?.data || data?.user || data;
      setUser(u);
      setComments(u?.adminComments || u?.comments || '');
    } catch (err) { const msg = err?.response?.data?.message || 'Failed to load user'; setError(msg); toast.error(msg); }
    finally { setLoading(false); }
  }, [userId]);

  useEffect(() => { fetchUser(); }, [fetchUser]);

  const fullName = user ? `${user.firstName || ''} ${user.middleName || ''} ${user.lastName || ''}`.replace(/\s+/g,' ').trim() : '';

  const beginEdit = (field, current) => {
    if (savingField) return; // avoid while saving
    // Lazy load departments only when editing department first time
    if (field === 'department' && departments.length === 0) {
      fetchDepartments().then(()=>{
        setEditingField(field);
        setFieldDraft(current ?? '');
      });
      return;
    }
    setEditingField(field);
    setFieldDraft(current ?? '');
  };

  const cancelEdit = () => {
    if (savingField) return;
    setEditingField('');
    setFieldDraft('');
  };

  const saveField = async () => {
    const field = editingField;
    if (!field || !user?._id) return;
    if (field !== 'department' && user[field] === fieldDraft) { cancelEdit(); return; }
    setSavingField(field);
    try {
      if (field === 'department') {
        await api.patch(`/users/${user._id}`, { department: fieldDraft || null });
        await fetchUser(); // refresh to get populated department name
      } else {
        await api.patch(`/users/${user._id}`, { [field]: fieldDraft });
        setUser(u => ({ ...u, [field]: fieldDraft }));
      }
      cancelEdit();
      toast.success('Field updated');
    } catch (err) { toast.error(err?.response?.data?.message || 'Update failed'); }
    finally { setSavingField(''); }
  };

  const onDraftChange = (e) => setFieldDraft(e.target.value);

  const saveComments = async () => {
    if (!user?._id) return;
    setCommentSaving(true);
    try {
      await api.patch(`/users/${user._id}`, { adminComments: comments });
      toast.success('Comments saved');
    } catch (err) { toast.error(err?.response?.data?.message || 'Failed to save comments'); }
    finally { setCommentSaving(false); }
  };

  const performAction = async (action) => {
    if (!user?._id) return;
    // Map action to status updates
    let newStatus = null;
    if (action === 'accept') newStatus = 'Active';
    else if (action === 'reject') newStatus = 'Rejected';

    if (action === 'delete') {
      if (!window.confirm('Confirm delete?')) return;
      setActionLoading(true);
      try {
        await api.delete(`/users/${user._id}`);
        navigate('/admin/users');
        toast.success('User deleted');
      } catch (err) { toast.error(err?.response?.data?.message || 'Delete failed'); }
      finally { setActionLoading(false); }
      return;
    }

    if (!newStatus) return;
    if (user.status === newStatus) return; // no-op if already set
    if (!window.confirm(`Confirm set status to ${newStatus}?`)) return;
    setActionLoading(true);
    try {
      await api.patch(`/users/${user._id}/status`, { status: newStatus });
      toast.success(`User status set to ${newStatus}`);
      navigate('/admin/users');
      return; // stop further state changes here
    } catch (err) { toast.error(err?.response?.data?.message || 'Status update failed'); }
    finally { setActionLoading(false); }
  };

  const fetchDepartments = useCallback(async () => {
    setDeptLoading(true); setDeptError('');
    try {
      const { data } = await api.get('/departments');
      const list = data?.data || data?.departments || data || [];
      setDepartments(Array.isArray(list) ? list : []);
    } catch (err) { setDeptError(err?.response?.data?.message || 'Failed to load departments'); }
    finally { setDeptLoading(false); }
  }, []);

  useEffect(()=>{ fetchDepartments(); }, [fetchDepartments]);

  return (
    <div className="p-4 p-lg-5 overflow-auto">
      <div className="mx-auto" style={{ maxWidth: 1180 }}>
        <div className="mb-4 mb-lg-5 d-flex justify-content-between align-items-start flex-wrap gap-3">
          <div>
            <h2 className="fw-bold text-heading mb-1" style={{ fontSize: '2rem' }}>User Details Review</h2>
            <p className="text-secondary m-0">{loading ? 'Loading user...' : error ? error : fullName ? `Review and manage registration for ${fullName}.` : 'User not found.'}</p>
          </div>
          <button className="btn btn-secondary-custom d-flex align-items-center gap-2" onClick={fetchUser} disabled={loading}>
            <span className="material-symbols-outlined">refresh</span> Refresh
          </button>
        </div>

        {error && <div className="alert alert-danger">{error}</div>}

        <div className="row g-4 g-xl-5">
          <div className="col-md-8 d-flex flex-column gap-4">
            <div className="card-dark p-4 p-lg-5">
              <h3 className="fw-semibold mb-4">User Information</h3>
              {!user && !loading && <div className="text-secondary">No data.</div>}
              <div className="row g-3">
                {['firstName','middleName','lastName'].map(f => {
                  const isEditing = editingField === f;
                  return (
                    <div className="col-sm-6" key={f}>
                      <label className="form-label" htmlFor={f}>{f.replace(/Name/,' Name').replace(/([A-Z])/g,' $1').trim()}</label>
                      <div className="field-actions position-relative">
                        <input
                          id={f}
                          className="form-input"
                          value={isEditing ? fieldDraft : (user?.[f] || '')}
                          onChange={isEditing ? onDraftChange : undefined}
                          disabled={savingField===f}
                          readOnly={!isEditing}
                        />
                        {!isEditing && (
                          <button type="button" className="btn btn-action" onClick={()=>beginEdit(f, user?.[f] || '')} disabled={!!editingField}>
                            <span className="material-symbols-outlined">edit</span>
                          </button>
                        )}
                        {isEditing && (
                          <div className="d-flex gap-1 ms-2">
                            <button type="button" className="btn btn-action" onClick={saveField} disabled={savingField===f}>
                              <span className="material-symbols-outlined">{savingField===f ? 'hourglass_empty' : 'save'}</span>
                            </button>
                            <button type="button" className="btn btn-action" onClick={cancelEdit} disabled={savingField===f}>
                              <span className="material-symbols-outlined">close</span>
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
                <div className="col-sm-6">
                  <label className="form-label" htmlFor="dob">Date of Birth</label>
                  <div className="field-actions">
                    <input id="dob" type="date" className="form-input" value={editingField==='dob' ? fieldDraft : (user?.dob || '').slice(0,10)} onChange={editingField==='dob' ? onDraftChange : undefined} disabled={savingField==='dob'} readOnly={editingField!=='dob'} />
                    {editingField !== 'dob' && <button type="button" className="btn btn-action" onClick={()=>beginEdit('dob', (user?.dob || '').slice(0,10))} disabled={!!editingField}><span className="material-symbols-outlined">edit</span></button>}
                    {editingField === 'dob' && (
                      <div className="d-flex gap-1 ms-2">
                        <button type="button" className="btn btn-action" onClick={saveField} disabled={savingField==='dob'}><span className="material-symbols-outlined">{savingField==='dob' ? 'hourglass_empty' : 'save'}</span></button>
                        <button type="button" className="btn btn-action" onClick={cancelEdit} disabled={savingField==='dob'}><span className="material-symbols-outlined">close</span></button>
                      </div>
                    )}
                  </div>
                </div>
                <div className="col-sm-6">
                  <label className="form-label" htmlFor="gender">Gender</label>
                  <div className="field-actions">
                    <select id="gender" className="form-input" value={editingField==='gender' ? fieldDraft : (user?.gender || '')} onChange={editingField==='gender' ? onDraftChange : undefined} disabled={editingField!=='gender' || savingField==='gender'}>
                      <option value="">Select</option>
                      <option>Male</option>
                      <option>Female</option>
                      <option>Other</option>
                    </select>
                    {editingField !== 'gender' && <button type="button" className="btn btn-action" onClick={()=>beginEdit('gender', user?.gender || '')} disabled={!!editingField}><span className="material-symbols-outlined">edit</span></button>}
                    {editingField === 'gender' && (
                      <div className="d-flex gap-1 ms-2">
                        <button type="button" className="btn btn-action" onClick={saveField} disabled={savingField==='gender'}><span className="material-symbols-outlined">{savingField==='gender' ? 'hourglass_empty' : 'save'}</span></button>
                        <button type="button" className="btn btn-action" onClick={cancelEdit} disabled={savingField==='gender'}><span className="material-symbols-outlined">close</span></button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            <div className="card-dark p-4 p-lg-5">
              <h3 className="fw-semibold mb-4">Address Information</h3>
              <div className="mb-3">
                <label className="form-label" htmlFor="permanentAddress">Permanent Address</label>
                <div className="field-actions align-items-start">
                  <textarea id="permanentAddress" rows={3} className="form-control input-custom form-input" value={editingField==='permanentAddress' ? fieldDraft : (user?.permanentAddress || '')} onChange={editingField==='permanentAddress' ? onDraftChange : undefined} disabled={savingField==='permanentAddress'} readOnly={editingField!=='permanentAddress'} />
                  {editingField!=='permanentAddress' && <button type="button" className="btn btn-action mt-1" onClick={()=>beginEdit('permanentAddress', user?.permanentAddress || '')} disabled={!!editingField}><span className="material-symbols-outlined">edit</span></button>}
                  {editingField==='permanentAddress' && <div className="d-flex gap-1 mt-1 ms-2"> <button type="button" className="btn btn-action" onClick={saveField} disabled={savingField==='permanentAddress'}><span className="material-symbols-outlined">{savingField==='permanentAddress' ? 'hourglass_empty' : 'save'}</span></button><button type="button" className="btn btn-action" onClick={cancelEdit} disabled={savingField==='permanentAddress'}><span className="material-symbols-outlined">close</span></button></div>}
                </div>
              </div>
              <div className="mb-0">
                <label className="form-label" htmlFor="currentAddress">Current Address</label>
                <div className="field-actions align-items-start">
                  <textarea id="currentAddress" rows={3} className="form-control input-custom form-input" value={editingField==='currentAddress' ? fieldDraft : (user?.currentAddress || '')} onChange={editingField==='currentAddress' ? onDraftChange : undefined} disabled={savingField==='currentAddress'} readOnly={editingField!=='currentAddress'} />
                  {editingField!=='currentAddress' && <button type="button" className="btn btn-action mt-1" onClick={()=>beginEdit('currentAddress', user?.currentAddress || '')} disabled={!!editingField}><span className="material-symbols-outlined">edit</span></button>}
                  {editingField==='currentAddress' && <div className="d-flex gap-1 mt-1 ms-2"> <button type="button" className="btn btn-action" onClick={saveField} disabled={savingField==='currentAddress'}><span className="material-symbols-outlined">{savingField==='currentAddress' ? 'hourglass_empty' : 'save'}</span></button><button type="button" className="btn btn-action" onClick={cancelEdit} disabled={savingField==='currentAddress'}><span className="material-symbols-outlined">close</span></button></div>}
                </div>
              </div>
            </div>

            <div className="card-dark p-4 p-lg-5">
              <h3 className="fw-semibold mb-4">Employment Details</h3>
              <div className="row g-3">
                <div className="col-sm-6">
                  <label className="form-label" htmlFor="designation">Designation</label>
                  <div className="field-actions">
                    <input id="designation" className="form-input" value={editingField==='designation' ? fieldDraft : (user?.designation || '')} onChange={editingField==='designation' ? onDraftChange : undefined} disabled={savingField==='designation'} readOnly={editingField!=='designation'} />
                    {editingField!=='designation' && <button type="button" className="btn btn-action" onClick={()=>beginEdit('designation', user?.designation || '')} disabled={!!editingField}><span className="material-symbols-outlined">edit</span></button>}
                    {editingField==='designation' && <div className="d-flex gap-1 ms-2"> <button type="button" className="btn btn-action" onClick={saveField} disabled={savingField==='designation'}><span className="material-symbols-outlined">{savingField==='designation' ? 'hourglass_empty' : 'save'}</span></button><button type="button" className="btn btn-action" onClick={cancelEdit} disabled={savingField==='designation'}><span className="material-symbols-outlined">close</span></button></div>}
                  </div>
                </div>
                <div className="col-sm-6">
                  <label className="form-label" htmlFor="department">Department</label>
                  <div className="field-actions">
                    {editingField === 'department' ? (
                      <>
                        <select
                          id="department"
                          className="form-input"
                          value={fieldDraft}
                          onChange={onDraftChange}
                          disabled={savingField==='department' || deptLoading}
                        >
                          <option value="">-- None --</option>
                          {departments.map(d => (
                            <option key={d._id || d.id} value={d._id || d.id}>{d.name}</option>
                          ))}
                        </select>
                        <div className="d-flex gap-1 ms-2">
                          <button type="button" className="btn btn-action" onClick={saveField} disabled={savingField==='department' || deptLoading}>
                            <span className="material-symbols-outlined">{savingField==='department' ? 'hourglass_empty' : 'save'}</span>
                          </button>
                          <button type="button" className="btn btn-action" onClick={cancelEdit} disabled={savingField==='department'}>
                            <span className="material-symbols-outlined">close</span>
                          </button>
                        </div>
                      </>
                    ) : (
                      <>
                        <input id="department" className="form-input" value={user?.department?.name || user?.departmentName || ''} readOnly />
                        <button type="button" className="btn btn-action" onClick={()=>beginEdit('department', user?.department?._id || user?.department || '')} disabled={!!editingField}>
                          <span className="material-symbols-outlined">edit</span>
                        </button>
                      </>
                    )}
                  </div>
                  {editingField==='department' && deptError && <div className="text-danger small mt-1">{deptError}</div>}
                </div>
                <div className="col-sm-6">
                  <label className="form-label" htmlFor="userGroup">User Group</label>
                  <div className="field-actions">
                    <input id="userGroup" className="form-input" value={editingField==='userGroup' ? fieldDraft : (user?.userGroup || '')} onChange={editingField==='userGroup' ? onDraftChange : undefined} disabled={savingField==='userGroup'} readOnly={editingField!=='userGroup'} />
                    {editingField!=='userGroup' && <button type="button" className="btn btn-action" onClick={()=>beginEdit('userGroup', user?.userGroup || '')} disabled={!!editingField}><span className="material-symbols-outlined">edit</span></button>}
                    {editingField==='userGroup' && <div className="d-flex gap-1 ms-2"> <button type="button" className="btn btn-action" onClick={saveField} disabled={savingField==='userGroup'}><span className="material-symbols-outlined">{savingField==='userGroup' ? 'hourglass_empty' : 'save'}</span></button><button type="button" className="btn btn-action" onClick={cancelEdit} disabled={savingField==='userGroup'}><span className="material-symbols-outlined">close</span></button></div>}
                  </div>
                </div>
                <div className="col-sm-6">
                  <label className="form-label" htmlFor="employeeId">Employee ID</label>
                  <div className="field-actions">
                    <input id="employeeId" className="form-input" value={editingField==='employeeId' ? fieldDraft : (user?.employeeId || '')} onChange={editingField==='employeeId' ? onDraftChange : undefined} disabled={savingField==='employeeId'} readOnly={editingField!=='employeeId'} />
                    {editingField!=='employeeId' && <button type="button" className="btn btn-action" onClick={()=>beginEdit('employeeId', user?.employeeId || '')} disabled={!!editingField}><span className="material-symbols-outlined">edit</span></button>}
                    {editingField==='employeeId' && <div className="d-flex gap-1 ms-2"> <button type="button" className="btn btn-action" onClick={saveField} disabled={savingField==='employeeId'}><span className="material-symbols-outlined">{savingField==='employeeId' ? 'hourglass_empty' : 'save'}</span></button><button type="button" className="btn btn-action" onClick={cancelEdit} disabled={savingField==='employeeId'}><span className="material-symbols-outlined">close</span></button></div>}
                  </div>
                </div>
              </div>
            </div>

            <div className="card-dark p-4 p-lg-5">
              <h3 className="fw-semibold mb-4">Contact Information</h3>
              <div className="row g-3">
                <div className="col-sm-6">
                  <label className="form-label" htmlFor="personalEmail">Personal Email</label>
                  <div className="field-actions">
                    <input id="personalEmail" type="email" className="form-input" value={editingField==='personalEmail' ? fieldDraft : (user?.personalEmail || '')} onChange={editingField==='personalEmail' ? onDraftChange : undefined} disabled={savingField==='personalEmail'} readOnly={editingField!=='personalEmail'} />
                    {editingField!=='personalEmail' && <button type="button" className="btn btn-action" onClick={()=>beginEdit('personalEmail', user?.personalEmail || '')} disabled={!!editingField}><span className="material-symbols-outlined">edit</span></button>}
                    {editingField==='personalEmail' && <div className="d-flex gap-1 ms-2"> <button type="button" className="btn btn-action" onClick={saveField} disabled={savingField==='personalEmail'}><span className="material-symbols-outlined">{savingField==='personalEmail' ? 'hourglass_empty' : 'save'}</span></button><button type="button" className="btn btn-action" onClick={cancelEdit} disabled={savingField==='personalEmail'}><span className="material-symbols-outlined">close</span></button></div>}
                  </div>
                </div>
                <div className="col-sm-6">
                  <label className="form-label" htmlFor="companyUnofficialGmail">Company Unofficial Gmail</label>
                  <div className="field-actions">
                    <input id="companyUnofficialGmail" type="email" className="form-input" value={editingField==='companyUnofficialGmail' ? fieldDraft : (user?.companyUnofficialGmail || '')} onChange={editingField==='companyUnofficialGmail' ? onDraftChange : undefined} disabled={savingField==='companyUnofficialGmail'} readOnly={editingField!=='companyUnofficialGmail'} />
                    {editingField!=='companyUnofficialGmail' && <button type="button" className="btn btn-action" onClick={()=>beginEdit('companyUnofficialGmail', user?.companyUnofficialGmail || '')} disabled={!!editingField}><span className="material-symbols-outlined">edit</span></button>}
                    {editingField==='companyUnofficialGmail' && <div className="d-flex gap-1 ms-2"> <button type="button" className="btn btn-action" onClick={saveField} disabled={savingField==='companyUnofficialGmail'}><span className="material-symbols-outlined">{savingField==='companyUnofficialGmail' ? 'hourglass_empty' : 'save'}</span></button><button type="button" className="btn btn-action" onClick={cancelEdit} disabled={savingField==='companyUnofficialGmail'}><span className="material-symbols-outlined">close</span></button></div>}
                  </div>
                </div>
                <div className="col-12">
                  <label className="form-label" htmlFor="companyOfficialEmail">Company Official Email</label>
                  <div className="field-actions">
                    <input id="companyOfficialEmail" type="email" className="form-input" value={editingField==='companyOfficialEmail' ? fieldDraft : (user?.companyOfficialEmail || '')} onChange={editingField==='companyOfficialEmail' ? onDraftChange : undefined} disabled={savingField==='companyOfficialEmail'} readOnly={editingField!=='companyOfficialEmail'} />
                    {editingField!=='companyOfficialEmail' && <button type="button" className="btn btn-action" onClick={()=>beginEdit('companyOfficialEmail', user?.companyOfficialEmail || '')} disabled={!!editingField}><span className="material-symbols-outlined">edit</span></button>}
                    {editingField==='companyOfficialEmail' && <div className="d-flex gap-1 ms-2"> <button type="button" className="btn btn-action" onClick={saveField} disabled={savingField==='companyOfficialEmail'}><span className="material-symbols-outlined">{savingField==='companyOfficialEmail' ? 'hourglass_empty' : 'save'}</span></button><button type="button" className="btn btn-action" onClick={cancelEdit} disabled={savingField==='companyOfficialEmail'}><span className="material-symbols-outlined">close</span></button></div>}
                  </div>
                </div>
                <div className="col-sm-6">
                  <label className="form-label" htmlFor="officePhone">Office Phone Number</label>
                  <div className="field-actions">
                    <input id="officePhone" type="tel" className="form-input" value={editingField==='officePhone' ? fieldDraft : (user?.officePhone || '')} onChange={editingField==='officePhone' ? onDraftChange : undefined} disabled={savingField==='officePhone'} readOnly={editingField!=='officePhone'} />
                    {editingField!=='officePhone' && <button type="button" className="btn btn-action" onClick={()=>beginEdit('officePhone', user?.officePhone || '')} disabled={!!editingField}><span className="material-symbols-outlined">edit</span></button>}
                    {editingField==='officePhone' && <div className="d-flex gap-1 ms-2"> <button type="button" className="btn btn-action" onClick={saveField} disabled={savingField==='officePhone'}><span className="material-symbols-outlined">{savingField==='officePhone' ? 'hourglass_empty' : 'save'}</span></button><button type="button" className="btn btn-action" onClick={cancelEdit} disabled={savingField==='officePhone'}><span className="material-symbols-outlined">close</span></button></div>}
                  </div>
                </div>
                <div className="col-sm-6">
                  <label className="form-label" htmlFor="personalPhone">Personal Phone Number</label>
                  <div className="field-actions">
                    <input id="personalPhone" type="tel" className="form-input" value={editingField==='personalPhone' ? fieldDraft : (user?.personalPhone || '')} onChange={editingField==='personalPhone' ? onDraftChange : undefined} disabled={savingField==='personalPhone'} readOnly={editingField!=='personalPhone'} />
                    {editingField!=='personalPhone' && <button type="button" className="btn btn-action" onClick={()=>beginEdit('personalPhone', user?.personalPhone || '')} disabled={!!editingField}><span className="material-symbols-outlined">edit</span></button>}
                    {editingField==='personalPhone' && <div className="d-flex gap-1 ms-2"> <button type="button" className="btn btn-action" onClick={saveField} disabled={savingField==='personalPhone'}><span className="material-symbols-outlined">{savingField==='personalPhone' ? 'hourglass_empty' : 'save'}</span></button><button type="button" className="btn btn-action" onClick={cancelEdit} disabled={savingField==='personalPhone'}><span className="material-symbols-outlined">close</span></button></div>}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="col-md-4 d-flex flex-column gap-4">
            <div className="card-dark p-4 d-flex flex-column align-items-center text-center">
              <div className="avatar-xl mb-3" style={{ backgroundImage: `url(${resolveUserAvatar(user)})` }} />
              <h3 className="h5 fw-bold mb-1">{fullName || '—'}</h3>
              <p className="text-secondary mb-0" style={{ fontSize: '.8rem' }}>{user?.employeeId || '—'}</p>
              <button className="btn btn-soft btn-sm d-inline-flex align-items-center gap-1 mt-3" type="button" onClick={() => alert('Avatar upload not implemented yet') }>
                <span className="material-symbols-outlined" style={{ fontSize: 16 }}>upload_file</span>
                Change Picture
              </button>
            </div>

            <div className="card-dark p-4">
              <h4 className="fw-semibold mb-3">Super Admin Comments</h4>
              <label className="form-label d-flex justify-content-between align-items-center" htmlFor="adminComments">
                <span>Notes</span>
                <span className="text-soft" style={{fontSize:'.65rem'}}>{comments.length}/1000</span>
              </label>
              <textarea id="adminComments" maxLength={1000} rows={5} className="form-control input-custom form-input" placeholder="Add comments or notes for this registration..." value={comments} onChange={e=>setComments(e.target.value)} disabled={commentSaving} />
              <div className="d-flex justify-content-end mt-2 gap-2">
                <button className="btn btn-outline-soft btn-sm" type="button" disabled={commentSaving || !user || comments === (user.adminComments || user.comments || '')} onClick={()=>setComments(user?.adminComments || user?.comments || '')}>Reset</button>
                <button className="btn btn-primary-custom btn-sm d-flex align-items-center gap-1" onClick={saveComments} disabled={commentSaving || !user || comments === (user.adminComments || user.comments || '')}>
                  <span className="material-symbols-outlined" style={{ fontSize:16 }}>{commentSaving ? 'hourglass_empty' : 'save'}</span>
                  {commentSaving ? 'Saving...' : 'Save'}
                </button>
              </div>
            </div>

            <div className="card-dark p-4">
              <h3 className="fw-semibold mb-3">Actions</h3>
              <div className="d-flex flex-column gap-2">
                <button className="btn btn-primary w-100 fw-bold btn-sm py-2" disabled={actionLoading || user?.status==='Active'} onClick={()=>performAction('accept')}>{actionLoading ? 'Working...' : (user?.status==='Active' ? 'User Active' : 'Accept User')}</button>
                <button className="btn btn-danger w-100 fw-bold btn-sm py-2" disabled={actionLoading || user?.status==='Rejected'} onClick={()=>performAction('reject')}>{user?.status==='Rejected' ? 'User Rejected' : 'Reject Registration'}</button>
                <button className="btn btn-outline-soft w-100 fw-bold btn-sm py-2" disabled={actionLoading} onClick={()=>performAction('delete')}>Delete Registration</button>
              </div>
              {user?.status && (
                <p className="mt-3 mb-0 text-soft" style={{fontSize:'.75rem'}}>Current Status: <span className={`px-2 py-1 rounded-pill ${user.status==='Active' ? 'badge-status-completed' : user.status==='Rejected' ? 'badge-status-pending' : 'badge-status-inprogress'}`}>{user.status}</span></p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
