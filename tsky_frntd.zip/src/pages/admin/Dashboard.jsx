import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { api } from '../../api/client';
import { Link } from 'react-router-dom';
import { resolveUserAvatar } from '../../utils/avatars.js';

export default function Dashboard() {
  // Filter state
  const [selectedUser, setSelectedUser] = useState('all');
  const [timeframe, setTimeframe] = useState('today'); // today | all | range
  const [rangeStart, setRangeStart] = useState('');
  const [rangeEnd, setRangeEnd] = useState('');

  // Data state
  const [users, setUsers] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [refreshing, setRefreshing] = useState(false);

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const userPromise = api.get('/users');
      // Build task query params
      const params = new URLSearchParams();
      if (selectedUser !== 'all') params.set('assignedTo', selectedUser);
      if (timeframe === 'today') {
        const today = new Date();
        const iso = today.toISOString().slice(0,10);
        params.set('dateStart', iso);
        params.set('dateEnd', iso);
      } else if (timeframe === 'range' && rangeStart && rangeEnd) {
        params.set('dateStart', rangeStart);
        params.set('dateEnd', rangeEnd);
      }
      const taskPromise = api.get(`/tasks?${params.toString()}`);
      const [{ data: usersRes }, { data: tasksRes }] = await Promise.all([userPromise, taskPromise]);
      const userArray = Array.isArray(usersRes?.data) ? usersRes.data : Array.isArray(usersRes) ? usersRes : [];
      const taskArray = Array.isArray(tasksRes?.data) ? tasksRes.data : Array.isArray(tasksRes) ? tasksRes : [];
      setUsers(userArray);
      setTasks(taskArray);
    } catch (e) {
      setError(e?.response?.data?.message || e.message || 'Failed to load data');
    } finally {
      setLoading(false);
    }
  }, [selectedUser, timeframe, rangeStart, rangeEnd]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const onRefresh = async () => {
    setRefreshing(true);
    await fetchData();
    setRefreshing(false);
  };

  // Aggregate tasks per user
  const userStats = useMemo(() => {
    const map = new Map();
    if (selectedUser !== 'all') {
      const sel = users.find(u => String(u._id || u.id) === String(selectedUser)) || { _id: selectedUser, name: 'Unknown' };
      map.set(String(sel._id || sel.id), { user: sel, total: 0, pending: 0, completed: 0 });
    } else {
      users.forEach(u => {
        map.set(String(u._id || u.id), { user: u, total: 0, pending: 0, completed: 0 });
      });
    }
    tasks.forEach(t => {
      const uid = t.assignedTo?._id || t.assignedTo; // may be object or id
      if (!uid) return;
      if (!map.has(String(uid))) {
        map.set(String(uid), { user: { _id: uid, name: 'Unknown' }, total: 0, pending: 0, completed: 0 });
      }
      const stat = map.get(String(uid));
      stat.total += 1;
      if (t.status === 'Completed') stat.completed += 1; else stat.pending += 1;
    });
    const arr = Array.from(map.values());
    return arr.sort((a,b)=> (a.user.name || '').localeCompare(b.user.name || ''));
  }, [users, tasks, selectedUser]);

  const disableRangeInputs = timeframe !== 'range';

  return (
    <div className="container-fluid">
      <div className="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-3">
        <p className="mb-0 text-soft">Overview of tasks and progress</p>
        <div className="d-flex align-items-center gap-2 flex-wrap">
          <select className="form-select" style={{width:180}} value={selectedUser} onChange={e=>setSelectedUser(e.target.value)}>
            <option value="all">All Users</option>
            {users.map(u => <option key={u._id} value={u._id}>{u.name || u.fullName || u.email}</option>)}
          </select>
          <select className="form-select" style={{width:150}} value={timeframe} onChange={e=>setTimeframe(e.target.value)}>
            <option value="today">Today</option>
            <option value="all">All Time</option>
            <option value="range">Date Range</option>
          </select>
          <input type="date" className="form-control" style={{width:150}} value={rangeStart} onChange={e=>setRangeStart(e.target.value)} disabled={disableRangeInputs} />
          <input type="date" className="form-control" style={{width:150}} value={rangeEnd} onChange={e=>setRangeEnd(e.target.value)} disabled={disableRangeInputs} />
          <button className="btn btn-dark d-flex align-items-center gap-1 fw-medium" onClick={onRefresh} disabled={refreshing || loading}>
            <span className="material-symbols-outlined">refresh</span>
            <span>{refreshing ? 'Refreshing…' : 'Refresh'}</span>
          </button>
        </div>
      </div>
      {error && <div className="alert alert-danger mb-4">{error}</div>}
      {loading && <div className="text-soft mb-4">Loading data…</div>}
      {!loading && !error && userStats.length === 0 && <div className="text-soft">No users/tasks to display.</div>}
      <div className="row g-4">
        {userStats.map(({ user, total, pending, completed }) => (
          <div key={user._id} className="col-12 col-sm-6 col-lg-4 col-xl-3 col-xxl-3">
            <div className="card card-custom p-4 mb-0 h-100 d-flex flex-column">
              <div className="d-flex align-items-center gap-3 mb-3">
                <img alt={user.name || 'User'} className="rounded-circle" style={{width:48,height:48,objectFit:'cover'}} src={resolveUserAvatar(user)} />
                <div>
                  <Link to={`/admin/users/view/${user._id || user.id}`} className="text-decoration-none">
                  <h3 className="fs-5 fw-semibold text-heading mb-0">{user.name || user.fullName || user.email || 'User'}</h3>
                  </Link>
                  <p className="mb-0 text-soft" style={{fontSize:'0.9rem'}}>{user.designation || 'Designation'}</p>
                  <p className="mb-0 text-muted" style={{fontSize:'0.75rem'}}>{user.department?.name || user.departmentName || '—'}</p>
                </div>
              </div>
              <div className="row text-center mt-auto">
                <div className="col">
                  <Link to={`/admin/users/tasks/${user._id || user.id}`} className="text-decoration-none">
                  <p className="fs-4 fw-bold text-heading mb-0">{total}</p>
                  <p className="mb-0 text-soft" style={{fontSize:'0.75rem'}}>Total</p>
                  </Link>
                </div>
                <div className="col">
                  <Link to={`/admin/users/tasks/${user._id || user.id}`} className="text-decoration-none">
                  <p className="fs-4 fw-bold mb-0" style={{color:'#facc15'}}>{pending}</p>
                  <p className="mb-0 text-soft" style={{fontSize:'0.75rem'}}>Pending</p>
                  </Link>
                </div>
                <div className="col">
                  <Link to={`/admin/users/tasks/${user._id || user.id}`} className="text-decoration-none">
                  <p className="fs-4 fw-bold mb-0" style={{color:'#22c55e'}}>{completed}</p>
                  <p className="mb-0 text-soft" style={{fontSize:'0.75rem'}}>Completed</p>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
