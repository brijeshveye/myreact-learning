import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../../api/client';
import { resolveUserAvatar } from '../../utils/avatars.js';
import { usePermission } from '../../context/PermissionContext.jsx';
import { PERMISSIONS } from '../../utils/permissions.js';
import { toast } from 'react-toastify';

export default function UserManagement() {
  const navigate = useNavigate();
  const { has } = usePermission();
  const [view, setView] = useState('all'); // 'all' | 'requests'
  const [users, setUsers] = useState([]);
  const [pending, setPending] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [filters, setFilters] = useState({ department: '', role: '', status: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const debounceRef = useRef();

  const displayUsers = view === 'all' ? users : pending;

  const buildParams = ({ q, forPending }) => {
    const params = {};
    if (q) params.q = q;
    // Backend expects userType mapped to status field via controller mapping
    if (forPending) {
      params.userType = 'Pending';
    } else if (filters.status) {
      params.userType = filters.status; // maps to status in controller
    }
    if (filters.role) params.userGroup = filters.role; // not currently filtered backend, placeholder for future
    if (filters.department) params.department = filters.department; // not currently filtered backend, placeholder
    return params;
  };

  const fetchUsers = async ({ q } = {}) => {
    setError('');
    try {
      const params = buildParams({ q, forPending: false });
      const { data } = await api.get('/users', { params });
      const list = Array.isArray(data?.data) ? data.data : Array.isArray(data) ? data : (data?.users || []);
      setUsers(list);
    } catch (err) {
      const status = err?.response?.status;
      if (status === 401) navigate('/login');
      else {
        const msg = err?.response?.data?.message || 'Failed to load users';
        setError(msg);
        toast.error(msg);
      }
    }
  };

  const fetchPending = async ({ q } = {}) => {
    setError('');
    try {
      const params = buildParams({ q, forPending: true });
      const { data } = await api.get('/users', { params });
      const list = Array.isArray(data?.data) ? data.data : Array.isArray(data) ? data : (data?.users || []);
      setPending(list);
    } catch (err) {
      const status = err?.response?.status;
      if (status === 401) navigate('/login');
      else {
        const msg = err?.response?.data?.message || 'Failed to load pending requests';
        setError(msg);
        toast.error(msg);
      }
    }
  };

  useEffect(() => {
    // Initial load: users, pending, departments list
    (async () => {
      setLoading(true);
      try {
        await Promise.all([
          fetchUsers({ q: search }),
          fetchPending({ q: search }),
          (async () => {
            try {
              const { data } = await api.get('/departments');
              const list = Array.isArray(data?.data) ? data.data : Array.isArray(data) ? data : (data?.departments || []);
              setDepartments(list);
            } catch (_) { /* silent */ }
          })()
        ]);
      } finally {
        setLoading(false);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Refetch when filters change (debounced with search already handled separately)
  useEffect(() => {
    if (view === 'all') fetchUsers({ q: search }); else fetchPending({ q: search });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filters, view]);

  const onSearchChange = (e) => {
    const q = e.target.value;
    setSearch(q);
    clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      if (view === 'all') fetchUsers({ q });
      else fetchPending({ q });
    }, 300);
  };

  const fullName = (u) => `${u.firstName || u.firstname || ''} ${u.lastName || u.lastname || ''}`.trim();
  const deptName = (u) => u.department?.name || u.dept?.name || u.dept || '-';
  const roleName = (u) => u.userGroup || u.role || '-';
  const statusName = (u) => u.userType || u.status || '-';
  const requestedOn = (u) => u.createdAt ? new Date(u.createdAt).toISOString().slice(0, 10) : '-';

  const approve = async (user) => {
    if (!user?._id && !user?.id) return;
    try {
      await api.patch(`/users/${user._id || user.id}`, { status: 'Active' });
      await fetchPending({ q: search });
      await fetchUsers({ q: search });
      toast.success('User approved');
    } catch (err) {
      const msg = err?.response?.data?.message || 'Approve failed';
      setError(msg);
      toast.error(msg);
    }
  };

  const reject = async (user) => {
    if (!user?._id && !user?.id) return;
    const confirmed = window.confirm('Reject this user request?');
    if (!confirmed) return;
    try {
      await api.patch(`/users/${user._id || user.id}`, { status: 'Rejected' });
      await fetchPending({ q: search });
      toast.success('User request rejected');
    } catch (err) {
      const msg = err?.response?.data?.message || 'Reject failed';
      setError(msg);
      toast.error(msg);
    }
  };

  const removeUser = async (user) => {
    if (!user?._id && !user?.id) return;
    const confirmed = window.confirm('Delete this user?');
    if (!confirmed) return;
    try {
      await api.delete(`/users/${user._id || user.id}`);
      await fetchUsers({ q: search });
      toast.success('User deleted');
    } catch (err) {
      const msg = err?.response?.data?.message || 'Delete failed';
      setError(msg);
      toast.error(msg);
    }
  };

  const stats = useMemo(() => {
    const total = users.length;
    const active = users.filter((u) => (u.userType || u.status) === 'Active').length;
    const perDept = users.reduce((acc, u) => {
      const d = deptName(u);
      if (!acc[d]) acc[d] = 0;
      acc[d] += 1;
      return acc;
    }, {});
    const perDeptStr = Object.entries(perDept)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([k, v]) => `${k}: ${v}`)
      .join(', ');
    return { total, active, perDeptStr };
  }, [users]);

  return (
    <div className="p-4 p-lg-5 overflow-auto">
      <div className="mx-auto" style={{ maxWidth: 1280 }}>
        <div className="d-flex flex-wrap align-items-start justify-content-between gap-3 mb-4 mb-lg-5">
          <div>
            <h1 className="h2 fw-bold mb-1 text-heading">User Management</h1>
            <p className="text-soft m-0">Manage user accounts, roles, and permissions.</p>
          </div>

          <div>
            {has(PERMISSIONS.USER_CREATE) && (
              <Link to="/admin/users/new" className="btn btn-primary-custom d-inline-flex align-items-center gap-1 btn-sm px-3 py-2">
                <span className="material-symbols-outlined">add</span> Add New User
              </Link>
            )}
            {has(PERMISSIONS.USER_CREATE) && (
              <Link to="/register" className="btn btn-success d-inline-flex align-items-center gap-1 btn-sm px-3 py-2 ms-3">
                <span className="material-symbols-outlined">share</span> Share Form Link
              </Link>
            )}
            <button className="btn btn-secondary d-inline-flex align-items-center gap-1 btn-sm px-3 py-2 ms-3" onClick={() => { if (view === 'all') fetchUsers({ q: search }); else fetchPending({ q: search }); }}>
              <span className="material-symbols-outlined">refresh</span>
            </button>
          </div>

        </div>

        <div className="mb-5">
          <h2 className="h5 fw-semibold text-heading mb-3">User Statistics</h2>
          <div className="row g-3 g-lg-4">
            <div className="col-md-4">
              <div className="stat-card h-100">
                <p className="text-soft mb-1">Total Users</p>
                <h4 className="text-heading">{stats.total}</h4>
              </div>
            </div>
            <div className="col-md-4">
              <div className="stat-card h-100">
                <p className="text-soft mb-1">Active Users</p>
                <h4 className="text-heading">{stats.active}</h4>
              </div>
            </div>
            <div className="col-md-4">
              <div className="stat-card h-100">
                <p className="text-soft mb-1">Users per Department</p>
                <p className="fw-semibold text-heading" style={{ fontSize: '.95rem' }}>{stats.perDeptStr || '—'}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Filters Bar */}
        <div className="bg-card rounded p-3 mb-4">
          <div className="row g-3 align-items-end">
            <div className="col-12 col-md-4">
              <label className="form-label text-soft small mb-1">Department</label>
              <select
                className="form-select form-select-sm"
                value={filters.department}
                onChange={(e) => setFilters((f) => ({ ...f, department: e.target.value }))}
              >
                <option value="">All</option>
                {departments.map((d) => (
                  <option key={d._id || d.id} value={d._id || d.id}>{d.name}</option>
                ))}
              </select>
            </div>
            <div className="col-12 col-md-4">
              <label className="form-label text-soft small mb-1">Role</label>
              <select
                className="form-select form-select-sm"
                value={filters.role}
                onChange={(e) => setFilters((f) => ({ ...f, role: e.target.value }))}
              >
                <option value="">All</option>
                <option value="Super Admin">Super Admin</option>
                <option value="Super Management">Super Management</option>
                <option value="Management">Management</option>
                <option value="Employee">Employee</option>
              </select>
            </div>
            <div className="col-12 col-md-4">
              <label className="form-label text-soft small mb-1">Status</label>
              <select
                className="form-select form-select-sm"
                value={filters.status}
                onChange={(e) => setFilters((f) => ({ ...f, status: e.target.value }))}
              >
                <option value="">All</option>
                <option value="Active">Active</option>
                <option value="Pending">Pending</option>
                <option value="Rejected">Rejected</option>
                <option value="Banned">Banned</option>
                <option value="Suspended">Suspended</option>
              </select>
            </div>
            <div className="col-12 d-flex gap-2">
              <button
                type="button"
                className="btn btn-outline-soft btn-sm"
                onClick={() => setFilters({ department: '', role: '', status: '' })}
                disabled={!filters.department && !filters.role && !filters.status}
              >
                Clear Filters
              </button>
            </div>
          </div>
        </div>

        <div className="panel mb-4">
          <div className="panel-header">
            <h2 className="m-0 text-heading">User List</h2>
            <div className="d-flex align-items-center gap-2">
              <div style={{ width: 240 }} className="d-none d-sm-block">
                <div className="position-relative">
                  {/* <span className="material-symbols-outlined search-icon">search</span> */}
                  <input
                    type="search"
                    value={search}
                    onChange={onSearchChange}
                    className="form-control form-control-sm search-input"
                    placeholder="Search users..."
                  />
                </div>
              </div>
              <div className="btn-group btn-group-sm" role="group" aria-label="View toggle">
                <button
                  type="button"
                  className={`btn ${view === 'all' ? 'btn-primary-custom' : 'btn-outline-soft'}`}
                  onClick={() => { setView('all'); fetchUsers({ q: search }); }}
                >
                  All Users
                </button>
                <button
                  type="button"
                  className={`btn ${view === 'requests' ? 'btn-primary-custom' : 'btn-outline-soft'}`}
                  onClick={() => { setView('requests'); fetchPending({ q: search }); }}
                >
                  New Requests
                </button>
              </div>
            </div>
          </div>
          <div className="table-responsive">
            <table className="table table-dark-custom table-surface mb-0 w-100">
              <thead>
                {view === 'all' ? (
                  <tr>
                    <th scope="col" className="ps-4">Name</th>
                    <th scope="col">Department</th>
                    <th scope="col">Role</th>
                    <th scope="col">Status</th>
                    <th scope="col" className="text-end pe-4">Actions</th>
                  </tr>
                ) : (
                  <tr>
                    <th scope="col" className="ps-4">Name</th>
                    <th scope="col">Department</th>
                    <th scope="col">Email</th>
                    <th scope="col">Requested On</th>
                    <th scope="col" className="text-end pe-4">Actions</th>
                  </tr>
                )}
              </thead>
              <tbody>
                {loading && (
                  <tr>
                    <td colSpan={5} className="text-center py-4">Loading…</td>
                  </tr>
                )}
                {!loading && error && (
                  <tr>
                    <td colSpan={5} className="text-center py-4 text-danger">{error}</td>
                  </tr>
                )}
                {!loading && !error && displayUsers.length === 0 && (
                  <tr>
                    <td colSpan={5} className="text-center py-4 text-soft">No users found</td>
                  </tr>
                )}
                {!loading && !error && view === 'all'
                  ? displayUsers.map((u) => (
                    <tr key={u._id || u.id}>
                      <td className="ps-4">
                        <div className="d-flex align-items-center gap-2 gap-lg-3">
                          <img
                            src={resolveUserAvatar(u)}
                            alt={fullName(u) || u.email}
                            className="rounded-circle"
                            style={{ width: 40, height: 40, objectFit: 'cover' }}
                          />
                          <div>
                            <Link to={`/admin/users/tasks/${u._id || u.id}`} className="text-decoration-none text-dark">
                              <div className="fw-semibold text-heading">{fullName(u) || u.name || u.email}</div>
                            </Link>
                            <div className="text-soft" style={{ fontSize: '.7rem' }}>{u.email}</div>
                          </div>
                        </div>
                      </td>
                      <td>{deptName(u)}</td>
                      <td>{roleName(u)}</td>
                      <td>
                        <span className={`status-badge ${(statusName(u)) === 'Active' ? 'status-active' : 'status-inactive'}`}>{statusName(u)}</span>
                      </td>
                      <td className="text-end pe-4">
                        {has(PERMISSIONS.USER_READ) && (
                          <Link to={`/admin/users/view/${u._id || u.id}`} className="table-link text-decoration-none edit btn btn-link p-0">View</Link>
                        )}
                        {has(PERMISSIONS.USER_READ) && has(PERMISSIONS.USER_READ) && <span className="text-soft mx-1">|</span>}
                        {has(PERMISSIONS.USER_UPDATE) && (
                          <Link to={`/admin/users/edit/${u._id || u.id}`} className="table-link text-decoration-none edit btn btn-link p-0">Edit</Link>
                        )}
                        {has(PERMISSIONS.USER_UPDATE) && has(PERMISSIONS.USER_DELETE) && <span className="text-soft mx-1">|</span>}
                        {has(PERMISSIONS.USER_DELETE) && (
                          <button type="button" className="table-link text-decoration-none delete btn text-danger btn-link p-0" onClick={() => removeUser(u)}>Delete</button>
                        )}
                      </td>
                    </tr>
                  ))
                  : displayUsers.map((r) => (
                    <tr key={r._id || r.id}>
                      <td className="ps-4">
                        <div className="d-flex align-items-center gap-2 gap-lg-3">
                          <img
                            src={resolveUserAvatar(r)}
                            alt={fullName(r) || r.email}
                            className="rounded-circle"
                            style={{ width: 40, height: 40, objectFit: 'cover' }}
                          />
                          <div>
                            <Link to={`/admin/users/review/${r._id || r.id}`} className="text-decoration-none text-heading">
                              <div className="fw-semibold text-heading">{fullName(r) || r.name || r.email}</div>
                            </Link>
                            <div className="text-soft" style={{ fontSize: '.7rem' }}>{r.email}</div>
                          </div>
                        </div>
                      </td>
                      <td>
                        {deptName(r)}
                      </td>
                      <td>{r.email}</td>
                      <td>{requestedOn(r)}</td>
                      <td className="text-end pe-4">
                        {has(PERMISSIONS.USER_UPDATE) && (
                          <Link className="table-link edit btn btn-link p-0" to={`/admin/users/review/${r._id || r.id}`}>View Request</Link>
                        )}
                        {has(PERMISSIONS.USER_UPDATE) && (
                          <span className="text-soft mx-1">|</span>
                        )}
                        {has(PERMISSIONS.USER_UPDATE) && (
                          <button type="button" className="table-link text-decoration-none edit text-success btn btn-link p-0" onClick={() => approve(r)}>Approve</button>
                        )}
                        {has(PERMISSIONS.USER_UPDATE) && (
                          <span className="text-soft mx-1">|</span>
                        )}
                        {has(PERMISSIONS.USER_UPDATE) && (
                          <button type="button" className="table-link text-decoration-none delete text-danger btn btn-link p-0" onClick={() => reject(r)}>Reject</button>
                        )}
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
