import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api } from '../../api/client';
import { toast } from 'react-toastify';

export default function UserTaskManagement() {
  const { userId } = useParams();
  const [activeTab, setActiveTab] = useState('all'); // all | pendingApproval | longPending

  // Data state
  const [user, setUser] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [refreshing, setRefreshing] = useState(false);

  // Create task form state
  const [form, setForm] = useState({ title: '', description: '', priority: '0', status: 'Pending', endDate: '' });
  const [creating, setCreating] = useState(false);
  const [createError, setCreateError] = useState('');
  const [deletingId, setDeletingId] = useState(null);

  // Edit modal state
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingTask, setEditingTask] = useState(null);
  const [editForm, setEditForm] = useState({ title: '', description: '', priority: '0', status: 'Pending', endDate: '' });
  const [editSaving, setEditSaving] = useState(false);
  const [editError, setEditError] = useState('');

  // Helpers
  const priorityLabel = (p) => {
    const labels = ['Normal','High','Low','Critical','Urgent'];
    if (p === null || p === undefined) return 'Normal';
    if (typeof p === 'number' && !Number.isNaN(p)) return labels[p] || 'Normal';
    if (typeof p === 'string') {
      if (/^\d+$/.test(p)) return labels[Number(p)] || 'Normal';
      const idx = labels.findIndex(l => l.toLowerCase() === p.toLowerCase());
      return idx === -1 ? 'Normal' : labels[idx];
    }
    return 'Normal';
  };
  const priorityBadge = (pRaw) => {
    const p = priorityLabel(pRaw);
    switch (p) {
      case 'High': return 'badge-priority-high';
      case 'Low': return 'badge-priority-low';
      case 'Critical': return 'badge-priority-critical';
      case 'Urgent': return 'badge-priority-urgent';
      default: return 'badge-priority-normal';
    }
  };
  const normalizeStatus = (s) => {
    const map = { 'In Progress': 'Ongoing', 'Pending Approval': 'Pending' };
    const canonical = ['Pending','Ongoing','Hold','Suspended','Completed'];
    if (!s) return 'Pending';
    const mapped = map[s] || s;
    return canonical.includes(mapped) ? mapped : 'Pending';
  };
  const statusBadge = (raw) => {
    const s = normalizeStatus(raw);
    const map = {
      Completed: 'badge-status-completed',
      Ongoing: 'badge-status-inprogress',
      Hold: 'badge-status-hold',
      Suspended: 'badge-status-suspended',
      Pending: 'badge-status-pending'
    };
    return map[s] || 'badge-status-pending';
  };
  const getTaskId = (t) => (t?._id || t?.id || t?.taskId || null);
  const fmtDate = (d) => { if (!d) return '-'; try { return new Date(d).toISOString().slice(0, 10); } catch { return '-'; } };

  // Fetch logic
  const fetchData = useCallback(async () => {
    if (!userId) return;
    setLoading(true); setError('');
    try {
      const userPromise = api.get(`/users/${userId}`).catch(() => ({ data: null }));
      const taskPromise = api.get('/tasks', { params: { assignedTo: userId, limit: 1000 } });
      const [{ data: uRes }, { data: tRes }] = await Promise.all([userPromise, taskPromise]);
      const u = uRes?.data || uRes || null;
      setUser(u);
      const list = Array.isArray(tRes?.data) ? tRes.data : Array.isArray(tRes) ? tRes : (tRes?.items || []);
      setTasks(list);
    } catch (e) {
      const msg = e?.response?.data?.message || e.message || 'Failed to load user tasks';
      setError(msg);
      toast.error(msg);
    } finally { setLoading(false); }
  }, [userId]);

  useEffect(() => { fetchData(); }, [fetchData]);
  const onRefresh = async () => { setRefreshing(true); await fetchData(); setRefreshing(false); };

  // Derived lists
  const isLongPending = (t) => {
    if (t.status !== 'Pending') return false;
    const end = new Date(t.dateExpectedEnd || t.dueDate || t.endDate);
    const now = new Date();
    if (!end || isNaN(end)) return false;
    const diffDays = Math.floor((now - end) / 86400000);
    return diffDays > 7;
  };
  const filteredTasks = useMemo(() => {
    if (activeTab === 'pendingApproval') return tasks.filter(t => normalizeStatus(t.status) === 'Pending');
    if (activeTab === 'longPending') return tasks.filter(t => isLongPending(t));
    return tasks;
  }, [activeTab, tasks]);

  // Pending approval list subset
  const pendingApprovalTasks = useMemo(() => tasks.filter(t => normalizeStatus(t.status) === 'Pending'), [tasks]);

  // Create
  const onFormChange = (e) => { const { name, value } = e.target; setForm(f => ({ ...f, [name]: value })); };
  const onCreateTask = async (e) => {
    e.preventDefault(); if (!userId) return;
    setCreating(true); setCreateError('');
    try {
      const pr = Number(form.priority);
      const payload = {
        title: form.title?.trim(),
        description: form.description?.trim() || '',
        priority: Number.isFinite(pr) ? pr : 0,
        status: form.status,
        dueDate: form.endDate || null,
        assignedTo: userId,
      };
      await api.post('/tasks', payload);
      setForm({ title: '', description: '', priority: '0', status: 'Pending', endDate: '' });
      await fetchData();
      toast.success('Task created');
    } catch (err) {
      const msg = err?.response?.data?.message || err.message || 'Failed to create task';
      setCreateError(msg);
      toast.error(msg);
    } finally { setCreating(false); }
  };

  // Delete
  const onDelete = async (task) => {
    const id = getTaskId(task); if (!id) return;
    if (!window.confirm('Delete this task?')) return;
    try {
      setDeletingId(id);
      await api.delete(`/tasks/${id}`);
      await fetchData();
      toast.success('Task deleted');
    } catch (err) { toast.error(err?.response?.data?.message || 'Failed to delete task'); }
    finally { setDeletingId(null); }
  };

  // Edit
  const onEditFormChange = (e) => { const { name, value } = e.target; setEditForm(f => ({ ...f, [name]: value })); };
  const onUpdateTask = async (e) => {
    e.preventDefault(); if (!editingTask) return; const id = getTaskId(editingTask); if (!id) return;
    setEditSaving(true); setEditError('');
    try {
      const pr = Number(editForm.priority);
      const payload = {
        title: editForm.title?.trim(),
        description: editForm.description?.trim() || '',
        priority: Number.isFinite(pr) ? pr : 0,
        status: editForm.status,
        dueDate: editForm.endDate || null,
        assignedTo: userId,
      };
      await api.patch(`/tasks/${id}`, payload);
      setShowEditModal(false); setEditingTask(null);
      await fetchData();
      toast.success('Task updated');
    } catch (err) { const msg = err?.response?.data?.message || err.message || 'Failed to update task'; setEditError(msg); toast.error(msg); }
    finally { setEditSaving(false); }
  };

  // Approve all pending approval tasks -> set status to 'In Progress'
  const [approvingAll, setApprovingAll] = useState(false);
  const onApproveAll = async () => {
    if (!pendingApprovalTasks.length) return;
    if (!window.confirm(`Approve ${pendingApprovalTasks.length} tasks?`)) return;
    setApprovingAll(true);
    try {
      await Promise.all(pendingApprovalTasks.map(t => api.patch(`/tasks/${getTaskId(t)}`, { status: 'Completed' })));
      await fetchData();
      toast.success('All pending tasks approved');
    } catch (e) { toast.error(e?.response?.data?.message || 'Failed to approve all'); }
    finally { setApprovingAll(false); }
  };

  const rows = filteredTasks;

  return (
    <>
      <div className="p-4 p-lg-5 overflow-auto">
        <div className="mx-auto" style={{ maxWidth: 1200 }}>
          <div className="mb-4 d-flex align-items-center justify-content-between">
            <div>
              <h1 className="fs-2 fw-bold text-heading mb-1">User Specific Task Management</h1>
              <p className="text-soft mb-0">
                {user ? (
                  <>
                    Manage tasks for{' '}
                    <Link to={`/admin/users/view/${user._id}`} className="text-decoration-none">
                    <span className='fw-bold' style={{ color: 'var(--primary-color)' }}>
                      {user.name || user.fullName || user.companyOfficialEmail || user.email || user._id}
                    </span>
                    </Link>
                  </>
                ) : loading ? (
                  'Loading user…'
                ) : (
                  'User not found'
                )}
              </p>
            </div>
            <div className="d-flex gap-2">
              <button className="btn btn-custom d-flex align-items-center gap-1" onClick={onRefresh} disabled={refreshing || loading}><span className="material-symbols-outlined" style={{ fontSize: 18 }}>refresh</span>{refreshing ? 'Refreshing' : 'Refresh'}</button>
            </div>
          </div>

          <div className="d-flex flex-column gap-5">
            {/* Pending Approval */}
            <section>
              <div className="mb-3 d-flex align-items-center justify-content-between">
                <h2 className="fs-5 fw-bold text-heading mb-0">Pending Tasks</h2>
                <button className="btn btn-primary d-flex align-items-center gap-2 px-3 py-2 fw-bold" onClick={onApproveAll} disabled={approvingAll || !pendingApprovalTasks.length}>
                  <span className="material-symbols-outlined">done_all</span> {approvingAll ? 'Approving…' : 'Approve All'}
                </button>
              </div>
              <div className="table-responsive rounded bg-card p-2">
                <table className="table table-dark-custom align-middle mb-0 w-100">
                  <thead>
                    <tr>
                      <th className="text-heading">Task Title</th>
                      <th className="text-heading">Description</th>
                      <th className="text-heading">Priority</th>
                      <th className="text-heading">End Date</th>
                      <th className="text-heading text-end">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {loading && <tr><td colSpan={5} className="text-center text-soft py-3">Loading…</td></tr>}
                    {!loading && pendingApprovalTasks.length === 0 && <tr><td colSpan={5} className="text-center text-soft py-3">No pending tasks.</td></tr>}
                    {!loading && pendingApprovalTasks.map(t => (
                      <tr key={getTaskId(t)}>
                        <td>{t.title}</td>
                        <td className="text-soft" style={{ maxWidth: 260, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{t.description || '-'}</td>
                        <td><span className={priorityBadge(t.priority)}>{priorityLabel(t.priority)}</span></td>
                        <td className="text-soft">{fmtDate(t.dueDate || t.dateExpectedEnd)}</td>
                        <td className="text-end">
                          <button className="btn-action p-0" style={{ color: 'var(--primary-color)' }} onClick={async () => { try { await api.patch(`/tasks/${getTaskId(t)}`, { status: 'Completed' }); await fetchData(); toast.success('Task approved'); } catch (e) { toast.error(e?.response?.data?.message || 'Failed to approve'); } }}>Approve</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>

            {/* Task Listings */}
            <section>
              <div className="mb-3 d-flex align-items-center justify-content-between">
                <h2 className="fs-5 fw-bold text-heading mb-0">Task Listings</h2>
                <div className="d-flex align-items-center gap-2">
                  <div className="btn-group ms-3" role="tablist">
                    <button type="button" className={`btn btn-custom px-3 py-1 ${activeTab === 'all' ? 'active' : ''}`} onClick={() => setActiveTab('all')}>All</button>
                    <button type="button" className={`btn btn-custom px-3 py-1 ${activeTab === 'pendingApproval' ? 'active' : ''}`} onClick={() => setActiveTab('pendingApproval')}>Pending</button>
                    <button type="button" className={`btn btn-custom px-3 py-1 ${activeTab === 'longPending' ? 'active' : ''}`} onClick={() => setActiveTab('longPending')}>Long Pending</button>
                  </div>
                </div>
              </div>
              {error && <div className="mb-3 text-red-custom fw-medium">{error}</div>}
              <div className="table-responsive rounded bg-card p-2">
                <table className="table table-dark-custom align-middle mb-0 w-100">
                  <thead>
                    <tr>
                      <th className="text-heading">Task Title</th>
                      <th className="text-heading">Priority</th>
                      <th className="text-heading">Status</th>
                      <th className="text-heading">Approval</th>
                      <th className="text-heading">Created At</th>
                      <th className="text-heading">Expected Close</th>
                      <th className="text-heading">End Date</th>
                      <th className="text-heading">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {loading && <tr><td colSpan={5} className="text-center text-soft py-4">Loading…</td></tr>}
                    {!loading && rows.map(t => (
                      <tr key={getTaskId(t)}>
                        <td><Link to={`/tasks/${getTaskId(t)}`} className="text-decoration-none text-heading">{t.title}</Link>
                        {t.assignedType == 'Department' ? t.assignedDepartment ? 
                            <>
                            <span className="badge bg-secondary" style={{ fontSize: '.6rem', verticalAlign: 'middle', color: 'var(--color-bg-body)' }}>
                              (To Dept: {t.assignedDepartment.name || 'N/A'})
                            </span>
                            </>
                             : '(Dept: N/A)' : ''}
                        </td>
                        <td><span className={priorityBadge(t.priority)}>{priorityLabel(t.priority)}</span></td>
                        <td>
                          { t.additionalTask == true || t.rawStatus == 'Approved' ? <span className={statusBadge(t.status)}>{normalizeStatus(t.status)}</span> : '-' }
                          { t.status != 'Completed' && (new Date(t.dateStart).setHours(0, 0, 0, 0) < new Date().setHours(0, 0, 0, 0)) ?
                            <><br />
                              <span className="text-secondary mx-auto" style={{ fontSize: '.7rem' }}>Carry Over of {fmtDate(t.dateStart)}</span>
                            </>
                          : null
                          }

                          { t.status != 'Completed' && t.dateExpectedEnd || t.dueDate ?
                            <>
                            <br />
                              { (new Date(t.dateExpectedEnd || t.dueDate).getTime() < Date.now()) ? <span className="text-danger mx-auto">Overdue</span> : <span className="text-warning mx-auto">Due Soon</span> }
                            </>
                          : null }
                        </td>
                        <td>
                          {
                            t.additionalTask == true ?
                            <>
                            <span className="badge bg-info" style={{ fontSize: '.6rem', verticalAlign: 'middle', color: 'var(--color-bg-body)' }}>
                              (Additional Task)
                            </span>
                            </>
                            : t.rawStatus != 'Approved' ? 
                            <><span className="badge bg-warning" style={{ fontSize: '.6rem', verticalAlign: 'middle', color: 'var(--color-bg-body)' }}>
                              (Pending Approval)
                            </span></>
                            : null
                          }
                        </td>
                        <td className="text-soft">{fmtDate(t.dateStart)}</td>
                        <td className="text-soft">{fmtDate(t.dateExpectedEnd)}</td>
                        <td className="text-soft">{fmtDate(t.dateClose)}</td>
                        <td>
                          <Link to={`/tasks/${getTaskId(t)}`} className="btn-action p-0" title="View"><span className="material-symbols-outlined">visibility</span></Link>
                          <button className="btn-action p-0 ms-2" title="Edit" onClick={() => {
                            setEditingTask(t);
                            const p = t.priority; const pVal = (typeof p === 'number' && !Number.isNaN(p)) ? String(p) : (['0','1','2','3','4'].includes(p) ? p : (p === 'High' ? '1' : p === 'Low' ? '2' : p === 'Critical' ? '3' : p === 'Urgent' ? '4' : '0'));
                            setEditForm({ title: t.title || '', description: t.description || '', priority: pVal, status: normalizeStatus(t.status) || 'Pending', endDate: fmtDate(t.dueDate || t.dateExpectedEnd) });
                            setEditError(''); setShowEditModal(true);
                          }}><span className="material-symbols-outlined">edit</span></button>
                          <button className="btn-action p-0 ms-2" disabled={deletingId === getTaskId(t)} onClick={() => onDelete(t)} title={deletingId === getTaskId(t) ? 'Deleting…' : 'Delete'}>
                            <span className="material-symbols-outlined">{deletingId === getTaskId(t) ? 'hourglass_empty' : 'delete'}</span>
                          </button>
                        </td>
                      </tr>
                    ))}
                    {!loading && rows.length === 0 && <tr><td colSpan={8} className="text-center text-soft py-4">No tasks to display.</td></tr>}
                  </tbody>
                </table>
              </div>
            </section>

            {/* Task Creation */}
            <section>
              <h2 className="fs-5 fw-bold text-heading mb-3">Task Creation</h2>
              <div className="bg-card p-4 rounded">
                {createError && <div className="mb-3 text-red-custom fw-medium">{createError}</div>}
                <form className="row g-3" onSubmit={onCreateTask}>
                  <div className="col-12">
                    <label className="form-label" htmlFor="title">Title</label>
                    <input className="form-control" id="title" name="title" type="text" placeholder="Enter task title" value={form.title} onChange={onFormChange} required />
                  </div>
                  <div className="col-12">
                    <label className="form-label" htmlFor="description">Description (optional)</label>
                    <textarea className="form-control input-custom" id="description" name="description" rows={3} placeholder="Enter task description" value={form.description} onChange={onFormChange}></textarea>
                  </div>
                  <div className="col-md-6">
                    <label className="form-label" htmlFor="priority">Priority</label>
                    <select className="form-select" id="priority" name="priority" value={form.priority} onChange={onFormChange}>
                      <option value="0">Normal</option>
                      <option value="1">High</option>
                      <option value="2">Low</option>
                      <option value="3">Critical</option>
                      <option value="4">Urgent</option>
                    </select>
                  </div>
                  <div className="col-md-6">
                    <label className="form-label" htmlFor="status">Status</label>
                    <select className="form-select" id="status" name="status" value={form.status} onChange={onFormChange}>
                      <option>Pending</option>
                      <option>Ongoing</option>
                      <option>Hold</option>
                      <option>Suspended</option>
                      <option>Completed</option>
                    </select>
                  </div>
                  <div className="col-md-6">
                    <label className="form-label" htmlFor="end-date">End Date (optional)</label>
                    <input className="form-control" id="end-date" name="endDate" type="date" value={form.endDate} onChange={onFormChange} />
                  </div>
                  <div className="col-12 d-flex justify-content-end">
                    <button className="btn btn-primary d-flex align-items-center gap-2 px-4 py-2 fw-bold" type="submit" disabled={creating}>
                      <span className="material-symbols-outlined">add</span>{creating ? 'Creating…' : 'Create Task'}
                    </button>
                  </div>
                </form>
              </div>
            </section>
          </div>
        </div>
      </div>
      {showEditModal && (
        <div className="position-fixed top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center" style={{ zIndex: 1050 }}>
          <div className="position-absolute top-0 start-0 w-100 h-100" style={{ background: 'rgba(0,0,0,0.5)' }} onClick={() => { if (!editSaving) { setShowEditModal(false); setEditingTask(null); } }} />
          <div className="bg-card rounded shadow p-4 position-relative" style={{ width: '90%', maxWidth: 560 }} role="dialog" aria-modal="true" aria-labelledby="editTaskTitle">
            <div className="d-flex align-items-center justify-content-between mb-3">
              <h2 id="editTaskTitle" className="fs-5 fw-bold mb-0 text-heading">Edit Task</h2>
              <button className="btn btn-action" type="button" onClick={() => { if (!editSaving) { setShowEditModal(false); setEditingTask(null); } }} aria-label="Close"><span className="material-symbols-outlined">close</span></button>
            </div>
            {editError && <div className="mb-3 text-red-custom fw-medium">{editError}</div>}
            <form className="row g-3" onSubmit={onUpdateTask}>
              <div className="col-12">
                <label className="form-label" htmlFor="edit-title">Title</label>
                <input className="form-control" id="edit-title" name="title" type="text" value={editForm.title} onChange={onEditFormChange} required />
              </div>
              <div className="col-12">
                <label className="form-label" htmlFor="edit-description">Description</label>
                <textarea className="form-control input-custom" id="edit-description" name="description" rows={3} value={editForm.description} onChange={onEditFormChange}></textarea>
              </div>
              <div className="col-md-6">
                <label className="form-label" htmlFor="edit-priority">Priority</label>
                <select className="form-select" id="edit-priority" name="priority" value={editForm.priority} onChange={onEditFormChange}>
                  <option value="0">Normal</option>
                  <option value="1">High</option>
                  <option value="2">Low</option>
                  <option value="3">Critical</option>
                  <option value="4">Urgent</option>
                </select>
              </div>
              <div className="col-md-6">
                <label className="form-label" htmlFor="edit-status">Status</label>
                <select className="form-select" id="edit-status" name="status" value={editForm.status} onChange={onEditFormChange}>
                  <option>Pending</option>
                  <option>Ongoing</option>
                  <option>Hold</option>
                  <option>Suspended</option>
                  <option>Completed</option>
                </select>
              </div>
              <div className="col-md-6">
                <label className="form-label" htmlFor="edit-end-date">End Date</label>
                <input className="form-control" id="edit-end-date" name="endDate" type="date" value={editForm.endDate} onChange={onEditFormChange} />
              </div>
              <div className="col-12 d-flex justify-content-end gap-2 pt-2">
                <button type="button" className="btn btn-secondary-custom px-4" disabled={editSaving} onClick={() => { setShowEditModal(false); setEditingTask(null); }}>Cancel</button>
                <button type="submit" className="btn btn-primary-custom px-4 d-flex align-items-center gap-2" disabled={editSaving}><span className="material-symbols-outlined">save</span><span>{editSaving ? 'Saving…' : 'Save Changes'}</span></button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
