import React, { useEffect, useMemo, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { api } from '../../api/client';
import { fetchAdminAttendanceDay } from '../../api/attendance';

function formatHMS(totalSeconds) {
	// Human-readable duration like "1d 2h 3m 4s"
	if (totalSeconds == null) return '-';
	const sec = Math.max(0, Math.floor(totalSeconds));
	const d = Math.floor(sec / 86400);
	const h = Math.floor((sec % 86400) / 3600);
	const m = Math.floor((sec % 3600) / 60);
	const s = sec % 60;
	const parts = [];
	if (d) parts.push(`${d}d`);
	if (h) parts.push(`${h}h`);
	if (m) parts.push(`${m}m`);
	if (s || parts.length === 0) parts.push(`${s}s`);
	return parts.join(' ');
}

function diffSeconds(a, b) {
	if (!a || !b) return null;
	try { return Math.max(0, Math.floor((new Date(b) - new Date(a)) / 1000)); } catch { return null; }
}

function formatDT(input) {
	// Human-readable local date-time like "Oct 24, 2025, 10:15:30 AM"
	if (!input) return '...';
	try {
		const d = new Date(input);
		if (isNaN(d.getTime())) return '...';
		return d.toLocaleString(undefined, {
			year: 'numeric',
			month: 'short',
			day: '2-digit',
			hour: '2-digit',
			minute: '2-digit',
			second: '2-digit',
			hour12: true
		});
	} catch {
		return '...';
	}
}

const Dot = () => <span className="mx-1" style={{opacity:.6}}>•</span>;

export default function AdminAttendancePage() {
	const { userId } = useParams();
	const navigate = useNavigate();
	const [user, setUser] = useState(null);
	const [date, setDate] = useState(() => new Date().toISOString().slice(0,10));
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState('');
	const [data, setData] = useState(null);
	const [users, setUsers] = useState([]);
	const [usersLoading, setUsersLoading] = useState(false);
	const [selectedUserId, setSelectedUserId] = useState(userId || '');

	useEffect(() => {
		let mounted = true;
		async function load() {
			if (!userId) return;
			setLoading(true); setError('');
			try {
				const [uRes, att] = await Promise.all([
					api.get(`/users/${userId}`),
					fetchAdminAttendanceDay({ userId, date })
				]);
				const u = uRes?.data?.user || uRes?.data || null;
				if (mounted) { setUser(u); setData(att); }
			} catch (e) {
				if (mounted) setError(e?.response?.data?.message || e.message || 'Failed to load attendance');
			} finally { if (mounted) setLoading(false); }
		}
		load();
		return () => { mounted = false; };
	}, [userId, date]);

		const fullName = (u) => `${u.firstName || u.firstname || ''} ${u.lastName || u.lastname || ''}`.trim();

	// Load active users for dropdown
	useEffect(() => {
		let mounted = true;
		async function loadUsers() {
			setUsersLoading(true);
			try {
				const params = { userType: 'Active' };
				const { data } = await api.get('/users', { params });
				const list = Array.isArray(data?.data) ? data.data : Array.isArray(data) ? data : (data?.users || []);
				let mapped = list.map(u => ({ id: u._id || u.id, label: (fullName(u) || u.companyOfficialEmail || u.email || '...'), subtitle: u.companyOfficialEmail || u.email || '' }));
				// ensure current user appears in dropdown even if not in Active filter
				if (user && user._id && !mapped.some(x => x.id === user._id)) {
					mapped = [{ id: user._id, label: (fullName(user) || user.companyOfficialEmail || user.email || '...'), subtitle: user.companyOfficialEmail || user.email || '' }, ...mapped];
				}
				if (mounted) setUsers(mapped);
			} catch (_) {
				if (mounted) setUsers([]);
			} finally {
				if (mounted) setUsersLoading(false);
			}
		}
		loadUsers();
		return () => { mounted = false; };
	}, [user]);

	// keep local selection in sync with route
	useEffect(() => {
		setSelectedUserId(userId || '');
	}, [userId]);

	const totals = useMemo(() => {
		if (!data) return { worked: 0, break: 0, idle: 0 };
		const dayLogin = data.clock_in_at;
		const dayLogout = data.clock_out_at;
		const worked = diffSeconds(dayLogin, dayLogout) || 0;
		const breakTotal = (data.breaks||[]).reduce((acc,b)=> acc + (b.duration_seconds || diffSeconds(b.start, b.end) || 0), 0);
		const idleTotal = (data.idles||[]).reduce((acc,i)=> acc + (i.duration_seconds || diffSeconds(i.start, i.end) || 0), 0);
		return { worked, break: breakTotal, idle: idleTotal };
	}, [data]);

  const trackersTotal = useMemo(() => {
    if (!data?.trackers) return 0;
    return data.trackers.reduce((acc, t) => acc + (t.duration_seconds || 0), 0);
  }, [data]);

	return (
		<div className="px-3 py-4">
			<div className="container-xl">
				<div className="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
					<div>
						<h1 className="mb-1 fs-2 fw-bold text-heading d-flex align-items-center gap-2">
                <span className="material-symbols-outlined">schedule</span>
                <span>Attendance</span>
              </h1>
						<p className="text-soft small mb-0">Daily attendance details for a user: login/logout, breaks, idle, and tracked sessions.</p>
					</div>
					<div className="d-flex align-items-center gap-2">
						{user && <Link to={`/admin/users/view/${user._id}`} className="btn btn-secondary-custom d-flex align-items-center gap-1">
							<span className="material-symbols-outlined">arrow_back</span>
							<span>Back to User</span>
						</Link>}
					</div>
				</div>

				{/* Filters */}
				<div className="card p-3 mb-4">
					<div className="row g-3 align-items-end">
						<div className="col-md-4">
							<label className="form-label small fw-semibold text-soft">Date</label>
							<input type="date" className="form-control input-custom" value={date} onChange={(e)=> setDate(e.target.value)} />
						</div>
											<div className="col-md-8">
												<label className="form-label small fw-semibold text-soft">User</label>
												<select
													className="form-select input-custom"
													value={selectedUserId}
													onChange={(e) => {
														const id = e.target.value;
														setSelectedUserId(id);
														if (id) navigate(`/admin/users/attendance/${id}`);
													}}
												>
													<option value="" disabled>{usersLoading ? 'Loading users…' : 'Select a user'}</option>
													{users.map(u => (
														<option key={u.id} value={u.id}>{u.subtitle ? `${u.label} (${u.subtitle})` : u.label}</option>
													))}
												</select>
											</div>
					</div>
				</div>

				{error && <div className="alert alert-danger py-2 px-3 mb-3">{error}</div>}

				{/* Summary Tiles */}
				<div className="row g-3 mb-4">
					<div className="col-md-3">
						<div className="card p-3 h-100">
                <div className="d-flex align-items-center justify-content-between">
                  <div className="text-soft small d-flex align-items-center gap-1"><span className="material-symbols-outlined" style={{fontSize:18}}>login</span>Login</div>
                </div>
							<div className="fs-6 fw-bold text-heading mt-1">{formatDT(data?.clock_in_at)}</div>
						</div>
					</div>
					<div className="col-md-3">
						<div className="card p-3 h-100">
                <div className="text-soft small d-flex align-items-center gap-1"><span className="material-symbols-outlined" style={{fontSize:18}}>logout</span>Logout</div>
							<div className="fs-6 fw-bold text-heading mt-1">{formatDT(data?.clock_out_at)}</div>
						</div>
					</div>
					<div className="col-md-3">
						<div className="card p-3 h-100">
                <div className="text-soft small d-flex align-items-center gap-1"><span className="material-symbols-outlined" style={{fontSize:18}}>coffee</span>Break Time</div>
							<div className="fs-6 fw-bold text-heading mt-1">{formatHMS(totals.break)}</div>
						</div>
					</div>
					<div className="col-md-3">
						<div className="card p-3 h-100">
                <div className="text-soft small d-flex align-items-center gap-1"><span className="material-symbols-outlined" style={{fontSize:18}}>power_sleep</span>Idle Time</div>
							<div className="fs-6 fw-bold text-heading mt-1">{formatHMS(totals.idle)}</div>
						</div>
					</div>
				</div>

				<div className="row g-4">
					<div className="col-lg-6">
						<div className="card p-3">
							<div className="d-flex align-items-center justify-content-between mb-2">
	                <h3 className="h6 fw-bold text-heading mb-0 d-flex align-items-center gap-1"><span className="material-symbols-outlined" style={{fontSize:18}}>coffee</span>Breaks</h3>
	                <div className="badge bg-secondary-subtle text-soft fw-semibold">{(data?.breaks||[]).length} items <Dot /> total {formatHMS(totals.break)}</div>
	              </div>
							<div className="table-responsive">
								<table className="table table-dark-custom mb-0">
									<thead><tr><th>Start</th><th>End</th><th>Duration</th></tr></thead>
									<tbody>
										{loading && <tr><td colSpan={3} className="text-center text-soft">Loading…</td></tr>}
										{!loading && (data?.breaks||[]).length === 0 && <tr><td colSpan={3} className="text-center text-soft">No breaks</td></tr>}
										{(data?.breaks||[]).map((b, i)=> (
											<tr key={i}><td>{formatDT(b.start)}</td><td>{b.end ? formatDT(b.end) : '...'}</td><td>{formatHMS(b.duration_seconds || diffSeconds(b.start, b.end))}</td></tr>
										))}
									</tbody>
									<tfoot>
	                    <tr>
	                      <td className="text-end" colSpan={2}><strong>Total</strong></td>
	                      <td><strong>{formatHMS(totals.break)}</strong></td>
	                    </tr>
	                  </tfoot>
								</table>
							</div>
						</div>
					</div>
					<div className="col-lg-6">
						<div className="card p-3">
							<div className="d-flex align-items-center justify-content-between mb-2">
	                <h3 className="h6 fw-bold text-heading mb-0 d-flex align-items-center gap-1"><span className="material-symbols-outlined" style={{fontSize:18}}>power_sleep</span>Idle</h3>
	                <div className="badge bg-secondary-subtle text-soft fw-semibold">{(data?.idles||[]).length} items <Dot /> total {formatHMS(totals.idle)}</div>
	              </div>
							<div className="table-responsive">
								<table className="table table-dark-custom mb-0">
									<thead><tr><th>Start</th><th>End</th><th>Duration</th><th>Tracker</th></tr></thead>
									<tbody>
										{loading && <tr><td colSpan={4} className="text-center text-soft">Loading…</td></tr>}
										{!loading && (data?.idles||[]).length === 0 && <tr><td colSpan={4} className="text-center text-soft">No idle intervals</td></tr>}
										{(data?.idles||[]).map((i, idx)=> (
											<tr key={idx}><td>{formatDT(i.start)}</td><td>{i.end ? formatDT(i.end) : '...'}</td><td>{formatHMS(i.duration_seconds || diffSeconds(i.start, i.end))}</td><td>{i.tracker_id || '...'}</td></tr>
										))}
									</tbody>
									<tfoot>
	                    <tr>
	                      <td className="text-end" colSpan={3}><strong>Total</strong></td>
	                      <td><strong>{formatHMS(totals.idle)}</strong></td>
	                    </tr>
	                  </tfoot>
								</table>
							</div>
						</div>
					</div>
				</div>

				<div className="card p-3 mt-4">
					<div className="d-flex align-items-center justify-content-between mb-2">
	          <h3 className="h6 fw-bold text-heading mb-0 d-flex align-items-center gap-1"><span className="material-symbols-outlined" style={{fontSize:18}}>timer</span>Windows Tracker Sessions</h3>
	          <div className="badge bg-secondary-subtle text-soft fw-semibold">{(data?.trackers||[]).length} items <Dot /> total {formatHMS(trackersTotal)}</div>
	        </div>
					<div className="table-responsive">
						<table className="table table-dark-custom mb-0">
							<thead>
								<tr><th>Task</th><th>Started</th><th>Ended</th><th>Duration</th></tr>
							</thead>
							<tbody>
								{loading && <tr><td colSpan={4} className="text-center text-soft">Loading…</td></tr>}
								{!loading && (data?.trackers||[]).length === 0 && <tr><td colSpan={4} className="text-center text-soft">No sessions</td></tr>}
								{(data?.trackers||[]).map((t)=> (
									<tr key={t.id}><td>{t.task_name || '...'}</td><td>{formatDT(t.started_at)}</td><td>{t.ended_at ? formatDT(t.ended_at) : '...'}</td><td>{formatHMS(t.duration_seconds)}</td></tr>
								))}
							</tbody>
							<tfoot>
	              <tr>
	                <td className="text-end" colSpan={3}><strong>Total</strong></td>
	                <td><strong>{formatHMS(trackersTotal)}</strong></td>
	              </tr>
	            </tfoot>
						</table>
					</div>
				</div>

				<div className="card p-3 mt-4">
					<h3 className="h6 fw-bold text-heading mb-3 d-flex align-items-center gap-1"><span className="material-symbols-outlined" style={{fontSize:18}}>task_alt</span>Tasks Covered</h3>
					<div className="d-flex flex-wrap gap-2">
						{(data?.tasks_covered||[]).map((t)=> (
							<span key={t.id} className="badge bg-secondary">{t.name || '...'}</span>
						))}
						{(!data || (data?.tasks_covered||[]).length === 0) && <div className="text-soft small">No tasks</div>}
					</div>
				</div>

			</div>
		</div>
	);
}

