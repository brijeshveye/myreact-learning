import React, { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../../api/client';
import { usePermission } from '../../context/PermissionContext.jsx';
import { PERMISSIONS } from '../../utils/permissions.js';
import { toast } from 'react-toastify';

export default function Departments() {
  const navigate = useNavigate();
  const { has } = usePermission();
  const [items, setItems] = useState([]);
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function fetchDepartments() {
    setLoading(true);
    setError('');
    try {
      const { data } = await api.get('/departments');
      setItems(Array.isArray(data) ? data : []);
    } catch (err) {
      const status = err?.response?.status;
      if (status === 401) {
        navigate('/login');
      } else if (status === 403) {
        setError('You are not authorized to view departments.');
      } else {
        const msg = 'Failed to load departments.';
        setError(msg);
        toast.error(err?.response?.data?.message || msg);
      }
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchDepartments();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return items;
    return items.filter(d =>
      d.name?.toLowerCase().includes(q) ||
      d.description?.toLowerCase().includes(q) ||
      (d.head1 && `${d.head1.firstName || ''} ${d.head1.lastName || ''}`.toLowerCase().includes(q))
    );
  }, [items, query]);

  async function onDelete(id) {
    if (!id) return;
    const confirmed = window.confirm('Delete this department?');
    if (!confirmed) return;
    try {
      await api.delete(`/departments/${id}`);
      await fetchDepartments();
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Delete failed');
    }
  }

  return (
    <div className="px-3 py-4">
      <div className="container-xl">
        <div className="d-flex flex-column flex-sm-row align-items-sm-center justify-content-sm-between gap-3 mb-4">
          <h1 className="mb-0 text-heading fs-2 fw-bold">Department Management</h1>
          {has(PERMISSIONS.DEPARTMENT_CREATE) && (
            <button className="btn btn-primary-custom d-flex align-items-center gap-2 px-4 py-2 fw-medium" onClick={() => navigate('/admin/departments/new')}>
              <span className="material-symbols-outlined">add</span>
              <span>Add New Department</span>
            </button>
          )}
        </div>

        <div className="d-flex flex-column gap-3">
          <div className="position-relative mb-2">
            <span className="material-symbols-outlined position-absolute text-soft" style={{ left: 16, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none' }}>search</span>
            <input className="form-control ps-5 bg-surface border-0 text-heading" placeholder="Search departments..." value={query} onChange={e=>setQuery(e.target.value)} />
          </div>

          <div className="table-responsive rounded border border-surface bg-surface">
            <table className="table table-surface align-middle mb-0">
              <thead>
                <tr>
                  <th scope="col" className="text-uppercase text-heading fw-bold">Department Name</th>
                  <th scope="col" className="text-uppercase text-heading fw-bold">Description</th>
                  <th scope="col" className="text-uppercase text-heading fw-bold">Department Head</th>
                  <th scope="col" className="text-uppercase text-heading fw-bold">Employees</th>
                  <th scope="col" className="text-uppercase text-heading fw-bold text-end">Actions</th>
                </tr>
              </thead>
              <tbody>
                {loading && (
                  <tr><td colSpan={5} className="text-center text-soft py-4">Loading…</td></tr>
                )}
                {!loading && filtered.length === 0 && (
                  <tr><td colSpan={5} className="text-center text-soft py-4">No departments found</td></tr>
                )}
                {!loading && filtered.map((d) => {
                  const id = d._id;
                  const headName = d.head1 ? `${d.head1.firstName || ''} ${d.head1.lastName || ''}`.trim() : '-';
                  return (
                    <tr key={id}>
                      <td className="fw-semibold">
                        <Link to={`/admin/users` + '?department=' + id} className="text-decoration-none text-heading">
                          {d.name}
                        </Link>
                      </td>
                      <td className="text-soft">{d.description || '-'}</td>
                      <td className="text-soft">{headName ? <Link to={`/admin/users/${d.head1._id}`} className="text-decoration-none text-heading">{headName}</Link> : '-'}</td>
                      <td className="text-soft">-</td>
                      <td className="text-end">
                        {has(PERMISSIONS.DEPARTMENT_UPDATE) && (
                          <button className="btn-action me-2" title="Edit" onClick={() => navigate(`/admin/departments/${id}`, { state: { dept: d } })}><span className="material-symbols-outlined fs-5">edit</span></button>
                        )}
                        {has(PERMISSIONS.DEPARTMENT_DELETE) && (
                          <button className="btn-action delete" title="Delete" onClick={() => onDelete(id)}><span className="material-symbols-outlined fs-5">delete</span></button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {error && <div className="alert alert-danger mt-2">{error}</div>}
        </div>
      </div>
    </div>
  );
}
