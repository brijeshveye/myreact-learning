import React, { useCallback, useEffect, useMemo, useState } from 'react';
import ReportTabs from '../../../components/ReportTabs';
import { api } from '../../../api/client';
import { resolveUserAvatar } from '../../../utils/avatars.js';

export default function PerformanceReport() {
    // Filters
    const [departmentId, setDepartmentId] = useState('all');
    const [dateMode, setDateMode] = useState('today'); // today | range | all
    const [start, setStart] = useState(() => new Date(Date.now() - 14*24*60*60*1000).toISOString().slice(0,10));
    const [end, setEnd] = useState(() => new Date().toISOString().slice(0,10));
    const [search, setSearch] = useState('');

    // Data
    const [departments, setDepartments] = useState([]);
    const [users, setUsers] = useState([]);
    const [tasks, setTasks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [refreshing, setRefreshing] = useState(false);

    const buildTaskQuery = () => {
        const params = new URLSearchParams();
        if (dateMode === 'today') {
            const iso = new Date().toISOString().slice(0,10); params.set('dateStart', iso); params.set('dateEnd', iso);
        } else if (dateMode === 'range' && start && end) {
            params.set('dateStart', start); params.set('dateEnd', end);
        }
        if (search.trim()) params.set('q', search.trim());
        params.set('limit','1000');
        return params.toString();
    };

    const fetchData = useCallback(async () => {
        setLoading(true); setError('');
        try {
            const deptPromise = api.get('/departments');
            const userPromise = api.get('/users');
            const taskPromise = api.get(`/tasks?${buildTaskQuery()}`);
            const [{ data: deptRes }, { data: usersRes }, { data: taskRes }] = await Promise.all([deptPromise, userPromise, taskPromise]);
            const deptArray = Array.isArray(deptRes?.data) ? deptRes.data : Array.isArray(deptRes) ? deptRes : [];
            const userArray = Array.isArray(usersRes?.data) ? usersRes.data : Array.isArray(usersRes) ? usersRes : [];
            const taskArray = Array.isArray(taskRes?.data) ? taskRes.data : Array.isArray(taskRes) ? taskRes : [];
            setDepartments(deptArray);
            setUsers(userArray);
            setTasks(taskArray);
        } catch (e) { setError(e?.response?.data?.message || e.message || 'Failed to load performance data'); }
        finally { setLoading(false); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [dateMode, start, end, search]);

    useEffect(() => { fetchData(); }, [fetchData]);

    const onRefresh = async () => { setRefreshing(true); await fetchData(); setRefreshing(false); };

    // Filter users by department if selected
    const filteredUsers = useMemo(() => {
        return users.filter(u => departmentId === 'all' || String(u.department?._id || u.department) === String(departmentId));
    }, [users, departmentId]);

    // Stats per user
    const userStats = useMemo(() => {
        if (!tasks.length) return [];

        // Enforce client-side date filtering to ensure correctness
        let dateFiltered = tasks;
        try {
            if (dateMode === 'today') {
                const todayKey = new Date().toISOString().slice(0, 10);
                dateFiltered = tasks.filter(t => t?.dateStart && new Date(t.dateStart).toISOString().slice(0, 10) === todayKey);
            } else if (dateMode === 'range' && start && end) {
                dateFiltered = tasks.filter(t => {
                    if (!t?.dateStart) return false;
                    const d = new Date(t.dateStart).toISOString().slice(0, 10);
                    return d >= start && d <= end;
                });
            }
        } catch (_) { /* noop */ }

        if (!dateFiltered.length) return [];

        const map = new Map();
        filteredUsers.forEach(u => {
            map.set(String(u._id), { user: u, total: 0, completed: 0, inProgress: 0, pending: 0 });
        });
        dateFiltered.forEach(t => {
            const uid = t.assignedTo?._id || t.assignedTo; if (!uid) return;
            if (!map.has(String(uid))) return; // skip users not in filtered set
            const stat = map.get(String(uid));
            stat.total += 1;
            if (t.status === 'Completed') stat.completed += 1;
            else if (t.status === 'In Progress') stat.inProgress += 1;
            else stat.pending += 1;
        });
        return Array.from(map.values()).sort((a,b)=> (a.user.name||'').localeCompare(b.user.name||''));
    }, [tasks, filteredUsers, dateMode, start, end]);

    // Efficiency trend mock: derive last 5 buckets by dividing completed across 5 segments
    const efficiencyBars = (completed, total) => {
        if (!total) return [0,0,0,0,0];
        const ratio = completed/total; // simple ratio
        const base = Math.round(ratio * 40); // max height 40
        return [base*0.5, base*0.7, base*0.6, base*0.9, base];
    };

    const exportCSV = () => {
        const header = ['User','Department','Total Tasks','Completed','In Progress','Pending','Completion %'];
        const rows = userStats.map(s => [
            JSON.stringify(s.user.name || s.user.fullName || s.user.email || ''),
            JSON.stringify(s.user.department?.name || ''),
            s.total,
            s.completed,
            s.inProgress,
            s.pending,
            ((s.completed / (s.total||1))*100).toFixed(2)+'%'
        ].join(','));
        const csv = [header.join(','), ...rows].join('\n');
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url; a.download = 'performance_report.csv'; a.click();
        URL.revokeObjectURL(url);
    };

    const disableRange = dateMode !== 'range';

    return (
        <div className="px-4 py-4">
            <div className="mx-auto" style={{ maxWidth: 1200 }}>
                <ReportTabs />
                <div className="mb-2 d-flex align-items-center justify-content-between flex-wrap gap-2">
                    <div>
                        <h1 className="fs-2 fw-bold mb-1 text-heading">Performance Report</h1>
                        <p className="text-soft mb-0">Analyze team performance metrics and identify areas for improvement.</p>
                    </div>
                    <button className="btn btn-primary d-flex align-items-center gap-2 px-3 py-1 fw-semibold" onClick={exportCSV} disabled={!userStats.length}>
                        <span className="material-symbols-outlined">download</span>
                        <span>Export</span>
                    </button>
                </div>

                <div className="bg-card rounded p-3 mb-4 shadow">
                    <div className="row g-2 align-items-end">
                        <div className="col-12 col-md-3">
                            <label className="form-label text-soft">Department</label>
                            <select className="form-select" value={departmentId} onChange={e=>setDepartmentId(e.target.value)}>
                                <option value="all">All</option>
                                {departments.map(d => <option key={d._id} value={d._id}>{d.name}</option>)}
                            </select>
                        </div>
                        <div className="col-6 col-md-2">
                            <label className="form-label text-soft">Date Mode</label>
                            <select className="form-select" value={dateMode} onChange={e=>setDateMode(e.target.value)}>
                                <option value="today">Today</option>
                                <option value="range">Range</option>
                                <option value="all">All Time</option>
                            </select>
                        </div>
                        <div className="col-6 col-md-2">
                            <label className="form-label text-soft">Start</label>
                            <input type="date" className="form-control" value={start} onChange={e=>setStart(e.target.value)} disabled={disableRange} />
                        </div>
                        <div className="col-6 col-md-2">
                            <label className="form-label text-soft">End</label>
                            <input type="date" className="form-control" value={end} onChange={e=>setEnd(e.target.value)} disabled={disableRange} />
                        </div>
                        <div className="col-12 col-md-3">
                            <label className="form-label text-soft">Search</label>
                            <input type="text" className="form-control" placeholder="User name/email" value={search} onChange={e=>setSearch(e.target.value)} />
                        </div>
                        <div className="col-12 d-flex justify-content-end">
                            <button className="btn btn-custom d-flex align-items-center gap-2" onClick={onRefresh} disabled={refreshing || loading}>
                                <span className="material-symbols-outlined">refresh</span>
                                <span>{refreshing ? 'Refreshing…' : 'Refresh'}</span>
                            </button>
                        </div>
                    </div>
                </div>

                {error && <div className="alert alert-danger mb-3">{error}</div>}
                {loading && <div className="text-soft mb-3">Loading performance data…</div>}
                {!loading && !error && userStats.length === 0 && <div className="text-soft">No users/tasks match current filters.</div>}

                <div className="table-responsive rounded bg-card p-2">
                    {/* Use theme-aware custom dark/light adaptive table styles */}
                    <table className="table table-dark-custom table-borderless align-middle mb-0">
                        <thead>
                            <tr>
                                <th className="text-heading">Employee</th>
                                <th className="text-heading">Tasks Completed</th>
                                <th className="text-heading">Task Status Distribution</th>
                                <th className="text-heading">Efficiency Trend</th>
                            </tr>
                        </thead>
                        <tbody>
                            {userStats.filter(s => !search.trim() || (s.user.name || s.user.fullName || s.user.email || '').toLowerCase().includes(search.toLowerCase())).map(stat => {
                                const completionPct = stat.total ? (stat.completed / stat.total) * 100 : 0;
                                const bars = efficiencyBars(stat.completed, stat.total);
                                const distCompleted = (completionPct).toFixed(0);
                                const distInProgress = stat.total ? ((stat.inProgress / stat.total)*100).toFixed(0) : 0;
                                const distPending = stat.total ? ((stat.pending / stat.total)*100).toFixed(0) : 0;
                                return (
                                    <tr key={stat.user._id}>
                                        <td>
                                            <div className="d-flex align-items-center gap-2">
                                                <img alt="" className="profile-img" src={resolveUserAvatar(stat.user)} />
                                                <span>{stat.user.name || stat.user.fullName || stat.user.email}</span>
                                            </div>
                                        </td>
                                        <td>
                                            <div className="d-flex align-items-center gap-2">
                                                <div className="progress progress-bg" style={{ width: 100, height: 8 }}>
                                                    <div className="progress-bar progress-bar-custom" style={{ width: `${completionPct.toFixed(0)}%`, height: 8 }} />
                                                </div>
                                                <span className="fw-semibold text-heading">{stat.completed}/{stat.total}</span>
                                            </div>
                                        </td>
                                        <td>
                                            <div className="d-flex align-items-center gap-2">
                                                <div className="d-flex" style={{ width: 100, height: 8, overflow: 'hidden', borderRadius: 4 }}>
                                                    {/* Use status badge palette via CSS vars by reusing existing classes for color context */}
                                                    <div className="badge-status-completed" style={{ width: `${distCompleted}%`, height: 8, padding:0, borderRadius:0 }} />
                                                    <div className="badge-status-inprogress" style={{ width: `${distInProgress}%`, height: 8, padding:0, borderRadius:0 }} />
                                                    <div className="badge-status-pending" style={{ width: `${distPending}%`, height: 8, padding:0, borderRadius:0 }} />
                                                </div>
                                                <span className="text-soft" style={{ fontSize: '0.75rem' }}>({distCompleted}% C, {distInProgress}% IP, {distPending}% P)</span>
                                            </div>
                                        </td>
                                        <td>
                                            <div className="d-flex align-items-end gap-1" style={{ height: 40, width: 120 }}>
                                                {bars.map((h,i)=>(<div key={i} className="efficiency-bar" style={{ width: 16, height: Math.max(4, Math.round(h)) }} />))}
                                            </div>
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}
