import React, { useCallback, useEffect, useMemo, useState } from 'react';
import ReportTabs from '../../../components/ReportTabs';
import { api } from '../../../api/client';
import { Link } from 'react-router-dom';

export default function DetailedTaskReport() {
    // Filters
    const [userId, setUserId] = useState('all');
    const [status, setStatus] = useState('all');
    const [dateMode, setDateMode] = useState('today'); // today | all | range
    const [start, setStart] = useState('');
    const [end, setEnd] = useState('');
    const [search, setSearch] = useState('');

    // Data
    const [users, setUsers] = useState([]);
    const [tasks, setTasks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [refreshing, setRefreshing] = useState(false);

    const buildQuery = () => {
        const params = new URLSearchParams();
        if (userId !== 'all') params.set('assignedTo', userId);
        if (status !== 'all') params.set('status', status);
        if (search.trim()) params.set('q', search.trim());
        if (dateMode === 'today') {
            const iso = new Date().toISOString().slice(0, 10);
            params.set('dateStart', iso); params.set('dateEnd', iso);
        } else if (dateMode === 'range' && start && end) {
            params.set('dateStart', start); params.set('dateEnd', end);
        }
        params.set('limit', '1000'); // large limit for report
        return params.toString();
    };

    const fetchData = useCallback(async () => {
        setLoading(true); setError('');
        try {
            const usersPromise = api.get('/users');
            const taskPromise = api.get(`/tasks?${buildQuery()}`);
            const [{ data: usersRes }, { data: taskRes }] = await Promise.all([usersPromise, taskPromise]);
            const userArray = Array.isArray(usersRes?.data) ? usersRes.data : Array.isArray(usersRes) ? usersRes : [];
            const taskArray = Array.isArray(taskRes?.data) ? taskRes.data : Array.isArray(taskRes) ? taskRes : [];
            setUsers(userArray);
            setTasks(taskArray);
        } catch (e) {
            setError(e?.response?.data?.message || e.message || 'Failed to load report');
        } finally { setLoading(false); }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [userId, status, dateMode, start, end, search]);

    useEffect(() => { fetchData(); }, [fetchData]);

    const onRefresh = async () => { setRefreshing(true); await fetchData(); setRefreshing(false); };

    // Group by date (dateStart) then by assignedTo
    const grouped = useMemo(() => {
        if (!tasks.length) return [];

        // Enforce client-side date filtering to ensure correctness
        let filtered = tasks;
        try {
            if (dateMode === 'today') {
                const todayKey = new Date().toISOString().slice(0, 10);
                filtered = tasks.filter(
                    t => t?.dateStart && new Date(t.dateStart).toISOString().slice(0, 10) === todayKey
                );
            } else if (dateMode === 'range' && start && end) {
                filtered = tasks.filter(t => {
                    if (!t?.dateStart) return false;
                    const d = new Date(t.dateStart).toISOString().slice(0, 10);
                    return d >= start && d <= end;
                });
            }
        } catch (_) { /* noop */ }

        if (!filtered.length) return [];

        const byDate = new Map();
        filtered.forEach(t => {
            const dKey = t.dateStart ? new Date(t.dateStart).toISOString().slice(0, 10) : 'unknown';
            if (!byDate.has(dKey)) byDate.set(dKey, []);
            byDate.get(dKey).push(t);
        });
        // Sort dates desc
        const dateEntries = Array.from(byDate.entries()).sort((a, b) => b[0].localeCompare(a[0]));
        return dateEntries.map(([date, list]) => {
            const byUser = new Map();
            list.forEach(t => {
                const uid = t.assignedTo?._id || t.assignedTo || 'unknown';
                if (!byUser.has(uid)) byUser.set(uid, []);
                byUser.get(uid).push(t);
            });
            const usersGrouped = Array.from(byUser.entries()).map(([uid, tlist]) => {
                const uObj = users.find(u => String(u._id) === String(uid));
                return { user: uObj || { _id: uid, name: 'Unknown' }, tasks: tlist };
            }).sort((a, b) => (a.user.name || '').localeCompare(b.user.name || ''));
            return { date, users: usersGrouped };
        });
    }, [tasks, users, dateMode, start, end]);

    // Theme-aware status badge mapping (avoids raw color classes)
    const statusClass = (s) => {
        switch (s) {
            case 'Completed': return 'badge-status-completed';
            case 'In Progress': return 'badge-status-inprogress';
            case 'Pending Approval': return 'badge-status-review';
            case 'Pending':
            default: return 'badge-status-pending';
        }
    };
    const fmtDateHeading = (d) => {
        try { return new Date(d).toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' }); } catch { return d; }
    };

    const disableRange = dateMode !== 'range';

    return (
        <div className="d-flex justify-content-center py-4 px-3">
            <div className="w-100" style={{ maxWidth: 900 }}>
                <ReportTabs />
                <div className="mb-2 d-flex align-items-center justify-content-between flex-wrap gap-2">
                    <div>
                        <h1 className="fs-1 fw-bold mb-1 text-heading">Reports</h1>
                        <p className="text-soft mb-0">Detailed Task Report</p>
                    </div>
                    <button className="btn btn-custom d-flex align-items-center gap-2" onClick={onRefresh} disabled={refreshing || loading}>
                        <span className="material-symbols-outlined">refresh</span>
                        <span>{refreshing ? 'Refreshing…' : 'Refresh'}</span>
                    </button>
                </div>

                <div className="bg-card rounded p-3 mb-4 shadow">
                    <div className="row g-2 align-items-end">
                        <div className="col-12 col-md-3">
                            <label className="form-label text-soft">User</label>
                            <select className="form-select" value={userId} onChange={e => setUserId(e.target.value)}>
                                <option value="all">All</option>
                                {users.map(u => <option key={u._id} value={u._id}>{u.name || u.fullName || u.email}</option>)}
                            </select>
                        </div>
                        <div className="col-6 col-md-2">
                            <label className="form-label text-soft">Status</label>
                            <select className="form-select" value={status} onChange={e => setStatus(e.target.value)}>
                                <option value="all">All</option>
                                <option value="Pending">Pending</option>
                                <option value="In Progress">In Progress</option>
                                <option value="Completed">Completed</option>
                                <option value="Pending Approval">Pending Approval</option>
                            </select>
                        </div>
                        <div className="col-6 col-md-2">
                            <label className="form-label text-soft">Date Mode</label>
                            <select className="form-select" value={dateMode} onChange={e => setDateMode(e.target.value)}>
                                <option value="today">Today</option>
                                <option value="all">All Time</option>
                                <option value="range">Range</option>
                            </select>
                        </div>
                        <div className="col-6 col-md-2">
                            <label className="form-label text-soft">Start</label>
                            <input type="date" className="form-control" value={start} onChange={e => setStart(e.target.value)} disabled={disableRange} />
                        </div>
                        <div className="col-6 col-md-2">
                            <label className="form-label text-soft">End</label>
                            <input type="date" className="form-control" value={end} onChange={e => setEnd(e.target.value)} disabled={disableRange} />
                        </div>
                        <div className="col-12 col-md-3">
                            <label className="form-label text-soft">Search</label>
                            <input type="text" className="form-control" placeholder="Title / description" value={search} onChange={e => setSearch(e.target.value)} />
                        </div>
                    </div>
                </div>

                {error && <div className="alert alert-danger mb-3">{error}</div>}
                {loading && <div className="text-soft mb-3">Loading tasks…</div>}
                {!loading && !error && grouped.length === 0 && <div className="text-soft">No tasks match current filters.</div>}

                <div className="d-flex flex-column gap-4">
                    {grouped.map(group => (
                        <div key={group.date} className="position-relative">
                            <div className="border-left-custom" />
                            <div className="ps-4">
                                <h3 className="fs-4 fw-bold mb-3 sticky-date text-soft">{fmtDateHeading(group.date)}</h3>
                                <div className="d-flex flex-column gap-3">
                                    {group.users.map(gUser => (
                                        <div key={gUser.user._id}>
                                            <h4 className="fs-5 fw-semibold mb-2 ms-2 text-soft">{gUser.user.name || gUser.user.fullName || gUser.user.email || 'User'}</h4>
                                            <div className="d-flex flex-column gap-2">
                                                {gUser.tasks.map(t => (
                                                    <div className="d-flex gap-3 rounded bg-card p-3 align-items-center" key={t._id}>
                                                        <div className="flex-grow-1">
                                                            <Link to={`/tasks/${t._id || t.id}`} className="text-decoration-none">
                                                                <p className="mb-0 text-heading fw-medium">{t.title}</p>
                                                            </Link>
                                                            <p className="mb-0 text-soft" style={{ fontSize: '0.85rem' }}>
                                                               EC: {(t.dateExpectedEnd || t.dueDate || '-').slice(0, 10)},
                                                               C: {(t.endDate || t.dueDate || '-').slice(0, 10)}
                                                            </p>
                                                        </div>
                                                        <span className={`rounded-pill-custom ${statusClass(t.status)}`}>{t.status}</span>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}
