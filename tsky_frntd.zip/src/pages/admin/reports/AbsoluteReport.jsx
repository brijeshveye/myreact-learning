import React, { useCallback, useEffect, useMemo, useState } from 'react';
import ReportTabs from '../../../components/ReportTabs';
import { api } from '../../../api/client';

export default function AbsoluteReport() {
    // Filters
    const [userId, setUserId] = useState('all');
    const [status, setStatus] = useState('all');
    const [dateMode, setDateMode] = useState('today');
    const [start, setStart] = useState(() => new Date(Date.now()-7*24*60*60*1000).toISOString().slice(0,10));
    const [end, setEnd] = useState(() => new Date().toISOString().slice(0,10));

    // Data
    const [users, setUsers] = useState([]);
    const [tasks, setTasks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [refreshing, setRefreshing] = useState(false);

    const buildQuery = () => {
        const params = new URLSearchParams();
        if (userId !== 'all') params.set('assignedTo', userId);
        if (status !== 'all') params.set('status', status);
        if (dateMode === 'range' && start && end) { params.set('dateStart', start); params.set('dateEnd', end); }
        if (dateMode === 'today') { const iso = new Date().toISOString().slice(0,10); params.set('dateStart', iso); params.set('dateEnd', iso); }
        params.set('limit','1000');
        return params.toString();
    };

    const fetchData = useCallback(async () => {
        setLoading(true); setError('');
        try {
            const usersPromise = api.get('/users');
            const taskPromise = api.get(`/tasks?${buildQuery()}`);
            const [{ data: usersRes }, { data: taskRes }] = await Promise.all([usersPromise, taskPromise]);
            const userArray = Array.isArray(usersRes?.data) ? usersRes.data : Array.isArray(usersRes) ? usersRes : [];
            const taskArray = Array.isArray(taskRes?.data) ? taskRes.data : Array.isArray(taskRes) ? taskRes : [];
            setUsers(userArray); setTasks(taskArray);
        } catch (e) { setError(e?.response?.data?.message || e.message || 'Failed to load report'); }
        finally { setLoading(false); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [userId, status, dateMode, start, end]);

    useEffect(() => { fetchData(); }, [fetchData]);

    const onRefresh = async () => { setRefreshing(true); await fetchData(); setRefreshing(false); };

    const grouped = useMemo(() => {
        if (!tasks.length) return [];

        // Enforce date filters client-side in case backend returns extra data
        let filtered = tasks;
        try {
            if (dateMode === 'today') {
                const todayKey = new Date().toISOString().slice(0, 10);
                filtered = tasks.filter(t => t?.dateStart && new Date(t.dateStart).toISOString().slice(0, 10) === todayKey);
            } else if (dateMode === 'range' && start && end) {
                filtered = tasks.filter(t => {
                    if (!t?.dateStart) return false;
                    const d = new Date(t.dateStart).toISOString().slice(0, 10);
                    return d >= start && d <= end;
                });
            }
        } catch (_) { /* noop */ }

        if (!filtered.length) return [];

        const byDate = new Map();
        filtered.forEach(t => {
            const dKey = t.dateStart ? new Date(t.dateStart).toISOString().slice(0,10) : 'unknown';
            if (!byDate.has(dKey)) byDate.set(dKey, []);
            byDate.get(dKey).push(t);
        });
        return Array.from(byDate.entries()).sort((a,b)=> b[0].localeCompare(a[0])).map(([date,list]) => {
            const userMap = new Map();
            list.forEach(t => {
                const uid = t.assignedTo?._id || t.assignedTo || 'unknown';
                if (!userMap.has(uid)) userMap.set(uid, { tasks: [], counts: { pending:0, progress:0, completed:0 } });
                const entry = userMap.get(uid);
                entry.tasks.push(t);
                if (t.status === 'Completed') entry.counts.completed += 1; else if (t.status === 'In Progress') entry.counts.progress += 1; else entry.counts.pending += 1;
            });
            const usersArr = Array.from(userMap.entries()).map(([uid,val]) => ({ user: users.find(u => String(u._id)===String(uid)) || { _id: uid, name: 'Unknown' }, counts: val.counts, total: val.tasks.length }));
            return { date, users: usersArr.sort((a,b)=> (a.user.name||'').localeCompare(b.user.name||'')) };
        });
    }, [tasks, users, dateMode, start, end]);

    const fmtDate = (d) => { try { return new Date(d).toLocaleDateString(undefined,{year:'numeric',month:'long',day:'numeric'});} catch { return d; } };
    const disableRange = dateMode !== 'range';

    return (
        <div className="px-4 px-sm-5 py-4">
            <div className="mx-auto" style={{ maxWidth: 1200 }}>
                <ReportTabs />
                <div className="mb-2 d-flex align-items-center justify-content-between flex-wrap gap-2">
                    <div>
                        <h1 className="fs-2 fw-bold mb-1 text-heading">Absolute Data</h1>
                        <p className="text-soft mb-0">View all tasks and their statuses over time.</p>
                    </div>
                    <button className="btn btn-custom d-flex align-items-center gap-2" onClick={onRefresh} disabled={refreshing || loading}>
                        <span className="material-symbols-outlined">refresh</span>
                        <span>{refreshing ? 'Refreshing…' : 'Refresh'}</span>
                    </button>
                </div>

                <div className="bg-card rounded p-3 mb-4 shadow">
                    <div className="row g-2 align-items-end">
                        <div className="col-12 col-md-3">
                            <label className="form-label text-soft">User</label>
                            <select className="form-select" value={userId} onChange={e=>setUserId(e.target.value)}>
                                <option value="all">All</option>
                                {users.map(u => <option key={u._id} value={u._id}>{u.name || u.fullName || u.email}</option>)}
                            </select>
                        </div>
                        <div className="col-6 col-md-2">
                            <label className="form-label text-soft">Status</label>
                            <select className="form-select" value={status} onChange={e=>setStatus(e.target.value)}>
                                <option value="all">All</option>
                                <option value="Pending">Pending</option>
                                <option value="In Progress">In Progress</option>
                                <option value="Completed">Completed</option>
                            </select>
                        </div>
                        <div className="col-6 col-md-2">
                            <label className="form-label text-soft">Date Mode</label>
                            <select className="form-select" value={dateMode} onChange={e=>setDateMode(e.target.value)}>
                                <option value="today">Today</option>
                                <option value="range">Range</option>
                                <option value="all">All Time</option>
                            </select>
                        </div>
                        <div className="col-6 col-md-2">
                            <label className="form-label text-soft">Start</label>
                            <input type="date" className="form-control" value={start} onChange={e=>setStart(e.target.value)} disabled={disableRange} />
                        </div>
                        <div className="col-6 col-md-2">
                            <label className="form-label text-soft">End</label>
                            <input type="date" className="form-control" value={end} onChange={e=>setEnd(e.target.value)} disabled={disableRange} />
                        </div>
                    </div>
                </div>

                {error && <div className="alert alert-danger mb-3">{error}</div>}
                {loading && <div className="text-soft mb-3">Loading tasks…</div>}
                {!loading && !error && grouped.length === 0 && <div className="text-soft">No tasks match current filters.</div>}

                {/* Use theme classes instead of hard-coded dark colors */}
                <div className="table-responsive rounded border bg-card">
                    <table className="table table-bordered align-middle mb-0">
                        <thead>
                            <tr>
                                <th style={{width:180}}>Date</th>
                                <th style={{width:220}}>User</th>
                                <th>Tasks</th>
                                <th className="text-center">Pending</th>
                                <th className="text-center">In Progress</th>
                                <th className="text-center">Completed</th>
                            </tr>
                        </thead>
                        <tbody>
                            {grouped.map(group => (
                                <React.Fragment key={group.date}>
                                    <tr className="table-group-row">
                                        <td colSpan={6}>{fmtDate(group.date)}</td>
                                    </tr>
                                    {group.users.map(uRow => (
                                        <tr key={uRow.user._id}>
                                            <td></td>
                                            <td className="fw-semibold">{uRow.user.name || uRow.user.fullName || uRow.user.email || 'User'}</td>
                                            <td className="text-soft">{uRow.total}</td>
                                            <td className="text-center"><span className="rounded-pill-custom badge-status-pending">{uRow.counts.pending || ''}</span></td>
                                            <td className="text-center"><span className="rounded-pill-custom badge-status-inprogress">{uRow.counts.progress || ''}</span></td>
                                            <td className="text-center"><span className="rounded-pill-custom badge-status-completed">{uRow.counts.completed || ''}</span></td>
                                        </tr>
                                    ))}
                                </React.Fragment>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}
