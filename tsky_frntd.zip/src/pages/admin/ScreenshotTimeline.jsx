import React, { useEffect, useMemo, useState } from 'react';
import { useParams, useSearchParams, Link } from 'react-router-dom';
import { api } from '../../api/client';

function todayStr(d = new Date()) { return d.toISOString().slice(0,10); }

export default function ScreenshotTimeline() {
  const { userId } = useParams();
  const [sp, setSp] = useSearchParams();
  const [items, setItems] = useState([]);
  const [taskOptions, setTaskOptions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const from = sp.get('from') || todayStr();
  const to = sp.get('to') || todayStr();
  const startTime = sp.get('start') || '';
  const endTime = sp.get('end') || '';

  useEffect(()=>{
    let cancelled = false;
    async function run() {
      setLoading(true); setError('');
      try {
        const params = { user: userId, from, to, startTime, endTime, limit: 1000 };
        const selectedTasks = sp.getAll('task');
        if (selectedTasks.length > 0) params.task = selectedTasks; // send as array
        const { data } = await api.get('/screenshots/timeline', { params });
        if (!cancelled) {
          setItems(Array.isArray(data?.items) ? data.items : []);
          setTaskOptions(Array.isArray(data?.taskOptions) ? data.taskOptions : []);
        }
      } catch (e) {
        if (!cancelled) setError(e?.response?.data?.message || e.message || 'Failed to load screenshots');
      } finally { if (!cancelled) setLoading(false); }
    }
    if (userId) run();
    return () => { cancelled = true; };
  }, [userId, from, to, startTime, endTime, sp]);

  const groups = useMemo(()=>{
    // First group by date, then by task
    const byDate = new Map();
    for (const it of items) {
      const dateKey = new Date(it.capturedAt).toISOString().slice(0,10);
      if (!byDate.has(dateKey)) byDate.set(dateKey, new Map());
      const byTask = byDate.get(dateKey);
      const taskKey = it.task?.id || 'no-task';
      const taskLabel = it.task?.title || 'Unassigned Task';
      if (!byTask.has(taskKey)) byTask.set(taskKey, { title: taskLabel, shots: [] });
      byTask.get(taskKey).shots.push(it);
    }
    // Sort date asc, and within each date, sort task title asc
    return Array.from(byDate.entries())
      .sort(([a],[b]) => a.localeCompare(b))
      .map(([dateKey, map]) => {
        const taskBlocks = Array.from(map.entries())
          .sort((a, b) => a[1].title.localeCompare(b[1].title))
          .map(([taskId, group]) => ({ taskId, title: group.title, list: group.shots }));
        return { dateKey, taskBlocks };
      });
  }, [items]);

  const updateParam = (k, v) => {
    const next = new URLSearchParams(sp);
    if (v) next.set(k, v); else next.delete(k);
    setSp(next, { replace: true });
  };

  const toggleTaskFilter = (taskId) => {
    const next = new URLSearchParams(sp);
    const all = next.getAll('task');
    if (all.includes(taskId)) {
      // remove
      const filtered = all.filter(id => id !== taskId);
      next.delete('task');
      filtered.forEach(id => next.append('task', id));
    } else {
      next.append('task', taskId);
    }
    setSp(next, { replace: true });
  };

  return (
    <div className="px-3 py-4">
      <div className="container-xl">
        <div className="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
          <div>
            <h1 className="mb-1 fs-3 fw-bold text-heading">Screenshot Timeline</h1>
            <p className="text-soft small mb-0">User: <code>{userId}</code></p>
          </div>
          <div>
            <Link className="btn btn-secondary-custom" to={`/admin/users/view/${userId}`}>Back to User</Link>
          </div>
        </div>

        <div className="card p-3 mb-4">
          <div className="row g-3 align-items-end">
            <div className="col-md-3">
              <label className="form-label small text-soft">From</label>
              <input type="date" className="form-control input-custom" value={from} onChange={(e)=>updateParam('from', e.target.value)} />
            </div>
            <div className="col-md-3">
              <label className="form-label small text-soft">To</label>
              <input type="date" className="form-control input-custom" value={to} onChange={(e)=>updateParam('to', e.target.value)} />
            </div>
            <div className="col-md-2">
              <label className="form-label small text-soft">Start time</label>
              <input type="time" className="form-control input-custom" value={startTime} onChange={(e)=>updateParam('start', e.target.value)} />
            </div>
            <div className="col-md-2">
              <label className="form-label small text-soft">End time</label>
              <input type="time" className="form-control input-custom" value={endTime} onChange={(e)=>updateParam('end', e.target.value)} />
            </div>
            <div className="col-md-2 d-flex gap-2">
              <button className="btn btn-secondary-custom w-100" onClick={()=>{ updateParam('from', todayStr()); updateParam('to', todayStr()); updateParam('start',''); updateParam('end',''); }}>Today</button>
            </div>
          </div>
          {/* Task filters */}
          {taskOptions.length > 0 && (
            <div className="mt-3">
              <div className="small text-soft mb-2">Filter by task</div>
              <div className="d-flex flex-wrap gap-2">
                {taskOptions.map(t => {
                  const active = sp.getAll('task').includes(String(t.id));
                  return (
                    <button
                      key={t.id}
                      type="button"
                      className={`btn btn-sm ${active ? 'btn-primary-custom' : 'btn-secondary-custom'}`}
                      onClick={()=>toggleTaskFilter(String(t.id))}
                      title={`${t.title} (${t.count})`}
                    >
                      <span className="text-truncate" style={{maxWidth:200}}>{t.title}</span>
                      <span className="ms-1 badge bg-dark-subtle text-soft">{t.count}</span>
                    </button>
                  );
                })}
                {sp.getAll('task').length > 0 && (
                  <button type="button" className="btn btn-sm btn-outline-warning" onClick={()=>{ const next = new URLSearchParams(sp); next.delete('task'); setSp(next, { replace: true }); }}>Clear tasks</button>
                )}
              </div>
            </div>
          )}
        </div>

        {error && <div className="alert alert-danger py-2 px-3 mb-4">{error}</div>}
        {loading && <div className="text-soft small">Loading screenshots…</div>}

        {!loading && groups.length === 0 && <div className="text-soft small">No screenshots found for the selected filters.</div>}

        {groups.map(({ dateKey, taskBlocks }) => (
          <div key={dateKey} className="mb-4">
            <h3 className="h6 fw-bold mb-3 text-heading">{dateKey}</h3>
            {taskBlocks.map(block => (
              <div key={block.taskId} className="mb-3">
                <div className="d-flex align-items-center justify-content-between mb-2">
                  <div className="d-flex align-items-center gap-2">
                    <span className="material-symbols-outlined">task</span>
                    <h4 className="h6 mb-0 text-heading">{block.title}</h4>
                    <span className="badge bg-dark-subtle text-soft">{block.list.length}</span>
                  </div>
                </div>
                <div className="row g-2">
                  {block.list.map(it => (
                    <div className="col-6 col-md-3 col-lg-2" key={it.id}>
                      <div className="card p-1 h-100">
                        <a href={it.url} target="_blank" rel="noreferrer" title={`${new Date(it.capturedAt).toLocaleString()} — ${it.task?.title || ''}`}>
                          <img src={it.url} alt="screenshot" className="w-100" style={{aspectRatio:'4/3', objectFit:'cover', borderRadius:6}} />
                        </a>
                        <div className="small text-soft px-1 py-1">
                          <div className="d-flex flex-column">
                            <span>{new Date(it.capturedAt).toLocaleTimeString()}</span>
                            {it.task?.title && <span className="text-truncate" title={it.task.title}>{it.task.title}</span>}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
