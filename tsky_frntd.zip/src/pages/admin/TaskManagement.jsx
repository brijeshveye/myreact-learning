import React, { useCallback, useEffect, useMemo, useState } from 'react';
import Select from 'react-select';
import { api } from '../../api/client';
import { Link, useNavigate } from 'react-router-dom';
import { usePermission } from '../../context/PermissionContext.jsx';
import { PERMISSIONS } from '../../utils/permissions.js';
import { toast } from 'react-toastify';
import { sendDirectNotification } from '../../api/notifications.js';

export default function TaskManagement() {
  const navigate = useNavigate();
  const { has, any } = usePermission();
  const [tasks, setTasks] = useState([]);
  const [users, setUsers] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [filterToday, setFilterToday] = useState(true); // default today active per requirement
  const [filterDate, setFilterDate] = useState('');
  const [filterUser, setFilterUser] = useState('');
  const [creating, setCreating] = useState(false);
  const [createError, setCreateError] = useState('');
  const [form, setForm] = useState({
    title: '',
    description: '',
    priority: 'Normal',
    status: 'Pending',
    endDate: '',
    assignee: '',
    department: '',
  });
  const [assignMode, setAssignMode] = useState('user'); // 'user' | 'department'
  const [approving, setApproving] = useState(false);
  const [actioningId, setActioningId] = useState(null); // track row being acted on
  // Pending section tab state: 'pending' | 'rejected'
  const [pendingTab, setPendingTab] = useState('pending');
  // Pending section date filter: 'all' | 'today' | 'older'
  const [pendingDateFilter, setPendingDateFilter] = useState('today');
  // Edit/Delete modal states
  const [editingTask, setEditingTask] = useState(null);
  const [editForm, setEditForm] = useState({ title: '', description: '', priority: 'Normal', status: 'Pending', endDate: '', assignee: '', department: '' });
  const [editAssignMode, setEditAssignMode] = useState('user');
  const [updating, setUpdating] = useState(false);
  const [editError, setEditError] = useState('');
  const [deletingTask, setDeletingTask] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  // Notify state for "not submitted" section
  const [notifyingAll, setNotifyingAll] = useState(false);
  const [notifyingUserId, setNotifyingUserId] = useState(null);

  const selectStyles = {
    control: (base, state) => ({
      ...base,
      background: 'var(--color-bg-surface-5)',
      borderColor: state.isFocused ? 'var(--primary-color)' : 'var(--color-bg-surface-5)',
      boxShadow: state.isFocused ? '0 0 0 .2rem rgba(17,115,212,.25)' : 'none',
      minHeight: 48,
      color: 'var(--color-text)'
    }),
    singleValue: (base) => ({ ...base, color: 'var(--color-text)' }),
    input: (base) => ({ ...base, color: 'var(--color-text)' }),
    menu: (base) => ({ ...base, background: 'var(--color-bg-surface-4)', border: '1px solid var(--color-border-alt)', zIndex: 20 }),
    option: (base, state) => ({
      ...base,
      background: state.isFocused ? 'var(--color-bg-surface-3)' : 'transparent',
      color: 'var(--color-text)',
      cursor: 'pointer'
    }),
    placeholder: (base) => ({ ...base, color: 'var(--color-text-soft)' }),
    dropdownIndicator: (base) => ({
      ...base,
      color: 'var(--color-text-soft)',
      ':hover': { color: 'var(--color-text)' }
    }),
    indicatorSeparator: (base) => ({ ...base, background: 'var(--color-border-alt)' }),
    menuPortal: base => ({ ...base, zIndex: 9999 })
  };

  // Compact select styles for filter chips to match native controls
  const filterSelectStyles = {
    ...selectStyles,
    control: (base, state) => ({
      ...base,
      background: 'transparent',
      border: 'none',
      boxShadow: 'none',
      minHeight: 26,
      height: 26,
      fontSize: '.8rem',
    }),
    valueContainer: (base) => ({
      ...base,
      padding: '0 6px',
    }),
    dropdownIndicator: (base) => ({
      ...base,
      padding: 2,
    }),
    clearIndicator: (base) => ({
      ...base,
      padding: 2,
    }),
    indicatorsContainer: (base) => ({
      ...base,
      paddingRight: 2,
    }),
    input: (base) => ({
      ...base,
      color: 'var(--color-text)',
      margin: 0,
      padding: 0,
    }),
    singleValue: (base) => ({
      ...base,
      color: 'var(--color-text)',
      fontSize: '.75rem',
    }),
    placeholder: (base) => ({
      ...base,
      color: 'var(--color-text-soft)',
      fontSize: '.75rem',
    }),
    option: (base, state) => ({
      ...selectStyles.option(base, state),
      padding: 6,
      fontSize: '.85rem',
    }),
    indicatorSeparator: () => ({ display: 'none' }),
  };

  // Priority mapping helpers (backend expects numeric priority)
  const priorityLabels = ['Normal', 'High', 'Low', 'Critical', 'Urgent'];
  const numberToPriorityLabel = (n) => priorityLabels[n] || 'Normal';
  const labelToPriorityNumber = (label) => {
    if (typeof label === 'number') return label; // already numeric
    const idx = priorityLabels.indexOf(label);
    return idx === -1 ? 0 : idx;
  };

  const getPriorityLabel = (p) => {
    if (p === null || p === undefined) return 'Normal';
    const labels = ['Normal','High','Low','Critical','Urgent'];
    if (typeof p === 'number' && !Number.isNaN(p)) return labels[p] || 'Normal';
    if (typeof p === 'string') {
      if (/^\d+$/.test(p)) return labels[Number(p)] || 'Normal';
      const idx = labels.findIndex(l => l.toLowerCase() === p.toLowerCase());
      return idx === -1 ? 'Normal' : labels[idx];
    }
    return 'Normal';
  };

  const priorityBadge = (p) => p === 'High' ? 'badge-priority-high' : p === 'Low' ? 'badge-priority-low' : 'badge-priority-normal';
  const statusBadge = (s) => {
    const map = {
      Completed: 'badge-status-completed',
      Ongoing: 'badge-status-inprogress',
      Hold: 'badge-status-hold',
      Suspended: 'badge-status-suspended',
      Pending: 'badge-status-pending'
    }; return map[s] || 'badge-status-pending';
  };

  const fetchTasks = useCallback(async () => {
    setLoading(true); setError('');
    try {
      // Explicit admin-wide endpoint
      const { data } = await api.get('/tasks/all', { params: { limit: 1000 } });
      const list = Array.isArray(data?.data) ? data.data : Array.isArray(data) ? data : (data?.tasks || []);
      setTasks(list);
    } catch (err) { const msg = err?.response?.data?.message || 'Failed to load tasks'; setError(msg); toast.error(msg); }
    finally { setLoading(false); }
  }, []);

  const fetchUsers = useCallback(async () => {
    try {
      const { data } = await api.get('/users');
      const list = Array.isArray(data?.data) ? data.data : Array.isArray(data) ? data : (data?.users || []);
      setUsers(list.filter(u => (u.userType || u.status) === 'Active'));
    } catch (err) { /* silent */ }
  }, []);

  const fetchDepartments = useCallback(async () => {
    try {
      const { data } = await api.get('/departments');
      const list = Array.isArray(data?.data) ? data.data : Array.isArray(data) ? data : (data?.departments || []);
      setDepartments(list);
    } catch (err) { /* silent */ }
  }, []);

  useEffect(() => { fetchTasks(); fetchUsers(); fetchDepartments(); }, [fetchTasks, fetchUsers, fetchDepartments]);

  const fmtDate = (d) => {
    if (!d) return '-';
    try { return new Date(d).toLocaleDateString(); } catch { return '-'; }
  };

  const pendingAll = useMemo(() => tasks
    .filter(t => (t.rawStatus || t.raw_status || t.rawstatus) === 'Pending')
    .filter(t => !t.additionalTask)
  , [tasks]);
  const rejectedAll = useMemo(() => tasks
    .filter(t => (t.rawStatus || t.raw_status || t.rawstatus) === 'Rejected')
    .filter(t => !t.additionalTask)
  , [tasks]);
  const displayedPendingTabTasks = useMemo(() => {
    const base = pendingTab === 'pending' ? pendingAll : rejectedAll;
    if (pendingDateFilter === 'all') return base;
    const todayStr = new Date().toISOString().slice(0,10);
    const resolveDate = (t) => (t.dateStart || t.dateExpectedEnd || t.endDate || t.dueDate || '').slice(0,10);
    if (pendingDateFilter === 'today') return base.filter(t => resolveDate(t) === todayStr);
    if (pendingDateFilter === 'older') return base.filter(t => { const ds = resolveDate(t); return ds && ds < todayStr; });
    return base;
  }, [pendingTab, pendingAll, rejectedAll, pendingDateFilter]);
  const displayTasks = useMemo(() => {
    // Base: only Approved rawStatus
    let list = tasks.filter(t => (t.rawStatus || t.raw_status || t.rawstatus) === 'Approved');
    if (filterStatus) list = list.filter(t => (t.status || t.taskStatus) === filterStatus);
    if (filterUser) {
      list = list.filter(t => {
        const ass = t.assignedTo || t.user;
        const assId = ass && (ass._id || ass.id || ass);
        return assId && String(assId) === String(filterUser);
      });
    }
    const resolveDate = (t) => (t.dateStart || t.dateExpectedEnd || t.endDate || t.dueDate || '').slice(0,10);
    if (filterToday) {
      const todayStr = new Date().toISOString().slice(0,10);
      list = list.filter(t => resolveDate(t) === todayStr);
    } else if (filterDate) {
      list = list.filter(t => resolveDate(t) === filterDate);
    }
    return list;
  }, [tasks, filterStatus, filterToday, filterDate, filterUser]);

  // Compute users who have not submitted any task today (based on dateStart or createdAt)
  const notSubmittedUsers = useMemo(() => {
    const today = new Date().toISOString().slice(0, 10);
    const getUserId = (t) => {
      const ass = t.assignedTo || t.user;
      if (!ass) return null;
      return typeof ass === 'object' ? (ass._id || ass.id) : ass;
    };
    const submittedSet = new Set();
    for (const t of tasks) {
      const dateStr = (t.dateStart || t.createdAt || '').slice(0, 10);
      if (dateStr === today) {
        const uid = getUserId(t);
        if (uid) submittedSet.add(String(uid));
      }
    }
    const activeUsers = users.filter(u => (u.userType || u.status) === 'Active');
    const isManagement = (u) => {
      const g = String(u.userGroup || '').toLowerCase();
      return g === 'management' || g === 'super management';
    };
    return activeUsers.filter(u => !isManagement(u) && !submittedSet.has(String(u._id || u.id)));
  }, [tasks, users]);

  const displayUserName = useCallback((u) => {
    return `${u.firstName || u.firstname || ''} ${u.lastName || u.lastname || ''}`.trim() || u.companyOfficialEmail || u.email || '—';
  }, []);

  const notifyOneUser = useCallback(async (u) => {
    if (!u?._id && !u?.id) return;
    try {
      setNotifyingUserId(u._id || u.id);
      await sendDirectNotification({
        user: u._id || u.id,
        title: 'Task submission reminder',
        message: 'Please submit your tasks for today.',
        type: 'admin',
        delivery: 'both',
        icon: 'notifications',
        color: 'warning'
      });
      toast.success(`Reminder sent to ${displayUserName(u)}`);
    } catch (err) {
      toast.error(err?.response?.data?.message || err.message || 'Failed to send reminder');
    } finally {
      setNotifyingUserId(null);
    }
  }, [displayUserName]);

  const notifyAllUsers = useCallback(async () => {
    if (!notSubmittedUsers.length) return;
    setNotifyingAll(true);
    try {
      for (const u of notSubmittedUsers) {
        // sequential to avoid WS/email storms; can batch if needed
        // eslint-disable-next-line no-await-in-loop
        await sendDirectNotification({
          user: u._id || u.id,
          title: 'Task submission reminder',
          message: 'Please submit your tasks for today.',
          type: 'admin',
          delivery: 'both',
          icon: 'notifications',
          color: 'warning'
        });
      }
      toast.success('Reminders sent to all pending users');
    } catch (err) {
      toast.error(err?.response?.data?.message || err.message || 'Failed to send some reminders');
    } finally {
      setNotifyingAll(false);
    }
  }, [notSubmittedUsers]);

  const userName = (id) => {
    const u = users.find(u => (u._id || u.id) === (id?._id || id?.id || id));
    if (!u) return '—';
    return `${u.firstName || u.firstname || ''} ${u.lastName || u.lastname || ''}`.trim() || u.email;
  };

  const userOptions = useMemo(() => users.map(u => ({
    value: u._id || u.id,
    label: `${u.firstName || u.firstname || ''} ${u.lastName || u.lastname || ''}`.trim() || u.email
  })), [users]);

  const departmentOptions = useMemo(() => departments.map(d => ({
    value: d._id || d.id,
    label: d.name || d.departmentName || 'Unnamed Department'
  })), [departments]);

  const approveTask = async (task) => {
    if (!task?._id && !task?.id) return;
    try {
      setActioningId(task._id || task.id);
      await api.patch(`/tasks/${task._id || task.id}`, { rawStatus: 'Approved' });
      await fetchTasks();
      toast.success('Task approved');
    } catch (err) { toast.error(err?.response?.data?.message || 'Approve failed'); }
    finally { setActioningId(null); }
  };
  const approveAll = async () => {
    if (pendingTab !== 'pending') return;
    if (!displayedPendingTabTasks.length) return;
    setApproving(true);
    try {
      await Promise.all(displayedPendingTabTasks.map(t => api.patch(`/tasks/${t._id || t.id}`, { rawStatus: 'Approved' })));
      await fetchTasks();
      toast.success('All pending tasks approved');
    } catch (err) { toast.error(err?.response?.data?.message || 'Bulk approve failed'); }
    finally { setApproving(false); }
  };
  const rejectTask = async (task) => {
    if (!task?._id && !task?.id) return;
    if (!window.confirm('Reject this task?')) return;
    try {
      setActioningId(task._id || task.id);
      await api.patch(`/tasks/${task._id || task.id}`, { rawStatus: 'Rejected' });
      await fetchTasks();
      toast.success('Task rejected');
    } catch (err) { toast.error(err?.response?.data?.message || 'Reject failed'); }
    finally { setActioningId(null); }
  };
  const suspendTask = async (task) => {
    if (!task?._id && !task?.id) return;
    if (!window.confirm('Suspend this task?')) return;
    try {
      setActioningId(task._id || task.id);
      await api.patch(`/tasks/${task._id || task.id}`, { status: 'Suspended' });
      await fetchTasks();
      toast.success('Task suspended');
    } catch (err) { toast.error(err?.response?.data?.message || 'Suspend failed'); }
    finally { setActioningId(null); }
  };

  const onFormChange = (e) => {
    const { name, value } = e.target;
    setForm(f => ({ ...f, [name]: value }));
  };
  const onCreate = async (e) => {
    e.preventDefault();
    setCreating(true); setCreateError('');
    try {
      if (assignMode === 'user' && !form.assignee) {
        setCreateError('Please select a user');
        setCreating(false);
        return;
      }
      if (assignMode === 'department' && !form.department) {
        setCreateError('Please select a department');
        setCreating(false);
        return;
      }
      const payload = {
        title: form.title,
        description: form.description,
        priority: labelToPriorityNumber(form.priority),
        status: form.status,
        rawStatus: 'Approved',
        endDate: form.endDate ? new Date(form.endDate).toISOString() : undefined,
        assignedType: assignMode === 'department' ? 'Department' : 'Employee',
        assignee: assignMode === 'user' ? (form.assignee || undefined) : undefined,
        department: assignMode === 'department' ? (form.department || undefined) : undefined,
      };
      await api.post('/tasks', payload);
      setForm({ title: '', description: '', priority: 'Normal', status: 'Pending', endDate: '', assignee: '', department: '' });
      await fetchTasks();
      toast.success('Task created');
    } catch (err) { const msg = err?.response?.data?.message || 'Create failed'; setCreateError(msg); toast.error(msg); }
    finally { setCreating(false); }
  };

  // Edit Handlers
  const openEdit = (task) => {
    if (!task) return;
    const extractId = (val) => {
      if (!val) return '';
      if (typeof val === 'object') return val._id || val.id || '';
      return val;
    };
    // Determine mode from explicit assignedType first, then presence of department
    let mode = 'user';
    if (task.assignedType === 'Department') mode = 'department';
    else if (task.department) mode = 'department';
    setEditAssignMode(mode);
    const userId = extractId(task.assignedTo && task.assignedType !== 'Department' ? task.assignedTo : (task.assignee || task.user));
    const deptId = extractId(task.assignedType === 'Department' ? task.assignedTo : task.department);
    setEditingTask(task);
    setEditForm({
      title: task.title || '',
      description: task.description || task.desc || '',
      priority: typeof task.priority === 'number' ? numberToPriorityLabel(task.priority) : (task.priority || 'Normal'),
      status: task.status || task.taskStatus || 'Pending',
      endDate: (task.endDate || task.dateExpectedEnd || task.dueDate || '').slice(0,10),
      assignee: mode === 'user' ? userId : '',
      department: mode === 'department' ? deptId : ''
    });
    setEditError('');
  };
  const closeEdit = () => {
    if (updating) return; // prevent closing mid-update
    setEditingTask(null);
    setEditError('');
  };
  const onEditChange = (e) => {
    const { name, value } = e.target;
    setEditForm(f => ({ ...f, [name]: value }));
  };
  const onUpdate = async (e) => {
    e.preventDefault();
    if (!editingTask) return;
    setUpdating(true); setEditError('');
    try {
      if (editAssignMode === 'user' && !editForm.assignee) {
        setEditError('Please select a user');
        setUpdating(false); return;
      }
      if (editAssignMode === 'department' && !editForm.department) {
        setEditError('Please select a department');
        setUpdating(false); return;
      }
      const payload = {
        title: editForm.title,
        description: editForm.description,
        priority: labelToPriorityNumber(editForm.priority),
        status: editForm.status,
        endDate: editForm.endDate ? new Date(editForm.endDate).toISOString() : undefined,
        assignedType: editAssignMode === 'department' ? 'Department' : 'Employee',
        assignee: editAssignMode === 'user' ? (editForm.assignee || undefined) : undefined,
        department: editAssignMode === 'department' ? (editForm.department || undefined) : undefined,
      };
      await api.patch(`/tasks/${editingTask._id || editingTask.id}` , payload);
      await fetchTasks();
      closeEdit();
      toast.success('Task updated');
    } catch (err) {
      const msg = err?.response?.data?.message || 'Update failed';
      setEditError(msg);
      toast.error(msg);
    } finally { setUpdating(false); }
  };

  // Delete Handlers
  const openDelete = (task) => { setDeletingTask(task); };
  const closeDelete = () => { if (deleteLoading) return; setDeletingTask(null); };
  const confirmDelete = async () => {
    if (!deletingTask) return;
    setDeleteLoading(true);
    try {
      await api.delete(`/tasks/${deletingTask._id || deletingTask.id}`);
      await fetchTasks();
      closeDelete();
      toast.success('Task deleted');
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Delete failed');
    } finally { setDeleteLoading(false); }
  };

  return (
    <>
    <div className="p-4 p-lg-5 overflow-auto">
      {/* Inline style block for filter styling (could be moved to a global stylesheet) */}
      <style>{`
    .filter-bar { background: var(--color-bg-surface-4); border:1px solid var(--color-border-alt); }
    .filter-chip { display:inline-flex; align-items:center; gap:.4rem; background: var(--color-bg-surface-5); border:1px solid var(--color-border-alt); padding:.45rem .65rem; border-radius:999px; position:relative; transition:.15s border-color, .15s background; }
    .filter-chip:hover { border-color: var(--primary-color); }
    .filter-chip select.filter-control, .filter-chip input.filter-control { background:transparent; border:none; color: var(--color-text); font-size:.8rem; padding:0; outline:none; box-shadow:none; min-width:90px; }
    .filter-chip select.filter-control option { background: var(--color-bg-surface-3); color: var(--color-text); }
    .filter-chip .btn-icon { background:transparent; border:none; padding:0; display:flex; align-items:center; cursor:pointer; color: var(--color-text-soft); }
    .filter-chip .btn-icon:hover { color: var(--color-text); }
    .filter-chip.toggle { cursor:pointer; }
    .filter-chip.toggle.active { background: var(--primary-color); border-color: var(--primary-color); }
    .filter-chip.toggle.active .filter-label { color: var(--color-text); }
    .filter-label { font-size:.7rem; text-transform:uppercase; letter-spacing:.05em; font-weight:600; color: var(--color-text-soft); }
        .filter-date { min-width:135px; }
        @media (max-width: 576px) { .filter-chip { width:100%; justify-content:flex-start; } }
      `}</style>
      <div className="mx-auto" style={{ maxWidth: 1400 }}>
        <div className="mb-4 d-flex align-items-center justify-content-between">
          <div>
      <h1 className="fs-2 fw-bold text-heading mb-1">Task Management</h1>
      <p className="text-soft">Admin can view, create, and approve user tasks.</p>
          </div>
          <div>
      <button className="btn btn-custom d-flex align-items-center gap-2" onClick={fetchTasks} disabled={loading}>
              <span className="material-symbols-outlined">refresh</span> Refresh
            </button>
          </div>
        </div>

        <div className="d-flex flex-column gap-5">
          {/* Pending / Rejected Tabs Section */}
          <section>
            <div className="mb-3 d-flex align-items-center justify-content-between">
              <div className="d-flex align-items-center gap-3 flex-wrap">
                <h2 className="fs-5 fw-bold text-heading mb-0">Pending Tasks</h2>
                <div className="btn-group" role="tablist" aria-label="Pending / Rejected">
                  <button
                    type="button"
                    className={`btn btn-custom px-3 py-1 ${pendingTab === 'pending' ? 'active' : ''}`}
                    onClick={() => setPendingTab('pending')}
                    aria-selected={pendingTab === 'pending'}
                  >Pending</button>
                  <button
                    type="button"
                    className={`btn btn-custom px-3 py-1 ${pendingTab === 'rejected' ? 'active' : ''}`}
                    onClick={() => setPendingTab('rejected')}
                    aria-selected={pendingTab === 'rejected'}
                  >Rejected</button>
                </div>
                <div className="btn-group" role="group" aria-label="Date filter">
                  <button type="button" className={`btn btn-outline-soft px-3 py-1 ${pendingDateFilter === 'all' ? 'active' : ''}`} onClick={() => setPendingDateFilter('all')}>All</button>
                  <button type="button" className={`btn btn-outline-soft px-3 py-1 ${pendingDateFilter === 'today' ? 'active' : ''}`} onClick={() => setPendingDateFilter('today')}>Today</button>
                  <button type="button" className={`btn btn-outline-soft px-3 py-1 ${pendingDateFilter === 'older' ? 'active' : ''}`} onClick={() => setPendingDateFilter('older')}>Older</button>
                </div>
              </div>
              {has(PERMISSIONS.TASK_UPDATE) && pendingTab === 'pending' && (
                <button className="btn btn-primary d-flex align-items-center gap-2 px-3 py-2 fw-bold" onClick={approveAll} disabled={approving || displayedPendingTabTasks.length === 0}>
                  <span className="material-symbols-outlined">done_all</span> {approving ? 'Approving…' : 'Approve All'}
                </button>
              )}
            </div>
            <div className="table-responsive rounded bg-card p-2">
              <table className="table table-dark-custom align-middle mb-0 w-100">
                <thead>
                  <tr>
                    <th className="text-heading">Task Title</th>
                    <th className="text-heading">Description</th>
                    <th className="text-heading">Priority</th>
                    <th className="text-heading">Assigned To</th>
                    <th className="text-heading">Created At</th>
                    <th className="text-heading">Expected Close</th>
                    <th className="text-heading text-end">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {displayedPendingTabTasks.length === 0 && (
                    <tr><td colSpan={8} className="text-center py-3 text-soft">{pendingTab === 'pending' ? 'No pending tasks' : 'No rejected tasks'}</td></tr>
                  )}
                  {displayedPendingTabTasks.map(t => (
                    <tr key={t._id || t.id}>
                      <td>
                        <Link to={`/admin/tasks/${t._id || t.id}`} className="text-decoration-none text-heading">
                        {t.title}
                        </Link>
                        {t.assignedType == 'Department' ? t.assignedDepartment ? 
                            <>
                            <span className="badge bg-secondary" style={{ fontSize: '.6rem', verticalAlign: 'middle', color: 'var(--color-bg-body)' }}>
                              (To Dept: {t.assignedDepartment.name || 'N/A'})
                            </span>
                            </>
                             : '(Dept: N/A)' : ''}
                        </td>
                        
                      <td className="text-soft" style={{ maxWidth: 300 }}>{t.description || t.desc || '—'}</td>
                      <td><span className={priorityBadge(t.priority)}>{t.priority || 'Normal'}</span></td>
                      <td>{userName(t.assignedTo || t.user)}</td>
                      <td className="text-soft">{(t.dateStart || t.createdAt || '').slice(0, 10) || '—'}</td>
                      <td className="text-soft">{(t.dateExpectedEnd || t.dueDate || '').slice(0, 10) || '—'}</td>
                      <td className="text-end d-flex justify-content-end gap-2 flex-wrap">
                        {pendingTab === 'pending' && (
                          <>
                            <button className="btn btn-action p-0" style={{ color: 'var(--primary-color)' }} onClick={() => approveTask(t)} disabled={actioningId === (t._id || t.id)} title="Approve">
                              <span className="material-symbols-outlined" style={{ fontSize: 20 }}>{actioningId === (t._id || t.id) ? 'hourglass_empty' : 'check_circle'}</span>
                            </button>
                            {has(PERMISSIONS.TASK_UPDATE) && (
                              <button className="btn btn-action p-0" onClick={() => openEdit(t)} disabled={actioningId === (t._id || t.id)} title="Edit">
                                <span className="material-symbols-outlined" style={{ fontSize: 20 }}>edit</span>
                              </button>
                            )}
                            {has(PERMISSIONS.TASK_UPDATE) && (
                              <button className="btn btn-action p-0" onClick={() => suspendTask(t)} disabled={actioningId === (t._id || t.id)} title="Suspend">
                                <span className="material-symbols-outlined" style={{ fontSize: 20 }}>pause_circle</span>
                              </button>
                            )}
                            {has(PERMISSIONS.TASK_UPDATE) && (
                              <button className="btn btn-action p-0 text-danger" onClick={() => rejectTask(t)} disabled={actioningId === (t._id || t.id)} title="Reject">
                                <span className="material-symbols-outlined" style={{ fontSize: 20 }}>cancel</span>
                              </button>
                            )}
                          </>
                        )}
                        {pendingTab === 'rejected' && (
                          <button className="btn btn-action p-0" onClick={() => openEdit(t)} disabled={actioningId === (t._id || t.id)} title="View / Edit">
                            <span className="material-symbols-outlined" style={{ fontSize: 20 }}>visibility</span>
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          {/* Tasks Not Submitted by Users (Today) */}
          <section>
            <div className="mb-3 d-flex align-items-center justify-content-between">
              <h2 className="fs-5 fw-bold text-heading mb-0">Tasks Not Submitted by Users <span className="text-soft" style={{fontWeight:400}}>(Today)</span></h2>
              <button
                className="btn btn-warning d-flex align-items-center gap-2 px-3 py-2 fw-bold"
                onClick={notifyAllUsers}
                disabled={notifyingAll || notSubmittedUsers.length === 0}
                title={notSubmittedUsers.length ? `Notify ${notSubmittedUsers.length} user(s)` : 'No users to notify'}
              >
                <span className="material-symbols-outlined">campaign</span>
                {notifyingAll ? 'Notifying…' : 'Notify All'}
              </button>
            </div>
            <div className="table-responsive rounded bg-card p-2">
              <table className="table table-dark-custom align-middle mb-0 w-100">
                <thead>
                  <tr>
                    <th className="text-heading">User</th>
                    <th className="text-heading">Email</th>
                    <th className="text-heading text-end">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {notSubmittedUsers.length === 0 && (
                    <tr><td colSpan={3} className="text-center py-3 text-soft">All active users have submitted tasks today.</td></tr>
                  )}
                  {notSubmittedUsers.map(u => (
                    <tr key={u._id || u.id}>
                      <td className="text-heading">{displayUserName(u)}</td>
                      <td className="text-soft">{u.companyOfficialEmail || u.email || '—'}</td>
                      <td className="text-end">
                        <button
                          className="btn btn-secondary-custom d-inline-flex align-items-center gap-1"
                          onClick={() => notifyOneUser(u)}
                          disabled={notifyingUserId === (u._id || u.id)}
                        >
                          <span className="material-symbols-outlined" style={{fontSize:18}}>{notifyingUserId === (u._id || u.id) ? 'hourglass_top' : 'send'}</span>
                          <span>Notify</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          {/* Task Listings */}
          <section>
            <div className="mb-3 d-flex align-items-center justify-content-between flex-wrap gap-3">
              <h2 className="fs-5 fw-bold text-heading mb-0">Task Listings</h2>
              <div className="flex-grow-1 w-100">
                <div className="bg-card rounded p-3 d-flex flex-wrap align-items-center gap-2 gap-lg-3 filter-bar">
                  <span className="text-soft fw-medium me-1">Filters:</span>

                  {/* Status Chip */}
                  <div className="filter-chip">
                    <span className="filter-label">Status</span>
                    <select className="filter-control" value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
                      <option value="">Any</option>
                      <option>Pending</option>
                      <option>Ongoing</option>
                      <option>Hold</option>
                      <option>Suspended</option>
                      <option>Completed</option>
                    </select>
                    {filterStatus && (
                      <button type="button" className="btn-icon" onClick={() => setFilterStatus('')} aria-label="Clear status filter">
                        <span className="material-symbols-outlined">close</span>
                      </button>
                    )}
                  </div>

                  {/* User Chip */}
                  <div className="filter-chip" style={{ minWidth: 155 }}>
                    <span className="filter-label">User</span>
                    <div style={{ width: 130 }}>
                      <Select
                        classNamePrefix="react-select"
                        options={[{ value: '', label: 'All Users' }, ...userOptions]}
                        value={(() => {
                          const current = userOptions.find(o => String(o.value) === String(filterUser));
                          return current || { value: '', label: 'All Users' };
                        })()}
                        onChange={(opt) => setFilterUser(opt?.value || '')}
                        placeholder="Select user"
                        styles={filterSelectStyles}
                        menuPortalTarget={typeof document !== 'undefined' ? document.body : null}
                        isClearable
                      />
                    </div>
                    {filterUser && (
                      <button type="button" className="btn-icon" onClick={() => setFilterUser('')} aria-label="Clear user filter">
                        <span className="material-symbols-outlined">close</span>
                      </button>
                    )}
                  </div>

                  {/* Date Chip */}
                  <div className="filter-chip">
                    <span className="filter-label">End Date</span>
                    <input type="date" className="filter-control filter-date" value={filterDate} onChange={e => setFilterDate(e.target.value)} />
                    {filterDate && (
                      <button type="button" className="btn-icon" onClick={() => setFilterDate('')} aria-label="Clear date filter">
                        <span className="material-symbols-outlined">close</span>
                      </button>
                    )}
                  </div>

                  {/* Today Chip */}
                  <button type="button" className={`filter-chip toggle ${filterToday ? 'active' : ''}`} onClick={() => setFilterToday(t => !t)}>
                    <span className="material-symbols-outlined" style={{ fontSize: 16 }}>today</span>
                    <span className="filter-label">Today</span>
                  </button>

                  {(filterStatus || filterDate || filterToday || filterUser) && (
                    <button type="button" className="btn btn-outline-soft btn-sm ms-auto" onClick={() => { setFilterStatus(''); setFilterDate(''); setFilterToday(false); setFilterUser(''); }}>
                      Clear All
                    </button>
                  )}
                </div>
              </div>
            </div>
            <div className="table-responsive rounded bg-card p-2">
              <table className="table table-dark-custom align-middle mb-0 w-100">
                <thead>
                  <tr>
                    <th className="text-heading">Task Title</th>
                    <th className="text-heading">Priority</th>
                    <th className="text-heading">Status</th>
                    <th className="text-heading">Assigned To</th>
                    <th className="text-heading">Created At</th>
                    <th className="text-heading">Expected Close</th>
                    <th className="text-heading">Closed At</th>
                    <th className="text-heading">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {loading && <tr><td colSpan={8} className="text-center py-4">Loading…</td></tr>}
                  {!loading && error && <tr><td colSpan={8} className="text-red-custom text-center py-4">{error}</td></tr>}
                  {!loading && !error && displayTasks.length === 0 && <tr><td colSpan={8} className="text-soft text-center py-4">No tasks found</td></tr>}
                  {!loading && !error && displayTasks.map(t => (
                    <tr key={t._id || t.id}>
                      <td>
                        <Link to={`/admin/tasks/${t._id || t.id}`} className="text-decoration-none text-heading">
                        {t.title}
                        </Link>
                        {t.assignedType == 'Department' ? t.assignedDepartment ? 
                            <>
                            <span className="badge bg-secondary" style={{ fontSize: '.6rem', verticalAlign: 'middle', color: 'var(--color-bg-body)' }}>
                              (To Dept: {t.assignedDepartment.name || 'N/A'})
                            </span>
                            </>
                             : '(Dept: N/A)' : ''}
                        </td>
                      <td><span className={priorityBadge(t.priority)}>{ getPriorityLabel(t.priority) || 'Normal'}</span></td>
                      <td>
                        { t.additionalTask == true || t.rawStatus == 'Approved' ? <span className={statusBadge(t.status)}>{t.status}</span> : 
                        <>
                        {
                            t.additionalTask == true ?
                            <>
                            <br />
                            <span className="badge bg-info" style={{ fontSize: '.6rem', verticalAlign: 'middle', color: 'var(--color-bg-body)' }}>
                              (Additional Task)
                            </span>
                            </>
                            : t.rawStatus != 'Approved' ? 
                            <><br /><span className="badge bg-warning" style={{ fontSize: '.6rem', verticalAlign: 'middle', color: 'var(--color-bg-body)' }}>
                              (Pending Approval)
                            </span></>
                            : null
                          }
                        </>
                         }
                        { t.status != 'Completed' && (new Date(t.dateStart).setHours(0, 0, 0, 0) < new Date().setHours(0, 0, 0, 0)) ?
                            <><br />
                              <span className="text-secondary mx-auto" style={{ fontSize: '.7rem' }}>Carry Over of {fmtDate(t.dateStart)}</span>
                            </>
                          : null
                          }

                          { t.status != 'Completed' && t.dateExpectedEnd || t.dueDate ?
                            <>
                            <br />
                              { (new Date(t.dateExpectedEnd || t.dueDate).setHours(0, 0, 0, 0) < new Date().setHours(0, 0, 0, 0)) ? <span className="text-danger mx-auto">Overdue</span> : <span className="text-warning mx-auto">Due Soon</span> }
                            </>
                          : null }
                      </td>
                      <td>{userName(t.assignedTo || t.user)}</td>
                      <td className="text-soft">{(t.dateStart || t.createdAt || '').slice(0, 10) || '—'}</td>
                      <td className="text-soft">{(t.dateExpectedEnd || t.dueDate || '').slice(0, 10) || '—'}</td>
                      <td className="text-soft">{(t.endDate || t.dueDate || '').slice(0, 10) || '—'}</td>
                      <td>
                        <button className="btn-action p-0" onClick={() => navigate(`/admin/tasks/${t._id || t.id}`)}><span className="material-symbols-outlined">visibility</span></button>
                        {has(PERMISSIONS.TASK_UPDATE) && (
                          <button className="btn-action p-0 ms-2" onClick={() => openEdit(t)}><span className="material-symbols-outlined">edit</span></button>
                        )}
                        {has(PERMISSIONS.TASK_DELETE) && (
                          <button className="btn-action p-0 ms-2" onClick={() => openDelete(t)}><span className="material-symbols-outlined">delete</span></button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          {/* Task Creation */}
          {has(PERMISSIONS.TASK_CREATE) && (
          <section>
            <h2 className="fs-5 fw-bold text-heading mb-3">Task Creation</h2>
            <div className="bg-card p-4 rounded">
              <form className="row g-3" onSubmit={onCreate}>
                <div className="col-12">
                  <label className="form-label" htmlFor="title">Title</label>
                  <input className="form-control" id="title" name="title" placeholder="Enter task title" type="text" value={form.title} onChange={onFormChange} required />
                </div>
                <div className="col-12">
                  <label className="form-label" htmlFor="description">Description (optional)</label>
                  <textarea className="form-control input-custom" id="description" name="description" placeholder="Enter task description" rows={3} value={form.description} onChange={onFormChange}></textarea>
                </div>
                <div className="col-md-4">
                  <label className="form-label" htmlFor="priority">Priority</label>
                  <select className="form-select" id="priority" name="priority" value={form.priority} onChange={onFormChange}>
                    <option>Normal</option>
                    <option>High</option>
                    <option>Low</option>
                    <option>Critical</option>
                    <option>Urgent</option>
                  </select>
                </div>
                <div className="col-md-4">
                  <label className="form-label" htmlFor="status">Status</label>
                  <select className="form-select" id="status" name="status" value={form.status} onChange={onFormChange}>
                    <option>Pending</option>
                    <option>Ongoing</option>
                    <option>Hold</option>
                    <option>Suspended</option>
                    <option>Completed</option>
                  </select>
                </div>
                <div className="col-md-4">
                  <label className="form-label" htmlFor="endDate">End Date (optional)</label>
                  <input className="form-control" id="endDate" name="endDate" type="date" value={form.endDate} onChange={onFormChange} />
                </div>
                <div className="col-md-6">
                  <label className="form-label d-flex align-items-center justify-content-between" htmlFor={assignMode === 'user' ? 'assignee' : 'department'}>
                    <span>Assign To {assignMode === 'department' ? 'Department' : 'User'}</span>
                    <button
                      type="button"
                      className="btn btn-action p-0 small"
                      style={{ fontSize: '.7rem', color: 'var(--primary-color)' }}
                      onClick={() => setAssignMode(m => m === 'user' ? 'department' : 'user')}
                    >
                      Switch to {assignMode === 'user' ? 'Department' : 'User'}
                    </button>
                  </label>
                  {assignMode === 'user' ? (
                    <Select
                      inputId="assignee"
                      classNamePrefix="react-select"
                      options={userOptions}
                      value={userOptions.find(o => o.value === form.assignee) || null}
                      onChange={(opt) => setForm(f => ({ ...f, assignee: opt ? opt.value : '', department: '' }))}
                      placeholder="Select user"
                      styles={selectStyles}
                      menuPortalTarget={typeof document !== 'undefined' ? document.body : null}
                      isClearable
                    />
                  ) : (
                    <Select
                      inputId="department"
                      classNamePrefix="react-select"
                      options={departmentOptions}
                      value={departmentOptions.find(o => o.value === form.department) || null}
                      onChange={(opt) => setForm(f => ({ ...f, department: opt ? opt.value : '', assignee: '' }))}
                      placeholder="Select department"
                      styles={selectStyles}
                      menuPortalTarget={typeof document !== 'undefined' ? document.body : null}
                      isClearable
                    />
                  )}
                </div>
                {createError && <div className="col-12"><div className="text-danger small">{createError}</div></div>}
                <div className="col-12"><div className="text-secondary small" style={{fontSize: '.7rem'}}>Note: This process doesn't require any task approval.</div></div>
                <div className="col-12 d-flex justify-content-end">
                  <button className="btn btn-primary d-flex align-items-center gap-2 px-4 py-2 fw-bold" type="submit" disabled={creating}>
                    <span className="material-symbols-outlined">add</span> {creating ? 'Creating…' : 'Create Task'}
                  </button>
                </div>
              </form>
            </div>
          </section>
          )}
        </div>
      </div>
    </div>
    {/* Modals */}
    {(editingTask || deletingTask) && (
        <div className="modal-portal">
          <style>{`
            .modal-portal { position:fixed; inset:0; display:flex; align-items:flex-start; justify-content:center; padding:4rem 1rem 2rem; background:rgba(0,0,0,.55); z-index:1200; overflow-y:auto; }
            .modal-card { width:100%; max-width:640px; background:var(--color-bg-surface-4); border:1px solid var(--color-border-alt); border-radius:1rem; box-shadow:0 10px 30px -5px rgba(0,0,0,.4); animation:modalIn .25s ease; }
            .modal-header { padding:1.1rem 1.25rem; border-bottom:1px solid var(--color-border-alt); display:flex; align-items:center; justify-content:space-between; }
            .modal-body { padding:1.25rem; }
            .modal-footer { padding:1rem 1.25rem; border-top:1px solid var(--color-border-alt); display:flex; justify-content:flex-end; gap:.75rem; }
            .close-btn { background:transparent; border:none; color:var(--color-text-soft); cursor:pointer; padding:.25rem; }
            .close-btn:hover { color:var(--color-text); }
            .assign-switch-btn { font-size:.65rem; color:var(--primary-color); background:transparent; border:none; font-weight:600; letter-spacing:.05em; }
            .assign-switch-btn:hover { text-decoration:underline; }
            @keyframes modalIn { from { opacity:0; transform:translateY(10px);} to { opacity:1; transform:translateY(0);} }
          `}</style>
          {/* Edit Modal */}
          {editingTask && (
            <div className="modal-card">
              <div className="modal-header">
                <h3 className="fs-6 text-heading mb-0 fw-bold">Edit Task</h3>
                <button className="close-btn" type="button" onClick={closeEdit} disabled={updating}><span className="material-symbols-outlined">close</span></button>
              </div>
              <form onSubmit={onUpdate}>
                <div className="modal-body row g-3">
                  <div className="col-12">
                    <label className="form-label" htmlFor="edit_title">Title</label>
                    <input id="edit_title" name="title" className="form-control" value={editForm.title} onChange={onEditChange} required />
                  </div>
                  <div className="col-12">
                    <label className="form-label" htmlFor="edit_description">Description</label>
                    <textarea id="edit_description" name="description" className="form-control" rows={3} value={editForm.description} onChange={onEditChange}></textarea>
                  </div>
                  <div className="col-md-4">
                    <label className="form-label" htmlFor="edit_priority">Priority</label>
                    <select id="edit_priority" name="priority" className="form-select" value={editForm.priority} onChange={onEditChange}>
                      <option>Normal</option><option>High</option><option>Low</option><option>Critical</option><option>Urgent</option>
                    </select>
                  </div>
                  <div className="col-md-4">
                    <label className="form-label" htmlFor="edit_status">Status</label>
                    <select id="edit_status" name="status" className="form-select" value={editForm.status} onChange={onEditChange}>
                      <option>Pending</option><option>Ongoing</option><option>Hold</option><option>Suspended</option><option>Completed</option>
                    </select>
                  </div>
                  <div className="col-md-4">
                    <label className="form-label" htmlFor="edit_endDate">End Date</label>
                    <input id="edit_endDate" type="date" name="endDate" className="form-control" value={editForm.endDate} onChange={onEditChange} />
                  </div>
                  <div className="col-md-6">
                    <label className="form-label d-flex align-items-center justify-content-between" htmlFor={editAssignMode === 'user' ? 'edit_assignee' : 'edit_department'}>
                      <span>Assign To {editAssignMode === 'department' ? 'Department' : 'User'}</span>
                      <button
                        type="button"
                        className="assign-switch-btn"
                        onClick={() => {
                          setEditAssignMode(m => m === 'user' ? 'department' : 'user');
                          setEditForm(f => ({ ...f, assignee: '', department: '' }));
                        }}
                      >Switch to {editAssignMode === 'user' ? 'Department' : 'User'}</button>
                    </label>
                    {editAssignMode === 'user' ? (
                      <Select
                        inputId="edit_assignee"
                        classNamePrefix="react-select"
                        options={userOptions}
                        value={userOptions.find(o => o.value === editForm.assignee) || null}
                        onChange={(opt) => setEditForm(f => ({ ...f, assignee: opt ? opt.value : '', department: '' }))}
                        placeholder="Select user"
                        styles={selectStyles}
                        menuPortalTarget={typeof document !== 'undefined' ? document.body : null}
                        isClearable
                      />
                    ) : (
                      <Select
                        inputId="edit_department"
                        classNamePrefix="react-select"
                        options={departmentOptions}
                        value={departmentOptions.find(o => o.value === editForm.department) || null}
                        onChange={(opt) => setEditForm(f => ({ ...f, department: opt ? opt.value : '', assignee: '' }))}
                        placeholder="Select department"
                        styles={selectStyles}
                        menuPortalTarget={typeof document !== 'undefined' ? document.body : null}
                        isClearable
                      />
                    )}
                  </div>
                  {editError && <div className="col-12"><div className="text-danger small">{editError}</div></div>}
                </div>
                <div className="modal-footer">
                  <button type="button" className="btn btn-outline-soft" onClick={closeEdit} disabled={updating}>Cancel</button>
                  <button type="submit" className="btn btn-primary d-flex align-items-center gap-2" disabled={updating}>
                    <span className="material-symbols-outlined">save</span> {updating ? 'Updating…' : 'Save Changes'}
                  </button>
                </div>
              </form>
            </div>
          )}
          {/* Delete Modal */}
          {deletingTask && (
            <div className="modal-card" style={{ maxWidth: 420 }}>
              <div className="modal-header">
                <h3 className="fs-6 text-heading mb-0 fw-bold">Delete Task</h3>
                <button className="close-btn" type="button" onClick={closeDelete} disabled={deleteLoading}><span className="material-symbols-outlined">close</span></button>
              </div>
              <div className="modal-body">
                <p className="mb-0">Are you sure you want to delete <strong>{deletingTask.title}</strong>? This action cannot be undone.</p>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-outline-soft" onClick={closeDelete} disabled={deleteLoading}>Cancel</button>
                <button type="button" className="btn btn-danger d-flex align-items-center gap-2" onClick={confirmDelete} disabled={deleteLoading}>
                  <span className="material-symbols-outlined">delete</span> {deleteLoading ? 'Deleting…' : 'Delete'}
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </>
  );
}
