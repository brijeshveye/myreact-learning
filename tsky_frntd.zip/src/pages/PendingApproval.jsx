import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api/client';

export default function PendingApproval() {
  const navigate = useNavigate();
  const [checking, setChecking] = useState(false);
  const [info, setInfo] = useState('');
  const [lastChecked, setLastChecked] = useState(null);

  async function checkStatus() {
    setChecking(true);
    setInfo('');
    try {
      const { data } = await api.get('/auth/me');
      const user = data?.user;
      if (user) {
        localStorage.setItem('user', JSON.stringify(user));
        if (user.status === 'Active') {
          if (user.userGroup && user.userGroup !== 'Employee') navigate('/admin/dashboard');
          else navigate('/dashboard');
          return;
        }
      }
      setInfo('Still pending. Please check again later.');
      setLastChecked(new Date());
    } catch (err) {
      if (err?.response?.status === 401) {
        navigate('/login');
      } else {
        setInfo('Unable to check status right now.');
      }
    } finally {
      setChecking(false);
    }
  }
  return (
    <div className="d-flex flex-column align-items-center justify-content-center text-center" style={{ minHeight: '60vh' }}>
      <span className="material-symbols-outlined" style={{ fontSize: 64, color: 'var(--warning-color)' }}>hourglass_top</span>
      <h1 className="text-white mt-3">Your details are not yet approved</h1>
      <p className="text-secondary mt-2" style={{ maxWidth: 680 }}>
        Your registration is at details review stage. Please check after some time, or contact IT.
      </p>
      <div className="mt-3 d-flex flex-column align-items-center gap-2">
        <button className="btn btn-primary-custom px-4" onClick={checkStatus} disabled={checking}>
          {checking ? 'Checking…' : 'Check approval status'}
        </button>
        {info && <div className="text-secondary small">{info}</div>}
        {lastChecked && (
          <div className="text-soft small">Last checked: {lastChecked.toLocaleString()}</div>
        )}
      </div>
    </div>
  );
}
