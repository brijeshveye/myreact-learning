import React, { useEffect, useMemo, useState } from 'react';
import { fetchNotifications, markAllNotificationsRead, markNotificationRead, deleteNotification } from '../api/notifications';

// Conversion of Notifications.html into Bootstrap-based, theme-aware React component.
// Preserves visual hierarchy, spacing, and interactive affordances.

// Removed static list; now fetched from backend.

const TAB_DEFS = [
  { key:'all', label:'All' },
  { key:'unread', label:'Unread' },
  { key:'task', label:'Tasks' },
  { key:'comment', label:'Comments' },
  { key:'approval', label:'Approvals' },
];

export default function Notifications() {
  const [tab, setTab] = useState('all');
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [page, setPage] = useState(1);
  const [unreadCount, setUnreadCount] = useState(0);

  async function loadData(opts = {}) {
    try {
      setLoading(true);
      setError(null);
      const data = await fetchNotifications({ page: opts.page || page, unread: tab === 'unread' ? true : undefined, type: ['all','unread'].includes(tab) ? undefined : tab });
      setItems(data.items.map(n => ({
        id: n._id,
        type: n.type,
        icon: n.icon || 'notifications',
        color: n.color || 'primary',
        title: n.title,
        emphasis: n.message,
        time: new Date(n.createdAt).toLocaleString(),
        unread: !n.isRead
      })));
      setUnreadCount(data.unreadCount);
    } catch (e) {
      setError(e.message || 'Failed to load notifications');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadData({ page:1 });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab]);

  // Listen for realtime new notifications (dispatched from Layout hook)
  useEffect(() => {
    function handleNew(e) {
      const n = e.detail;
      const mapped = {
        id: n._id || n.id,
        type: n.type,
        icon: n.icon || 'notifications',
        color: n.color || 'primary',
        title: n.title,
        emphasis: n.message,
        time: new Date(n.createdAt || Date.now()).toLocaleString(),
        unread: !n.isRead
      };
      setItems(prev => [mapped, ...prev]);
      setUnreadCount(c => c + 1);
    }
    window.addEventListener('notifications:new', handleNew);
    return () => window.removeEventListener('notifications:new', handleNew);
  }, []);

  const filtered = useMemo(() => {
    if (tab === 'all') return items;
    if (tab === 'unread') return items.filter(i => i.unread);
    return items.filter(i => i.type === tab);
  }, [tab, items]);

  const markAllRead = async () => {
    try { await markAllNotificationsRead(); loadData(); } catch (e) { /* silent */ }
  };
  const archiveOne = async (id) => { // treat archive as mark read
    try { await markNotificationRead(id, true); setItems(prev => prev.map(i => i.id===id? { ...i, unread:false }: i)); loadData(); } catch(e) { /* silent */ }
  };
  const deleteOne = async (id) => {
    const prev = items;
    setItems(prev.filter(i => i.id !== id));
    try { await deleteNotification(id); loadData(); } catch (e) { setItems(prev); }
  };

  const colorClass = (c) => {
    switch (c) {
      case 'primary': return 'bg-blue';
      case 'purple': return 'bg-purple';
      case 'success': return 'bg-green';
      case 'warning': return 'bg-yellow';
      default: return 'bg-blue';
    }
  };

  return (
    <div className="px-3 py-4">
      <div className="container-lg" style={{maxWidth:'960px'}}>
        <div className="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
          <h1 className="mb-0 fs-2 fw-bold text-heading">Notifications</h1>
          <button className="btn btn-secondary-custom d-flex align-items-center gap-2" onClick={markAllRead}>
            <span className="material-symbols-outlined fs-5">done_all</span>
            <span className="fw-medium small">Mark all as read</span>
          </button>
        </div>

        {/* Tabs */}
        <div className="mb-4 border-bottom border-secondary" style={{borderColor:'var(--color-border)'}}> 
          <ul className="nav nav-tabs border-0" role="tablist">
            {TAB_DEFS.map(t => {
              const active = tab === t.key;
              return (
                <li key={t.key} className="nav-item" role="presentation">
                  <button
                    type="button"
                    className={`nav-link px-4 pb-2 ${active ? 'active fw-semibold text-heading' : 'text-soft'}`}
                    style={{border:'none', borderBottom: active ? '2px solid var(--primary-color)' : '2px solid transparent', background:'transparent'}}
                    onClick={() => setTab(t.key)}
                  >
                    <span className="small">{t.label}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </div>

        <div className="d-flex flex-column gap-2">
          {loading && <div className="text-center py-4 text-soft small">Loading...</div>}
          {error && <div className="text-center py-4 text-danger small">{error}</div>}
          {!loading && filtered.length === 0 && !error && (
            <div className="text-center py-5 text-soft small">No notifications.</div>
          )}
          {filtered.map(n => {
            const badgeBg = {
              primary:'bg-primary-color',
              purple:'bg-purple-600',
              success:'bg-success-color',
              warning:'bg-warning-color'
            }[n.color] || 'bg-primary-color';
            return (
              <div key={n.id} className={`notification-item card border-0 p-3 bg-surface flex-row d-flex align-items-center gap-3 ${n.unread ? 'notification-unread' : ''}`}> 
                <div className="position-relative d-flex align-items-center justify-content-center">
                  <div className={`rounded-circle d-flex align-items-center justify-content-center flex-shrink-0`} style={{width:48, height:48, background: n.color==='primary'? '#2563eb' : n.color==='purple'? '#7e22ce' : n.color==='success'? '#16a34a' : '#d97706'}}>
                    <span className="material-symbols-outlined text-white">{n.icon}</span>
                  </div>
                  {n.unread && <span className="position-absolute translate-middle p-1 rounded-circle bg-primary-color border border-2" style={{bottom:-4, right:-4, width:16, height:16, borderColor:'var(--color-bg-surface-4)'}} />}
                </div>
                <div className="flex-grow-1">
                  <p className="mb-1 small text-heading fw-medium">
                    {n.title} <span className="fw-bold">{n.emphasis}</span>
                  </p>
                  <p className="mb-0 text-soft small">{n.time}</p>
                </div>
                <div className="d-flex align-items-center gap-1 actions opacity-0">
                  <button className="btn-action text-black" onClick={() => archiveOne(n.id)} title="Read">
                    <span className="material-symbols-outlined">mark_email_read</span>
                  </button>
                  <button className="btn-action text-danger delete" onClick={() => deleteOne(n.id)} title="Delete">
                    <span className="material-symbols-outlined">delete</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
