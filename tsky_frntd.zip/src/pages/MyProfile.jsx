import React, { useEffect, useMemo, useState } from 'react';
import { api } from '../api/client';
import { resolveUserAvatar } from '../utils/avatars.js';

export default function MyProfile() {
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [userId, setUserId] = useState(null);

  const initial = useMemo(() => ({
    firstName: '',
    middleName: '',
    lastName: '',
    dob: '',
    gender: '',
    permanentAddress: '',
    currentAddress: '',
    designation: '',
    departmentName: '',
    userGroup: '',
    employeeId: '',
    companyEmail: '',
    personalEmail: '',
    companyGmail: '',
    officePhone: '',
    personalPhone: '',
  }), []);

  const [form, setForm] = useState(initial);
  const [original, setOriginal] = useState(initial);

  const [user, setUser] = useState(null);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const fileInputId = 'avatarFileInput';

  useEffect(() => {
    async function load() {
      setLoading(true);
      setError('');
      try {
        const { data } = await api.get('/auth/me');
        const u = data?.user || data || {};
        setUserId(u._id || u.id || null);
        setUser(u);
  const mapped = {
          firstName: u.firstName || u.firstname || '',
          middleName: u.middleName || '',
          lastName: u.lastName || u.lastname || '',
          dob: (u.dob || '').slice(0, 10),
          gender: u.gender || '',
          permanentAddress: u.permanentAddress || u.addressPermanent || '',
          currentAddress: u.currentAddress || u.addressCurrent || '',
          designation: u.designation || '',
          departmentName: u.department?.name || u.dept?.name || u.dept || '',
          userGroup: u.userGroup || '',
          employeeId: u.employeeId || u.empId || '',
          companyEmail: u.email || u.companyEmail || '',
          personalEmail: u.personalEmail || '',
          companyGmail: u.companyGmail || '',
          officePhone: u.officePhone || '',
          personalPhone: u.personalPhone || '',
  };
  setForm(mapped);
  setOriginal(mapped);
      } catch (err) {
        const status = err?.response?.status;
        if (status === 401) {
          setError('Please login to view your profile.');
        } else {
          setError(err?.response?.data?.message || 'Failed to load profile');
        }
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  const onChange = (e) => {
    const { name, value } = e.target;
    setForm((f) => ({ ...f, [name]: value }));
  };

  const onSave = async (e) => {
    e?.preventDefault?.();
    setSaving(true);
    setError('');
    setSuccess('');
    try {
      if (!userId) throw new Error('User not loaded');
      const payload = {
        firstName: form.firstName?.trim() || '',
        middleName: form.middleName?.trim() || '',
        lastName: form.lastName?.trim() || '',
        dob: form.dob || null,
        gender: form.gender || '',
        permanentAddress: form.permanentAddress?.trim() || '',
        currentAddress: form.currentAddress?.trim() || '',
        designation: form.designation?.trim() || '',
        personalEmail: form.personalEmail?.trim() || '',
        companyGmail: form.companyGmail?.trim() || '',
        officePhone: form.officePhone?.trim() || '',
        personalPhone: form.personalPhone?.trim() || '',
      };
  await api.patch(`/users/${userId}`, payload);
  setSuccess('Profile updated successfully.');
  // Update original snapshot after successful save
  setOriginal((prev) => ({ ...prev, ...payload }));
    } catch (err) {
      setError(err?.response?.data?.message || err.message || 'Update failed');
    } finally {
      setSaving(false);
    }
  };

  // Password modal state
  const [pwd, setPwd] = useState({ current: '', next: '', confirm: '' });
  const [pwdError, setPwdError] = useState('');
  const [pwdSaving, setPwdSaving] = useState(false);

  const onUpdatePassword = async () => {
    setPwdError('');
    if (!pwd.current || !pwd.next || !pwd.confirm) {
      setPwdError('Please fill all password fields.');
      return;
    }
    if (pwd.next.length < 8) {
      setPwdError('New password must be at least 8 characters.');
      return;
    }
    if (pwd.next !== pwd.confirm) {
      setPwdError('Passwords do not match.');
      return;
    }
    setPwdSaving(true);
    try {
      await api.post('/auth/change-password', { currentPassword: pwd.current, newPassword: pwd.next });
      setShowPasswordModal(false);
      setPwd({ current: '', next: '', confirm: '' });
      setSuccess('Password updated successfully.');
    } catch (err) {
      setPwdError(err?.response?.data?.message || 'Failed to update password');
    } finally {
      setPwdSaving(false);
    }
  };

  return (
    <div className="d-flex justify-content-center py-5 px-3">
      <div className="w-100" style={{ maxWidth: 1100 }}>
        <div className="mb-4">
          <h1 className="fs-2 fw-bold mb-1">My Profile</h1>
          <p className="text-secondary-custom">Manage your personal and professional information.</p>
        </div>

        {loading && <div className="alert alert-info">Loading…</div>}
        {error && <div className="alert alert-danger">{error}</div>}
        {success && <div className="alert alert-success">{success}</div>}

        <form className="row g-4" onSubmit={onSave}>
          {/* Left summary card */}
          <div className="col-12 col-lg-4">
            <div className="bg-secondary-custom rounded p-4 d-flex flex-column align-items-center text-center shadow">
              <div className="position-relative mb-2">
                <div
                  className="profile-img profile-lg"
                  style={{ backgroundImage:`url(${resolveUserAvatar(user)})` }}
                />
                <button
                  className="btn btn-primary-custom position-absolute"
                  style={{ bottom: 8, right: 8, width: 32, height: 32, padding: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                  aria-label="Edit avatar"
                  type="button"
                  onClick={() => document.getElementById(fileInputId)?.click()}
                  disabled={uploadingAvatar}
                  title={uploadingAvatar ? 'Uploading...' : 'Change picture'}
                >
                  <span className="material-symbols-outlined fs-5">{uploadingAvatar ? 'hourglass_empty' : 'edit'}</span>
                </button>
                <input
                  id={fileInputId}
                  type="file"
                  accept="image/*"
                  className="d-none"
                  onChange={async (e) => {
                    const file = e.target.files?.[0];
                    if (!file || !userId) return;
                    if (file.size > 2 * 1024 * 1024) { setError('Image must be <= 2MB'); return; }
                    setUploadingAvatar(true); setError(''); setSuccess('');
                    try {
                      const fd = new FormData();
                      fd.append('avatar', file);
                      const { data } = await api.patch(`/users/${userId}/avatar`, fd, { headers: { 'Content-Type': 'multipart/form-data' } });
                      if (data?.user) {
                        setUser(data.user);
                        // update local storage copy if same user
                        try {
                          const stored = localStorage.getItem('user');
                          if (stored) {
                            const parsed = JSON.parse(stored);
                            if (parsed._id === data.user._id) {
                              localStorage.setItem('user', JSON.stringify({ ...parsed, profilePicture: data.user.profilePicture }));
                            }
                          }
                        } catch { /* ignore */ }
                        setSuccess('Profile picture updated.');
                      }
                    } catch (err) {
                      setError(err?.response?.data?.message || 'Failed to upload avatar');
                    } finally {
                      setUploadingAvatar(false);
                      e.target.value = '';
                    }
                  }}
                />
              </div>
              <h2 className="mt-2 fs-4 fw-bold mb-0">{[form.firstName, form.lastName].filter(Boolean).join(' ') || '—'}</h2>
              <p className="text-secondary-custom mb-0">{form.designation || '—'}</p>
              <p className="text-secondary-custom mb-2" style={{ fontSize: '0.95rem' }}>Employee ID: {form.employeeId || '—'}</p>
              <div className="w-100 mt-3">
                <button onClick={() => setShowPasswordModal(true)} className="btn w-100 text-start py-2 px-3 rounded mb-2 d-flex align-items-center gap-2 bg-transparent text-secondary-custom" style={{ transition: 'background 0.2s' }} type="button">
                  <span className="material-symbols-outlined fs-5">lock</span>
                  <span>Update Password</span>
                </button>
                <button onClick={() => setShowPrivacyModal(true)} className="btn w-100 text-start py-2 px-3 rounded d-flex align-items-center gap-2 bg-transparent text-secondary-custom" style={{ transition: 'background 0.2s' }} type="button">
                  <span className="material-symbols-outlined fs-5">privacy_tip</span>
                  <span>Privacy Settings</span>
                </button>
              </div>
            </div>
          </div>

          {/* Right detail forms */}
          <div className="col-12 col-lg-8">
            <div className="row g-4">
              <div className="col-12">
                <div className="bg-secondary-custom rounded p-4 shadow mb-4">
                  <h3 className="fs-5 fw-bold mb-3">Personal Information</h3>
                  <div className="row g-3">
                    <div className="col-12 col-sm-6">
                      <label className="form-label text-secondary-custom">First Name</label>
                      <input className="form-control input-custom" type="text" name="firstName" value={form.firstName} onChange={onChange} />
                    </div>
                    <div className="col-12 col-sm-6">
                      <label className="form-label text-secondary-custom">Middle Name</label>
                      <input className="form-control input-custom" type="text" name="middleName" value={form.middleName} onChange={onChange} />
                    </div>
                    <div className="col-12">
                      <label className="form-label text-secondary-custom">Last Name</label>
                      <input className="form-control input-custom" type="text" name="lastName" value={form.lastName} onChange={onChange} />
                    </div>
                    <div className="col-12 col-sm-6">
                      <label className="form-label text-secondary-custom">Date of Birth</label>
                      <input className="form-control input-custom" type="date" name="dob" value={form.dob} onChange={onChange} />
                    </div>
                    <div className="col-12 col-sm-6">
                      <label className="form-label text-secondary-custom">Gender</label>
                      <select className="form-select input-custom" name="gender" value={form.gender} onChange={onChange}>
                        <option value="">Select</option>
                        <option value="Female">Female</option>
                        <option value="Male">Male</option>
                        <option value="Other">Other</option>
                        <option value="Prefer not to say">Prefer not to say</option>
                      </select>
                    </div>
                    <div className="col-12">
                      <label className="form-label text-secondary-custom">Permanent Address</label>
                      <textarea className="form-control input-custom" name="permanentAddress" value={form.permanentAddress} onChange={onChange} rows={2} />
                    </div>
                    <div className="col-12">
                      <label className="form-label text-secondary-custom">Current Address</label>
                      <textarea className="form-control input-custom" name="currentAddress" value={form.currentAddress} onChange={onChange} rows={2} />
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-12">
                <div className="bg-secondary-custom rounded p-4 shadow mb-4">
                  <h3 className="fs-5 fw-bold mb-3">Professional Information</h3>
                  <div className="row g-3">
                    <div className="col-12 col-sm-6">
                      <label className="form-label text-secondary-custom">Designation</label>
                      <input className="form-control input-custom" type="text" name="designation" value={form.designation} onChange={onChange} />
                    </div>
                    <div className="col-12 col-sm-6">
                      <label className="form-label text-secondary-custom">Department</label>
                      <input className="form-control input-custom" type="text" name="departmentName" value={form.departmentName} disabled />
                    </div>
                    <div className="col-12 col-sm-6">
                      <label className="form-label text-secondary-custom">User Group</label>
                      <input className="form-control input-custom" type="text" name="userGroup" value={form.userGroup} disabled />
                    </div>
                    <div className="col-12 col-sm-6">
                      <label className="form-label text-secondary-custom">Employee ID</label>
                      <input className="form-control input-custom" type="text" name="employeeId" value={form.employeeId} disabled />
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-12">
                <div className="bg-secondary-custom rounded p-4 shadow mb-4">
                  <h3 className="fs-5 fw-bold mb-3">Contact Information</h3>
                  <div className="row g-3">
                    <div className="col-12">
                      <label className="form-label text-secondary-custom">Company Official Email</label>
                      <input className="form-control input-custom" type="email" name="companyEmail" value={form.companyEmail} disabled />
                    </div>
                    <div className="col-12 col-sm-6">
                      <label className="form-label text-secondary-custom">Personal Email</label>
                      <input className="form-control input-custom" type="email" name="personalEmail" value={form.personalEmail} onChange={onChange} />
                    </div>
                    <div className="col-12 col-sm-6">
                      <label className="form-label text-secondary-custom">Company Unofficial Gmail</label>
                      <input className="form-control input-custom" type="email" name="companyGmail" value={form.companyGmail} onChange={onChange} />
                    </div>
                    <div className="col-12 col-sm-6">
                      <label className="form-label text-secondary-custom">Office Phone Number</label>
                      <input className="form-control input-custom" type="tel" name="officePhone" value={form.officePhone} onChange={onChange} />
                    </div>
                    <div className="col-12 col-sm-6">
                      <label className="form-label text-secondary-custom">Personal Phone Number</label>
                      <input className="form-control input-custom" type="tel" name="personalPhone" value={form.personalPhone} onChange={onChange} />
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-12 d-flex justify-content-end pt-2 gap-2">
                <button className="btn btn-secondary-custom px-4" type="button" onClick={() => setForm(original)} disabled={saving}>Cancel</button>
                <button className="btn btn-primary-custom d-flex align-items-center gap-2 px-4" type="submit" disabled={saving}>
                  <span className="material-symbols-outlined">save</span>
                  <span>{saving ? 'Saving…' : 'Save Changes'}</span>
                </button>
              </div>
            </div>
          </div>
        </form>
      </div>
      {/* Update Password Modal */}
      {showPasswordModal && (
        <div className="position-fixed top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center" style={{ zIndex: 1050 }}>
          <div className="position-absolute top-0 start-0 w-100 h-100" onClick={() => setShowPasswordModal(false)} style={{ background: 'rgba(0,0,0,0.5)' }} />
          <div className="bg-card rounded shadow p-3 p-sm-4 position-relative" style={{ width: '90%', maxWidth: 520 }} role="dialog" aria-modal="true" aria-labelledby="updPassTitle">
            <div className="d-flex align-items-center justify-content-between mb-3">
              <h2 id="updPassTitle" className="fs-5 fw-bold mb-0 text-heading">Update Password</h2>
              <button className="btn btn-action" onClick={() => setShowPasswordModal(false)} aria-label="Close">
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>
            <div className="row g-3">
              <div className="col-12">
                <label className="form-label text-secondary-custom">Current Password</label>
                <input type="password" className="form-control input-custom" placeholder="••••••••" value={pwd.current} onChange={(e) => setPwd((p) => ({ ...p, current: e.target.value }))} />
              </div>
              <div className="col-12 col-sm-6">
                <label className="form-label text-secondary-custom">New Password</label>
                <input type="password" className="form-control input-custom" placeholder="New password" value={pwd.next} onChange={(e) => setPwd((p) => ({ ...p, next: e.target.value }))} />
              </div>
              <div className="col-12 col-sm-6">
                <label className="form-label text-secondary-custom">Confirm Password</label>
                <input type="password" className="form-control input-custom" placeholder="Confirm password" value={pwd.confirm} onChange={(e) => setPwd((p) => ({ ...p, confirm: e.target.value }))} />
              </div>
            </div>
            {pwdError && <div className="text-danger mt-2">{pwdError}</div>}
            <div className="d-flex justify-content-end gap-2 mt-4">
              <button className="btn btn-secondary-custom" onClick={() => setShowPasswordModal(false)} type="button">Cancel</button>
              <button className="btn btn-primary-custom" type="button" onClick={onUpdatePassword} disabled={pwdSaving}>{pwdSaving ? 'Updating…' : 'Update'}</button>
            </div>
          </div>
        </div>
      )}

      {/* Privacy Settings Modal */}
      {showPrivacyModal && (
        <div className="position-fixed top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center" style={{ zIndex: 1050 }}>
          <div className="position-absolute top-0 start-0 w-100 h-100" onClick={() => setShowPrivacyModal(false)} style={{ background: 'rgba(0,0,0,0.5)' }} />
          <div className="bg-card rounded shadow p-3 p-sm-4 position-relative" style={{ width: '90%', maxWidth: 520 }} role="dialog" aria-modal="true" aria-labelledby="privacyTitle">
            <div className="d-flex align-items-center justify-content-between mb-3">
              <h2 id="privacyTitle" className="fs-5 fw-bold mb-0 text-heading">Privacy Settings</h2>
              <button className="btn btn-action" onClick={() => setShowPrivacyModal(false)} aria-label="Close">
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>
            <div className="d-flex flex-column gap-2">
              <label className="d-flex align-items-center gap-2">
                <input className="form-check-input" type="checkbox" defaultChecked />
                <span className="text-secondary-custom">Show my company email to team members</span>
              </label>
              <label className="d-flex align-items-center gap-2">
                <input className="form-check-input" type="checkbox" />
                <span className="text-secondary-custom">Enable two-factor authentication</span>
              </label>
              <label className="d-flex align-items-center gap-2">
                <input className="form-check-input" type="checkbox" defaultChecked />
                <span className="text-secondary-custom">Share activity status</span>
              </label>
            </div>
            <div className="d-flex justify-content-end gap-2 mt-4">
              <button className="btn btn-secondary-custom" onClick={() => setShowPrivacyModal(false)} type="button">Cancel</button>
              <button className="btn btn-primary-custom" type="button">Save</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
