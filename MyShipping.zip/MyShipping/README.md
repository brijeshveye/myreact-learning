# MyShipping package

A shipping and logistics integration module for ShopyJi/Laravel that provides a unified interface to configure shipping gateways, create shipping orders (where supported), and track shipments.

## Overview

MyShipping adds an admin UI and endpoints for:
- Selecting an active shipping gateway (e.g., ShipRocket, DHL)
- Configuring credentials and options per gateway
- Creating shipping orders (for gateways that support it)
- Tracking shipments from both the admin and storefront
- Viewing API order status history stored in your database

It is fully store-aware using your platform helpers (e.g., `getCurrentStore()`, `getAdminAllSetting`, `setShippingOptions`, `getShippingOption`).

## Features

- Admin panel at `/my-shipping` to manage the Shipping Center
- Gateway registry with logos, capabilities, and service classes (DHL, ShipRocket included)
- Per-store settings and configuration with persistence
- Create shipping orders and list order history (for supported gateways)
- Track shipments by tracking number via API
- Event-registered menus for Company/Super Admin contexts
- Laravel package auto-discovery for the service provider

## Requirements

- PHP 8.2+
- Laravel 11.x (as used in this repository)
- Gateway accounts and credentials (e.g., ShipRocket user/password, tokens; DHL API keys) if you plan to use those services.

## Installation

This repository already includes the package as a local path dependency. If integrating elsewhere, require it or add a path repository and run `composer update`.

1) Auto-discovery
- The package registers `Shopyji\\MyShipping\\app\\Providers\\MyShippingServiceProvider` via Laravel auto-discovery.

2) Run migrations and optional seeders

```bash
php artisan migrate
# Optional seeders if provided:
php artisan db:seed --class="Shopyji\\MyShipping\\Database\\seeders\\PermissionTableSeeder"
php artisan db:seed --class="Shopyji\\MyShipping\\Database\\seeders\\MarketPlaceSeederTableSeeder"
```

3) Clear caches (recommended)

```bash
php artisan optimize:clear
```

## Routes and UI

Admin routes (protected by `web`, `auth`, and `PlanModuleCheck:MyShipping`):
- `GET /my-shipping` → Shipping center dashboard (name: `myshipping.admin.index`)
- `POST /my-shipping/track` → Admin tracking (name: `myshipping.admin.track`)
- `GET /my-shipping/create-order/{order_id}` → Create shipping order (name: `myshipping.admin.order.create`)
- `GET /my-shipping/settings` → Settings (name: `myshipping.admin.settings`)
- `POST /my-shipping/settings/gateway/update` → Switch active gateway (name: `myshipping.admin.settings.gatway.update`)
- `POST /my-shipping/settings/update` → Save credentials/settings (name: `myshipping.admin.settings.update`)
- `POST /my-shipping/configuration/update` → Save configuration (name: `myshipping.admin.configuration.update`)
- `GET /my-shipping/status` → Toggle active gateway (AJAX) (name: `myshipping.admin.status.change`)

Customer route:
- `POST /shipping-plugin/track` → Public tracking endpoint (name: `myshipping.customer.track`)

Views namespace: `myshipping` (e.g., `view('myshipping::company.index')`).

## Gateways and capabilities

Gateways are defined in `app/Services/ShippingService::gateways()` with:
- `name`, `slug`, `logo`, `reference` (docs link)
- `authorization` and `configuration` flags
- `service_class` that implements tracking and (optionally) order creation
- `api_order_flag` to toggle order list UI support

Included examples:
- DHL: tracking only (`api_order_flag = false`)
- ShipRocket: tracking + order creation (`api_order_flag = true`)

You can add new gateways by extending the registry and implementing a service class exposing methods used by `ShippingService`.

## Configuration flow

1) Pick the active gateway under Settings → choose from the list; the active gateway is stored via `setShippingOptions(['active_shipping_gateway' => '...'])`.
2) Provide required credentials for that gateway (e.g., ShipRocket email/password) and save.
3) If the gateway supports token authorization, the module can request and store an authorization token when missing.
4) Optional configuration (e.g., auto-create order, pickup location, etc.) can be saved per store.

## Creating orders (supported gateways)

- Use the admin UI “Create Order” action: `GET /my-shipping/create-order/{order_id}`
- The controller prepares an order payload from your platform order (customer info, items, totals) then calls `ShippingService::createOrder()`.
- Responses are persisted in `shipping_api_order_statuses` for history.

## Tracking shipments

- Admin can track via `POST /my-shipping/track`
- Customers can track via `POST /shipping-plugin/track`
- `ShippingService` dispatches to the appropriate gateway method (e.g., `dhlTracking`, `shiprocketTracking`).

## Database schema

Migration: `shipping_api_order_statuses`
- `id`, `order_id`, `gateway`, `status`, `message`, timestamps

Model: `Shopyji\\MyShipping\\app\\Models\\ShippingApiOrderStatus`

## Troubleshooting

- Service not available right now
  - Ensure an active gateway is set (`getShippingOption('active_shipping_gateway')`), and credentials are valid.

- Order list not visible
  - Your active gateway must set `api_order_flag = true` in the registry (e.g., ShipRocket).

- Create order fails
  - Check the prepared order payload (dimensions/weights, pickup location, items), and gateway credentials/authorization token.

- Tracking fails or returns plugin configuration incorrect
  - Verify that the gateway methods exist and the active gateway is set correctly.

## Internals at a glance

- Service provider: `app/Providers/MyShippingServiceProvider.php`
- Routes: `Routes/web.php`, `Routes/api.php`
- Controllers: `app/Http/Controllers/Company/ShippingPluginController.php`, `app/Http/Controllers/Company/ShippingPluginFrontendController.php`
- Services: `app/Services/ShippingService.php` and gateway classes in `app/Services/Gateways`
- Model: `app/Models/ShippingApiOrderStatus.php`
- Migration: `Database/Migrations/2023_12_27_151555_create_shipping_api_order_statuses_table.php`
- Views: `Resources/views/`
- Event wiring: `app/Providers/EventServiceProvider.php` and listeners in `app/Listeners`

## License

MIT

## Support

For issues or questions, contact ShopyJi support or the authors listed in `composer.json`.
