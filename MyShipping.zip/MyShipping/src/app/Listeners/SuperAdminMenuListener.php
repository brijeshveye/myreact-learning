<?php

namespace Shopyji\MyShipping\app\Listeners;
use App\Events\SuperAdminMenuEvent;

class SuperAdminMenuListener
{
    /**
     * Handle the event.
     */
    public function handle(SuperAdminMenuEvent $event): void
    {
        $module = 'MyShipping';
        $menu = $event->menu;
        $menu->add([
            'title' => __('My Shipping'),
            'icon' => 'truck',
            'name' => 'myshipping',
            'parent' => null,
            'order' => 210,
            'ignore_if' => [],
            'depend_on' => [],
            'route' => '',
            'module' => $module,
            'permission' => ''
        ]);
    }
}
