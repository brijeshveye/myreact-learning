<?php

namespace Shopyji\MyShipping\app\Listeners;

use App\Events\CompanyMenuEvent;

class CompanyMenuListener
{
    /**
     * Handle the event.
     */
    public function handle(CompanyMenuEvent $event): void
    {
        $module = 'MyShipping';
        $menu = $event->menu;
        $menu->add([
            'title' => __('Shipping Center'),
            'icon' => 'truck',
            'name' => 'shipping_center',
            'parent' => null,
            'order' => 210,
            'ignore_if' => [],
            'depend_on' => [],
            'route' => '',
            'module' => $module,
            'permission' => ''
        ]);

        $menu->add([
            'title' => __('Shipping Dashboard'),
            'icon' => 'truck',
            'name' => 'shipping_center_index',
            'parent' => 'shipping_center',
            'order' => 211,
            'ignore_if' => [],
            'depend_on' => [],
            'route' => 'myshipping.admin.index',
            'module' => $module,
            'permission' => ''
        ]);

        $menu->add([
            'title' => __('Shipping Center Settings'),
            'icon' => 'truck',
            'name' => 'shipping_center_settings',
            'parent' => 'shipping_center',
            'order' => 212,
            'ignore_if' => [],
            'depend_on' => [],
            'route' => 'myshipping.admin.settings',
            'module' => $module,
            'permission' => ''
        ]);

    }
}
