<?php

namespace Shopyji\MyShipping\app\Http\Controllers\Company;

use App\Helpers\FlashMsg;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Shopyji\MyShipping\DataTables\ShippingOrderDataTable;
use Shopyji\MyShipping\app\Models\ShippingApiOrderStatus;
use Shopyji\MyShipping\app\Services\AuthorizationService;
use Shopyji\MyShipping\app\Services\Gateways\DHL;
use Shopyji\MyShipping\app\Services\ShippingService;

class ShippingPluginController extends Controller
{
    public function index(Request $request, ShippingOrderDataTable $dataTable)
    {
        // Get all settings for the current user and store
        $user = auth()->user();
        $setting = getAdminAllSetting($user->id, getCurrentStore(), APP_THEME());
        
        // $active_shipping_gateway = get_static_option('active_shipping_gateway');
        $active_shipping_gateway = $setting['active_shipping_gateway'] ?? null;

        // Wether to show order list or not
        $has_orders = false;
        $orders = [];
        if (!empty($active_shipping_gateway))
        {
            $gateways = ShippingService::gateways();
            $has_orders = $gateways[$active_shipping_gateway]['api_order_flag'];

            $orders = ShippingApiOrderStatus::orderByDesc('id')->paginate(10);
        }

        // Ajax datatable
        return $dataTable->render('myshipping::company.index', compact('orders', 'active_shipping_gateway', 'has_orders'));

        // return view('myshipping::backend.index', compact('orders', 'active_shipping_gateway', 'has_orders'));
        //return view('myshipping::company.index', compact('orders', 'active_shipping_gateway', 'has_orders'));
    }

    public function prepareOrder($order_id)
    {

        $customerOrder = \App\Models\Order::where('id', $order_id)->first();

        if ($customerOrder && module_is_active('MyShipping'))
        {
            $active_gateway = getShippingOption('active_shipping_gateway');
            if (!empty($active_gateway))
            {
                $order = $customerOrder;
                $orderDetails =  $customerOrder->order_detail();
                
                $items = $orderDetails['product'] ?? [];

                $old_sku = '';
                $order_items = [];
                foreach ($items ?? [] as $item)
                {
                    // $sku = (ProductInventory::where('product_id', $item->id)->first())->sku ?? '';
                    $variant_color = strtolower($item->options?->color_name ?? null);
                    $variant_size = strtolower($item->options?->size_name ?? null);

                    $order_items[] = [
                        "name" => $variant_color ? $item->name." : $variant_color - $variant_size" : $item->name,
                        "sku" => $item->name, //$old_sku == $sku ? $sku."-$variant_color-$variant_size" : $item->name,
                        "units" => $item->qty,
                        "selling_price" => $item->final_price,
                        "tax" => 0, //($item->final_price * $item->options->tax_options_sum_rate) / 100,
                        "hsn" => ""
                    ];

                    // $old_sku = $sku;
                }

                $payment_type = 'COD';
                if ($order->payment_status == 'success')
                {
                    $payment_type = 'Prepaid';
                }


                $orderBodyResp = [
                    "order_id" => $order->id,
                    "order_date" => $order->created_at->format('Y-m-d H:i'),
                    "pickup_location" => getShippingOption("{$active_gateway}_pickup_location"),
                    //"channel_id" => "",
                    "comment" => $order->delivery_comment, //"Reseller: M/s Atul",
                    "billing_customer_name" => $orderDetails['delivery_informations']['name'], //"Brijesh",
                    "billing_last_name" => "",
                    "billing_address" => $orderDetails['delivery_informations']['address'], //"House 221B, Dulhera Village",
                    //"billing_address_2" => "Near CP House",
                    "billing_city" => $orderDetails['billing_informations']['city'], //"New Delhi",
                    "billing_pincode" => $orderDetails['delivery_informations']['post_code'],
                    "billing_state" => $orderDetails['delivery_informations']['state'], //"Delhi",
                    "billing_country" => $orderDetails['delivery_informations']['country'], //"India",
                    "billing_email" => $orderDetails['billing_informations']['email'], //"customer@gmail.com",
                    "billing_phone" => $orderDetails['billing_informations']['phone'], //"701744xxxx",
                    "shipping_is_billing" => true,
                    "order_items" => $order_items,
                    "payment_method" => $payment_type,
                    "shipping_charges" => $orderDetails['delivered_charge'] ?? 0,
                    "giftwrap_charges" => 0,
                    "transaction_charges" => 0,
                    "total_discount" => $orderDetails['coupon_info']['discount'] ?? 0,
                    "sub_total" => $orderDetails['final_price'],
                    "length" => 10,
                    "breadth" => 10,
                    "height" => 10,
                    "weight" => 10
                ];


                return $orderBodyResp;
            }
        }

        return [];
    }

    public function createOrder(Request $request, $order_id)
    {
        // $validated = $request->validate([
        //     'order_id' => 'required|alpha_num'
        // ]);

        $validated = $request->validate([
            'order_id' => 'required|numeric'
        ]);

        $shipping_order = new ShippingService();

        $orderBody = $this->prepareOrder($validated['order_id']);

        $shipping_order = $shipping_order->createOrder($orderBody);

        // return response()->json($shipping_order);
        return redirect()->back()->with([
            'type' => $shipping_order['status'] ? 'success' : 'danger',
            'message' => $shipping_order['message'],
            'tracking_data' => $shipping_order
        ]);
    }

    public function track(Request $request)
    {
        if ($this->availability()['status'])
        {
            return $this->availability()['response'];
        }

        $validated = $request->validate([
            'tracking_number' => 'required|alpha_num'
        ]);

        $track_order = new ShippingService($validated['tracking_number']);
        $track_order = $track_order->track();

        // return back()->with(FlashMsg::explain($track_order['status'] ? 'success' : 'danger', $track_order['title']))
        //     ->with('tracking_data', $track_order);

        return redirect()->back()->with([
            'type' => $track_order['status'] ? 'success' : 'danger',
            'message' => $track_order['title'],
            'tracking_data' => $track_order
        ]);
    }

    public function availability()
    {
        // return [
        //     'status' => empty(get_static_option('active_shipping_gateway')),
        //     'response' => back()->with(FlashMsg::explain('danger', __('Service not available right now')))
        // ];

        return [
            'status' => empty(getShippingOption('active_shipping_gateway')),
            'response' => back()->with(['error'=> __('Service not available right now.')])
        ];
    }

    public function settings()
    {
        $gateways = ShippingService::gateways();

        $user = auth()->user();
        $setting = getAdminAllSetting($user->id, getCurrentStore(), APP_THEME());

        $active_shipping_gateway = $setting['active_shipping_gateway'] ?? null;

        $gateway_names = array_map(function ($item) {
            return $item['name'];
        }, $gateways);

        $app_setting_tab = session()->get('app_setting_tab');
        if (empty($app_setting_tab)) {
            $app_setting_tab = 'pills-shipping-center-setting-tab';
        }

        // return view('shippingplugin::backend.settings', compact('gateways'));
        return view('myshipping::company.settings', compact('gateways', 'gateway_names', 'setting','app_setting_tab', 'active_shipping_gateway'));
    }

    public function updateShippingGateway(Request $request)
    {
        $validated = $request->validate([
            'active_shipping_gateway' => 'required',
        ]);
        $shipping_gateway_name = $validated['active_shipping_gateway'];

        setShippingOptions(['active_shipping_gateway' => $shipping_gateway_name]);

        return redirect()->back()->with(['success'=> __('Shipping Gateway changed successfully.')]);
    }

    public function UpdateSettings(Request $request)
    {
        $validated = $request->validate([
            'shipping_gateway_name' => 'required',
            'dhl_api_key' => 'required_if:shipping_gateway_name,dhl',
            'dhl_api_secret' => 'required_if:shipping_gateway_name,dhl',
            'shiprocket_api_user_email' => 'required_if:shipping_gateway_name,shiprocket',
            'shiprocket_api_user_password' => 'required_if:shipping_gateway_name,shiprocket',
            'shiprocket_api_authorization_token' => 'nullable'
        ]);

        // dump($validated);

        $shipping_gateway_name = $request->shipping_gateway_name;
        unset($request->shipping_gateway_name);
        unset($validated['shipping_gateway_name']);

        // foreach ($validated ?? [] as $index => $item)
        // {
        //     update_static_option($index, esc_html($item));
        // }

        setShippingOptions($validated);

        $gateway_name = $shipping_gateway_name.'_api_authorization_token';
        if(empty($request->$gateway_name))
        {
            (new AuthorizationService(esc_html($shipping_gateway_name)))->checkAuthorization()->saveAuthorization();
        }

        return redirect()->back()->with(['success'=> __('Shipping Center Settings saved successfully.')]);
    }

    public function UpdateConfiguration(Request $request)
    {
        $rules = [
            'shipping_gateway_name' => 'required',
            'shiprocket_auto_create_order_option' => 'nullable',
            'shiprocket_order_tracking_option' => 'nullable',
            'shiprocket_pickup_location' => 'required'
        ];

        $request->validate($rules);
        unset($request->shipping_gateway_name);
        unset($rules['shipping_gateway_name']);

        foreach ($rules ?? [] as $index => $item)
        {
            // update_static_option($index, empty(esc_html($request->$index)) ? null : trim(esc_html($request->$index)));
            setShippingOptions([$index => empty(esc_html($request->$index)) ? null : trim(esc_html($request->$index))]);
        }

        return redirect()->back()->with(['success'=> __('Shipping Center Settings save successfully.')]);
    }

    public function changeStatus()
    {
        $request = \request();
        $this->validation($request);

        // if (empty(get_static_option("active_shipping_gateway")))
        // {
        //     update_static_option("active_shipping_gateway" , esc_html($request->option));
        // } else {
        //     if (get_static_option('active_shipping_gateway') == esc_html($request->option))
        //     {
        //         delete_static_option("active_shipping_gateway");
        //     } else {
        //         delete_static_option("active_shipping_gateway");
        //         update_static_option("active_shipping_gateway" , esc_html($request->option));
        //     }
        // }

        if (empty(getShippingOption("active_shipping_gateway")))
        {
            setShippingOptions(["active_shipping_gateway" => esc_html($request->option)]);
        } else {
            if (getShippingOption('active_shipping_gateway') == esc_html($request->option))
            {
                // delete_static_option("active_shipping_gateway");
                setShippingOptions(["active_shipping_gateway" => null]);
            } else {
                // delete_static_option("active_shipping_gateway");
                setShippingOptions(["active_shipping_gateway" => esc_html($request->option)]);
            }
        }

        return response()->json([
            'type' => "success"
        ]);
    }

    private function validation($request)
    {
        abort_if(!$request->has('option'), 404);
        abort_if(empty($request->option), 404);

        $gateway_slugs_array = data_get(ShippingService::gateways(), '*.slug');
        abort_if(!in_array($request->option, $gateway_slugs_array), 404);
    }
}
