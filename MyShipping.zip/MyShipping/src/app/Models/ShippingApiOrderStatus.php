<?php

namespace Shopyji\MyShipping\app\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class ShippingApiOrderStatus extends Model
{
    protected $table = "shipping_api_order_statuses";
    protected $fillable = ['order_id', 'status', 'message', 'gateway'];

    public function order()
    {
        return $this->belongsTo('App\Models\Order', 'order_id');
    }
    
    public function gateway()
    {
        return $this->belongsTo('App\Models\ShippingGateway', 'gateway');
    }

    public function getStatusAttribute($value)
    {
        return $value == 1 ? 'success' : 'failed';
    }
}
