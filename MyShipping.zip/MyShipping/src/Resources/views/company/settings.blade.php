@extends('layouts.app')

@section('page-title')
{{ __('Shipping Center Settings') }}
@endsection

@section('breadcrumb')
<li class="breadcrumb-item" aria-current="page">{{ __('Shipping Center Settings') }}</li>
@endsection

@section('content')
{{--
this will contain sections:
cards of dhl and shiprocket.

cards contain
-activat/deactivate button [btn]
-settings button [btn]
-config (only in shiprocket)
 --}}

<div class="row">
    <div class="col-xl-12">
        <div class="card">
            <div class="list-group list-group-flush app-seeting-tab" id="useradd-sidenav">
                <ul class="nav nav-pills w-100  row store-setting-tab" id="pills-tab" role="tablist">
                    <li class="nav-item col-xxl-2 col-xl-3 col-md-4 col-sm-6  col-12 text-center" role="presentation">
                        <a href="#Shipping_Center_Setting" class="nav-link @if(isset($app_setting_tab) && ($app_setting_tab == 'pills-shipping-center-setting-tab')) active show @endif btn-sm f-w-600" id="pills-shipping-center-setting-tab"
                            data-bs-toggle="pill" data-bs-target="#pills-shipping-center-setting" type="button" role="tab"
                            aria-controls="pills-shipping-center-setting" aria-selected="true">
                            {{ __('Shipping Center Settings') }}
                        </a>

                    </li>
                    <li class="nav-item col-xxl-2 col-xl-3 col-md-4 col-sm-6 col-12 text-center" role="presentation">
                        <a href="#DHL_Setting" class="nav-link btn-sm f-w-600 @if(isset($app_setting_tab) && ($app_setting_tab == 'pills-dhl-tab')) active show @endif" id="pills-dhl-tab" data-bs-toggle="pill"
                            data-bs-target="#pills-dhl" type="button" role="tab" aria-controls="pills-dhl"
                            aria-selected="true">
                            {{ __('DHL Settings') }}
                        </a>

                    </li>
                    <li class="nav-item col-xxl-2 col-xl-3 col-md-4 col-sm-6 col-12 text-center" role="presentation">
                        <a href="#Shiprocket_Setting" class="nav-link @if(isset($app_setting_tab) && ($app_setting_tab == 'pills-shiprocket-tab')) active show @endif btn-sm f-w-600" id="pills-shiprocket-tab"
                            data-bs-toggle="pill" data-bs-target="#pills-shiprocket" type="button" role="tab"
                            aria-controls="pills-shiprocket" aria-selected="true">
                            {{ __('Shiprocket Settings') }}
                        </a>

                    </li>
                    @stack('appSettingTab')
                </ul>
            </div>
        </div>
    </div>

    <div class="col-xl-12">
        <div class="tab-content store-tab-content" id="pills-tabContent">

            <div class="tab-pane fade @if(isset($app_setting_tab) && ($app_setting_tab == 'pills-shipping-center-setting-tab')) show active @endif" id="pills-shipping-center-setting" role="tabpanel" aria-labelledby="pills-shipping-center-setting-tab">
                <div id="Shipping_Center_Setting">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center gap-3">
                            <h5 class=""> {{ __('Shipping Gateway Settings') }} </h5>
                        </div>
                        {{ Form::model($setting, ['route' => 'myshipping.admin.settings.gatway.update', 'method' => 'POST', 'enctype' => 'multipart/form-data']) }}
                        <div class="card-body p-4 store-setting-tab">
                            <input type="hidden" name="app_setting_tab" value="pills-shipping-center-setting-tab">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="row ">
                                        
                                        <div class="form-group col-md-3">
                                            {{ Form::label('shipping-gateway-dropdown', __('Select Shipping Gateway'), ['class' => 'form-label']) }}
                                            {!! Form::select('active_shipping_gateway', $gateway_names, $active_shipping_gateway, [
                                            'class' => 'form-control',
                                            'data-role' => 'tagsinput',
                                            'id' => 'shipping-gateway-dropdown',
                                            ]) !!}
                                            @error('active_shipping_gateway')
                                            <span class="invalid-store_name" role="alert">
                                                <strong class="text-danger">
                                                    {{ $message }}
                                                </strong>
                                            </span>
                                            @enderror
                                        </div>

                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="row">
                                        @stack('appSettingEnableBtn')
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                        <div class="card-footer d-flex justify-content-end flex-wrap gap-1">
                            @permission('Edit Store Setting')
                            <input type="submit" value="{{ __('Save Changes') }}"
                                class="btn-submit btn btn-primary btn-badge">
                            @endpermission
                            {!! Form::close() !!}

                            
                        </div>
                    </div>
                </div>
            </div>

            <div class="tab-pane fade @if(isset($app_setting_tab) && ($app_setting_tab == 'pills-dhl-tab')) show active @endif" id="pills-dhl" role="tabpanel" aria-labelledby="pills-dhl-tab">
                <div id="DHL_Setting">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center gap-3">
                            <h5 class=""> {{ __('DHL Settings') }} </h5>                            
                        </div>
                        {{ Form::model($setting, ['route' => 'myshipping.admin.settings.update', 'method' => 'POST', 'enctype' => 'multipart/form-data']) }}

                        {{-- Hidden Gateway Name --}}
                        {!! Form::hidden('shipping_gateway_name', $setting['active_shipping_gateway'] ?? 'dhl') !!}

                        <div class="card-body p-4">
                            <input type="hidden" name="app_setting_tab" value="pills-dhl-tab">
                            <div class="row mt-2">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        
                                        {{ Form::label('dhl_api_key', __('DHL API Key *'), ['class' => 'form-label']) }}
                                        {{ Form::text('dhl_api_key', null, ['class' => 'form-control', 'placeholder' => 'Your DHL API Key']) }}
                                        @error('dhl_api_key')
                                        <span class="invalid-dhl_api_key" role="alert">
                                            <strong class="text-danger">{{ $message }}</strong>
                                        </span>
                                        @enderror
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        
                                        {{ Form::label('dhl_api_password', __('DHL API Secret *'), ['class' => 'form-label']) }}
                                        {{ Form::text('dhl_api_password', null, ['class' => 'form-control', 'placeholder' => 'Your DHL API Key Secret']) }}
                                        @error('dhl_api_password')
                                        <span class="invalid-dhl_api_password" role="alert">
                                            <strong class="text-danger">{{ $message }}</strong>
                                        </span>
                                        @enderror
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                        <div class="card-footer d-flex justify-content-end flex-wrap ">
                            @permission('Edit Store Setting')
                            <input type="submit" value="{{ __('Save Changes') }}"
                                class="btn-submit btn btn-primary btn-badge">
                            @endpermission
                        </div>
                        {!! Form::close() !!}
                    </div>
                </div>
            </div>

            <div class="tab-pane fade @if(isset($app_setting_tab) && ($app_setting_tab == 'pills-shiprocket-tab')) show active @endif" id="pills-shiprocket" role="tabpanel" aria-labelledby="pills-shiprocket-tab">
                <div id="Shiprocket_Setting">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center gap-3">
                            <h5 class=""> {{ __('Shiprocket Settings') }} </h5>                            
                        </div>
                        {{ Form::model($setting, ['route' => 'myshipping.admin.settings.update', 'method' => 'POST', 'enctype' => 'multipart/form-data']) }}

                        {{-- Hidden Gateway Name --}}
                        {!! Form::hidden('shipping_gateway_name', $setting['active_shipping_gateway'] ?? 'shiprocket') !!}

                        <div class="card-body p-4">
                            <input type="hidden" name="app_setting_tab" value="pills-shiprocket-tab">
                            <div class="row mt-2">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        
                                        {{ Form::label('shiprocket_api_user_email', __('Shiprocket API User Email *'), ['class' => 'form-label']) }}
                                        {{ Form::text('shiprocket_api_user_email', null, ['class' => 'form-control', 'placeholder' => 'email@example.com']) }}
                                        @error('shiprocket_api_user_email')
                                        <span class="invalid-google_analytic" role="alert">
                                            <strong class="text-danger">{{ $message }}</strong>
                                        </span>
                                        @enderror
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        
                                        {{ Form::label('shiprocket_api_user_password', __('Shiprocket API  User Password *'), ['class' => 'form-label']) }}
                                        {{ Form::text('shiprocket_api_user_password', null, ['class' => 'form-control', 'placeholder' => 'Your Shiprocket API Password']) }}
                                        @error('shiprocket_api_user_password')
                                        <span class="invalid-google_analytic" role="alert">
                                            <strong class="text-danger">{{ $message }}</strong>
                                        </span>
                                        @enderror
                                    </div>
                                </div>
                                
                            </div>

                            <div class="row mt-2">
                                <div class="col-md-10">
                                    <div class="form-group">
                                        {{-- The Token will be auto generated if above cred are correct --}}
                                        {{ Form::label('shiprocket_api_authorization_token', __('Shiprocket Authorization Token'), ['class' => 'form-label']) }}
                                        {{ Form::text('shiprocket_api_authorization_token', null, ['class' => 'form-control', 'placeholder' => 'Authorization Token']) }}
                                        @error('shiprocket_api_authorization_token')
                                        <span class="invalid-google_analytic" role="alert">
                                            <strong class="text-danger">{{ $message }}</strong>
                                        </span>
                                        @enderror
                                    </div>
                                </div>

                                
                                
                            </div>
                        </div>
                        <div class="card-footer d-flex justify-content-end flex-wrap ">
                            @permission('Edit Store Setting')
                            <input type="submit" value="{{ __('Save Changes') }}"
                                class="btn-submit btn btn-primary btn-badge">
                            @endpermission
                        </div>
                        {!! Form::close() !!}
                    </div>

                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center gap-3">
                            <h5 class=""> {{ __('Shiprocket Configuration Options') }} </h5>                            
                        </div>
                        {{ Form::model($setting, ['route' => 'myshipping.admin.configuration.update', 'method' => 'POST', 'enctype' => 'multipart/form-data']) }}

                        {{-- Hidden Gateway Name --}}
                        {!! Form::hidden('shipping_gateway_name', $setting['active_shipping_gateway'] ?? 'shiprocket') !!}

                        <div class="card-body p-4">
                            <input type="hidden" name="app_setting_tab" value="pills-shiprocket-tab">
                            <div class="row mt-2">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        {{-- Select pickup location which were created on the shiprocket account --}}
                                        {{ Form::label('shiprocket_pickup_location', __('Select Pickup location'), ['class' => 'form-label']) }}
                                        {{ Form::text('shiprocket_pickup_location', null, ['class' => 'form-control', 'placeholder' => 'Enter Location']) }}
                                        @error('shiprocket_pickup_location')
                                        <span class="invalid-shiprocket_pickup_location" role="alert">
                                            <strong class="text-danger">{{ $message }}</strong>
                                        </span>
                                        @enderror
                                    </div>
                                </div>

                                {{--  Auto Create Order switch --}}
                                {{-- Checking this button will auto create orders when any user place an order and complete his/her payment process. Disabling it will not take any action on automatic order creation on shiprocket. --}}

                                
                            </div>

                            
                        </div>
                        <div class="card-footer d-flex justify-content-end flex-wrap ">
                            @permission('Edit Store Setting')
                            <input type="submit" value="{{ __('Save Changes') }}"
                                class="btn-submit btn btn-primary btn-badge">
                            @endpermission
                        </div>
                        {!! Form::close() !!}
                    </div>
                </div>
            </div>

        </div>
    </div>


</div>
@endsection