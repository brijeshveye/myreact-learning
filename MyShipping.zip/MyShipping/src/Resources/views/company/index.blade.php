@extends('layouts.app')

@section('page-title')
{{ __('Shipping Center') }}
@endsection

@section('action-button')
<div class="text-end">
    {{-- <a class="btn btn-sm btn-primary btn-icon export-btn" href="{{ route('order.export') }}" data-bs-toggle="tooltip" data-bs-placement="top" title="{{ __('Export') }}" filename="{{ __('Order') }}">
        <i  class="ti ti-file-export"></i>
    </a> --}}
    {{-- <a href="{{ route('order.grid') }}" data-bs-toggle="tooltip" data-bs-original-title="{{ __('Grid View') }}" class="btn btn-sm btn-primary btn-icon ">
        <i class="ti ti-layout-grid"></i>
    </a> --}}
</div>
@endsection

@section('breadcrumb')
<li class="breadcrumb-item" aria-current="page">{{ __('Shipping Center') }}</li>
@endsection

@section('content')
{{--
this will contain sections:
1. Section one - order tracking
- waybill number or tracking number [input]
- submit btn [btn]

2. Order Creation Status [table]
ID, OrderID, Gateway, Status, Message, Date time [table]

 --}}
<div class="row mb-3">
    <div class="col-md-12">
        
        <div class="card">
            <div class="card-body">
                <h5 class="mb-4">{{ __('Order Tracking') }}</h5>
                <p class="text-muted mb-4">{{ __('Enter your tracking number to track your order.') }}</p>
                <form method="POST" action="{{ route('myshipping.admin.track') }}">
                    @csrf
                    <div class="row">
                        <div class="col-md-8">
                            <input type="text" name="tracking_number" class="form-control" placeholder="{{ __('Enter Tracking Number') }}" required>
                        </div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-primary">{{ __('Track Order') }}</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@if(session('tracking_data'))
    @php
        $tracking_data = session('tracking_data');
    @endphp

    <div class="row mb-3">
        <div class="col-md-12">
            
            <div class="card">
                <div class="card-body">
                    <h5 class="mb-4">{{ __('Tracking Details') }}</h5>
                    <p class="text-muted mb-4">{{ __('Here are the details of your tracking number.') }}</p>

                    @include("myshipping::company.track-table.{$tracking_data['gateway']}", $tracking_data)

                </div>
            </div>
        </div>
    </div>
@endif


 <div class="row">
    <div class="col-xl-12">
        <div class="card mb-4">
            <div class="card-body">
                <h5 class="mb-4">{{ __('Order Creation Status') }}</h5>
                <p class="text-muted mb-4">{{ __('This table shows the status of your order creation requests.') }}</p>
            
                <x-datatable :dataTable="$dataTable" />

            </div>
        </div>
    </div>
</div>
@endsection