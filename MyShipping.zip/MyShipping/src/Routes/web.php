<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use Illuminate\Support\Facades\Route;
use Shopyji\MyShipping\app\Http\Controllers\Company\ShippingPluginController;
use Shopyji\MyShipping\app\Http\Controllers\Company\ShippingPluginFrontendController;

// Shop Owner
Route::middleware(['auth', 'web', 'PlanModuleCheck:MyShipping'])->group(function () {
    Route::prefix('my-shipping')->name('myshipping.admin.')->group(function () {
        Route::get("/", [ShippingPluginController::class, "index"])->name("index");
        Route::post("track", [ShippingPluginController::class, "track"])->name("track");

        Route::get("create-order/{order_id}", [ShippingPluginController::class, "createOrder"])->name("order.create");

        Route::get("settings", [ShippingPluginController::class, "settings"])->name("settings");
        Route::post("settings/gateway/update", [ShippingPluginController::class, "updateShippingGateway"])->name("settings.gatway.update");
        Route::post("settings/update", [ShippingPluginController::class, "updateSettings"])->name("settings.update");
        Route::post("configuration/update", [ShippingPluginController::class, "updateConfiguration"])->name("configuration.update");

        Route::get("status", [ShippingPluginController::class, "changeStatus"])->name("status.change");

        Route::get("assets/shipping-gateway/logo/{logo}", function ($logo){
                return response()->file("core/Modules/ShippingPlugin/assets/logo/{$logo}");
        })->name("logo");
    });
});

// Customers
Route::middleware(['web'])->name('myshipping.customer.')->group(function () {
    Route::post("shipping-plugin/track", [ShippingPluginFrontendController::class, "track"])->name("track");
});