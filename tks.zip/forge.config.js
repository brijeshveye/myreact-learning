module.exports = {
  packagerConfig: {
    icon: 'src/assets/images/favicon', // Don't include extension (.ico will be picked automatically on Windows)
  },
  makers: [
    {
      name: '@electron-forge/maker-nsis',
      config: {
        oneClick: false,
        perMachine: false,
        allowToChangeInstallationDirectory: true,
        installerIcon: 'src/assets/images/favicon.ico',
        uninstallerIcon: 'src/assets/images/favicon.ico',
        createDesktopShortcut: true,
        createStartMenuShortcut: true,
        shortcutName: 'Taskly Tracker',
      },
    },
    {
      name: '@electron-forge/maker-zip',
      platforms: ['darwin'],
    },
    {
      name: '@electron-forge/maker-deb',
      config: {},
    },
    {
      name: '@electron-forge/maker-rpm',
      config: {},
    },
  ],
};
