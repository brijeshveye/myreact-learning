const { app, BrowserWindow, dialog } = require('electron');
const path = require('path');
const { ipcMain } = require('electron');
const fs = require('fs');
var force_quit = false;
// Handle creating/removing shortcuts on Windows when installing/uninstalling.
// if (require('electron-squirrel-startup')) { // eslint-disable-line global-require
//     app.quit();
// }

let rawdata = fs.readFileSync(path.resolve(__dirname, 'env-config.json'));
let config = JSON.parse(rawdata);

function compareSemver(a, b) {
    // returns 1 if a>b, -1 if a<b, 0 if equal
    const pa = String(a || '0').split('.').map(n => parseInt(n, 10) || 0);
    const pb = String(b || '0').split('.').map(n => parseInt(n, 10) || 0);
    const len = Math.max(pa.length, pb.length);
    for (let i = 0; i < len; i++) {
        const ai = pa[i] || 0;
        const bi = pb[i] || 0;
        if (ai > bi) return 1;
        if (ai < bi) return -1;
    }
    return 0;
}

function checkForUpdate(mainWindow) {
    try {
        const urlStr = (config.UPDATE_CHECK_URL && String(config.UPDATE_CHECK_URL).trim()) || '';
        if (!urlStr) return; // no update url configured

        const urlObj = new URL(urlStr);
        const mod = urlObj.protocol === 'https:' ? require('https') : require('http');

        const req = mod.request(urlObj, { method: 'GET', timeout: 5000 }, (res) => {
            let data = '';
            res.on('data', (chunk) => (data += chunk));
            res.on('end', () => {
                try {
                    const json = JSON.parse(data);
                    // Expecting shape: { latest_version: "1.2.3", notes?: "..." }
                    const latest = json.latest_version || json.version || json.latest || '';
                    const current = config.VERSION || app.getVersion();

                    if (latest && compareSemver(latest, current) === 1) {
                        const appName = config.APP_NAME || 'Taskly Tracker';
                        const message = `${appName} update available`;
                        const detail = config.IT_CONTACT_MESSAGE || 'A new version is available. Please contact the IT Department to get the latest update.';
                        dialog.showMessageBox(mainWindow, {
                            type: 'info',
                            buttons: ['OK'],
                            defaultId: 0,
                            title: `${appName} Update`,
                            message,
                            detail
                        });
                    }
                } catch (e) {
                    // ignore parse errors silently
                }
            });
        });
        req.on('error', () => { /* ignore */ });
        req.on('timeout', () => { try { req.destroy(); } catch (_) {} });
        req.end();
    } catch (e) {
        // ignore
    }
}



ipcMain.on('close-me', (evt, arg) => {
    force_quit = true;
    app.quit();
})
const createWindow = () => {
    // Create the browser window.
    const mainWindow = new BrowserWindow({
        width: 400, // Perfect Width for view
        // width: 1000, // For Testing Purpose
        height: 600,
        icon: __dirname + config.LOGO,
        webPreferences: {
            nodeIntegration: true,
            contextIsolation: false,
            enableRemoteModule: true,
        },
        resizable: true
    });

    // This opens DevTools
    mainWindow.webContents.openDevTools();

    // mainWindow.maximize();
    mainWindow.show();
    mainWindow.removeMenu();

    // and load the index.html of the app.
    mainWindow.loadFile(path.join(__dirname, 'index.html'));

    // Open the DevTools.
    // mainWindow.webContents.openDevTools();
    mainWindow.on('close', function(e) {
        if (!force_quit) {
            e.preventDefault();
        }
    });
    // mainWindow.on("close", (e) => {
    //     e.preventDefault();
    //     // var check = document.getElementById("time-tracking").getAttribute("data-tracking");
    //     // if(check == 'on'){
    //     //     if(confirm('Tracker is On . are you sore close app ?')){
    //     //         document.getElementById("time-tracking").click();
    //     //         setTimeout(function(){
    //     //             mainWindow.hide();
    //     //         },300)
    //     //         console.log('yes')
    //     //     }else{
    //     //         console.log('no');
    //     //     }
    //     // }else{
    //     //     mainWindow.hide();
    //     // }
    //     // Dereference the window object, usually you would store windows
    //     // in an array if your app supports multi windows, this is the time
    //     // when you should delete the corresponding element.
    //     // mainWindow = null;
    // });
    mainWindow.on('closed', function() {
        console.log("closed");
        mainWindow = null;
        app.quit();
    });

    // Check for app updates after window shows
    try { checkForUpdate(mainWindow); } catch (e) {}
};

// This method will be called when Electron has finished
// initialization and is ready to create browser windows.
// Some APIs can only be used after this event occurs.
// app.on('ready', createWindow);
app.on('ready', function() {
    createWindow();
});
// Quit when all windows are closed, except on macOS. There, it's common
// for applications and their menu bar to stay active until the user quits
// explicitly with Cmd + Q.
app.on('window-all-closed', () => {
    // if (process.platform !== 'darwin') {
    //     app.quit();
    // }
});

app.on('activate', () => {
    // On OS X it's common to re-create a window in the app when the
    // dock icon is clicked and there are no other windows open.
    if (BrowserWindow.getAllWindows().length === 0) {
        createWindow();
    }
});

// In this file you can include the rest of your app's specific main process
// code. You can also put them in separate files and import them here.
