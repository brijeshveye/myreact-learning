const electron = require('electron');
const { ipcRenderer } = require('electron');
const remote = electron.remote;
const BrowserWindow = remote.BrowserWindow;

const { dialog, getCurrentWindow, globalShortcut } = electron.remote;
// const fs = require('fs');
// const path = require('path');
// const config = require('../../env-config.json');
// console.log(config);
var shotTime = getShotTime() * 1000 * 60; // 1000 = 1 second
var showShot = 5 * 1000; // 1000 = 1 second
var appUrl = getApi();

if(appUrl !=null && appUrl.substr(-1) == '/') {
    appUrl = appUrl.substr(0, appUrl.length - 1);
}
apiUrl = appUrl + '/api/';

// ========================= Notification Utilities =========================
function showToast(type, message, title) {
    try {
        if (window.Swal && typeof Swal.mixin === 'function') {
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true
            });
            const opts = { icon: type || 'info' };
            if (title) { opts.title = title; opts.text = message; }
            else { opts.title = message; }
            Toast.fire(opts);
            return;
        }
        if (window.$ && $.notify) {
            $.notify({
                message: (title ? ('<strong>' + title + '</strong><br/>') : '') + (message || '')
            }, {
                type: (type === 'error' ? 'danger' : (type || 'info')),
                delay: 3000,
                placement: { from: 'top', align: 'right' }
            });
            return;
        }
        // Fallback
        alert((title ? title + ': ' : '') + (message || ''));
    } catch (e) { 
        console.log('Notification error', e);
     }
}

function showConfirm(options) {
    const {
        title = 'Are you sure?',
        text = '',
        icon = 'question',
        confirmButtonText = 'Yes',
        cancelButtonText = 'Cancel'
    } = options || {};
    if (window.Swal && typeof Swal.fire === 'function') {
        return Swal.fire({
            title, text, icon,
            showCancelButton: true,
            confirmButtonText,
            cancelButtonText,
            reverseButtons: true
        });
    }
    const ok = confirm(title + (text ? ('\n' + text) : ''));
    return Promise.resolve({ isConfirmed: ok });
}

$(document).ready(function() {


    let current_datetime = new Date();
    // See Password
    var e = $('[data-toggle="password-text"]');
    e.length && e.on("click", function(e) {
        var t, a;
        t = $(this), "password" == (a = $(t.data("target"))).attr("type") ? a.attr("type", "text") : a.attr("type", "password")
    })

    // Get localstorage data
    var user_data = JSON.parse(localStorage.getItem('user_data'));
    var task_data = JSON.parse(localStorage.getItem('curant_task'));

    // Check if users information is available or not
    if (user_data != null && user_data._token != null) {
        if (user_data.user_name != null) {
            // change some html if needed. like set profile photo and username
        }

        $('#login_section').addClass('d-none');
        $('#tracker_section').removeClass('d-none');

        // Get Projects and Tasks
        if (user_data.avatar != '' && user_data.avatar.match(/^http.*\.(jpeg|jpg|gif|png)$/) != null) {
            console.log(user_data);
            $('.img_avatar img').attr("src", user_data.avatar);
        }

        $('.user_name').text(user_data.user_name);
        appUrl = localStorage.getItem('clockgo_api_end_point');

        // Populate profile information
        populateProfileInfo();

    // Load attendance summary and update UI
    fetchAttendanceSummary();
    // Initialize idle monitor after session restore
    initIdleMonitor();

        // getProjectTask();
        getWorkSpace();
    } else {
        console.log('User Not logged in');
    }

});

// login button click
if ($('#login_btn').length > 0) {
    $(document).on('click', '#login_btn', function() {

        $('#site_url').removeClass('is-invalid');
        $('#email').removeClass('is-invalid');
        $('#password').removeClass('is-invalid');
        $('.email-error-text').text('').show();
        $('.site-error-text').text('').show();
        $('.passwprd-error-text').text('').show();

        var check = LoginValidation();
        if (check == false) {
            return false;
        }
        var frm_email = $("#email").val();
        var frm_password = $("#password").val();
        var site_end_point = $('#site_url').val();
        if(site_end_point.substr(-1) == '/') {
            site_end_point = site_end_point.substr(0, site_end_point.length - 1);
        }
        var apiUrl =  site_end_point+ '/api/';
        
        var data = { email: frm_email, password: frm_password };

        $.ajax({
            url: apiUrl + 'login',
            method: 'POST',
            data: JSON.stringify(data),
            dataType: 'JSON',
            cache: false,
            headers: {
                'Content-Type': 'application/json'
            },
            success: function(response) {
                if (response.is_success == true) {
                    try { showToast('success', 'Login successful'); } catch(e){}
                    $('#site_url').addClass('is-valid');
                    $('#email').addClass('is-valid');
                    $('#password').addClass('is-valid');
                    $('.email-error-text').text('').hide();
                    $('.site-error-text').text('').hide();
                    $('.password-error-text').text('').hide();
                    var arr_token = {
                        '_token': response.data.token,
                        'user_name': response.data.user.name,
                        'avatar': appUrl + 'storage/' + response.data.user.avatar,
                        'shot_time': response.data.settings.shot_time,
                        'show_shot': response.data.settings.show_shot,
                    };

                    // set token in localstorage
                    localStorage.setItem('user_data', JSON.stringify(arr_token));
                    localStorage.setItem('clockgo_api_end_point', $('#site_url').val());
                    var user_data = JSON.parse(localStorage.getItem('user_data'));

                    if (user_data != null && user_data._token != null) {
                        console.log('User Logged in Successfully');
                        setTimeout(function() {
                            getCurrentWindow().reload();
                            $('#login_section').addClass('d-none');
                            $('#tracker_section').removeClass('d-none');
                            // Get Projects and Tasks
                            $('.img_avatar img').attr("src", user_data.avatar);
                            $('.user_name').text(user_data.user_name);
                            populateProfileInfo();
                            getProjectTask();
                        }, 1000);

                    }
                } else {
                    $('#err_login').html('');
                    $('#err_login').html(response.message);
                    try { showToast('error', response.message || 'Login failed'); } catch(e){}
                }
            },
            statusCode: {
                404: function() {
                    $('#site_url').addClass('is-invalid');
                    $('.site-error-text').text('( please enter a valid site url )').show();
                    try { showToast('error', 'Invalid site URL'); } catch(e){}
                },
                422: function(data) {
                    $('#email').addClass('is-invalid');
                    $('#password').addClass('is-invalid');
                    $('.email-error-text').text('( please enter a valid email )').show();
                    $('.password-error-text').text('( please enter a valid password )').show();
                    try { showToast('error', 'Please enter a valid email and password'); } catch(e){}
                },
                401: function(data) {
                    $('#email').addClass('is-invalid');
                    $('#password').addClass('is-invalid');
                    $('.email-error-text').text('( please enter a valid password )').show();
                    try { showToast('error', 'Invalid credentials'); } catch(e){}
                },
                0: function() {
                    $('#site_url').addClass('is-invalid');
                    $('.site-error-text').text('( please enter a valid site url )').show();
                    try { showToast('error', 'Unable to reach the server'); } catch(e){}
                },
            },
            error: function(err) {
                console.log(err);
                try { showToast('error', 'Login request failed'); } catch(e){}
                return false;
            }
        })
    })
}

// $(document).on('click','#close_app',function(e){



// });


// Logout Button Click
if ($('#logout-click').length > 0) {

    $(document).on('click', '#logout-click', function() {
        let win = remote.getCurrentWindow();

        var check = $("#time-tracking").attr('data-tracking');
        var msg = "Do you really want to quit?";
        if (check == 'on') {
            msg = 'Tracke is on, Do you really want to logout?'
        }

        dialog.showMessageBox(
                win, {
                    title: 'Confirm',
                    message: msg,
                    buttons: ["Yes", "Cancel"],
                    defaultId: 0, // bound to buttons array
                    cancelId: 1 // bound to buttons array
                })
            .then(result => {
                if (result.response === 0) {
                    // bound to buttons array
                    $("#time-tracking").trigger('click');
                    setTimeout(function() {
                        $.ajax({
                            url: apiUrl + 'logout',
                            method: 'POST',
                            dataType: 'JSON',
                            cache: false,
                            headers: {
                                'Content-Type': 'application/json',
                                'Authorization': 'Bearer ' + JSON.parse(localStorage.getItem('user_data'))._token
                            },
                            success: function(response) {
                                $('#site_url').val('');
                                $('#email').val('');
                                $('#password').val('');
                                $('#site_url').removeClass('is-invalid').removeClass('is-valid');
                                $('#email').removeClass('is-invalid').removeClass('is-valid');
                                $('#password').removeClass('is-invalid').removeClass('is-valid');

                                if (response.is_success == true) {
                                    try { showToast('success', 'Logged out successfully'); } catch(e){}
                                    localStorage.removeItem('user_data');
                                    var user_data = JSON.parse(localStorage.getItem('user_data'));
                                    if (user_data == null) {
                                        $('#tracker_section').addClass('d-none');
                                        $('#login_section').removeClass('d-none');
                                    }
                                } else {
                                    console.log('Something Went Wrong.!!');
                                    try { showToast('error', 'Logout failed'); } catch(e){}
                                }
                            },
                            error: function(err) {
                                $('#site_url').val('');
                                $('#email').val('');
                                $('#password').val('');
                                $('#site_url').removeClass('is-invalid').removeClass('is-valid');
                                $('#email').removeClass('is-invalid').removeClass('is-valid');
                                $('#password').removeClass('is-invalid').removeClass('is-valid');
                                localStorage.removeItem('user_data');
                                var user_data = JSON.parse(localStorage.getItem('user_data'));
                                if (user_data == null) {
                                    $('#tracker_section').addClass('d-none');
                                    $('#login_section').removeClass('d-none');
                                }
                                console.log(err);
                                try { showToast('error', 'Logout request failed'); } catch(e){}
                                return false;
                            }
                        })
                    }, 700);
                } else if (result.response === 1) {
                    // bound to buttons array
                    e.preventDefault();
                }
            });

    });
}
/* Update Billable Doller Icon
----------------------------------------*/
$(document).on('click', '.update_billable', function(e) {
    if ($(this).hasClass('doller-non-billable')) {
        $("input[name='is_billable']").val(1);
        $(this).removeClass('doller-non-billable');
        $(this).addClass('doller-billable-blue');
    } else {
        $("input[name='is_billable']").val(0);
        $(this).removeClass('doller-billable-blue');
        $(this).addClass('doller-non-billable');
    }

});
// Tracking button click
if ($('#time-tracking').length > 0) {
    $(document).on('click', '#time-tracking', function() {
        let current_datetime = new Date();
        var tracker_btn = $(this);
        if (tracker_btn.attr('data-tracking') == 'off') {
            tracker_btn.removeClass('btn-success');
            tracker_btn.addClass('btn-danger');
            tracker_btn.attr('data-tracking', 'on');
            tracker_btn.html('Stop Tracking');
            // Badge Changes
            $('#tracking-badge').removeClass('badge-danger');
            $('#tracking-badge').addClass('badge-success');
            $('#tracking-badge').html('On');
            TrackerTimer('start', current_datetime);
        } else {
            tracker_btn.removeClass('btn-danger');
            tracker_btn.addClass('btn-success');
            tracker_btn.attr('data-tracking', 'off');
            tracker_btn.html('Start Tracking');
            // Badge Changes
            $('#tracking-badge').removeClass('badge-success');
            $('#tracking-badge').addClass('badge-danger');
            $('#tracking-badge').html('Off');
            TrackerTimer('end', current_datetime);
        }
    })
}

$(document).on('click', '#refresh', function() {
    // By BR
    // getWorkSpace();
    getProjectTask();
});

// Attendance: Clock In/Out
$(document).on('click', '#clock-toggle', function(e) {
    e.preventDefault();
    const isClockedIn = $('#clock-toggle .clock-text').text().toLowerCase().indexOf('out') !== -1;
    const actionLabel = isClockedIn ? 'Clock Out' : 'Clock In';
    showConfirm({
        title: actionLabel + ' now?',
        text: 'This will update your attendance status.',
        icon: 'question',
        confirmButtonText: actionLabel,
        cancelButtonText: 'Cancel'
    }).then((res) => {
        if (res && (res.isConfirmed || res.value === true)) {
            toggleClock();
        }
    });
});

// Attendance: Start/End Break
$(document).on('click', '#break-toggle', function(e) {
    e.preventDefault();
    const isEnding = $('#break-toggle .break-text').text().toLowerCase().indexOf('end') !== -1;
    const actionLabel = isEnding ? 'End Break' : 'Start Break';
    showConfirm({
        title: actionLabel + '?',
        text: isEnding ? 'You will resume your work session.' : 'You will pause your work session.',
        icon: 'question',
        confirmButtonText: actionLabel,
        cancelButtonText: 'Cancel'
    }).then((res) => {
        if (res && (res.isConfirmed || res.value === true)) {
            toggleBreak();
        }
    });
});

// Back to tracker button click
$(document).on('click', '#back-to-tracker', function() {
    // Switch back to tracker view
    $('#v-pills-profile').removeClass('show active');
    $('#v-pills-reports').removeClass('show active');
    $('#v-pills-home').addClass('show active');
    
    // Update tab styling
    $('.img_avatar').parent().removeClass('active').attr('aria-selected', 'false');
    $('#v-pills-reports-tab').removeClass('active').attr('aria-selected', 'false');
    $('#v-pills-home-tab').addClass('active').attr('aria-selected', 'true');
});

// User avatar click - toggle between profile and tracker view
$(document).on('click', '.img_avatar, .user_name', function(e) {
    e.preventDefault();
    
    // Check if we're currently on profile view
    if ($('#v-pills-profile').hasClass('show active')) {
        // Switch back to tracker view
        $('#v-pills-home-tab').tab('show');
    } else {
        // Switch to profile view
        populateProfileInfo();
        $('#v-pills-profile').addClass('tab-pane fade show active');
        $('#v-pills-home').removeClass('show active');
        $('#v-pills-reports').removeClass('show active');
        
        // Update the tab styling
        $('#v-pills-home-tab').removeClass('active').attr('aria-selected', 'false');
        $('#v-pills-reports-tab').removeClass('active').attr('aria-selected', 'false');
        $('.img_avatar').parent().addClass('active').attr('aria-selected', 'true');
    }
});

// Reports tab click - load reports data
$(document).on('click', '#v-pills-reports-tab', function() {
    loadReportsData();
});

// Back to tracker from reports
$(document).on('click', '#back-to-tracker-from-reports', function() {
    $('#v-pills-home-tab').trigger('click');
});

// Refresh reports button
$(document).on('click', '#refresh-reports', function() {
    loadReportsData();
});

// Profile tab click - populate profile data
$(document).on('click', '#v-pills-profile-tab', function() {
    populateProfileInfo();
});

// Function to populate profile information
function populateProfileInfo() {
    var user_data = JSON.parse(localStorage.getItem('user_data'));
    var site_url = localStorage.getItem('clockgo_api_end_point');
    
    if (user_data != null) {
        // Set profile avatar
        if (user_data.avatar != '' && user_data.avatar.match(/^http.*\.(jpeg|jpg|gif|png)$/) != null) {
            $('.profile-avatar').attr("src", user_data.avatar);
        } else {
            $('.profile-avatar').attr("src", "assets/images/avatar.png");
        }
        
        // Set profile information
        $('.profile-user-name').text(user_data.user_name || 'N/A');
        $('.profile-name').text(user_data.user_name || 'N/A');
        $('.profile-user-id').text(user_data.user_id || 'N/A');
        
        // Set settings information
        $('.profile-shot-time').text((user_data.shot_time || 10) + ' minutes');
        $('.profile-show-shot').text((user_data.show_shot || 2) + ' seconds');
        
        // Try to get email from login form if available
        var email = $('#email').val();
        if (email && email !== '') {
            $('.profile-user-email').text(email);
            $('.profile-email').text(email);
        } else {
            $('.profile-user-email').text('N/A');
            $('.profile-email').text('N/A');
        }
    }
}

// ========================= Attendance Helpers =========================
function fetchAttendanceSummary() {
    try {
        let today = new Date();
        let dateStr = today.getFullYear() + '-' + String(today.getMonth() + 1).padStart(2, '0') + '-' + String(today.getDate()).padStart(2, '0');
        var w_id = getCurrantWorkspace();

        $.ajax({
            url: apiUrl + 'attendance/summary?date=' + dateStr + (w_id ? ('&workspace_id=' + w_id) : ''),
            method: 'GET',
            cache: false,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + JSON.parse(localStorage.getItem('user_data'))._token
            },
            success: function(response) {
                if (response && response.is_success) {
                    updateAttendanceUI(response.data || {});
                } else {
                    // Safe defaults
                    updateAttendanceUI({ is_clocked_in: false, total_seconds: 0, total_break_seconds: 0, break_quota_seconds: 3600, is_on_break: false });
                }
            },
            error: function() {
                // Keep UI safe
                updateAttendanceUI({ is_clocked_in: false, total_seconds: 0, total_break_seconds: 0, break_quota_seconds: 3600, is_on_break: false });
            }
        });
    } catch (e) {
        console.log('Attendance summary error', e);
    }
}

function updateAttendanceUI(data) {
    // Totals
    const total = secondsToHMS(data.total_seconds || 0);
    const breakUsed = secondsToHMS(data.total_break_seconds || 0);
    const breakLeftSec = Math.max(0, (data.break_quota_seconds || 3600) - (data.total_break_seconds || 0));
    const breakLeft = secondsToHMS(breakLeftSec);

    $('#stats-total-time').text(total);
    $('#stats-break-time').text(breakUsed);
    $('#stats-break-left').text(breakLeft);

    // Attendance badge and buttons
    const clockedIn = !!data.is_clocked_in;
    const onBreak = !!data.is_on_break;

    if (clockedIn) {
        $('#attendance-badge').removeClass('badge-light').addClass(onBreak ? 'badge-warning' : 'badge-success').text(onBreak ? 'On Break' : 'On Duty');
        $('#clock-toggle').removeClass('btn-outline-success').addClass('btn-outline-danger');
        $('#clock-toggle .clock-text').text('Clock Out');
        $('#break-toggle').prop('disabled', false);
        if (onBreak) {
            $('#break-toggle').removeClass('btn-outline-warning').addClass('btn-outline-info');
            $('#break-toggle .break-text').text('End Break');
            // Disable task tracking while on break
            $('#time-tracking').attr('disabled', 'disabled');
        } else {
            $('#break-toggle').removeClass('btn-outline-info').addClass('btn-outline-warning');
            $('#break-toggle .break-text').text('Start Break');
            // Allow task tracking
            if ($("input[name='selected_task']:checked").length) {
                $('#time-tracking').removeAttr('disabled');
            }
        }
    } else {
        $('#attendance-badge').removeClass('badge-success badge-warning').addClass('badge-light').text('Off Duty');
        $('#clock-toggle').removeClass('btn-outline-danger').addClass('btn-outline-success');
        $('#clock-toggle .clock-text').text('Clock In');
        $('#break-toggle').prop('disabled', true).removeClass('btn-outline-info').addClass('btn-outline-warning');
        $('#break-toggle .break-text').text('Start Break');
        // Disable task tracking when off duty
        $('#time-tracking').attr('disabled', 'disabled');
    }
}

function toggleClock() {
    // Determine action
    const isClockedIn = $('#clock-toggle .clock-text').text().toLowerCase().indexOf('out') !== -1; // true means currently clocked in
    const actionUrl = apiUrl + (isClockedIn ? 'attendance/clock-out' : 'attendance/clock-in');

    // If user is currently idle, end the idle interval before toggling clock state
    try { if (typeof isIdle !== 'undefined' && isIdle) { endIdleInterval(); } } catch (e) { /* no-op */ }

    let now = new Date();
    let dt = now.getFullYear() + '-' + (now.getMonth()+1) + '-' + now.getDate() + ' ' + now.getHours() + ':' + now.getMinutes() + ':' + now.getSeconds();
    var w_id = getCurrantWorkspace();
    const payload = { time: dt, workspaces_id: w_id };

    var req = $.ajax({
        url: actionUrl,
        method: 'POST',
        data: JSON.stringify(payload),
        dataType: 'JSON',
        cache: false,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + JSON.parse(localStorage.getItem('user_data'))._token
        },
        success: function(resp) {
            if (resp && resp.is_success) {
                fetchAttendanceSummary();
            }
        },
        error: function(err) { console.log('Clock toggle error', err); }
    });

    // Toast feedback
    var msg = isClockedIn ? 'Clocked out successfully' : 'Clocked in successfully';
    req.done(function(){ try { showToast('success', msg); } catch(e){} })
       .fail(function(){ try { showToast('error', 'Failed to ' + (isClockedIn ? 'clock out' : 'clock in')); } catch(e){} });
}

function toggleBreak() {
    const isEnding = $('#break-toggle .break-text').text().toLowerCase().indexOf('end') !== -1;
    const actionUrl = apiUrl + (isEnding ? 'attendance/break-end' : 'attendance/break-start');

    // If user is currently idle, end the idle interval before toggling break state
    try { if (typeof isIdle !== 'undefined' && isIdle) { endIdleInterval(); } } catch (e) { /* no-op */ }
    let now = new Date();
    let dt = now.getFullYear() + '-' + (now.getMonth()+1) + '-' + now.getDate() + ' ' + now.getHours() + ':' + now.getMinutes() + ':' + now.getSeconds();
    var w_id = getCurrantWorkspace();
    const payload = { time: dt, workspaces_id: w_id };

    var req = $.ajax({
        url: actionUrl,
        method: 'POST',
        data: JSON.stringify(payload),
        dataType: 'JSON',
        cache: false,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + JSON.parse(localStorage.getItem('user_data'))._token
        },
        success: function(resp) {
            if (resp && resp.is_success) {
                fetchAttendanceSummary();
            }
        },
        error: function(err) { console.log('Break toggle error', err); }
    });
    var bmsg = isEnding ? 'Break ended' : 'Break started';
    req.done(function(){ try { showToast('info', bmsg); } catch(e){} })
       .fail(function(){ try { showToast('error', 'Failed to ' + (isEnding ? 'end break' : 'start break')); } catch(e){} });
}

function secondsToHMS(totalSeconds) {
    totalSeconds = Math.max(0, parseInt(totalSeconds || 0, 10));
    const h = Math.floor(totalSeconds / 3600);
    const m = Math.floor((totalSeconds % 3600) / 60);
    const s = totalSeconds % 60;
    return String(h).padStart(2,'0') + ':' + String(m).padStart(2,'0') + ':' + String(s).padStart(2,'0');
}

// ========================= Idle Monitor =========================
const IDLE_THRESHOLD_MIN = 5; // default 5 minutes; consider making configurable via settings
let lastActivityTs = Date.now();
let idleCheckTimer = null;
let isIdle = false;
let currentIdleId = null;

function initIdleMonitor() {
    const activityEvents = 'mousemove keydown mousedown wheel touchstart scroll';
    $(document).on(activityEvents, resetIdleActivity);
    $(window).on('focus', resetIdleActivity);

    if (idleCheckTimer) clearInterval(idleCheckTimer);
    idleCheckTimer = setInterval(checkIdleStatus, 30000); // every 30s
}

function resetIdleActivity() {
    lastActivityTs = Date.now();
    if (isIdle) {
        endIdleInterval();
    }
}

function checkIdleStatus() {
    // Eligible only when clocked in and not on break
    const isClockedIn = $('#clock-toggle .clock-text').text().toLowerCase().indexOf('out') !== -1;
    const onBreak = $('#break-toggle .break-text').text().toLowerCase().indexOf('end') !== -1;
    if (!isClockedIn || onBreak) {
        if (isIdle) endIdleInterval();
        return;
    }

    const idleSec = Math.floor((Date.now() - lastActivityTs) / 1000);
    const thresholdSec = (IDLE_THRESHOLD_MIN || 5) * 60;
    if (!isIdle && idleSec >= thresholdSec) {
        startIdleInterval(new Date(Date.now() - idleSec * 1000));
    }
}

function startIdleInterval(startDate) {
    isIdle = true;
    // Mark UI as idle (distinct from break)
    $('#attendance-badge').removeClass('badge-success badge-warning badge-light').addClass('badge-info').text('Idle');
    // Disable manual tracking during idle
    $('#time-tracking').attr('disabled', 'disabled');

    var w_id = getCurrantWorkspace();
    const payload = {
        time: formatDateTime(startDate),
        workspaces_id: w_id,
        tracker_id: $('#currant_trak_id').val() || null
    };

    var req = $.ajax({
        url: apiUrl + 'attendance/idle-start',
        method: 'POST',
        data: JSON.stringify(payload),
        dataType: 'JSON',
        cache: false,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + JSON.parse(localStorage.getItem('user_data'))._token
        },
        success: function(resp) {
            if (resp && resp.is_success && resp.data && resp.data.id) {
                currentIdleId = resp.data.id;
            }
        },
        error: function(err) { console.log('idle-start error', err); }
    });
    req.done(function(){ try { showToast('info', 'Idle detected'); } catch(e){} })
       .fail(function(){ try { showToast('error', 'Failed to mark idle'); } catch(e){} });
}

function endIdleInterval() {
    if (!isIdle) return;
    isIdle = false;

    // Restore UI state by refetching summary
    fetchAttendanceSummary();

    var w_id = getCurrantWorkspace();
    const payload = {
        time: formatDateTime(new Date()),
        workspaces_id: w_id,
        idle_id: currentIdleId || null
    };

    var req = $.ajax({
        url: apiUrl + 'attendance/idle-end',
        method: 'POST',
        data: JSON.stringify(payload),
        dataType: 'JSON',
        cache: false,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + JSON.parse(localStorage.getItem('user_data'))._token
        },
        success: function(resp) {
            currentIdleId = null;
            fetchAttendanceSummary();
        },
        error: function(err) { console.log('idle-end error', err); }
    });
    req.done(function(){ try { showToast('success', 'Welcome back! You are active.'); } catch(e){} })
       .fail(function(){ try { showToast('error', 'Failed to end idle'); } catch(e){} });
}

// Global AJAX error fallback (lightweight)
$(document).ajaxError(function(event, jqxhr, settings, thrownError) {
    try {
        if (jqxhr && jqxhr.status === 0) {
            showToast('error', 'Network error. Please check your connection.');
        }
    } catch (e) { /* noop */ }
});

function formatDateTime(d) {
    const pad = (n) => (n < 10 ? '0' + n : '' + n);
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
}

// Function to load reports data
function loadReportsData() {
    // Show loading state
    $('#time-entries-list').html(`
        <div class="list-group-item text-center py-5">
            <i class="fas fa-spinner fa-spin fa-2x text-muted mb-3"></i>
            <p class="text-muted mb-0">Loading time entries...</p>
        </div>
    `);
    
    // Get current date in YYYY-MM-DD format
    let today = new Date();
    let dateStr = today.getFullYear() + '-' + 
                  String(today.getMonth() + 1).padStart(2, '0') + '-' + 
                  String(today.getDate()).padStart(2, '0');
    
    // Get user workspace
    var w_id = getCurrantWorkspace();
    
    $.ajax({
        url: apiUrl + 'get-daily-reports?date=' + dateStr + '&workspace_id=' + w_id,
        method: 'GET',
        cache: false,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + JSON.parse(localStorage.getItem('user_data'))._token
        },
        success: function(response) {
            if (response.is_success == true) {
                displayReportsData(response.data);
            } else {
                showReportsError('Failed to load reports data.');
            }
        },
        error: function(xhr, status, error) {
            console.log('Reports Error:', error);
            showReportsError('Unable to connect to server. Please check your connection.');
            try { showToast('error', 'Failed to load today\'s report'); } catch(e){}
        }
    });
}

// Function to display reports data
function displayReportsData(data) {
    // Update total time
    let totalSeconds = data.total_seconds || 0;
    let totalTime = formatDuration(totalSeconds);
    $('#total-time-today').text(totalTime);
    
    // Build time entries list
    let entriesHtml = '';
    
    if (data.entries && data.entries.length > 0) {
        data.entries.forEach(function(entry) {
            let duration = formatDuration(entry.duration_seconds || 0);
            let startTime = formatTime(entry.start_time);
            let endTime = entry.end_time ? formatTime(entry.end_time) : 'In Progress';
            let status = entry.end_time ? 'completed' : 'running';
            let statusClass = status === 'running' ? 'badge-success' : 'badge-secondary';
            let statusIcon = status === 'running' ? 'fa-play' : 'fa-check';
            
            entriesHtml += `
                <div class="list-group-item">
                    <div class="row align-items-center">
                        <div class="col">
                            <div class="d-flex align-items-center">
                                <div class="avatar avatar-sm rounded-circle bg-primary text-white mr-3">
                                    <i class="fas ${statusIcon}"></i>
                                </div>
                                <div>
                                    <h6 class="mb-1">${entry.task_name || 'Unknown Task'}</h6>
                                    <p class="text-muted mb-0 small">${entry.project_name || 'No Project'}</p>
                                    ${entry.description ? `<p class="text-muted mb-0 small"><i class="fas fa-comment mr-1"></i>${entry.description}</p>` : ''}
                                </div>
                            </div>
                        </div>
                        <div class="col-auto text-right">
                            <div class="d-flex align-items-center">
                                <div class="mr-3">
                                    <div class="text-sm font-weight-bold">${duration}</div>
                                    <div class="text-xs text-muted">${startTime} - ${endTime}</div>
                                </div>
                                <span class="badge ${statusClass}">
                                    <i class="fas ${statusIcon} mr-1"></i>${status === 'running' ? 'Running' : 'Complete'}
                                </span>
                                ${entry.is_billable ? '<i class="fas fa-dollar-sign text-success ml-2" title="Billable"></i>' : ''}
                            </div>
                        </div>
                    </div>
                </div>
            `;
        });
    } else {
        entriesHtml = `
            <div class="list-group-item text-center py-5">
                <i class="fas fa-clock fa-2x text-muted mb-3"></i>
                <h6 class="text-muted">No time entries for today</h6>
                <p class="text-muted mb-0 small">Start tracking time to see your entries here.</p>
            </div>
        `;
    }
    
    $('#time-entries-list').html(entriesHtml);
}

// Function to show reports error
function showReportsError(message) {
    $('#time-entries-list').html(`
        <div class="list-group-item text-center py-5">
            <i class="fas fa-exclamation-triangle fa-2x text-warning mb-3"></i>
            <h6 class="text-muted">Error Loading Reports</h6>
            <p class="text-muted mb-0 small">${message}</p>
            <button class="btn btn-sm btn-outline-primary mt-3" onclick="loadReportsData()">
                <i class="fas fa-retry mr-1"></i>Try Again
            </button>
        </div>
    `);
}

// Utility function to format duration from seconds to HH:MM:SS
function formatDuration(seconds) {
    let hours = Math.floor(seconds / 3600);
    let minutes = Math.floor((seconds % 3600) / 60);
    let secs = seconds % 60;
    
    return String(hours).padStart(2, '0') + ':' + 
           String(minutes).padStart(2, '0') + ':' + 
           String(secs).padStart(2, '0');
}

// Utility function to format time string to display format
function formatTime(timeString) {
    if (!timeString) return '';
    
    try {
        let date = new Date(timeString);
        if (isNaN(date.getTime())) {
            // Try parsing as time only (HH:MM:SS format)
            let timeParts = timeString.split(/[:\s]/);
            if (timeParts.length >= 2) {
                let hours = parseInt(timeParts[0]) || 0;
                let minutes = parseInt(timeParts[1]) || 0;
                let ampm = hours >= 12 ? 'PM' : 'AM';
                hours = hours % 12;
                hours = hours ? hours : 12; // 0 should be 12
                return String(hours).padStart(2, '0') + ':' + String(minutes).padStart(2, '0') + ' ' + ampm;
            }
            return timeString;
        }
        
        return date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
    } catch (e) {
        return timeString;
    }
}

// function fot get project and tasks
function getProjectTask() {
    var w_id =getCurrantWorkspace();
    setTimeout(function() {
        $('#tracker_section #v-pills-home-tab').trigger('click');
    }, 100);
 
    // Get localstorage data
    $.ajax({
        url: apiUrl + 'get-projects?work_space='+w_id,
        method: 'GET',
        cache: false,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + JSON.parse(localStorage.getItem('user_data'))._token
        },
        success: function(response) {
            if (response.is_success == true) {
                var projectHtml = '';

                if(response.data.projects.length > 0){
                    $.each(response.data.projects, function(key, val) {
                        var taskHtml = '';

                        // Generate Task List HTML
                        $.each(val.tasks, function(taskid, t) {

                            taskHtml += '<div class="custom-control custom-radio custom-control-inline my-1">\n' +
                                ' <input type="radio" id="task-' + t._id + '" name="selected_task" class="custom-control-input" value="' + t._id + '" >\n' +
                                ' <label class="custom-control-label" for="task-' + t._id + '">' + t.title + '</label>\n' +
                                ' </div><br>';
                        });

                        // Generate Project List HTML
                        if (taskHtml !== '') {
                            projectHtml += '<div class="card">\n' +
                                ' <div class="card-header py-3" id="project-content-' + key + '" data-toggle="collapse" role="button" data-target="#project-' + key + '" aria-expanded="false" aria-controls="project-' + key + '">\n' +
                                '    <h6 class="mb-0">' + val.name + '</h6>\n' +
                                ' </div>\n' +
                                ' <div id="project-' + key + '" class="collapse" aria-labelledby="project-content-' + key + '" data-parent="#project_list">\n' +
                                '   <div class="card-body py-1">\n' + taskHtml +
                                '   </div>\n' +
                                ' </div>\n' +
                                '</div>';
                        }

                    });

                }else{
                       projectHtml += '<div class="card">\n' +
                                ' <div class="card-footer py-3 text-center" >\n' +
                                '    <h6 class="mb-0"> No Projects</h6>\n' +
                                ' </div>\n' +
                                '</div>';
                }
               
                $('#project_list').html('');
                $('#project_list').html(projectHtml);

                // Task select click
                setTimeout(function() {
                    if ($('.custom-control-input').length > 0) {
                        $(document).on('click', 'input[name="selected_task"]', function() {
                            // console.log($("input[name='selected_task']:checked").val());
                            var attr = $('#time-tracking').attr('disabled');
                            if (typeof attr !== 'undefined' && attr !== false) {
                                $('#time-tracking').removeAttr('disabled');
                            }
                        });
                    }
                }, 200);
            } else {
                console.log('Something Went Wrong.!!');
            }
        },
        error: function(err) {
            console.log(err);
            return false;
        }
    })
}

// Tracking Time
var timer = null;

function TrackerTimer(action, trackTime) {

    var date = trackTime.getFullYear() + '-' + (trackTime.getMonth() + 1) + '-' + trackTime.getDate();
    var time = trackTime.getHours() + ":" + trackTime.getMinutes() + ":" + trackTime.getSeconds();
    var dateTime = date + ' ' + time;

    // run timer
    if (action == 'start') {
        timer = setInterval(function() {
            var end = new Date();
            var hrs = end.getHours() - trackTime.getHours();
            var min = end.getMinutes() - trackTime.getMinutes();
            var sec = end.getSeconds() - trackTime.getSeconds();
            var hour_carry = 0;

            var minutes_carry = 0;
            if (min < 0) {
                min += 60;
                hour_carry += 1;
            }
            hrs = hrs - hour_carry;
            if (sec < 0) {
                sec += 60;
                minutes_carry += 1;
            }
            min = min - minutes_carry;
            $('#running_time').text(minTwoDigits(hrs) + ':' + minTwoDigits(min) + ':' + minTwoDigits(sec));
        }, 1000);


    } else {
        clearInterval(timer);
        $('#running_time').text('00:00:00');
    }
    // end run timer

    // API CALL
    var task_id = $("input[name='selected_task']:checked").val();
    var workin_on = $("input[name='name']").val();
    var trak_id = $("#currant_trak_id").val();
    var is_billable = $("input[name='is_billable']").val();
    var w_id = getCurrantWorkspace();
    data = {
        action: action,
        time: dateTime,
        task_id: task_id,
        workin_on: workin_on,
        traker_id: trak_id,
        workspaces_id :w_id,
        is_billable: is_billable,
    };


    var req = $.ajax({
        url: apiUrl + 'add-tracker',
        method: 'POST',
        data: JSON.stringify(data),
        dataType: 'JSON',
        cache: false,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + JSON.parse(localStorage.getItem('user_data'))._token
        },
        success: function(response) {
            if (response.is_success == true && response.data.action == 'start') {
                var resp = response.data;
                $("#currant_trak_id").val(resp.id);

                resp.title = $('.tracker-name').val();

                localStorage.setItem('curant_task', JSON.stringify(resp.title));
                var task_data = JSON.parse(localStorage.getItem('curant_task'));
                if (task_data != null && task_data.project_name != null) {
                    var work_task = task_data.task_name + ' - ' + task_data.project_name;
                    $('.what-say').hide();
                    $('.work-on').show();
                    if (task_data.whats_sat !== '') {
                        $('.what_saY-title').html(task_data.whats_sat);
                    } else {
                        $('.what_saY-title').html(' - ');
                    }
                    $('.what-task').html(work_task);
                    $('.project_list').addClass('active-track');
                    $("input[type='radio']").each(function(i) {
                        if (!$(this).is(":checked")) {
                            $(this).attr('disabled', 'disabled');
                        }
                    });
                    $('.works_list').attr('disabled', 'disabled');
                } else {
                    $('.what-say').show();
                    $('.work-on').hide();
                    $('.project_list').removeClass('active-track');
                    $("input[type='radio']").each(function(i) {
                        $(this).removeAttr('disabled');
                    });
                     $('.works_list').removeAttr('disabled', 'disabled');
                }
            } else {
                localStorage.removeItem('curant_task');
                $('.tracker-name').val('');
                $('.what-say').show();
                $('.work-on').hide();
                $('.what_saY-title').html(' - ');
                $('.what-task').html(' - ');
                $('.project_list').removeClass('active-track');
                $("input[type='radio']").each(function(i) {
                    $(this).removeAttr('disabled');
                });
            }
            takeShot(response.data.id, action);
        }
    })
    .done(function(){ try { showToast('success', (action === 'start' ? 'Tracking started' : 'Tracking stopped')); } catch(e){} })
    .fail(function(){ try { showToast('error', 'Failed to ' + (action === 'start' ? 'start' : 'stop') + ' tracking'); } catch(e){} });
    
}

function minTwoDigits(n) {
    return (n < 10 ? '0' : '') + n;
}

// end Tracking Time

// Function for Take Screenshot
var shotInterval = null;


function takeShot(tracker_id, action) {
    var user_data = JSON.parse(localStorage.getItem('user_data'));
    if (action == 'start') {
        shotInterval = setInterval(function() {
            const screenshot = require('screenshot-desktop');
            let current_datetime = new Date();
            var filename = current_datetime.getTime() + '_' + tracker_id + '.jpg';

            // Ensure images directory exists at app root
            let appRoot = path.resolve(__dirname, '../../../');
            let imagesDir = path.join(appRoot, 'images');
            try {
                if (!fs.existsSync(imagesDir)) {
                    fs.mkdirSync(imagesDir, { recursive: true });
                }
            } catch (e) {
                // Fallback to userData path if app root is not writable
                try {
                    const userImages = path.join(remote.app.getPath('userData'), 'images');
                    if (!fs.existsSync(userImages)) {
                        fs.mkdirSync(userImages, { recursive: true });
                    }
                    imagesDir = userImages;
                } catch (e) { 
                    console.error('Failed to create images directory:', e);
                    return; // Abort screenshot if no valid directory
                 }
            }

            var uploadPath = path.join(imagesDir, filename);

            console.log("Screenshot Taken with Path: ", uploadPath);

            var taken = screenshot({ filename: uploadPath }).then((img) => {
                // img: Buffer filled with png goodness
                // ...

                // window_open(img);

                var date = current_datetime.getFullYear() + '-' + (current_datetime.getMonth() + 1) + '-' + current_datetime.getDate();
                var time = current_datetime.getHours() + ":" + current_datetime.getMinutes() + ":" + current_datetime.getSeconds();
                var dateTime = date + ' ' + time;
                uploadShot(img, filename, dateTime, tracker_id);
            }).catch((err) => {
                console.log(err);
            });

        }, shotTime + 100);
    } else {
        clearInterval(shotInterval); // stop the interval
    }
}

// End Take Screenshot


// Code For Open Child Window
let win = null;

function window_open(path) {
    var user_data = JSON.parse(localStorage.getItem('user_data'));
    const opts = { show: false };
    if (BrowserWindow.getFocusedWindow()) {
        current_win = BrowserWindow.getFocusedWindow();
        Object.assign(opts, {
            frame: false,
            height: 200,
            width: 300,
            x: screen.width - 315,
            y: 80,
            fullscreenable: false,
            resizable: false,
            minimizable: false
        });
    }

    win = new BrowserWindow({
        frame: false,
        height: 200,
        width: 300,
        x: screen.width - 315,
        y: 80,
        show: false,
        fullscreenable: false,
        resizable: false,
        minimizable: false
    });
    win.setThumbarButtons([{
        tooltip: 'button1',
        click() { console.log('button1 clicked') }
    }, {
        tooltip: 'button2',
        flags: ['enabled', 'dismissonclick'],
        click() { console.log('button2 clicked.') }
    }])

    win.loadFile(path);
    win.removeMenu();
    win.once('win.resizable', () => {
        console.log('hi');
    });

    win.once('ready-to-show', () => {
        win.show()
    });
    setTimeout(function() {
        win.close();
    }, showShot);
}

// End Code For Open Child Window

function uploadShot(imgPath, imgName, time, tracker_id) {

    const path = imgPath;
    const contents = fs.readFileSync(path, { encoding: 'base64' });
    var data = { img: contents, imgName: imgName, time: time, tracker_id: tracker_id };

    $.ajax({
        url: apiUrl + 'upload-photos',
        method: 'POST',
        data: data,
        headers: {
            'Authorization': 'Bearer ' + JSON.parse(localStorage.getItem('user_data'))._token
        },
        success: function(response) {
            var obj = response;
            if (obj.is_success == true) {
                uploadedFileRemove(path);
            }
            return false;
        }
    });
}

function uploadedFileRemove(Imgpath) {
    try {
        if (fs.existsSync(Imgpath)) {
            //file exists
            fs.unlinkSync(Imgpath);
        }
    } catch (err) {
        console.error(err)
    }
}

// API End Point
function getApi() {
    // return localStorage.getItem('clockgo_api_end_point');
    return 'http://localhost:4000';
}

// Get API Data Showtime
function getShowTime() {
    var time = localStorage.getItem('user_data');
    if (time !== '' && time !== null) {
        time = JSON.parse(localStorage.getItem('user_data')).show_shot;
    }
    if (time !== '') {
        return time;
    } else {
        return 2;
    }
}

// Get API ShowTime
function getShotTime() {
    var time = localStorage.getItem('user_data');
    if (time !== '' && time !== null) {
        time = JSON.parse(localStorage.getItem('user_data')).shot_time;
    }
    if (time !== '') {
        return time;
    } else {
        return 10;
    }
}

// Login Validartion 

function LoginValidation() {
    var is_valid = true;
    var site = $('#site_url');
    var email = $('#email');
    var password = $('#password');
    if (site.val() == '') {
        is_valid = false;
        site.addClass('is-invalid');
        $('.site-error-text').text('( site url is required. )').show();

    } else {
        $('.site-error-text').text('').hide();

    }
    if (email.val() == '') {
        is_valid = false;
        email.addClass('is-invalid');
        $('.email-error-text').text('( email id is required. )').show();

    } else if (!isEmail(email.val())) {
        is_valid = false;
        email.addClass('is-invalid');
        $('.email-error-text').text('( please enter a valid email address').show();
    } else {
        $('.email-error-text').text('').hide();
    }

    if (password.val() == '') {
        is_valid = false;
        password.addClass('is-invalid');
        $('.password-error-text').text('( password is required. )').show();
    } else {
        $('.password-error-text').text('').hide();
    }
    return is_valid;
}

function isEmail(email) {
    var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    return regex.test(email);
}

function getWorkSpace() {
    // Get localstorage data
    $.ajax({
        url: apiUrl + 'get-workspace',
        method: 'GET',
        cache: false,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + JSON.parse(localStorage.getItem('user_data'))._token
        },
        success: function(response) {
            console.log("Workspace Response: ", response);
            if (response.is_success == true) {
                var projectHtml = '<select class="form-control custom-treker-input mb-2 p-0 px-2 works_list" onchange="reloadprojects()">';
                $.each(response.data.workspaces, function(key, val) {
                    projectHtml+='<option value="'+key+'">'+val+'</option>'    
                });
                projectHtml+='</select>';
                // console.log("Workspace HTML: ", projectHtml);
                $('#workSpace_list').html('');
                $('#workSpace_list').html(projectHtml);

                
                getProjectTask();

            } else {
                console.log('Something Went Wrong.!!');
            }
        },
        error: function(err) {
            console.log(err);
            return false;
        }
    })
}
function getCurrantWorkspace(){
    return $('.works_list').val();
}
function reloadprojects(){
    getProjectTask();
    // Refresh attendance summary for selected workspace
    fetchAttendanceSummary();
    // Reset idle monitor context
    if (typeof resetIdleActivity === 'function') {
        resetIdleActivity();
    }
}

BrowserWindow.getAllWindows().forEach(function(win) {
    win.on("close", (e) => {
        var check = $("#time-tracking").attr('data-tracking');
        var msg = "Do you really want to quit?";
        if (check == 'on') {
            msg = 'Tracke is on, Do you really want to quit?';
            dialog.showMessageBox(
                    win, {
                        title: 'Confirm',
                        message: msg,
                        buttons: ["Yes", "Cancel"],
                        defaultId: 0, // bound to buttons array
                        cancelId: 1 // bound to buttons array
                    })
                .then(result => {
                    if (result.response === 0) {
                        // bound to buttons array
                        $("#time-tracking").trigger('click');
                        setTimeout(function() {
                            ipcRenderer.send('close-me')
                        }, 700);
                    } else if (result.response === 1) {
                        // bound to buttons array
                        e.preventDefault();
                    }
                });
        } else {
            setTimeout(function() {
                ipcRenderer.send('close-me')
            }, 700);
        }
    });
})