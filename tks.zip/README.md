# Taskly Tracker (Windows)

Taskly Tracker is a lightweight Electron-based desktop app for time tracking, screenshots, attendance (clock in/out, breaks), daily reports, and idle detection.

- Platform: Windows (Electron)
- UI: Bootstrap, jQuery, Font Awesome
- Extras: SweetAlert2 popups, Bootstrap Notify toasts

## Features

- Login with your site URL, email, and password
- Workspaces, Projects, Tasks selector
- Start/Stop task tracking with notes and billable toggle
- Periodic screenshots saved locally and uploaded to server
- Attendance controls: Clock In/Clock Out, Start/End Break
- Idle detection and reporting to server
- Daily reports view (today’s total + entry list)
- Update prompt: Contact IT if a new version is available

---

## Quick start

1) Install prerequisites
- Node.js 18+ (Windows)
- Git (optional)

2) Install dependencies
```bash
npm install
```

3) Run in development
```bash
npm start
```

The app opens with DevTools enabled. Log in with your site URL and credentials.

---

## Build and distribution

This repo uses electron-builder for packaging (configured in `package.json` under the `build` field).

- Build (no installer):
```bash
npm run build
```

- Build Windows NSIS installer (x64 and ia32):
```bash
npm run dist
```

Artifacts are placed in the `dist/` folder. Windows installer name pattern: `Taskly Tracker-Setup-<version>.exe`.

Optional publishing is configured for GitHub in `build.publish`.

Note: A `forge.config.js` is included for Electron Forge makers, but the active packaging flow in `package.json` uses electron-builder.

---

## Configuration

App configuration lives in `src/env-config.json` and via the login screen.

`src/env-config.json`:
```json
{
  "APP_NAME": "Taskly Tracker",
  "LOGO": "/assets/images/favicon.png",
  "API_URL": "http://localhost:3000/api",
  "VERSION": "1.0.0",
  "COMPANY_NAME": "Rajodiya Infotech",
  "UPDATE_CHECK_URL": "http://localhost:3000/api/app-version",
  "IT_CONTACT_MESSAGE": "A new version is available. Please contact the IT Department to get the latest update."
}
```
- APP_NAME: Window title and product name
- LOGO: Tray/window icons path used by Electron
- API_URL: Default API base (dev); the app primarily uses the site URL entered on the login screen
- VERSION: Local app version string used by the update checker
- UPDATE_CHECK_URL: Endpoint the app calls at startup to fetch `{ latest_version: "x.y.z" }`
- IT_CONTACT_MESSAGE: Message shown when a newer version is detected

Login-based API base:
- On login, users enter a Site URL (e.g., `https://app.example.com`). The app sets base API to `https://app.example.com/api/` and stores it in `localStorage` as `clockgo_api_end_point`.
- Subsequent requests use `{SITE_URL}/api/...`.

---

## Screenshot storage

- Local save path (preferred): `<repo-root>/images` (created automatically if missing)
- Fallback (if not writable): `%APPDATA%/Taskly Tracker/images`
- Screenshot naming: `<timestamp>_<trackerId>.jpg`
- Uploads: Each screenshot is uploaded to `POST /api/upload-photos` with fields `{ img (base64), imgName, time, tracker_id }`. On successful upload, the local file is deleted.

You can change the periodic interval via server-provided `shot_time` (minutes) returned on login; the client respects it. A small preview window may appear briefly depending on local settings.

---

## Attendance and idle

- Clock in/out: `POST /api/attendance/clock-in` and `/clock-out`
- Breaks: `POST /api/attendance/break-start` and `/break-end`
- Summary: `GET /api/attendance/summary?date=YYYY-MM-DD&workspace_id=<id>`
- Idle detection: If the user is inactive for N minutes (default 5), the app calls:
  - `POST /api/attendance/idle-start` when idle begins
  - `POST /api/attendance/idle-end` when activity resumes or state transitions (clock-out/break-start)

The app prevents open idle intervals from overlapping with break or off-duty states and will auto-close idle on transitions. See `docs/backend-api.md` for the full contract.

---

## Daily reports

- `GET /api/get-daily-reports?date=YYYY-MM-DD&workspace_id=<id>`
- UI shows the total for today and a list of entries (running and completed), with durations and billable marker.

---

## Update prompt (Contact IT)

On startup the app fetches `UPDATE_CHECK_URL` (default `http://localhost:3000/api/app-version`) and expects JSON like:
```json
{ "latest_version": "1.2.3" }
```
If `latest_version` > local `VERSION`, a dialog prompts the user to contact IT to get the latest installer. There is no auto-update or download flow by design.

---

## Project structure (high level)

```
├─ build/                  # Electron builder resources and NSIS script
├─ docs/
│  └─ backend-api.md       # API contract for server implementation
├─ src/
│  ├─ assets/
│  │  ├─ css/              # Custom and library CSS
│  │  ├─ images/           # App icons/assets
│  │  └─ js/               # Renderer logic (custom.js)
│  ├─ env-config.json      # App configuration
│  ├─ index.html           # UI (login, tracker, profile, reports)
│  └─ index.js             # Electron main process
├─ package.json            # Scripts and electron-builder config
├─ forge.config.js         # Optional forge makers (not used by scripts)
└─ README.md
```

---

## Development notes

- Renderer uses deprecated `electron.remote` API for dialogs and BrowserWindow. When upgrading Electron, consider migrating to IPC-safe patterns.
- UI built with Bootstrap and jQuery; SweetAlert2 and Bootstrap Notify are used for popups and toasts.
- Time tracking API has a `traker_id` field (client typo). Server should accept either `traker_id` or `tracker_id`.
- Idle threshold is set in the client (default 5 min); you can make it configurable if needed.

---

## Troubleshooting

- App doesn’t connect after login:
  - Verify you entered the correct Site URL (e.g., `https://yourdomain.com`). The client appends `/api/` automatically.
- No screenshots uploading:
  - Check that the `images/` folder exists and is writable, or confirm `%APPDATA%/Taskly Tracker/images` is used.
  - Ensure the server accepts `POST /api/upload-photos` as documented.
- Update prompt not showing:
  - Confirm `src/env-config.json` `UPDATE_CHECK_URL` returns `{ latest_version: "x.y.z" }` and `VERSION` is lower than that.
- Packaging errors:
  - Remove `dist/` and retry `npm run dist`. Verify `build/icons/*` files exist and paths match.

---

## License

MIT © Brijesh Chauhan / Rajodiya Infotech
