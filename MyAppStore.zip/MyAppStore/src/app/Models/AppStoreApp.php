<?php

namespace Shopyji\MyAppStore\app\Models;

use GeneaLabs\LaravelModelCaching\Traits\Cachable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AppStoreApp extends Model
{
    use HasFactory, Cachable;

    protected $fillable = [
        'app_slug', 'store_id'
    ];

    public function store()
    {
        return $this->belongsTo(Store::class);
    }

    public function isInstalled($appSlug)
    {
        return self::where('app_slug', $appSlug)->exists();
    }
}
