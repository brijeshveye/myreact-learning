<?php

namespace Shopyji\MyAppStore\app\Http\Controllers;

use Illuminate\Http\Request;
use App\Facades\ModuleFacade as Module;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Artisan;
use App\Models\AddOnManager;
use App\Models\Permission;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use ZipArchive;
use App\Models\Addon;
use App\Models\Utility;
use Shopyji\MyAppStore\app\Models\AppStoreApp;

class AppStoreController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        if (1 || auth()->user() && auth()->user()->isAbleTo('Manage Module')) {
            $user = auth()->user();
            $menu = new \App\Classes\Menu($user);
            // event(new \App\Events\SuperAdminStoreMenuEvent($menu));
            event(new \App\Events\CompanyStoreMenuEvent($menu));
            // dump($menu->menu);

            // Get installed apps for the current store
            $userApps = AppStoreApp::where('store_id', getCurrentStore())->pluck('app_slug')->toArray();


            foreach ($menu->menu as $key => $value) {
                if (1 || isset($value['isEnabled'])) {
                    $menu->menu[$key]['isEnabled'] = true;

                    // Mark as installed if in the userApps list
                    if (in_array($value['name'], $userApps)) {
                        $menu->menu[$key]['isInstalled'] = true;
                    } else {
                        $menu->menu[$key]['isInstalled'] = false;
                    }
                }
            }

            $menu->menu = arrayToObject($menu->menu);
            // dump($menu->menu);



            $addon_tab = session()->get('addon_tab');
            if (empty($addon_tab)) {
                $addon_tab = 'pills-premium-tab';
            }
            return view('my-app-store::index', compact('menu', 'addon_tab'));
        } else {
            return redirect()->back()->with('error', __('Permission denied.'));
        }
    }

    /**
     * Display a single app view (details/settings/actions)
     */
    public function show($appSlug)
    {
        $user = auth()->user();
        $menu = new \App\Classes\Menu($user);
        event(new \App\Events\CompanyStoreMenuEvent($menu));

        // Get installed apps for the current store
        $userApps = AppStoreApp::where('store_id', getCurrentStore())->pluck('app_slug')->toArray();


        foreach ($menu->menu as $key => $value) {
            $menu->menu[$key]['isEnabled'] = true;

            // Mark as installed if in the userApps list
            if (in_array($value['name'], $userApps)) {
                $menu->menu[$key]['isInstalled'] = true;
            } else {
                $menu->menu[$key]['isInstalled'] = false;
            }
        }

        $menu->menu = arrayToObject($menu->menu);

        // Try to resolve app info from menu (apps) or from Module registry (add-ons)
        $app = null;
        foreach ($menu->menu as $item) {
            if (($item->parent ?? null) == null && strtolower($item->name ?? '') === strtolower($appSlug)) {
                $app = $item;
                break;
            }
        }


        // Normalize a simple view-model
        $vm = (object) [
            'slug' => $appSlug,
            'title' => $app->title ?? $appSlug,
            'name' => $app->name,
            'description' => $app->description ?? '',
            'icon' => $app->icon ?? 'puzzle',
            'image' => $app->image ?? null,
            'version' => $app->version ?? '1.0',
            'isEnabled' => $app->isEnabled ?? false,
            'category' => $app->category ?? 'Apps',
            'isInstalled' => $app->isInstalled ?? false,
        ];

        // Build settings/actions menu using existing helper if available
        $settingsMenuHtml = '';
        try {
            if (function_exists('generateStoreMenu') && isset($menu->menu)) {
                $settingsMenuHtml = generateStoreMenu(objectToArray($menu->menu), $vm->name);
            }
        } catch (\Throwable $e) {
            $settingsMenuHtml = '';
        }

        return view('my-app-store::show', [
            'app' => $vm,
            'settingsMenuHtml' => $settingsMenuHtml,
        ]);
    }

    public function install(Request $request)
    {
        $installAppRequest = [];
        if ($request->has('appSlug')) {
            $request->merge(['app_slug' => $request->input('appSlug')]);

            $request->merge(['name' => $request->input('appSlug')]);
            $installAppRequest = $request->validate([
                'name' => 'required|string',
            ]);
        }else {
            $installAppRequest = $request->validate([
                'name' => 'required|string',
            ]);
        }

        // Install the app for the current store
        $appSlug = $installAppRequest['name'];
        $storeId = getCurrentStore();
        if (!AppStoreApp::where('app_slug', $appSlug)->where('store_id', $storeId)->exists()) {
            $appStoreApp = new AppStoreApp();
            $appStoreApp->app_slug = $appSlug;
            $appStoreApp->store_id = $storeId;
            $appStoreApp->save();

            return redirect()->back()->with('success', __('App installed successfully.'));
        }

        return redirect()->back()->with('info', __('App is already installed.'));
    }

    public function uninstall(Request $request)
    {
        $uninstallAppRequest = [];
        if ($request->has('appSlug')) {
            $request->merge(['app_slug' => $request->input('appSlug')]);

            $request->merge(['name' => $request->input('appSlug')]);
            $uninstallAppRequest = $request->validate([
                'name' => 'required|string',
            ]);
        }else {
            $uninstallAppRequest = $request->validate([
                'name' => 'required|string',
            ]);
        }


        // Uninstall the app for the current store
        $appSlug = $uninstallAppRequest['name'];
        $storeId = getCurrentStore();
        $app = AppStoreApp::where('app_slug', $appSlug)->where('store_id', $storeId)->first();
        if ($app) {
            $app->delete();
            return redirect()->back()->with('success', __('App uninstalled successfully.'));
        }

        return redirect()->back()->with('info', __('App is not installed.'));
    }



}
