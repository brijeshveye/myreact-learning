<?php

namespace Shopyji\MyAppStore\app\Listeners;
use App\Events\SuperAdminMenuEvent;

class SuperAdminMenuListener
{
    /**
     * Handle the event.
     */
    public function handle(SuperAdminMenuEvent $event): void
    {
        $module = 'MyAppStore';
        $menu = $event->menu;
        $menu->add([
            'title' => 'MyAppStore',
            'icon' => 'home',
            'name' => 'myappstore',
            'parent' => null,
            'order' => 130,
            'ignore_if' => [],
            'depend_on' => [],
            'route' => '',
            'module' => $module,
            'permission' => 'Manage App Store'
        ]);


        $menu->add([
            'title' => __('App Store'),
            'icon' => 'heart',
            'name' => 'app_store',
            'parent' => 'myappstore',
            'order' => 231,
            'ignore_if' => [],
            'depend_on' => [],
            'route' => 'myappstore.index',
            'module' => $module,
            'permission' => ''
        ]);
    }
}
