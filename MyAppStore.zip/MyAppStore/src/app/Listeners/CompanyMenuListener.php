<?php

namespace Shopyji\MyAppStore\app\Listeners;

use App\Events\CompanyMenuEvent;

class CompanyMenuListener
{
    /**
     * Handle the event.
     */
    public function handle(CompanyMenuEvent $event): void
    {
        $module = 'MyAppStore';
        $menu = $event->menu;
        $menu->add([
            'title' => 'MyAppStore',
            'icon' => 'package',
            'name' => 'myappstore',
            'parent' => null,
            'order' => 130,
            'ignore_if' => [],
            'depend_on' => [],
            'route' => '',
            'module' => $module,
            'permission' => ''
        ]);

        $menu->add([
            'title' => __('App Store'),
            'icon' => 'heart',
            'name' => 'app_store',
            'parent' => 'myappstore',
            'order' => 231,
            'ignore_if' => [],
            'depend_on' => [],
            'route' => 'myappstore.index',
            'module' => $module,
            'permission' => ''
        ]);
    }
}
