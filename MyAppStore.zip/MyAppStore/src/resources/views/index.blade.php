@extends('layouts.app')
@section('page-title')
    {{ __('My Apps Store') }}
@endsection
@section('page-breadcrumb')
    {{ __('My Apps Store') }}
@endsection
@push('css')
    <style>
        .product-img {
            padding-bottom: 24px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .system-version h5 {
            position: absolute;
            bottom: -44px;
            right: 27px;
        }

        .center-text {
            display: flex;
            flex-direction: column;
        }

        .center-text .text-primary {
            font-size: 14px;
            margin-top: 5px;
        }

        .theme-main {
            display: flex;
            align-items: center;
        }

        .theme-main .theme-avtar {
            margin-right: 15px;
        }

        .product-img .checkbox-custom .card-option {
            border: 0;
            outline: 0;
        }

        .product-img .checkbox-custom .card-option .btn.show {
            color: #000;
            border: 0;
        }

        .product-img .checkbox-custom .card-option .btn:focus {
            border: 0;
        }

        @media only screen and (max-width: 575px) {
            .system-version h5 {
                position: unset;
                margin-bottom: 0px;
            }

            .system-version {
                text-align: center;
                margin-bottom: -22px;
            }
        }

        /* Appstore action buttons */
        .action-row .btn {
            font-size: 0.9rem;
            white-space: nowrap;
        }

        .action-row .btn+.btn {
            margin-left: 0.5rem;
        }
    </style>
@endpush
@section('page-action')
@endsection

@section('content')
    <div class="row">
        <div class="col-12 mb-3">
            <ul class="nav nav-pills gap-2" id="pills-tab" role="tablist">
                <li class="nav-item" role="presentation">
                    <a class="nav-link @if (!isset($addon_tab) || in_array($addon_tab, ['pills-all-tab', 'pills-premium-tab'])) active @endif f-w-600" id="pills-all-tab"
                        data-bs-toggle="pill" data-bs-target="#pills-all" role="tab" aria-controls="pills-all"
                        aria-selected="true">
                        {{ __('All Apps') }}
                    </a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link @if (isset($addon_tab) && in_array($addon_tab, ['pills-installed-tab', 'pills-themes-tab'])) active @endif f-w-600" id="pills-installed-tab"
                        data-bs-toggle="pill" data-bs-target="#pills-installed" role="tab"
                        aria-controls="pills-installed" aria-selected="false">
                        {{ __('Installed Apps') }}
                    </a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link @if (isset($addon_tab) && in_array($addon_tab, ['pills-available-tab', 'pills-mobile-app-tab'])) active @endif f-w-600" id="pills-available-tab"
                        data-bs-toggle="pill" data-bs-target="#pills-available" role="tab"
                        aria-controls="pills-available" aria-selected="false">
                        {{ __('Apps Available') }}
                    </a>
                </li>
            </ul>
        </div>

        <div class="col-12">
            <div class="tab-content" id="pills-tabContent">
                <div class="tab-pane fade @if (!isset($addon_tab) || in_array($addon_tab, ['pills-all-tab', 'pills-premium-tab'])) show active @endif" id="pills-all"
                    role="tabpanel" aria-labelledby="pills-all-tab">
                    <div id="premium">
                        <div class="col-md-12">
                            @php
                                // Build dynamic category filters for All Apps
                                $filter_map_all = [];

                                if (isset($menu) && isset($menu->menu)) {
                                    foreach ($menu->menu as $app) {
                                        if ($app->parent == null) {
                                            $label = $app->category ?? 'Apps';
                                            $slug = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $label));
                                            $filter_map_all[$slug] = $label;
                                        }
                                    }
                                }

                            @endphp
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h4 class="mb-0">{{ __('Filter by Category') }}</h4>
                                <ul class="nav nav-pills category-filter gap-1" data-target="#pills-all">
                                    <li class="nav-item">
                                        <a href="#" class="nav-link active"
                                            data-category="all">{{ __('All') }}</a>
                                    </li>
                                    @foreach ($filter_map_all as $slug => $label)
                                        <li class="nav-item">
                                            <a href="#" class="nav-link"
                                                data-category="{{ $slug }}">{{ __($label) }}</a>
                                        </li>
                                    @endforeach
                                </ul>
                            </div>


                            <!-- Search Input -->
                            <div class="row mb-3">
                                <div class="col-8">
                                    <h4 class="mb-3">{{ __('All Apps') }}</h4>
                                </div>
                                <div class="col-4">
                                    <input type="text" id="moduleSearch" class="form-control"
                                        placeholder="{{ __('Search Apps...') }}">
                                </div>
                            </div>

                            <!-- Installed Apps -->
                            <div class="event-cards row px-0">

                                @foreach ($menu->menu as $app)
                                    @if ($app->parent == null)
                                        @php
                                            $app_name = $app->name ?? $app->title;
                                            $app_id = strtolower(preg_replace('/\s+/', '_', $app_name));
                                            $app_cat_label = $app->category ?? 'Apps';
                                            $app_cat = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $app_cat_label));
                                        @endphp
                                        <div class="col-xl-4 col-md-4 col-sm-6 product-card h-auto module-card"
                                            data-name="{{ strtolower($app->name) }}" data-category="{{ $app_cat }}">
                                            <div
                                                class="card {{ $app->isInstalled ? 'enable_module' : 'disable_module' }} mb-0 h-100 justify-content-between">
                                                <div class="product-img">
                                                    <div class="theme-main">
                                                        <div class="theme-avtar">
                                                            {{-- <img src="{{ $module->image ?? '' }}"
                                                                alt="{{ $app->name }}" class="img-user"
                                                                style="max-width: 100%"> --}}
                                                            <i class="ti ti-{{ $app->icon }}"
                                                                style="font-size: 48px;"></i>
                                                        </div>
                                                        <div class="center-text">
                                                            <small class="text-muted">
                                                                @if ($app->isInstalled)
                                                                    <span
                                                                        class="badge bg-success">{{ __('Installed') }}</span>
                                                                @else
                                                                    <span
                                                                        class="badge bg-danger">{{ __('Not Installed') }}</span>
                                                                @endif
                                                            </small>

                                                            <small class="text-primary">{{ __('V') }}
                                                                {{ sprintf('%.1f', $app->version ?? '1.0') }}</small>
                                                        </div>

                                                    </div>
                                                    <div class="checkbox-custom">
                                                        <div class="btn-group card-option">
                                                            <button type="button" class="btn p-0" data-bs-toggle="dropdown"
                                                                aria-haspopup="true" aria-expanded="false"
                                                                id="dropdownTrigger_{{ $app_id }}">
                                                                <i class="ti ti-dots-vertical"></i>
                                                            </button>
                                                            <div class="dropdown-menu dropdown-menu-end" style="">
                                                                @if ($app->isInstalled)
                                                                    <a href="#!"
                                                                        class="dropdown-item module_change d-none"
                                                                        data-id="{{ $app_id }}">
                                                                        <span>{{ __('Uninstall') }}</span>
                                                                    </a>
                                                                    {!! generateStoreMenu(objectToArray($menu->menu), $app->name) !!}
                                                                @else
                                                                    <a href="#!"
                                                                        class="dropdown-item module_change"
                                                                        data-id="{{ $app_id }}">
                                                                        <span>{{ __('Install') }}</span>
                                                                    </a>
                                                                @endif

                                                                <form action="{{ route('myappstore.install', ['appSlug' => $app->name]) }}" method="POST"
                                                                    id="form_{{ $app_id }}">
                                                                    @csrf
                                                                    <input type="hidden" name="name"
                                                                        value="{{ $app->name }}">
                                                                </form>
                                                                <form action="{{ route('myappstore.uninstall', ['appSlug' => $app->name]) }}"
                                                                    method="POST" id="form_{{ $app_id }}">
                                                                    @csrf
                                                                    <input type="hidden" name="name"
                                                                        value="{{ $app->name }}">
                                                                    <button type="button"
                                                                        class="dropdown-item show_confirm d-none"
                                                                        data-confirm="{{ __('Are You Sure?') }}"
                                                                        data-text="{{ __('This action can not be undone. Do you want to continue?') }}"
                                                                        data-confirm-yes="delete-form-{{ $app_id }}"
                                                                        data-text-yes="{{ __('Yes') }}"
                                                                        data-text-no="{{ __('No') }}">
                                                                        <span
                                                                            class="text-danger">{{ __('Remove') }}</span>
                                                                    </button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="product-content">
                                                    <h4 class="text-capitalize"> {{ $app->title }}</h4>
                                                    <div class="center-texts my-1">
                                                        <span class="badge bg-info">{{ $app->category ?? 'Core' }}</span>
                                                    </div>
                                                    <p class="text-muted text-sm mb-0">
                                                        {{ $app->description ?? '' }}
                                                    </p>
                                                    <div class="d-flex gap-2 mt-2 action-row">
                                                        @if ($app->isInstalled)
                                                            <form action="{{ route('myappstore.uninstall', ['appSlug' => $app->name]) }}"
                                                                method="POST" id="uninstall_{{ $app_id }}"
                                                                class="m-0 p-0 flex-grow-1">
                                                                @csrf
                                                                <input type="hidden" name="name"
                                                                    value="{{ $app->name }}">
                                                                <button type="button"
                                                                    class="btn btn-outline-danger w-100 uninstall-btn"
                                                                    data-id="{{ $app_id }}">{{ __('Uninstall') }}</button>
                                                            </form>
                                                            <a href="{{ route('myappstore.show', $app->name) }}"
                                                                class="btn btn-outline-primary flex-grow-1"><i
                                                                    class="fas fa-eye"></i> {{ __('View') }}</a>
                                                            <a href="javascript:void(0);"
                                                                class="btn btn-outline-info flex-grow-1 open-dropdown"
                                                                data-id="{{ $app_id }}"><i class="fas fa-cog"></i>
                                                                {{ __('Settings') }}</a>
                                                        @else
                                                            <form action="{{ route('myappstore.install', ['appSlug' => $app->name]) }}" method="POST"
                                                                id="install_{{ $app_id }}"
                                                                class="m-0 p-0 flex-grow-1">
                                                                @csrf
                                                                <input type="hidden" name="name"
                                                                    value="{{ $app->name }}">
                                                                <button type="button"
                                                                    class="btn btn-success w-100 install-btn"
                                                                    data-id="{{ $app_id }}">{{ __('Install') }}</button>
                                                            </form>
                                                            <a href="{{ route('myappstore.show', $app->name) }}"
                                                                class="btn btn-primary flex-grow-1">{{ __('View') }}</a>
                                                        @endif
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    @endif
                                @endforeach
                            </div>
                            <!-- Installed Apps End -->


                        </div>
                    </div>
                </div>

                <div class="tab-pane fade @if (isset($addon_tab) && in_array($addon_tab, ['pills-installed-tab', 'pills-themes-tab'])) show active @endif" id="pills-installed"
                    role="tabpanel" aria-labelledby="pills-installed-tab">
                    <div class="col-md-12">
                        @php
                            // Build filters for Installed (modules + apps only)
                            $filter_map_inst = [];

                            if (isset($menu) && isset($menu->menu)) {
                                foreach ($menu->menu as $app) {
                                    if ($app->parent == null && $app->isInstalled) {
                                        $label = $app->category ?? 'Apps';
                                        $slug = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $label));
                                        $filter_map_inst[$slug] = $label;
                                    }
                                }
                            }
                        @endphp
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h4 class="mb-0">{{ __('Filter by Category') }}</h4>
                            <ul class="nav nav-pills category-filter gap-1" data-target="#pills-installed">
                                <li class="nav-item"><a href="#" class="nav-link active"
                                        data-category="all">{{ __('All') }}</a></li>
                                @foreach ($filter_map_inst as $slug => $label)
                                    <li class="nav-item"><a href="#" class="nav-link"
                                            data-category="{{ $slug }}">{{ __($label) }}</a></li>
                                @endforeach
                            </ul>
                        </div>


                        <div class="row mt-4 mb-3">
                            <div class="col-12">
                                <h4 class="mb-3">{{ __('Installed Apps') }}</h4>
                            </div>
                        </div>
                        <div class="event-cards row px-0">
                            @foreach ($menu->menu as $app)
                                @if ($app->parent == null && $app->isInstalled)
                                    @php
                                        $app_name = $app->name ?? $app->title;
                                        $app_id = strtolower(preg_replace('/\s+/', '_', $app_name));
                                        $app_cat_label = $app->category ?? 'Apps';
                                        $app_cat = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $app_cat_label));
                                    @endphp
                                    <div class="col-xl-4 col-md-4 col-sm-6 product-card h-auto module-card"
                                        data-name="{{ strtolower($app->name) }}" data-category="{{ $app_cat }}">
                                        <div
                                            class="card {{ $app->isInstalled ? 'enable_module' : 'disable_module' }} mb-0 h-100 justify-content-between">
                                            <div class="product-img">
                                                <div class="theme-main">
                                                    <div class="theme-avtar">
                                                        <i class="ti ti-{{ $app->icon }}"
                                                            style="font-size: 48px;"></i>
                                                    </div>
                                                    <div class="center-text">
                                                        <small class="text-muted">
                                                            @if ($app->isInstalled)
                                                                <span class="badge bg-success">{{ __('Enable') }}</span>
                                                            @else
                                                                <span class="badge bg-danger">{{ __('Disable') }}</span>
                                                            @endif
                                                        </small>
                                                        <small class="text-primary">{{ __('V') }}
                                                            {{ sprintf('%.1f', $app->version ?? '1.0') }}</small>
                                                    </div>
                                                </div>
                                                <div class="checkbox-custom">
                                                    <div class="btn-group card-option">
                                                        <button type="button" class="btn p-0" data-bs-toggle="dropdown"
                                                            aria-haspopup="true" aria-expanded="false">
                                                            <i class="ti ti-dots-vertical"></i>
                                                        </button>
                                                        <div class="dropdown-menu dropdown-menu-end">
                                                            @if ($app->isInstalled)
                                                                <a href="#" class="dropdown-item module_change"
                                                                    data-id="{{ $app_id }}">{{ __('Disable') }}</a>
                                                            @else
                                                                <a href="#" class="dropdown-item module_change"
                                                                    data-id="{{ $app_id }}">{{ __('Enable') }}</a>
                                                            @endif
                                                            <form action="{{ route('myappstore.install', ['appSlug' => $app->name]) }}" method="POST"
                                                                id="form_{{ $app_id }}">
                                                                @csrf
                                                                <input type="hidden" name="name"
                                                                    value="{{ $app->name }}">
                                                            </form>
                                                            <form action="{{ route('myappstore.uninstall', ['appSlug' => $app->name]) }}"
                                                                method="POST" id="form_{{ $app_id }}">
                                                                @csrf
                                                                <input type="hidden" name="name"
                                                                    value="{{ $app->name }}">
                                                                <button type="button" class="dropdown-item show_confirm"
                                                                    data-confirm="{{ __('Are You Sure?') }}"
                                                                    data-text="{{ __('This action can not be undone. Do you want to continue?') }}"
                                                                    data-confirm-yes="delete-form-{{ $app_id }}"
                                                                    data-text-yes="{{ __('Yes') }}"
                                                                    data-text-no="{{ __('No') }}">
                                                                    <span class="text-danger">{{ __('Remove') }}</span>
                                                                </button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-content">
                                                <h4 class="text-capitalize">{{ $app->title }}</h4>
                                                <p class="text-muted text-sm mb-0">{{ $app->description ?? '' }}</p>
                                                <div class="d-flex gap-2 mt-2 action-row">
                                                    @if ($app->isInstalled)
                                                        <form action="{{ route('myappstore.uninstall', ['appSlug' => $app->name]) }}"
                                                            method="POST" id="uninstall_{{ $app_id }}"
                                                            class="m-0 p-0 flex-grow-1">
                                                            @csrf
                                                            <input type="hidden" name="name"
                                                                value="{{ $app->name }}">
                                                            <button type="button"
                                                                class="btn btn-outline-danger w-100 uninstall-btn"
                                                                data-id="{{ $app_id }}">{{ __('Uninstall') }}</button>
                                                        </form>
                                                        <a href="{{ route('myappstore.show', $app->name) }}"
                                                            class="btn btn-primary flex-grow-1">{{ __('View') }}</a>
                                                    @else
                                                        <form action="{{ route('myappstore.install', ['appSlug' => $app->name]) }}" method="POST"
                                                            id="install_{{ $app_id }}" class="m-0 p-0 flex-grow-1">
                                                            @csrf
                                                            <input type="hidden" name="name"
                                                                value="{{ $app->name }}">
                                                            <button type="button"
                                                                class="btn btn-success w-100 install-btn"
                                                                data-id="{{ $app_id }}">{{ __('Install') }}</button>
                                                        </form>
                                                        <a href="{{ route('myappstore.show', $app->name) }}"
                                                            class="btn btn-primary flex-grow-1">{{ __('View') }}</a>
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endif
                            @endforeach
                        </div>
                    </div>
                </div>

                <div class="tab-pane fade @if (isset($addon_tab) && in_array($addon_tab, ['pills-available-tab', 'pills-mobile-app-tab'])) show active @endif" id="pills-available"
                    role="tabpanel" aria-labelledby="pills-available-tab">
                    <div class="col-md-12">
                        @php
                            // Build filters for Available (only not-installed apps)
                            $filter_map_avl = [];
                            if (isset($menu) && isset($menu->menu)) {
                                foreach ($menu->menu as $app) {
                                    if ($app->parent == null && empty($app->isInstalled)) {
                                        $label = $app->category ?? 'Apps';
                                        $slug = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $label));
                                        $filter_map_avl[$slug] = $label;
                                    }
                                }
                            }

                        @endphp
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h4 class="mb-0">{{ __('Filter by Category') }}</h4>
                            <ul class="nav nav-pills category-filter gap-1" data-target="#pills-available">
                                <li class="nav-item"><a href="#" class="nav-link active"
                                        data-category="all">{{ __('All') }}</a></li>
                                @foreach ($filter_map_avl as $slug => $label)
                                    <li class="nav-item"><a href="#" class="nav-link"
                                            data-category="{{ $slug }}">{{ __($label) }}</a></li>
                                @endforeach
                            </ul>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-4">
                                <h4 class="mb-3">{{ __('Apps Available') }}</h4>
                            </div>
                        </div>
                        <div class="event-cards row px-0">
                            @if (isset($menu) && isset($menu->menu))
                                @foreach ($menu->menu as $app)
                                    @if ($app->parent == null && empty($app->isInstalled))
                                        @php
                                            $app_name = $app->name ?? $app->title;
                                            $app_id = strtolower(preg_replace('/\s+/', '_', $app_name));
                                            $app_cat_label = $app->category ?? 'Apps';
                                            $app_cat = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $app_cat_label));
                                        @endphp
                                        <div class="col-xl-4 col-md-4 col-sm-6 product-card h-auto module-card" data-name="{{ strtolower($app->name) }}" data-category="{{ $app_cat }}">
                                            <div class="card disable_module mb-0 h-100 justify-content-between">
                                                <div class="product-img">
                                                    <div class="theme-main">
                                                        <div class="theme-avtar">
                                                            <i class="ti ti-{{ $app->icon }}" style="font-size: 48px;"></i>
                                                        </div>
                                                        <div class="center-text">
                                                            <small class="text-muted">
                                                                <span class="badge bg-danger">{{ __('Not Installed') }}</span>
                                                            </small>
                                                            <small class="text-primary">{{ __('V') }} {{ sprintf('%.1f', $app->version ?? '1.0') }}</small>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="product-content">
                                                    <h4 class="text-capitalize">{{ $app->title }}</h4>
                                                    <div class="center-texts my-1">
                                                        <span class="badge bg-info">{{ $app->category ?? 'Core' }}</span>
                                                    </div>
                                                    <p class="text-muted text-sm mb-0">{{ $app->description ?? '' }}</p>
                                                    <div class="d-flex gap-2 mt-2 action-row">
                                                        <form action="{{ route('myappstore.install', ['appSlug' => $app->name]) }}" method="POST" id="install_{{ $app_id }}" class="m-0 p-0 flex-grow-1">
                                                            @csrf
                                                            <input type="hidden" name="name" value="{{ $app->name }}">
                                                            <button type="button" class="btn btn-success w-100 install-btn" data-id="{{ $app_id }}">{{ __('Install') }}</button>
                                                        </form>
                                                        <a href="{{ route('myappstore.show', $app->name) }}" class="btn btn-primary flex-grow-1">{{ __('View') }}</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    @endif
                                @endforeach
                            @endif
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
@endsection

@push('scripts')
    <script>
        // Added by Brijesh for dropdown settings on app card
        document.addEventListener('DOMContentLoaded', function() {
            const triggers = document.querySelectorAll('.open-dropdown');

            triggers.forEach(function(btn) {
                btn.addEventListener('click', function() {
                    const appId = this.getAttribute('data-id');
                    const dropdownBtn = document.getElementById('dropdownTrigger_' + appId);

                    if (dropdownBtn) {
                        dropdownBtn.click(); // Simulates the click to open dropdown
                    }
                });
            });
        });


        $(document).on('click', '.module_change', function() {
            var id = $(this).attr('data-id');
            $('#loader').show();
            $('#form_' + id).submit();
        });

        // Install/Uninstall buttons on app cards
        $(document).on('click', '.install-btn', function() {
            var id = $(this).data('id');
            var form = document.getElementById('install_' + id);
            if (form) {
                $('#loader').show();
                form.submit();
            }
        });

        $(document).on('click', '.uninstall-btn', function() {
            var id = $(this).data('id');
            var form = document.getElementById('uninstall_' + id);
            if (form) {
                var ok = confirm(
                    "{{ __('Are You Sure? This action can not be undone. Do you want to continue?') }}");
                if (ok) {
                    $('#loader').show();
                    form.submit();
                }
            }
        });

        var moduleSearch = document.getElementById('moduleSearch');

        function applyFilters(scopeSelector) {
            var scope = document.querySelector(scopeSelector);
            if (!scope) return;

            var q = (moduleSearch && moduleSearch.value ? moduleSearch.value.toLowerCase() : '');
            var activeCat = 'all';
            var filterBar = document.querySelector(scopeSelector + ' .category-filter');
            if (filterBar) {
                var activeLink = filterBar.querySelector('.nav-link.active');
                if (activeLink) activeCat = activeLink.getAttribute('data-category') || 'all';
            }

            var cards = scope.querySelectorAll('.module-card');
            cards.forEach(function(card) {
                var name = (card.getAttribute('data-name') || '').toLowerCase();
                var cat = (card.getAttribute('data-category') || '').toLowerCase();
                var matchSearch = !q || name.includes(q);
                var matchCat = (activeCat === 'all') || (cat === activeCat);
                card.style.display = (matchSearch && matchCat) ? 'block' : 'none';
            });
        }

        if (moduleSearch) {
            moduleSearch.addEventListener('keyup', function() {
                // Apply filters on currently visible pane
                var activePane = document.querySelector('.tab-pane.active.show');
                if (activePane) applyFilters('#' + activePane.id);
            });
        }

        // Category filter click handling for each pane
        document.querySelectorAll('.category-filter').forEach(function(ul) {
            ul.addEventListener('click', function(e) {
                var link = e.target.closest('a.nav-link');
                if (!link) return;
                e.preventDefault();
                ul.querySelectorAll('a.nav-link').forEach(function(a) {
                    a.classList.remove('active');
                });
                link.classList.add('active');
                var scope = ul.getAttribute('data-target');
                if (scope) applyFilters(scope);
            });
        });

        // Re-apply filters when switching tabs
        document.getElementById('pills-tab')?.addEventListener('shown.bs.tab', function(event) {
            var target = event.target.getAttribute('data-bs-target');
            if (target) applyFilters(target);
        });

        // Initial filter application on load
        setTimeout(function() {
            var activePane = document.querySelector('.tab-pane.active.show');
            if (activePane) applyFilters('#' + activePane.id);
        }, 0);

        var mobileInput = document.getElementById('searchMobileApp');
        if (mobileInput) {
            mobileInput.addEventListener('keyup', function() {
                var value = $(this).val().toLowerCase();
                $("#mobile-app .card-wrapper").filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });
        }

        var themesInput = document.getElementById('searchThemes');
        if (themesInput) {
            themesInput.addEventListener('keyup', function() {
                var value = $(this).val().toLowerCase();
                $("#themes .card-wrapper").filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });
        }
    </script>
@endpush
