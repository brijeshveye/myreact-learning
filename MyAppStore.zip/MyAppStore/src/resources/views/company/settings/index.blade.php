hello from company setting of myappstore
