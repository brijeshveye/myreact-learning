@extends('layouts.app')
@section('page-title')
   AppStore | {{ $app->title }}
@endsection
@section('page-breadcrumb')
    {{ __('App') }} / {{ url()->current() }} / {{ $app->title }}
@endsection

@push('css')
    <style>
        /* Decorative banner behind hero */
        .app-hero-wrap {
            position: relative;
            overflow: hidden;
            border-radius: 12px;
            background: linear-gradient(135deg, #f0f5ff, #fff0f6);
            padding: 20px;
        }
        .app-hero-bg {
            position: absolute;
            inset: 0;
            background-size: cover;
            background-position: center;
            opacity: 0.08;
            filter: blur(2px);
        }
        .app-hero {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .app-hero .app-icon {
            width: 64px;
            height: 64px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 8px;
            background: #f5f6f8;
            box-shadow: 0 1px 0 rgba(0,0,0,0.03) inset;
        }

        .app-actions .btn+.btn {
            margin-left: .5rem;
        }

        .quick-actions {
            margin-left: auto;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .icon-btn {
            width: 36px;
            height: 36px;
            border-radius: 8px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border: 1px solid #eef0f3;
            background: #fff;
            color: #374151;
            text-decoration: none;
            transition: background .15s ease, border-color .15s ease, transform .05s ease;
        }
        .icon-btn:hover { background: #f8fafc; border-color: #e5e7eb; }
        .icon-btn:active { transform: translateY(1px); }
        .icon-btn.active { color: #b45309; background: #fff7ed; border-color: #fed7aa; }

        .rating { display: inline-flex; align-items: center; gap: 4px; }
        .star { color: #f59e0b; }
        .muted { color: #6b7280; }

        .settings-list .list-group-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

            /* Improved styling for settings links */
            .settings-list {
                --item-bg: #ffffff;
                --item-border: #eef0f3;
                --item-hover: #f7f8fb;
            }
            .settings-list ul {
                list-style: none;
                padding-left: 0;
                margin: 0;
            }
            .settings-list li {
                margin: 0;
            }
            .settings-list li + li {
                margin-top: 8px;
            }
            .settings-list a {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 10px;
                padding: 10px 12px;
                border: 1px solid var(--item-border);
                border-radius: 8px;
                background: var(--item-bg);
                color: inherit;
                text-decoration: none;
                transition: background 0.15s ease, border-color 0.15s ease;
            }
            .settings-list a:hover {
                background: var(--item-hover);
                border-color: #e3e7ee;
            }
            .settings-list a:after {
                content: "\203A"; /* single right-pointing angle quotation mark */
                font-size: 18px;
                color: #9aa2af;
            }
            .settings-list a .label {
                display: inline-flex;
                align-items: center;
                gap: 8px;
            }
            .settings-list a .arrow::before {
                content: "\2192"; /* right arrow */
                font-size: 14px;
                color: #6b7280;
            }
        /* Indent nested lists */
        .settings-list ul ul { margin-top: 8px; padding-left: 14px; }
        .settings-list ul ul a { padding: 8px 10px; }

        /* Map existing store menu classes to our look */
        .settings-list .dash-item { list-style: none; }
        .settings-list .dash-link { text-decoration: none; color: inherit; }
        .settings-list .dash-micon { display: inline-flex; margin-right: 8px; color: #6b7280; }
        .settings-list .dash-mtext { font-weight: 600; }
        .settings-list .dash-arrow { display: none; }
        .settings-list .collepse-menu-buttons { display: none; }
        .settings-list .dash-submenu { display: block !important; border-left: 2px solid #eef0f3; margin-left: 8px; padding-left: 12px; border-radius: 0; }

        .badge-muted {
            background: #eef0f3;
            color: #6b7280;
        }

        /* Gallery */
        .gallery-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; }
        .gallery-item { position: relative; border-radius: 8px; overflow: hidden; background: #f3f4f6; cursor: pointer; }
        .gallery-item img { width: 100%; height: 140px; object-fit: cover; display: block; }
        .gallery-item .overlay { position: absolute; inset: 0; background: linear-gradient(transparent, rgba(0,0,0,0.5)); opacity: 0; transition: opacity .15s ease; }
        .gallery-item:hover .overlay { opacity: 1; }
        .gallery-item .zoom { position: absolute; bottom: 8px; right: 8px; color: #fff; background: rgba(0,0,0,0.4); border-radius: 6px; padding: 4px 6px; font-size: 12px; }
        .gallery-item.placeholder { height: 140px; display:flex; align-items:center; justify-content:center; background: linear-gradient(135deg, #f3f4f6, #e5e7eb); color:#9ca3af; font-size:14px; }

        /* Lightbox */
        #lightbox { position: fixed; z-index: 1055; inset: 0; background: rgba(17,24,39,0.9); display: none; align-items: center; justify-content: center; }
        #lightbox img { max-width: 92vw; max-height: 86vh; border-radius: 8px; box-shadow: 0 10px 30px rgba(0,0,0,0.4); }
        #lightbox .close { position: absolute; top: 20px; right: 20px; color: #fff; font-size: 24px; cursor: pointer; }

        /* Toast */
        #toast { position: fixed; z-index: 1060; bottom: 20px; right: 20px; background: #111827; color: #fff; padding: 10px 14px; border-radius: 8px; display: none; box-shadow: 0 10px 20px rgba(0,0,0,0.2); }

        /* Action overlay */
        #actionOverlay { position: fixed; z-index: 1060; inset: 0; background: rgba(255,255,255,0.6); display: none; align-items: center; justify-content: center; }
        .spinner { width: 42px; height: 42px; border: 3px solid #e5e7eb; border-top-color: #3b82f6; border-radius: 50%; animation: spin 1s linear infinite; }
        @keyframes spin { to { transform: rotate(360deg); } }

        /* Confirm modal (lightweight custom) */
        #confirmModal { position: fixed; z-index: 1065; inset: 0; background: rgba(17,24,39,0.6); display: none; align-items: center; justify-content: center; padding: 16px; }
        .modal-card { background: #fff; border-radius: 12px; max-width: 430px; width: 100%; box-shadow: 0 24px 48px rgba(0,0,0,0.2); }
        .modal-card .modal-header { padding: 14px 16px; border-bottom: 1px solid #eef0f3; display:flex; align-items:center; justify-content:space-between; }
        .modal-card .modal-body { padding: 16px; color: #374151; }
        .modal-card .modal-footer { padding: 12px 16px; display:flex; justify-content:flex-end; gap: 8px; border-top: 1px solid #eef0f3; }
    </style>
@endpush

@section('content')
    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">
                    <div class="app-hero-wrap">
                        @php
                            $bgImage = !empty($app->image) ? $app->image : null;
                        @endphp
                        @if ($bgImage)
                            <div class="app-hero-bg" style="background-image:url('{{ $bgImage }}')"></div>
                        @endif
                        <div class="app-hero">
                            @if (0 && !empty($app->image))
                                <img src="{{ $app->image }}" alt="{{ $app->title }}" class="app-icon" style="object-fit:cover;">
                            @else
                                <div class="app-icon"><i class="ti ti-{{ $app->icon }}" style="font-size:32px;"></i></div>
                            @endif
                            <div>
                                <h3 class="mb-1">{{ $app->title }}</h3>
                                <div class="d-flex align-items-center gap-2">
                                    <span class="badge {{ $app->isInstalled ? 'bg-success' : 'bg-danger' }}">{{ $app->isInstalled ? __('Installed') : __('Not Installed') }}</span>
                                    <span class="badge badge-muted">{{ __('V') }} {{ sprintf('%.1f', $app->version ?? '1.0') }}</span>
                                    <span class="badge badge-muted">{{ $app->category }}</span>
                                    @if (!empty($app->rating))
                                        <span class="rating" title="{{ number_format($app->rating, 1) }} / 5">
                                            @for ($i = 1; $i <= 5; $i++)
                                                <i class="ti {{ $i <= floor($app->rating) ? 'ti-star-filled star' : ($i - $app->rating < 1 && $i - $app->rating > 0 ? 'ti-star-half-filled star' : 'ti-star') }}"></i>
                                            @endfor
                                            <span class="muted">{{ number_format($app->rating, 1) }}</span>
                                            @if (!empty($app->reviews_count))
                                                <span class="muted">({{ $app->reviews_count }})</span>
                                            @endif
                                        </span>
                                    @endif
                                </div>
                            </div>
                            <div class="quick-actions">
                                <a href="#" class="icon-btn" id="btn-share" title="{{ __('Copy link') }}" aria-label="{{ __('Copy link') }}"><i class="ti ti-share"></i></a>
                                <button type="button" class="icon-btn" id="btn-favorite" title="{{ __('Add to favorites') }}" aria-pressed="false" aria-label="{{ __('Add to favorites') }}"><i class="ti ti-heart"></i></button>
                                @if ($app->isInstalled)
                                    <a href="#settings-section" class="icon-btn" title="{{ __('Go to settings') }}" aria-label="{{ __('Go to settings') }}"><i class="ti ti-settings"></i></a>
                                @endif
                            </div>
                        </div>
                    </div>
                    <p class="mt-3 text-muted">{{ $app->description }}</p>
                    <div class="app-actions d-flex">
                        @if ($app->isInstalled)
                            <form onsubmit="return false;" class="me-2">
                                <a href="javascript:void(0)" class="btn btn-outline-danger" id="btn-uninstall"
                                    data-slug="{{ $app->name }}">
                                    <i class="ti ti-trash"></i> {{ __('Uninstall') }}
                                </a>
                            </form>
                            <a href="{{ route('myappstore.index') }}"
                                class="btn btn-outline-secondary"><i class="ti ti-arrow-left"></i> {{ __('Back to Store') }}</a>
                        @else
                            <form onsubmit="return false;" class="me-2">
                                <a href="javascript:void(0)" class="btn btn-success" id="btn-install"
                                    data-slug="{{ $app->name }}">
                                    <i class="ti ti-download"></i> {{ __('Install') }}
                                </a>
                            </form>
                            <a href="{{ route('myappstore.index') }}"
                                class="btn btn-outline-secondary"><i class="ti ti-arrow-left"></i> {{ __('Back to Store') }}</a>
                        @endif
                    </div>
                </div>
            </div>


            @if ($app->isInstalled)
            <div class="card mt-3">
                <div class="card-header d-flex align-items-center justify-content-between" id="settings-section">
                    <h5 class="mb-0">{{ __('Settings & Configuration') }}</h5>
                </div>
                <div class="card-body">
                        <p class="text-muted" style="margin-top:-6px;">{{ __('Manage and configure this app using the options below.') }}</p>
                        @if (!empty($settingsMenuHtml))
                            <div class="settings-list">
                                {!! $settingsMenuHtml !!}
                            </div>
                        @else
                            <div class="text-muted">{{ __('No additional settings are available for this app.') }}</div>
                        @endif
                </div>
            </div>
            @endif

            <div class="card mt-3">
                <div class="card-header d-flex align-items-center justify-content-between">
                    <h5 class="mb-0">{{ __('Screenshots') }}</h5>
                    <span class="text-muted" style="font-size:12px;">{{ __('Click an image to enlarge') }}</span>
                </div>
                <div class="card-body">
                    @php
                        $screens = [];
                        if (!empty($app->screenshots) && is_iterable($app->screenshots)) {
                            $screens = $app->screenshots;
                        }
                    @endphp
                    @if (!empty($screens))
                        <div class="gallery-grid">
                            @foreach ($screens as $src)
                                <div class="gallery-item" data-src="{{ $src }}">
                                    <img src="{{ $src }}" alt="{{ $app->title }} screenshot" loading="lazy">
                                    <div class="overlay"></div>
                                    <div class="zoom"><i class="ti ti-zoom-in"></i></div>
                                </div>
                            @endforeach
                        </div>
                    @else
                        <div class="gallery-grid">
                            @for ($i = 0; $i < 3; $i++)
                                <div class="gallery-item placeholder" aria-hidden="true">
                                    {{ __('No screenshot') }}
                                </div>
                            @endfor
                        </div>
                    @endif
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">{{ __('App Info') }}</h5>
                </div>
                <div class="card-body">
                    <dl class="row mb-0">
                        <dt class="col-5">{{ __('Name') }}</dt>
                        <dd class="col-7">{{ $app->title }}</dd>
                        <dt class="col-5">{{ __('Package Name') }}</dt>
                        <dd class="col-7">{{ $app->name }}</dd>
                        <dt class="col-5">{{ __('Version') }}</dt>
                        <dd class="col-7">{{ sprintf('%.1f', $app->version ?? '1.0') }}</dd>
                        <dt class="col-5">{{ __('Category') }}</dt>
                        <dd class="col-7">{{ $app->category }}</dd>
                        <dt class="col-5">{{ __('Status') }}</dt>
                        <dd class="col-7">{{ $app->isInstalled ? __('Installed') : __('Not Installed') }}</dd>
                    </dl>
                </div>
            </div>

            <div class="card mt-3">
                <div class="card-header">
                    <h5 class="mb-0">{{ __('Links & Support') }}</h5>
                </div>
                <div class="card-body">
                    @php
                        $hasLinks = !empty($app->homepage_url) || !empty($app->docs_url) || !empty($app->support_url) || !empty($app->privacy_url) || !empty($app->demo_url);
                    @endphp
                    @if ($hasLinks)
                        <ul class="list-unstyled mb-0">
                            @if (!empty($app->homepage_url))
                                <li class="mb-2"><a href="{{ $app->homepage_url }}" target="_blank" rel="noopener" class="text-primary"><i class="ti ti-world"></i> {{ __('Homepage') }}</a></li>
                            @endif
                            @if (!empty($app->docs_url))
                                <li class="mb-2"><a href="{{ $app->docs_url }}" target="_blank" rel="noopener" class="text-primary"><i class="ti ti-book"></i> {{ __('Documentation') }}</a></li>
                            @endif
                            @if (!empty($app->support_url))
                                <li class="mb-2"><a href="{{ $app->support_url }}" target="_blank" rel="noopener" class="text-primary"><i class="ti ti-lifebuoy"></i> {{ __('Support') }}</a></li>
                            @endif
                            @if (!empty($app->privacy_url))
                                <li class="mb-2"><a href="{{ $app->privacy_url }}" target="_blank" rel="noopener" class="text-primary"><i class="ti ti-shield-lock"></i> {{ __('Privacy Policy') }}</a></li>
                            @endif
                            @if (!empty($app->demo_url))
                                <li class="mb-2"><a href="{{ $app->demo_url }}" target="_blank" rel="noopener" class="text-primary"><i class="ti ti-external-link"></i> {{ __('Live Demo') }}</a></li>
                            @endif
                        </ul>
                    @else
                        <div class="text-muted">{{ __('No external links are available for this app.') }}</div>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <!-- Lightbox -->
    <div id="lightbox" role="dialog" aria-modal="true" aria-label="{{ __('Screenshot preview') }}">
        <span class="close" aria-label="{{ __('Close') }}">&times;</span>
        <img alt="{{ __('Screenshot') }}">
    </div>

    <!-- Action overlay -->
    <div id="actionOverlay"><div class="spinner" role="status" aria-label="{{ __('Loading') }}"></div></div>

    <!-- Toast -->
    <div id="toast" role="status" aria-live="polite"></div>

    <!-- Confirm Modal -->
    <div id="confirmModal" role="dialog" aria-modal="true" aria-labelledby="confirmTitle">
        <div class="modal-card">
            <div class="modal-header">
                <h6 id="confirmTitle" class="mb-0">{{ __('Confirm Uninstall') }}</h6>
                <button type="button" class="icon-btn" id="confirmClose" aria-label="{{ __('Close') }}"><i class="ti ti-x"></i></button>
            </div>
            <div class="modal-body">
                <p>{{ __('Are You Sure? This action can not be undone. Do you want to continue?') }}</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" id="btn-cancel-uninstall">{{ __('Cancel') }}</button>
                <button type="button" class="btn btn-danger" id="btn-confirm-uninstall">{{ __('Uninstall') }}</button>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
    <script>
        // Utilities
        function showToast(msg) {
            const t = document.getElementById('toast');
            if (!t) return;
            t.textContent = msg;
            t.style.display = 'block';
            setTimeout(() => { t.style.display = 'none'; }, 2500);
        }
        function showOverlay(show) {
            const o = document.getElementById('actionOverlay');
            if (!o) return;
            o.style.display = show ? 'flex' : 'none';
        }

        // Use hidden forms to submit install/uninstall like index grid does, with overlay
        document.getElementById('btn-install')?.addEventListener('click', function() {
            const slug = this.dataset.slug;
            const f = document.getElementById('install_form');
            if (f) {
                f.querySelector('input[name="name"]').value = slug;
                showOverlay(true);
                setTimeout(() => f.submit(), 50);
            }
        });

        // Custom confirm modal for uninstall
        const uninstallBtn = document.getElementById('btn-uninstall');
        const confirmModal = document.getElementById('confirmModal');
        const confirmClose = document.getElementById('confirmClose');
        const cancelUninstall = document.getElementById('btn-cancel-uninstall');
        const confirmUninstall = document.getElementById('btn-confirm-uninstall');
        let pendingSlug = null;

        function closeConfirm() { confirmModal.style.display = 'none'; pendingSlug = null; }
        function openConfirm(slug) { pendingSlug = slug; confirmModal.style.display = 'flex'; }

        uninstallBtn?.addEventListener('click', function() {
            openConfirm(this.dataset.slug);
        });
        confirmClose?.addEventListener('click', closeConfirm);
        cancelUninstall?.addEventListener('click', closeConfirm);
        confirmModal?.addEventListener('click', function(e){ if(e.target === confirmModal) closeConfirm(); });
        confirmUninstall?.addEventListener('click', function() {
            if (!pendingSlug) return;
            const f = document.getElementById('uninstall_form');
            if (f) {
                f.action = f.getAttribute('data-action-template').replace('SLUG_PLACEHOLDER', encodeURIComponent(pendingSlug));
                closeConfirm();
                showOverlay(true);
                setTimeout(() => f.submit(), 50);
            }
        });

        // Favorite (localStorage)
        (function(){
            const favBtn = document.getElementById('btn-favorite');
            if (!favBtn) return;
            const key = `fav:app:{{ $app->name }}`;
            const saved = localStorage.getItem(key) === '1';
            if (saved) { favBtn.classList.add('active'); favBtn.setAttribute('aria-pressed', 'true'); }
            favBtn.addEventListener('click', function(){
                const isActive = favBtn.classList.toggle('active');
                favBtn.setAttribute('aria-pressed', isActive ? 'true' : 'false');
                localStorage.setItem(key, isActive ? '1' : '0');
                showToast(isActive ? "{{ __('Added to favorites') }}" : "{{ __('Removed from favorites') }}");
            });
        })();

        // Share (copy current URL)
        document.getElementById('btn-share')?.addEventListener('click', function(e){
            e.preventDefault();
            const url = window.location.href;
            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(url).then(()=> showToast("{{ __('Link copied to clipboard') }}"));
            } else {
                const ta = document.createElement('textarea');
                ta.value = url; document.body.appendChild(ta); ta.select();
                try { document.execCommand('copy'); showToast("{{ __('Link copied to clipboard') }}"); } catch(_) {}
                document.body.removeChild(ta);
            }
        });

        // Lightbox for screenshots
        (function(){
            const lb = document.getElementById('lightbox');
            if (!lb) return;
            const img = lb.querySelector('img');
            const close = lb.querySelector('.close');
            document.querySelectorAll('.gallery-item').forEach(el => {
                el.addEventListener('click', () => {
                    const src = el.getAttribute('data-src') || el.querySelector('img')?.src;
                    if (src) { img.src = src; lb.style.display = 'flex'; }
                });
            });
            const hide = () => { lb.style.display = 'none'; img.src = ''; };
            close?.addEventListener('click', hide);
            lb.addEventListener('click', (e)=>{ if (e.target === lb) hide(); });
            window.addEventListener('keydown', (e)=>{ if (e.key === 'Escape' && lb.style.display === 'flex') hide(); });
        })();
    </script>
@endpush

@push('scripts')
    <form id="install_form" method="POST" action="{{ route('myappstore.install', ['appSlug' => $app->name]) }}" style="display:none;">
        @csrf
        <input type="hidden" name="name" value="{{ $app->name }}" />
    </form>
    <form id="uninstall_form" method="POST"
        data-action-template="{{ route('myappstore.uninstall', ['appSlug' => $app->name]) }}" action="#"
        style="display:none;">
        @csrf
        <input type="hidden" name="name" value="{{ $app->name }}" />
    </form>
@endpush
