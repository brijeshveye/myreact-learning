<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use Illuminate\Support\Facades\Route;
use Shopyji\MyAppStore\app\Http\Controllers\AppStoreController;

Route::middleware(['auth', 'web', 'PlanModuleCheck:MyAppStore'])->group(function () {
// Route::middleware(['auth', 'web'])->group(function () {
    Route::prefix('myappstore')->name('myappstore.')->group(function () {
        Route::get('/', [AppStoreController::class, 'index'])->name('index');
        Route::get('/app/{appSlug}', [AppStoreController::class, 'show'])->name('show');

        Route::post('/app/{appSlug}/install', [AppStoreController::class, 'install'])->name('install');
        Route::post('/app/{appSlug}/uninstall', [AppStoreController::class, 'uninstall'])->name('uninstall');
    });
});
