# MyAppStore package

A pluggable in-app marketplace for discovering, viewing, installing, and uninstalling apps/modules per store in your ShopyJi/Laravel application.

## Overview

MyAppStore provides a UI and endpoints to:
- List available apps (from your event-driven menu registry)
- Filter/search apps by category
- View an app detail page with settings/actions
- Install or uninstall apps per store with a single click
- Track installations in the database (`app_store_apps`)

It integrates with your existing Menu event system so third‑party or first‑party modules can self‑register as "apps" with title, icon, description, category, and version.

## Features

- App catalog at `/myappstore` with tabs: All Apps, Installed Apps, Apps Available
- Per-store install/uninstall state, persisted in `app_store_apps`
- Category filter + search box
- App detail page at `/myappstore/app/{appSlug}` with optional settings menu
- Automatic menu wiring via listeners (Company menu → MyAppStore → App Store)
- Laravel package auto-discovery for the service provider

## Requirements

- PHP 8.2+
- Laravel 11.x (as used in this repository)

No additional Composer dependencies are required for core functionality.

## Installation

This repository already includes the package as a local path dependency. If integrating elsewhere, require it or add a path repository and run `composer update`.

1) Auto-discovery
- The package registers `Shopyji\\MyAppStore\\app\\Providers\\MyAppStoreServiceProvider` via Laravel auto-discovery (no manual registration needed).

2) Run migrations and optional seeders

```bash
php artisan migrate
# Optional (if provided in your build):
php artisan db:seed --class="Shopyji\\MyAppStore\\Database\\Seeders\\PermissionTableSeeder"
php artisan db:seed --class="Shopyji\\MyAppStore\\Database\\Seeders\\MarketPlaceSeederTableSeeder"
```

3) Clear caches (recommended)

```bash
php artisan optimize:clear
```

## Routes and UI

Base routes (behind `web`, `auth`, and `PlanModuleCheck:MyAppStore`):
- `GET /myappstore` → App catalog (name: `myappstore.index`)
- `GET /myappstore/app/{appSlug}` → App detail (name: `myappstore.show`)
- `POST /myappstore/app/{appSlug}/install` → Install (name: `myappstore.install`)
- `POST /myappstore/app/{appSlug}/uninstall` → Uninstall (name: `myappstore.uninstall`)

Views namespace: `my-app-store` (e.g., `view('my-app-store::index')`).

Menu entries are added by listeners so you’ll see “MyAppStore → App Store” in the sidebar.

## How apps appear in the store

MyAppStore doesn’t hardcode a list of apps. Instead, it listens to your menu event (e.g., `CompanyStoreMenuEvent`) and reads items registered by modules. To have an app show up in the Store, your module should add a top‑level menu entry with fields like:

- `title` (display name)
- `name` (unique slug; used as `appSlug`)
- `icon` (Tabler icons name, e.g., `puzzle`)
- `category` (optional grouping label)
- `version` (e.g., `1.0`)
- `description` (short text)

Example (simplified) inside your listener:

```php
$menu->add([
    'title' => 'My Cool App',
    'icon' => 'puzzle',
    'name' => 'my_cool_app', // this is the appSlug
    'parent' => null,
    'order' => 200,
    'route' => '',
    'module' => 'YourModuleName',
]);
```

Once registered, the app will be visible in the catalog. The Store uses the `name` as the slug for view/install/uninstall routes.

## Install/Uninstall behavior

- Install: creates a record in `app_store_apps` with `app_slug` and the current `store_id`.
- Uninstall: removes the record for that `app_slug` and store.
- The UI marks apps as "Installed" if a record exists for current store.

You can check installation state in your own code by querying the model:

```php
use Shopyji\MyAppStore\app\Models\AppStoreApp;

$isInstalled = AppStoreApp::where('app_slug', 'my_cool_app')
    ->where('store_id', getCurrentStore())
    ->exists();
```

## App detail and settings

The detail page (`/myappstore/app/{appSlug}`) renders a simple view‑model (title, icon, version, category, installed flag) and optionally builds a settings/actions menu via your existing helper (e.g., `generateStoreMenu`) using the same menu registry. If your app contributes nested menu items (children under its top‑level entry), they’ll appear as actions/settings.

## Customization

- Views are loaded with namespace `my-app-store`. You can override them by placing files under `resources/views/vendor/my-app-store/` with matching paths.
- If you want to relax access control, adjust or remove `PlanModuleCheck:MyAppStore` from the route group.

## Database schema

The migration creates a single table:

- `app_store_apps`
  - `id`
  - `app_slug` (unique)
  - `store_id` (nullable, foreign key to `stores.id`, cascade on delete)
  - `timestamps`

Note: The uniqueness on `app_slug` is global. If you want per‑store uniqueness (same app for multiple stores), make it a composite unique `(app_slug, store_id)` instead of `app_slug` alone.

## Troubleshooting

- App list is empty
  - Ensure your app listeners fire on `CompanyStoreMenuEvent` and add top‑level entries (parent = null).

- Install/Uninstall has no visible effect
  - Confirm records are being created/removed in `app_store_apps` for the current store id (check `getCurrentStore()`).

- Route 403/redirect
  - Verify user is authenticated and the current plan allows the `MyAppStore` module (or remove that middleware in routes).

- Settings aren’t visible
  - Only top‑level apps appear in the catalog. Add child menu items under the app’s `name` to surface settings/actions.

## Internals at a glance

- Service provider: `src/app/Providers/MyAppStoreServiceProvider.php`
- Routes: `src/routes/web.php`, `src/routes/api.php`
- Controllers: `src/app/Http/Controllers/AppStoreController.php`
- Model: `src/app/Models/AppStoreApp.php`
- Migration: `src/database/migrations/2025_10_11_102205_create_app_store_apps_table.php`
- Views: `src/resources/views/`
- Event wiring: `src/app/Providers/EventServiceProvider.php` and listeners in `src/app/Listeners`

## License

MIT

## Support

For issues or questions, contact ShopyJi support at support@shopyji.in or use your project tracker.
