<?php

namespace Shopyji\GoogleMerchantCenter\Helper;

use Shopyji\GoogleMerchantCenter\Helper\src\Product\Availability\Availability;
use Shopyji\GoogleMerchantCenter\Helper\src\Feed;
use Shopyji\GoogleMerchantCenter\Helper\src\Product;
use Shopyji\GoogleMerchantCenter\Helper\src\Product\Shipping;
use stdClass;

class Main{

    private $feed;

    public function index(){

        $this->feed = new Feed(
            'My awesome store',
            'https://example.com',
            'This is most awesome store in the world'
        );

        $products = $this->getProducts();
        $this->add_products($products);

        // Here we get complete XML of the feed, that we could write to file or send directly
        $feedXml = $this->feed->build();

        dd($feedXml);
        // $this->dd($feedXml);

    }

    public function getProducts(){
        $products = [];

        for($i = 0; $i<5; $i++){
            $object = new stdClass();

            // Property added to the object
            $object->id = $i;
            $object->title = "My awesome product $i";
            $object->description = 'My awesome description';
            $object->url = "https://example.com/product/$i";
            $object->image = "https://example.com/images/$i.jpg";
            $object->availability = 'in stock';
            $object->price = "100 USD";
            $object->category_name = 'Apparel & Accessories > Clothing > Dresses';
            $object->brand = new stdClass();
            $object->brand->name = 'My awesome brand';
            $object->barcode = '1234567890123';
            $object->color = 'red';
            $object->size = 'XL';

            $object->getUrl = function(){
                return 'https://example.com/product/1';
            };

            $object->isAvailable = function(){
                return 'in stock';
            };

            $object->getImage = function(){
                return 'https://example.com/images/1.jpg';
            };

            $products[] = $object;
        }

        return $products;
    }

    private function add_products($products){
        // Put products to the feed ($products - some data from database for example)
        foreach ($products as $product) {
            $item = new Product();

            // Set common product properties
            $item->setId($product->id);
            $item->setTitle($product->title);
            $item->setDescription($product->description);
            $item->setLink($product->url);
            $item->setImage($product->image);
            if ($product->availability) {
                $item->setAvailability(Availability::IN_STOCK);
            } else {
                $item->setAvailability(Availability::OUT_OF_STOCK);
            }
            $item->setPrice("{$product->price} USD");
            $item->setGoogleCategory($product->category_name);
            $item->setBrand($product->brand->name);
            $item->setGtin($product->barcode);
            $item->setCondition('new');

            // Some additional properties
            $item->setColor($product->color);
            $item->setSize($product->size);

            // Shipping info
            $shipping = new Shipping();
            $shipping->setCountry('US');
            $shipping->setRegion('CA, NSW, 03');
            $shipping->setPostalCode('94043');
            $shipping->setLocationId('21137');
            $shipping->setService('UPS Express');
            $shipping->setPrice('1300 USD');
            $item->setShipping($shipping);

            // Set a custom shipping label and weight (optional)
            $item->setShippingLabel('ups-ground');
            $item->setShippingWeight('2.14');

            // Set a custom label (optional)
            $item->setCustomLabel('Some Label 1', 0);
            $item->setCustomLabel('Some Label 2', 1);

            // Add this product to the feed
            $this->feed->addProduct($item);
        }
    }

    private function dd($data){
        echo '<pre>';
        //print_r($data);
        var_dump($data);
        echo '</pre>';
        //die();
    }
}

?>
