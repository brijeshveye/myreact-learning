<?php

namespace Shopyji\GoogleMerchantCenter\Helper\src\Exception;

use Exception;

class InvalidArgumentException extends Exception
{

}
