<?php

namespace Shopyji\GoogleMerchantCenter\Helper\src;

class RssElement implements \Shopyji\GoogleMerchantCenter\Helper\lib\XmlSerializable
{

    private $value;

    /**
     * Rss version attribute
     * @var string
     */
    private $rssVersion;

    /**
     * RssElement constructor.
     *
     * @param $value
     * @param string $rssVersion
     */
    public function __construct($value, $rssVersion = '')
    {
        $this->value = $value;
        $this->rssVersion = (string)$rssVersion;
    }

    public function xmlSerialize(\Modules\GoogleMerchantCenter\Helper\lib\Writer $writer):void
    {
        if ($this->rssVersion) {
            $writer->writeAttribute('version', $this->rssVersion);
        }

        $writer->write($this->value);
    }
}