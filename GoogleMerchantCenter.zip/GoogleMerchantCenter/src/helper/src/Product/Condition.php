<?php

namespace Shopyji\GoogleMerchantCenter\Helper\src;

class Condition
{
    const NEW_PRODUCT = 'new';

    const REFURBISHED = 'refurbished';

    const USED = 'used';
}
