<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use Illuminate\Support\Facades\Route;
use Shopyji\GoogleMerchantCenter\app\Http\Controllers\GoogleMerchantCenterController;

Route::middleware(['auth', 'web', 'PlanModuleCheck:GoogleMerchantCenter'])->group(function () {
    Route::prefix('gmc')->name('gmc.')->group(function () {
        Route::get('/', [GoogleMerchantCenterController::class, 'index'])->name('index');
        Route::any('/generate-feed', [GoogleMerchantCenterController::class, 'generateFeed'])->name('generateFeed');
    });
});
