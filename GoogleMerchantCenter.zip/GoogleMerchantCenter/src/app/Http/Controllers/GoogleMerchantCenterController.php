<?php

namespace Shopyji\GoogleMerchantCenter\app\Http\Controllers;

use App\Models\Product;
use Exception;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Artisan;
use Shopyji\GoogleMerchantCenter\Helper\GoogleShoppingFeed;
use Shopyji\GoogleMerchantCenter\Helper\Main;

class GoogleMerchantCenterController extends Controller
{
    private $feed;

    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index()
    {
        $currentStore = getCurrentStore();

        $feedData = [];

        $feedData['store'] = $currentStore;
        $feedData['feedExists'] = $this->checkFileExists();

        if ($feedData['feedExists']) {
            $feedContent = $this->getFileFromStorage();

            $feedData['storeEnabled'] = true;
            $feedData['status'] = 'active';

            $feedData['feedUrl'] = url('/storage/app/public/feeds/feed_store_' . $currentStore . '.xml');

            $feedData['fileSize'] = number_format(filesize(storage_path('app/public/feeds/feed_store_' . $currentStore . '.xml')) / 1024, 2) . ' KB';
            $feedData['lastUpdated'] = date("d-M-Y H:i:s", filemtime(storage_path('app/public/feeds/feed_store_' . $currentStore . '.xml')));
            $feedData['totalProducts'] = substr_count($feedContent, '<item>');

            $feedData['products'] = $this->getProductsFromFeed($feedContent);

        } else {
            $feedContent = null;
            $feedData['storeEnabled'] = false;
            $feedData['status'] = 'inactive';
            $feedData['error'] = 'Feed file not found. Please generate the feed.';
        }


        return view('google-merchant-center::index', compact('feedData', 'feedContent'));
    }

    public function generateFeed()
    {
        Artisan::call('optimize:clear');

        $this->feed = GoogleShoppingFeed::init(
            'My Awesome Store',
            'This is a description of my awesome store',
            'https://www.myawesomestore.com'
        );

        $products = $this->getStoreProducts();

        foreach ($products as $product) {
            $this->feed->addItem([
                'id' => $product->id,
                'link' => $product->url,
                'title' => $product->title,
                'g:price' => $product->price,
                'g:image_link' => $product->image,
            ]);
        }

        $xmlContent = $this->feed->generateXml();

        return $this->saveToFile($xmlContent);
    }

    private function getStoreProducts()
    {
        $currentStore = getCurrentStore();

        $products = Product::where('product_type', null)
            ->where('store_id', $currentStore)
            ->where('status', 1);

        return $products;
    }


    private function checkFileExists()
    {
        $currentStore = getCurrentStore();

        $filename = 'feed_store_' . $currentStore . '.xml';

        $filePath = storage_path('app/public/feeds/' . $filename);

        return file_exists($filePath);
    }


    private function saveToFile($content)
    {
        $currentStore = getCurrentStore();

        // check if directory exists, if not create it
        $directory = storage_path('app/public/feeds/');
        if (!file_exists($directory)) {
            mkdir($directory, 0755, true);
        }

        $filename = 'feed_store_' . $currentStore . '.xml';

        $filePath = storage_path('app/public/feeds/' . $filename);

        try{
            file_put_contents($filePath, $content);

            if (!file_exists($filePath)) {
                return redirect()->back()->with('error', __('Products feed file not found.'));
            }

            return redirect()->back()->with('success', __('Products feed generated successfully.'));

        } catch(Exception $ex) {
            throw $ex;
        }
    }


    private function getFileFromStorage() {
        $currentStore = getCurrentStore();

        $filename = 'feed_store_' . $currentStore . '.xml';

        $filePath = storage_path('app/public/feeds/' . $filename);

        if (!file_exists($filePath)) {
            return null;
        }

        return file_get_contents($filePath);
    }


    private function getProductsFromFeed($feedContent = null)
    {
        // Simple XML parsing
        $xml = simplexml_load_string($feedContent);
        $namespaces = $xml->getNamespaces(true);
        $items = $xml->channel->item;

        $products = [];

        foreach ($items as $item) {
            $product = [];
            $product['id'] = (string) $item->id;
            $product['title'] = (string) $item->title;
            $product['link'] = (string) $item->link;
            $product['price'] = (string) $item->children($namespaces['g'])->price;
            $product['image_link'] = (string) $item->children($namespaces['g'])->image_link;

            $products[] = $product;
        }

        return $products;
    }
}
