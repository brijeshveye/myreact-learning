<?php

namespace Shopyji\GoogleMerchantCenter\app\Listeners;
use App\Events\SuperAdminSettingMenuEvent;

class SuperAdminSettingMenuListener
{
    /**
     * Handle the event.
     */
    public function handle(SuperAdminSettingMenuEvent $event): void
    {
        $module = 'GoogleMerchantCenter';
        $menu = $event->menu;
        $menu->add([
            'title' => 'GoogleMerchantCenter',
            'name' => 'googlemerchantcenter',
            'order' => 100,
            'ignore_if' => [],
            'depend_on' => [],
            'route' => 'home',
            'navigation' => 'sidenav',
            'module' => $module,
            'permission' => 'manage-dashboard'
        ]);
    }
}
