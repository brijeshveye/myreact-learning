<?php

namespace Shopyji\GoogleMerchantCenter\app\Listeners;

use App\Events\CompanyStoreMenuEvent;

class CompanyStoreMenuListener
{
    /**
     * Handle the event.
     */
    public function handle(CompanyStoreMenuEvent $event): void
    {
        $module = 'GoogleMerchantCenter';
        $menu = $event->menu;
        $menu->add([
            'title' => 'Google Merchant Center',
            'icon' => 'home',
            'name' => 'google_merchant_center',
            'parent' => null,
            'order' => 2,
            'ignore_if' => [],
            'depend_on' => [],
            'route' => '',
            'module' => $module,
            'permission' => ''
        ]);

        $menu->add([
            'title' => __('Feed Generator'),
            'icon' => 'sitemap',
            'name' => 'feed_generator',
            'parent' => 'google_merchant_center',
            'order' => 231,
            'ignore_if' => [],
            'depend_on' => [],
            'route' => 'gmc.index',
            'module' => $module,
            'permission' => ''
        ]);
    }
}
