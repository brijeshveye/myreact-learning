<?php

namespace Shopyji\GoogleMerchantCenter\app\Listeners;
use App\Events\SuperAdminMenuEvent;

class SuperAdminMenuListener
{
    /**
     * Handle the event.
     */
    public function handle(SuperAdminMenuEvent $event): void
    {
        $module = 'GoogleMerchantCenter';
        $menu = $event->menu;
        $menu->add([
            'title' => 'GoogleMerchantCenter',
            'icon' => 'home',
            'name' => 'googlemerchantcenter',
            'parent' => null,
            'order' => 2,
            'ignore_if' => [],
            'depend_on' => [],
            'route' => 'home',
            'module' => $module,
            'permission' => 'manage-dashboard'
        ]);
    }
}
