@extends('layouts.app')
@section('page-title')
    {{ __('Google Merchant Center') }}
@endsection
@section('page-breadcrumb')
    {{ __('Google Merchant Center') }}
@endsection

@push('css')
    <style>
        /* Hero section styling */
        .feed-hero-wrap { position: relative; overflow: hidden; border-radius: 12px; background: linear-gradient(135deg, #f0f5ff, #eef2ff); padding: 20px; }
        .feed-hero-bg { position: absolute; inset: 0; background-size: cover; background-position: center; opacity: 0.06; filter: blur(2px); }
        .feed-hero { display: flex; align-items: center; gap: 16px; z-index: 1; }
        .feed-quick-actions { z-index: 1;}
        .feed-icon { width: 64px; height: 64px; display: flex; align-items: center; justify-content: center; border-radius: 12px; background: linear-gradient(135deg, #1d4ed8, #2563eb); color: #fff; box-shadow: 0 4px 12px rgba(37,99,235,0.3); }
        .status-indicator { display: inline-flex; align-items: center; gap: 6px; padding: 4px 8px; border-radius: 6px; font-size: 12px; font-weight: 600; }
        .status-active { background: #dcfce7; color: #166534; }
        .status-pending { background: #fef3c7; color: #92400e; }
        .status-error { background: #fee2e2; color: #991b1b; }
        .quick-actions { margin-left: auto; display: flex; align-items: center; gap: 8px; z-index: 1; }
        .icon-btn { width: 36px; height: 36px; border-radius: 8px; display: inline-flex; align-items: center; justify-content: center; border: 1px solid #e5e7eb; background: #fff; color: #374151; text-decoration: none; transition: all .15s ease; }
        .icon-btn:hover { background: #f9fafb; border-color: #d1d5db; transform: translateY(-1px); }
        .icon-btn:active { transform: translateY(0); }

        /* Table styling */
        .feed-table { border-radius: 8px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .feed-table th { background: #f8fafc; font-weight: 600; color: #374151; border-bottom: 1px solid #e5e7eb; }
        .feed-table td { vertical-align: middle; }
        .prod-thumb { width: 48px; height: 48px; border-radius: 6px; object-fit: cover; background: #f3f4f6; }
        .file-size, .money, .sku { font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace; font-size: 12px; color: #6b7280; }
        .action-btn { padding: 4px 8px; font-size: 12px; border-radius: 4px; }

        /* Toast and modal styling */
        #toast { position: fixed; z-index: 1060; bottom: 20px; right: 20px; background: #111827; color: #fff; padding: 12px 16px; border-radius: 8px; display: none; box-shadow: 0 10px 25px rgba(0,0,0,0.3); }
        #confirmModal { position: fixed; z-index: 1065; inset: 0; background: rgba(17,24,39,0.6); display: none; align-items: center; justify-content: center; padding: 16px; }
        .modal-card { background: #fff; border-radius: 12px; max-width: 440px; width: 100%; box-shadow: 0 25px 50px rgba(0,0,0,0.25); }
        .modal-card .modal-header { padding: 16px 20px; border-bottom: 1px solid #e5e7eb; display: flex; align-items: center; justify-content: space-between; }
        .modal-card .modal-body { padding: 20px; color: #374151; }
        .modal-card .modal-footer { padding: 16px 20px; display: flex; justify-content: flex-end; gap: 8px; border-top: 1px solid #e5e7eb; }

        /* Stats cards */
        .stats-card { background: linear-gradient(135deg, #fff, #f8fafc); border: 1px solid #e5e7eb; border-radius: 8px; padding: 16px; text-align: center; height: 100%; }
        .stats-number { font-size: 24px; font-weight: 700; color: #1f2937; }
        .stats-label { font-size: 13px; color: #6b7280; margin-top: 4px; }
    </style>
@endpush

@section('content')
    <div class="row">
        <!-- Feed Details Section -->
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="feed-hero-wrap">
                        <div class="feed-hero-bg" style="background-image:url('data:image/svg+xml,<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 100 100\"><circle cx=\"20\" cy=\"20\" r=\"3\" fill=\"%232563eb\" opacity=\"0.3\"/><circle cx=\"80\" cy=\"30\" r=\"2\" fill=\"%232563eb\" opacity=\"0.2\"/><circle cx=\"60\" cy=\"70\" r=\"4\" fill=\"%232563eb\" opacity=\"0.15\"/></svg>')"></div>
                        <div class="feed-hero">
                            <div class="feed-icon">
                                <i class="ti ti-brand-google" style="font-size: 32px;"></i>
                            </div>
                            <div class="feed-quick-actions">
                                <h3 class="mb-1">{{ __('Feed Status') }}</h3>
                                <div class="d-flex align-items-center gap-2 mb-2">
                                    @php
                                        $status = $feedData['status'] ?? 'pending';
                                        $statusClass = $status === 'active' ? 'status-active' : ($status === 'error' ? 'status-error' : 'status-pending');
                                    @endphp
                                    <span class="status-indicator {{ $statusClass }}" id="status-indicator">
                                        <i class="ti ti-{{ $status === 'active' ? 'check' : ($status === 'error' ? 'alert-circle' : 'clock') }}"></i>
                                        {{ $status === 'active' ? __('Active') : ($status === 'error' ? __('Error') : __('Generating')) }}
                                    </span>
                                    <span class="badge bg-light text-dark">{{ __('Last Generated') }}: {{ $feedData['lastGenerated'] ?? __('Never') }}</span>
                                </div>
                                <div class="d-flex align-items-center gap-3 flex-wrap">
                                    <span class="text-muted">{{ __('Feed for Store') }}:
                                        @if (!empty($feedData['storeEnabled']))
                                            <span class="text-success">{{ __('Enabled') }}</span>
                                        @else
                                            <span class="text-danger">{{ __('Disabled') }}</span>
                                        @endif
                                    </span>
                                    @if (!empty($feedData['feedUrl']))
                                        <a href="{{ $feedData['feedUrl'] }}" target="_blank" class="text-primary text-decoration-none">
                                            <i class="ti ti-external-link"></i> {{ __('View Feed') }}
                                        </a>
                                    @endif
                                </div>
                            </div>
                            <div class="quick-actions">
                                <button type="button" class="icon-btn" id="btn-generate" title="{{ __('Generate Feed') }}" aria-label="{{ __('Generate Feed') }}"><i class="ti ti-refresh"></i></button>
                                <button type="button" class="icon-btn" id="btn-settings" title="{{ __('Feed Settings') }}" aria-label="{{ __('Feed Settings') }}"><i class="ti ti-settings"></i></button>
                                <button type="button" class="icon-btn" id="btn-download" title="{{ __('Download Feed') }}" aria-label="{{ __('Download Feed') }}"><i class="ti ti-download"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Stats Section -->
        <div class="row mt-3">
            <div class="col-md-4 col-sm-6 mb-3">
                <div class="stats-card">
                    <div class="stats-number">{{ number_format($feedData['totalProducts'] ?? 0) }}</div>
                    <div class="stats-label">{{ __('Total Products in Feed') }}</div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 mb-3">
                <div class="stats-card">
                    <div class="stats-number">{{ $feedData['fileSize'] ?? '0 KB' }}</div>
                    <div class="stats-label">{{ __('Current File Size') }}</div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 mb-3">
                <div class="stats-card">
                    <div class="stats-number">{{ $feedData['lastUpdated'] ?? __('Never') }}</div>
                    <div class="stats-label">{{ __('Last Updated') }}</div>
                </div>
            </div>
        </div>

        <!-- Feed URL & Instructions -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header d-flex align-items-center justify-content-between">
                        <h5 class="mb-0">{{ __('Feed URL & Setup') }}</h5>
                        <div class="d-flex gap-2">
                            <button type="button" class="btn btn-outline-primary btn-sm" id="btn-copy-feed-url"><i class="ti ti-copy"></i> {{ __('Copy URL') }}</button>
                            <button type="button" class="btn btn-primary btn-sm" id="btn-regenerate-2"><i class="ti ti-refresh"></i> {{ __('Regenerate Feed') }}</button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label for="feedUrlInput" class="form-label">{{ __('Feed XML URL') }}</label>
                            <div class="input-group">
                                <input type="text" id="feedUrlInput" class="form-control" value="{{ $feedData['feedUrl'] ?? '' }}" readonly>
                                <button class="btn btn-outline-secondary" type="button" id="btn-copy-feed-url-inline"><i class="ti ti-clipboard"></i> {{ __('Copy') }}</button>
                                @if (!empty($feedData['feedUrl']))
                                    <a href="{{ $feedData['feedUrl'] }}" target="_blank" class="btn btn-outline-info"><i class="ti ti-external-link"></i> {{ __('Open') }}</a>
                                @endif
                            </div>
                            @if (empty($feedData['feedUrl']))
                                <small class="text-muted">{{ __('Feed URL is not available yet. Generate the feed first.') }}</small>
                            @endif
                        </div>
                        <div>
                            <h6 class="mb-2">{{ __('How to use this in Google Merchant Center') }}</h6>
                            <ol class="mb-0 text-muted">
                                <li>{{ __('Copy the Feed XML URL above.') }}</li>
                                <li>{{ __('In Google Merchant Center, go to Products > Feeds and click the plus (+) button to add a new feed.') }}</li>
                                <li>{{ __('Choose your target country and language, then select “Scheduled fetch” as the input method.') }}</li>
                                <li>{{ __('Paste the Feed XML URL into the file URL field and set an appropriate fetch frequency.') }}</li>
                                <li>{{ __('Save and fetch to import your products. Ensure the URL is publicly accessible.') }}</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Products in Feed Table -->
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex align-items-center justify-content-between">
                    <h5 class="mb-0">{{ __('Products in Feed') }}</h5>
                    <div class="d-flex gap-2">
                        <button type="button" class="btn btn-outline-danger btn-sm" id="btn-delete-selected"><i class="ti ti-trash"></i> {{ __('Delete Selected') }}</button>
                        <button type="button" class="btn btn-primary btn-sm" id="btn-refresh-table"><i class="ti ti-refresh"></i> {{ __('Refresh') }}</button>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table feed-table mb-0">
                            <thead>
                                <tr>
                                    <th style="width: 40px;"><input type="checkbox" id="selectAll" class="form-check-input"></th>
                                    <th>{{ __('Product') }}</th>
                                    <th>{{ __('SKU') }}</th>
                                    <th>{{ __('Price') }}</th>
                                    <th>{{ __('Availability') }}</th>
                                    <th>{{ __('Updated At') }}</th>
                                    <th style="width: 120px;">{{ __('Actions') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                @php $feedProducts = $feedData['products'] ?? []; @endphp
                                @if (empty($feedProducts))
                                    <tr>
                                        <td colspan="7" class="text-center py-4 text-muted">
                                            <i class="ti ti-package" style="font-size: 48px; opacity: 0.3;"></i>
                                            <div class="mt-2">{{ __('No products found in the feed') }}</div>
                                            <small>{{ __('Generate the feed to populate products') }}</small>
                                        </td>
                                    </tr>
                                @else
                                    @foreach ($feedProducts as $prod)
                                        <tr>
                                            <td><input type="checkbox" class="form-check-input prod-checkbox" value="{{ $prod['id'] }}"></td>
                                            <td>
                                                <div class="d-flex align-items-center gap-2">
                                                    @if (!empty($prod['image']))
                                                        <img src="{{ $prod['image'] }}" alt="{{ $prod['title'] }}" class="prod-thumb">
                                                    @else
                                                        <div class="prod-thumb d-flex align-items-center justify-content-center"><i class="ti ti-photo"></i></div>
                                                    @endif
                                                    <div>
                                                        <div class="fw-medium">{{ $prod['title'] }}</div>
                                                        <small class="text-muted">ID: {{ $prod['id'] }}</small>
                                                    </div>
                                                </div>
                                            </td>
                                            <td><span class="sku">{{ $prod['sku'] ?? '-' }}</span></td>
                                            <td><span class="money">{{ $prod['price'] ?? '-' }}</span></td>
                                            <td>
                                                @php $avail = $prod['availability'] ?? 'out_of_stock'; @endphp
                                                @if ($avail === 'in_stock')
                                                    <span class="badge bg-success">{{ __('In stock') }}</span>
                                                @elseif ($avail === 'preorder')
                                                    <span class="badge bg-info">{{ __('Preorder') }}</span>
                                                @else
                                                    <span class="badge bg-secondary">{{ __('Out of stock') }}</span>
                                                @endif
                                            </td>
                                            <td><small class="text-muted">{{ $prod['updated_at'] ?? '-' }}</small></td>
                                            <td>
                                                <div class="d-flex gap-1">
                                                    <button type="button" class="btn btn-outline-danger action-btn delete-product" data-id="{{ $prod['id'] }}" title="{{ __('Delete') }}"><i class="ti ti-trash"></i></button>
                                                </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Toast -->
    <div id="toast" role="status" aria-live="polite"></div>

    <!-- Confirm Modal -->
    <div id="confirmModal" role="dialog" aria-modal="true" aria-labelledby="confirmTitle">
        <div class="modal-card">
            <div class="modal-header">
                <h6 id="confirmTitle" class="mb-0">{{ __('Confirm Action') }}</h6>
                <button type="button" class="icon-btn" id="confirmClose" aria-label="{{ __('Close') }}"><i class="ti ti-x"></i></button>
            </div>
            <div class="modal-body">
                <p id="confirmMessage">{{ __('Are you sure you want to proceed?') }}</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" id="btn-cancel">{{ __('Cancel') }}</button>
                <button type="button" class="btn btn-danger" id="btn-confirm">{{ __('Confirm') }}</button>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
    <script>
        function showToast(msg, type = 'success') {
            const toast = document.getElementById('toast');
            if (!toast) return;
            toast.textContent = msg;
            toast.style.background = type === 'error' ? '#dc2626' : '#111827';
            toast.style.display = 'block';
            setTimeout(() => { toast.style.display = 'none'; }, 3000);
        }

        function showConfirm(title, message, callback) {
            const modal = document.getElementById('confirmModal');
            const titleEl = document.getElementById('confirmTitle');
            const messageEl = document.getElementById('confirmMessage');
            const confirmBtn = document.getElementById('btn-confirm');
            titleEl.textContent = title;
            messageEl.textContent = message;
            modal.style.display = 'flex';
            confirmBtn.onclick = function() { modal.style.display = 'none'; callback && callback(); };
        }

        document.getElementById('confirmClose')?.addEventListener('click', () => document.getElementById('confirmModal').style.display = 'none');
        document.getElementById('btn-cancel')?.addEventListener('click', () => document.getElementById('confirmModal').style.display = 'none');
        document.getElementById('confirmModal')?.addEventListener('click', function(e){ if (e.target === this) this.style.display = 'none'; });

        // Quick actions
        document.getElementById('btn-generate')?.addEventListener('click', function(){
            showConfirm(
                "{{ __('Generate Feed') }}",
                "{{ __('This will generate a new feed. Continue?') }}",
                function(){
                    showToast("{{ __('Generating feed...') }}");

                    // Disabe buttons during generation
                    document.getElementById('btn-generate').disabled = true;
                    document.getElementById('btn-settings').disabled = true;

                    document.getElementById('status-indicator').classList.add('loading');

                    $.ajax({
                        url: "{{ route('gmc.generateFeed') }}",
                        method: 'POST',
                        data: {
                            _token: "{{ csrf_token() }}"
                        },
                        success: function(response) {
                            showToast("{{ __('Feed generated successfully!') }}");
                            location.reload();
                        },
                        error: function() {
                            showToast("{{ __('Failed to generate feed.') }}", 'error');
                        },
                        complete: function() {
                            // Re-enable buttons
                            document.getElementById('btn-generate').disabled = false;
                            document.getElementById('btn-settings').disabled = false;
                            document.getElementById('status-indicator').classList.remove('loading');
                        }
                    });

                }
            );
        });
        document.getElementById('btn-settings')?.addEventListener('click', function(){
            @php $settingsRoute = route('gmc.index'); @endphp
            window.location.href = "{{ $settingsRoute }}#settings";
        });
        document.getElementById('btn-download')?.addEventListener('click', function(){
            @if (!empty($feedData['feedUrl']))
                window.open("{{ $feedData['feedUrl'] }}", '_blank');
                showToast("{{ __('Downloading feed...') }}");
            @else
                showToast("{{ __('No feed available for download') }}", 'error');
            @endif
        });

        // Table actions
        document.getElementById('selectAll')?.addEventListener('change', function(){
            document.querySelectorAll('.prod-checkbox').forEach(cb => cb.checked = this.checked);
        });
        document.getElementById('btn-delete-selected')?.addEventListener('click', function(){
            const selected = document.querySelectorAll('.prod-checkbox:checked');
            if (selected.length === 0) { showToast("{{ __('Please select products to delete') }}", 'error'); return; }
            showConfirm(
                "{{ __('Delete Selected Products') }}",
                `{{ __('Are you sure you want to delete') }} ${selected.length} {{ __('products from the feed?') }}`,
                function(){
                    const ids = Array.from(selected).map(cb => cb.value);
                    // TODO: submit deletion to backend
                    showToast(`{{ __('Deleted') }} ${ids.length} {{ __('products') }}`);
                    setTimeout(() => location.reload(), 600);
                }
            );
        });
        document.querySelectorAll('.delete-product').forEach(btn => {
            btn.addEventListener('click', function(){
                const id = this.dataset.id;
                showConfirm(
                    "{{ __('Delete Product') }}",
                    "{{ __('Are you sure you want to delete this product from the feed?') }}",
                    function(){
                        // TODO: submit deletion to backend
                        showToast("{{ __('Product deleted') }}");
                        setTimeout(() => location.reload(), 600);
                    }
                );
            });
        });
        document.getElementById('btn-refresh-table')?.addEventListener('click', function(){ showToast("{{ __('Refreshing...') }}"); location.reload(); });

        // Copy Feed URL
        function copyFeedUrl(){
            const input = document.getElementById('feedUrlInput');
            if (!input || !input.value) { showToast("{{ __('No feed URL to copy') }}", 'error'); return; }
            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(input.value).then(()=> showToast("{{ __('Feed URL copied') }}"));
            } else {
                input.select();
                try { document.execCommand('copy'); showToast("{{ __('Feed URL copied') }}"); } catch(_) { showToast("{{ __('Copy failed') }}", 'error'); }
                input.blur();
            }
        }
        document.getElementById('btn-copy-feed-url')?.addEventListener('click', copyFeedUrl);
        document.getElementById('btn-copy-feed-url-inline')?.addEventListener('click', copyFeedUrl);

        // Regenerate (secondary button)
        document.getElementById('btn-regenerate-2')?.addEventListener('click', function(){
            document.getElementById('btn-generate')?.click();
        });
    </script>
@endpush
