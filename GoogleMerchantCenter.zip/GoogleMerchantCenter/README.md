# Google Merchant Center (GMC) package

First‑party package for generating and serving a Google Merchant Center product feed from your ShopyJi/Laravel app.

## Overview

This package adds a simple UI and routes to:
- Build a Google Merchant Center compatible RSS/Atom XML feed for the current store
- Save it at `storage/app/public/feeds/feed_store_{STORE_ID}.xml`
- View feed status, copy the public feed URL, and inspect items parsed from the feed

Under the hood it uses `spatie/array-to-xml` to construct the XML and a small helper to enforce the minimal product fields Google expects.

## Features

- One‑click feed generation from the dashboard (UI at `/gmc`)
- Store‑scoped feed files (multi‑store aware via `getCurrentStore()`)
- Pretty dashboard with stats (total items, file size, last updated)
- Copy/Open feed URL from the UI
- Basic table preview parsed from the existing feed
- Automatic menu wiring via events (Company Store menu > Google Merchant Center)
- Laravel package auto‑discovery for the service provider

## Requirements

- PHP 8.2+
- Laravel 11.x (as used in this repository)
- Dependency: `spatie/array-to-xml` (already required in the project root). If you use this package outside this repo, require it:

```bash
composer require spatie/array-to-xml
```

## Installation

This repository already includes the package as a local path dependency (`packages/shopyji/*`). If you are integrating it elsewhere, either require it from Packagist or add it as a path repository and run `composer update`.

1) Ensure Composer autoload discovers the provider
- The package declares auto‑discovery via `extra.laravel.providers`:
  - `Shopyji\GoogleMerchantCenter\app\Providers\GoogleMerchantCenterServiceProvider`
- No manual provider registration is needed in a standard Laravel app.

2) Run migrations and (optionally) seeders
- This package ships with seeders for Marketplace page wiring and permissions. They are optional.

```bash
php artisan db:seed --class="Shopyji\\GoogleMerchantCenter\\Database\\Seeders\\MarketPlaceSeederTableSeeder"
php artisan db:seed --class="Shopyji\\GoogleMerchantCenter\\Database\\Seeders\\PermissionTableSeeder"
```

3) Ensure storage is publicly linked and writable

```bash
php artisan storage:link
```

- The feed file is written to: `storage/app/public/feeds/`
- Your web server user must be able to create and write files there.

4) Clear caches (recommended)

```bash
php artisan optimize:clear
```

## Routes and UI

- Base UI: `GET /gmc` (named route: `gmc.index`)
- Generate feed: `POST /gmc/generate-feed` (named route: `gmc.generateFeed`)

Middleware applied:
- `web`, `auth`, and `PlanModuleCheck:GoogleMerchantCenter`

Menu entry (Company Store) is added via event listeners; you should see “Google Merchant Center → Feed Generator” in the sidebar.

## How it works

1) The controller (`app/Http/Controllers/GoogleMerchantCenterController.php`) collects products for the current store and pushes them to the helper `Helper/GoogleShoppingFeed`.
2) The helper validates minimal required fields and builds the RSS/Atom XML using `spatie/array-to-xml`.
3) The XML is saved to `storage/app/public/feeds/feed_store_{STORE_ID}.xml`.
4) The UI reads that file, shows stats, and parses items back with SimpleXML for a quick preview.

Feed item minimum required keys (enforced):
- `id`
- `link`
- `title`
- `g:price`
- `g:image_link`

## Public feed URL

- By default the UI shows the URL like:
  - `https://your-domain.tld/storage/app/public/feeds/feed_store_{STORE_ID}.xml`
- If you use Laravel's default storage symlink (recommended), your public URL may be:
  - `https://your-domain.tld/storage/feeds/feed_store_{STORE_ID}.xml`
- Adjust as needed if you serve storage differently.

## Customizing data mapping

The package expects your `App\Models\Product` or equivalent to provide values for:
- `id` (string/int)
- `url` (product page URL)
- `title`
- `price` (e.g., `19.99 USD` or provide currency separately and format)
- `image` (absolute image URL)

Update `GoogleMerchantCenterController::getStoreProducts()` to fit your schema or hydrate a collection with these fields before passing to the feed builder.

Note: The sample code currently builds a query; make sure you actually fetch a collection (e.g., call `->get()` or `->cursor()`) before iterating.

## Scheduling (optional)

You can regenerate the feed on a schedule by either:
- Adding a scheduled task that hits `route('gmc.generateFeed')` via HTTP (with auth/CSRF considerations), or
- Creating a small Artisan command that calls the same helper and scheduling it in `app/Console/Kernel.php`.

Example scheduler stub:

```php
$schedule->call(function () {
    // Invoke the same logic as generateFeed()
})->dailyAt('02:30');
```

## Troubleshooting

- Class "Spatie\ArrayToXml\ArrayToXml" not found
  - Install the dependency: `composer require spatie/array-to-xml` and run `php artisan optimize:clear`.

- Failed to write file in storage
  - Ensure `storage/app/public/feeds/` exists and is writable, and run `php artisan storage:link`.

- simplexml_load_string parser error
  - Ensure you are parsing the raw XML string (see `generateXml()`), not a full HTTP response body (which includes headers). The controller uses `generateXml()` for file output.

- Missing product fields (exceptions like "Required field 'g:price' is missing")
  - Ensure you map and pass all required keys when calling `addItem()`.

## Internals at a glance

- Service provider: `app/Providers/GoogleMerchantCenterServiceProvider.php`
- Routes: `src/routes/web.php`, `src/routes/api.php`
- Controller: `app/Http/Controllers/GoogleMerchantCenterController.php`
- Feed helper: `src/helper/GoogleShoppingFeed.php`
- Views: `src/resources/views/`
- Event wiring: `app/Providers/EventServiceProvider.php` and listeners under `app/Listeners`

## License

MIT

## Support

For issues or questions, please contact ShopyJi support at support@shopyji.in or open an issue in your project tracker.
