<?php

namespace Shopyji\MyWallet\app\Http\Controllers\SuperAdmin;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Collection;
use Shopyji\MyWallet\app\Models\WalletWithdrawRequest;
use Shopyji\MyWallet\app\Models\Wallet;
use Shopyji\MyWallet\app\Models\WalletTransaction;
use App\Models\userActiveModule;
use App\Models\Store;
use Illuminate\Support\Facades\DB;

class WalletAdminController extends Controller
{
    public function index(Request $request)
    {
        // Withdraw aggregates
        $withdrawPending = (float) WalletWithdrawRequest::where('status', WalletWithdrawRequest::STATUS_PENDING)->sum('amount');
        $withdrawnAmount = (float) WalletWithdrawRequest::where('status', WalletWithdrawRequest::STATUS_APPROVED)->sum('amount');
        $withdrawCount = (int) WalletWithdrawRequest::count();

        // Business rule: total balance to pay currently equals pending amount (until earnings source integrated)
        $totalToPay = $withdrawPending;
        $status = 'active';

        // Latest withdraw requests
        $withdrawRequests = WalletWithdrawRequest::with(['user:id,name', 'store:id,name'])
            ->latest('created_at')->limit(25)->get();

        // Stores with MyWallet activated: based on userActiveModule for module 'MyWallet'
        $storeIds = userActiveModule::where('module', 'MyWallet')->pluck('user_id')->unique()->flatMap(function ($userId) {
            // Map user to their current_store; this keeps it simple for now
            $user = \App\Models\User::find($userId);
            return $user?->current_store ? [$user->current_store] : [];
        })->filter()->unique();

        $activatedStores = Store::whereIn('id', $storeIds)->get(['id', 'name', 'created_by', 'created_at'])->map(function ($store) {
            $owner = \App\Models\User::find($store->created_by);
            $store->owner_name = $owner?->name;
            $store->plan_name = null; // TODO: Integrate with plan system if needed
            $store->activated_at = $store->created_at;
            // Available balance for this store (owner's wallet)
            if ($owner) {
                $wallet = Wallet::firstOrCreate(['user_id' => $owner->id, 'store_id' => $store->id]);
                $store->available_balance = (float) $wallet->balance;
            } else {
                $store->available_balance = 0.0;
            }
            return $store;
        });

        $paymentMethods = collect([
            ['name' => 'Bank Transfer', 'code' => 'bank', 'status' => 'active'],
            ['name' => 'UPI', 'code' => 'upi', 'status' => 'active'],
        ]);

        return view('my-wallet::super-admin.index', compact(
            'totalToPay',
            'withdrawPending',
            'withdrawnAmount',
            'withdrawCount',
            'withdrawRequests',
            'activatedStores',
            'paymentMethods',
            'status'
        ));
    }

    public function creditStore(Request $request)
    {
        $data = $request->validate([
            'store_id' => ['required', 'integer', 'exists:stores,id'],
            'amount' => ['required', 'numeric', 'min:0.01'],
            'note' => ['nullable', 'string', 'max:500'],
        ]);

        $store = Store::findOrFail($data['store_id']);
        $owner = \App\Models\User::find($store->created_by);
        if (!$owner) {
            return back()->withErrors(['store_id' => __('Invalid store owner.')]);
        }

        DB::transaction(function () use ($data, $store, $owner, $request) {
            $wallet = Wallet::firstOrCreate([
                'user_id' => $owner->id,
                'store_id' => $store->id,
            ]);

            $wallet->balance = (float) $wallet->balance + (float) $data['amount'];
            $wallet->save();

            WalletTransaction::create([
                'wallet_id' => $wallet->id,
                'store_id' => $store->id,
                'user_id' => $owner->id,
                'type' => 'credit',
                'source' => 'manual',
                'amount' => $data['amount'],
                'reference' => null,
                'meta' => [
                    'note' => $data['note'] ?? null,
                    'credited_by' => $request->user()?->id,
                ],
            ]);
        });

        return back()->with('success', __('Amount credited to store wallet successfully.'));
    }

    public function review(Request $request, $id)
    {
        $withdraw = WalletWithdrawRequest::with(['user:id,name,email', 'store:id,name,created_by'])->findOrFail($id);
        $owner = \App\Models\User::find($withdraw->store?->created_by);

        // Payout settings for the user who requested
        $settings = \Shopyji\MyWallet\app\Models\WalletSetting::firstOrCreate(['user_id' => $withdraw->user_id]);

        // Past withdraws for this user/store
        $past = WalletWithdrawRequest::where('user_id', $withdraw->user_id)
            ->when($withdraw->store_id, fn($q) => $q->where('store_id', $withdraw->store_id))
            ->latest('created_at')->limit(20)->get();

        return view('my-wallet::super-admin.withdraw-review', compact('withdraw', 'owner', 'settings', 'past'));
    }

    public function approve(Request $request, $id)
    {
        $data = $request->validate([
            'paid_reference' => ['nullable','string','max:150'],
        ]);

        $withdraw = WalletWithdrawRequest::findOrFail($id);
        if ($withdraw->status !== WalletWithdrawRequest::STATUS_PENDING) {
            return back()->withErrors(['status' => __('Only pending requests can be approved.')]);
        }

        DB::transaction(function () use ($withdraw, $data, $request) {
            $withdraw->status = WalletWithdrawRequest::STATUS_APPROVED;
            $withdraw->paid_at = now();
            $withdraw->paid_reference = $data['paid_reference'] ?? null;
            $withdraw->save();

            // Update wallet withdrawn_total, leave balance as already reserved in user flow
            $wallet = Wallet::firstOrCreate([
                'user_id' => $withdraw->user_id,
                'store_id' => $withdraw->store_id,
            ]);
            $wallet->withdrawn_total = (float) $wallet->withdrawn_total + (float) $withdraw->amount;
            $wallet->save();

            // Update the existing withdraw transaction meta to approved or create if missing
            $tx = WalletTransaction::where('wallet_id', $wallet->id)
                ->where('source', 'withdraw')
                ->where('type', 'debit')
                ->where('amount', $withdraw->amount)
                ->latest('id')->first();
            if ($tx) {
                $meta = $tx->meta ?? [];
                $meta['status'] = 'approved';
                $meta['paid_reference'] = $withdraw->paid_reference;
                $meta['approved_by'] = $request->user()?->id;
                $tx->meta = $meta;
                $tx->save();
            } else {
                WalletTransaction::create([
                    'wallet_id' => $wallet->id,
                    'store_id' => $withdraw->store_id,
                    'user_id' => $withdraw->user_id,
                    'type' => 'debit',
                    'source' => 'withdraw',
                    'amount' => $withdraw->amount,
                    'reference' => $withdraw->paid_reference,
                    'meta' => [
                        'status' => 'approved',
                        'approved_by' => $request->user()?->id,
                    ],
                ]);
            }
        });

        return redirect()->route('superadmin.mywallet.withdraw.review', $withdraw->id)->with('success', __('Withdraw request approved.'));
    }

    public function reject(Request $request, $id)
    {
        $data = $request->validate([
            'reason' => ['required','string','max:500'],
        ]);

        $withdraw = WalletWithdrawRequest::findOrFail($id);
        if ($withdraw->status !== WalletWithdrawRequest::STATUS_PENDING) {
            return back()->withErrors(['status' => __('Only pending requests can be rejected.')]);
        }

        DB::transaction(function () use ($withdraw, $data, $request) {
            $withdraw->status = WalletWithdrawRequest::STATUS_REJECTED;
            $withdraw->save();

            // Refund reserved amount back to wallet balance
            $wallet = Wallet::firstOrCreate([
                'user_id' => $withdraw->user_id,
                'store_id' => $withdraw->store_id,
            ]);
            $wallet->balance = (float) $wallet->balance + (float) $withdraw->amount;
            $wallet->save();

            // Update or create a transaction entry marking rejection
            $tx = WalletTransaction::where('wallet_id', $wallet->id)
                ->where('source', 'withdraw')
                ->where('type', 'debit')
                ->where('amount', $withdraw->amount)
                ->latest('id')->first();
            if ($tx) {
                $meta = $tx->meta ?? [];
                $meta['status'] = 'rejected';
                $meta['reason'] = $data['reason'];
                $meta['rejected_by'] = $request->user()?->id;
                $tx->meta = $meta;
                $tx->save();
            }

            // Record a compensating credit for refund
            WalletTransaction::create([
                'wallet_id' => $wallet->id,
                'store_id' => $withdraw->store_id,
                'user_id' => $withdraw->user_id,
                'type' => 'credit',
                'source' => 'withdraw',
                'amount' => $withdraw->amount,
                'reference' => null,
                'meta' => [
                    'status' => 'refund',
                    'reason' => $data['reason'],
                    'rejected_by' => $request->user()?->id,
                ],
            ]);
        });

        return redirect()->route('superadmin.mywallet.withdraw.review', $withdraw->id)->with('success', __('Withdraw request rejected and amount refunded.'));
    }

    public function transactionsIndex(Request $request)
    {
        $type = $request->query('type');
        $source = $request->query('source');
        $storeId = $request->query('store_id');
        $userId = $request->query('user_id');
        $dateFrom = $request->query('from');
        $dateTo = $request->query('to');

        $query = WalletTransaction::with(['user:id,name', 'store:id,name'])
            ->when($type && in_array($type, ['credit','debit']), fn($q) => $q->where('type', $type))
            ->when($source, fn($q) => $q->where('source', $source))
            ->when($storeId, fn($q) => $q->where('store_id', $storeId))
            ->when($userId, fn($q) => $q->where('user_id', $userId))
            ->when($dateFrom, fn($q) => $q->whereDate('created_at', '>=', $dateFrom))
            ->when($dateTo, fn($q) => $q->whereDate('created_at', '<=', $dateTo))
            ->latest('created_at');

        $transactions = $query->paginate(25)->withQueryString();
        $totals = [
            'credits' => (float) (clone $query)->where('type','credit')->sum('amount'),
            'debits'  => (float) (clone $query)->where('type','debit')->sum('amount'),
        ];

        // For filters dropdowns
        $stores = Store::orderBy('name')->get(['id','name']);
        $users = \App\Models\User::orderBy('name')->get(['id','name']);

        return view('my-wallet::super-admin.transactions.index', compact('transactions', 'totals', 'type', 'source', 'storeId', 'userId', 'dateFrom', 'dateTo', 'stores', 'users'));
    }

    public function userTransactions(Request $request, $userId)
    {
        $type = $request->query('type');
        $source = $request->query('source');
        $storeId = $request->query('store_id');
        $dateFrom = $request->query('from');
        $dateTo = $request->query('to');

        $user = \App\Models\User::findOrFail($userId, ['id','name','email']);

        $query = WalletTransaction::with(['store:id,name'])
            ->where('user_id', $userId)
            ->when($type && in_array($type, ['credit','debit']), fn($q) => $q->where('type', $type))
            ->when($source, fn($q) => $q->where('source', $source))
            ->when($storeId, fn($q) => $q->where('store_id', $storeId))
            ->when($dateFrom, fn($q) => $q->whereDate('created_at', '>=', $dateFrom))
            ->when($dateTo, fn($q) => $q->whereDate('created_at', '<=', $dateTo))
            ->latest('created_at');

        $transactions = $query->paginate(25)->withQueryString();
        $totals = [
            'credits' => (float) (clone $query)->where('type','credit')->sum('amount'),
            'debits'  => (float) (clone $query)->where('type','debit')->sum('amount'),
        ];

        $stores = Store::orderBy('name')->get(['id','name']);

        return view('my-wallet::super-admin.transactions.user', compact('transactions', 'totals', 'type', 'source', 'storeId', 'dateFrom', 'dateTo', 'stores', 'user'));
    }

    public function storeTransactions(Request $request, $storeId)
    {
        $type = $request->query('type');
        $source = $request->query('source');
        $userId = $request->query('user_id');
        $dateFrom = $request->query('from');
        $dateTo = $request->query('to');

        $store = Store::findOrFail($storeId, ['id','name', 'created_by']);

        $query = WalletTransaction::with(['user:id,name'])
            ->where('store_id', $storeId)
            ->when($type && in_array($type, ['credit','debit']), fn($q) => $q->where('type', $type))
            ->when($source, fn($q) => $q->where('source', $source))
            ->when($userId, fn($q) => $q->where('user_id', $userId))
            ->when($dateFrom, fn($q) => $q->whereDate('created_at', '>=', $dateFrom))
            ->when($dateTo, fn($q) => $q->whereDate('created_at', '<=', $dateTo))
            ->latest('created_at');

        $transactions = $query->paginate(25)->withQueryString();
        $totals = [
            'credits' => (float) (clone $query)->where('type','credit')->sum('amount'),
            'debits'  => (float) (clone $query)->where('type','debit')->sum('amount'),
        ];

        // For filters dropdowns
        $users = \App\Models\User::orderBy('name')->get(['id','name']);

        $user = $store->created_by ? \App\Models\User::find($store->created_by, ['id','name','email']) : null;
        $stores = collect([$store]); // single store context

        return view('my-wallet::super-admin.transactions.user', compact('transactions', 'totals', 'type', 'source', 'userId', 'storeId', 'dateFrom', 'dateTo', 'users', 'store', 'stores', 'user'));
    }
}
