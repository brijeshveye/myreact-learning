<?php

namespace Shopyji\MyWallet\app\Http\Controllers\Company;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Shopyji\MyWallet\app\Models\WalletSetting;
use Shopyji\MyWallet\app\Models\WalletWithdrawRequest;
use Shopyji\MyWallet\app\Models\Wallet;
use Shopyji\MyWallet\app\Models\WalletTransaction;
use Illuminate\Support\Facades\DB;

class WalletController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();
        $storeId = function_exists('getCurrentStore') ? getCurrentStore() : ($user->current_store ?? null);

        // Latest withdraw requests for this user (scoped to store if available)
        $withdrawRequests = WalletWithdrawRequest::query()
            ->when($storeId, fn($q) => $q->where('store_id', $storeId))
            ->where('user_id', $user->id)
            ->latest('created_at')
            ->limit(25)
            ->get();

        // Aggregates
        $totalWithdrawn = (float) WalletWithdrawRequest::query()
            ->when($storeId, fn($q) => $q->where('store_id', $storeId))
            ->where('user_id', $user->id)
            ->where('status', WalletWithdrawRequest::STATUS_APPROVED)
            ->sum('amount');

        $lastApproved = WalletWithdrawRequest::query()
            ->when($storeId, fn($q) => $q->where('store_id', $storeId))
            ->where('user_id', $user->id)
            ->where('status', WalletWithdrawRequest::STATUS_APPROVED)
            ->latest('created_at')
            ->first();

        $lastWithdraw = $lastApproved ? [
            'date' => $lastApproved->created_at,
            'amount' => (float) $lastApproved->amount,
        ] : null;

        // Wallet balance
        $wallet = Wallet::firstOrCreate([
            'user_id' => $user->id,
            'store_id' => $storeId,
        ]);
        $totalBalance = (float) $wallet->balance;

        // Module status indicator (middleware ensures access; treat as active)
        $status = 'Active';

        return view('my-wallet::company.index', compact(
            'status', 'totalBalance', 'lastWithdraw', 'totalWithdrawn', 'withdrawRequests'
        ));
    }

    public function storeWithdraw(Request $request)
    {
        $data = $request->validate([
            'amount' => ['required','numeric','min:1'],
            'method' => ['required','in:bank,upi'],
            'note'   => ['nullable','string','max:500'],
        ]);

        $user = $request->user();
        $storeId = function_exists('getCurrentStore') ? getCurrentStore() : ($user->current_store ?? null);

        // Ensure payout method details exist for the chosen method
        $settings = WalletSetting::firstOrCreate(['user_id' => $user->id]);
        if ($data['method'] === 'bank') {
            if (empty($settings->bank_name) || empty($settings->account_name) || empty($settings->account_number)) {
                return back()->withErrors(['method' => __('Please complete your bank details in settings before requesting a bank withdrawal.')])->withInput();
            }
        } elseif ($data['method'] === 'upi') {
            if (empty($settings->upi_id) || empty($settings->upi_name)) {
                return back()->withErrors(['method' => __('Please complete your UPI details in settings before requesting a UPI withdrawal.')])->withInput();
            }
        }

        // Ensure sufficient balance
        $wallet = Wallet::firstOrCreate([
            'user_id' => $user->id,
            'store_id' => $storeId,
        ]);
        if ((float)$data['amount'] > (float)$wallet->balance) {
            return back()->withErrors(['amount' => __('Withdrawal amount exceeds available balance.')])->withInput();
        }

        DB::transaction(function () use ($storeId, $user, $data, $wallet) {
            WalletWithdrawRequest::create([
                'store_id' => $storeId,
                'user_id' => $user->id,
                'amount' => $data['amount'],
                'method' => $data['method'],
                'status' => WalletWithdrawRequest::STATUS_PENDING,
                'note' => $data['note'] ?? null,
            ]);

            // Record a pending debit transaction; actual balance deduction can happen either now (hold) or after approval.
            // Here we deduct immediately to reserve funds.
            $wallet->balance = (float)$wallet->balance - (float)$data['amount'];
            $wallet->save();
            WalletTransaction::create([
                'wallet_id' => $wallet->id,
                'store_id' => $storeId,
                'user_id' => $user->id,
                'type' => 'debit',
                'source' => 'withdraw',
                'amount' => $data['amount'],
                'reference' => null,
                'meta' => [
                    'method' => $data['method'],
                    'note' => $data['note'] ?? null,
                    'status' => 'pending',
                ],
            ]);
        });

        // Optionally: dispatch event for admin notification
        return back()->with('success', __('Withdraw request submitted.'));
    }

    public function settings(Request $request)
    {
        $user = $request->user();
        $model = WalletSetting::firstOrCreate(['user_id' => $user->id]);
        $walletSettings = [
            'bank_name' => $model->bank_name ?? '',
            'account_name' => $model->account_name ?? '',
            'account_number' => $model->account_number ?? '',
            'ifsc' => $model->ifsc ?? '',
            'branch' => $model->branch ?? '',
            'upi_id' => $model->upi_id ?? '',
            'upi_name' => $model->upi_name ?? '',
        ];

        return view('my-wallet::company.settings', compact('walletSettings', 'user'));
    }

    public function updateSettings(Request $request)
    {
        $data = $request->validate([
            'bank_name' => ['nullable','string','max:150'],
            'account_name' => ['nullable','string','max:150'],
            'account_number' => ['nullable','string','max:64'],
            'ifsc' => ['nullable','string','max:50'],
            'branch' => ['nullable','string','max:150'],
            'upi_id' => ['nullable','string','max:100'],
            'upi_name' => ['nullable','string','max:150'],
        ]);

        $user = $request->user();
        $model = WalletSetting::firstOrCreate(['user_id' => $user->id]);
        $model->fill($data);
        $model->save();

        return redirect()->route('mywallet.settings')->with('success', __('Settings updated successfully.'));
    }

    public function transactions(Request $request)
    {
        $user = $request->user();
        $storeId = function_exists('getCurrentStore') ? getCurrentStore() : ($user->current_store ?? null);

        $type = $request->query('type'); // credit|debit|all
        $source = $request->query('source'); // order|manual|withdraw|any
        $dateFrom = $request->query('from');
        $dateTo = $request->query('to');

        $wallet = Wallet::firstOrCreate([
            'user_id' => $user->id,
            'store_id' => $storeId,
        ]);

        $query = WalletTransaction::query()
            ->where('wallet_id', $wallet->id)
            ->when($type && in_array($type, ['credit','debit']), fn($q) => $q->where('type', $type))
            ->when($source, fn($q) => $q->where('source', $source))
            ->when($dateFrom, fn($q) => $q->whereDate('created_at', '>=', $dateFrom))
            ->when($dateTo, fn($q) => $q->whereDate('created_at', '<=', $dateTo))
            ->latest('created_at');

        $transactions = $query->paginate(20)->withQueryString();

        $totals = [
            'credits' => (float) (clone $query)->where('type','credit')->sum('amount'),
            'debits' => (float) (clone $query)->where('type','debit')->sum('amount'),
            'balance' => (float) $wallet->balance,
        ];

        return view('my-wallet::company.transactions', compact('transactions', 'totals', 'type', 'source', 'dateFrom', 'dateTo'));
    }
}
