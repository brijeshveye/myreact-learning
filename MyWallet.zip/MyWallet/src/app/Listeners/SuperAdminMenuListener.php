<?php

namespace Shopyji\MyWallet\app\Listeners;
use App\Events\SuperAdminMenuEvent;

class SuperAdminMenuListener
{
    /**
     * Handle the event.
     */
    public function handle(SuperAdminMenuEvent $event): void
    {
        $module = 'MyWallet';
        $menu = $event->menu;
        $menu->add([
            'title' => 'ShopyJi Wallet',
            'icon' => 'wallet',
            'name' => 'mywallet',
            'parent' => null,
            'order' => 10,
            'ignore_if' => [],
            'depend_on' => [],
            'route' => 'superadmin.mywallet.index',
            'module' => $module,
            'permission' => ''
        ]);
    }
}
