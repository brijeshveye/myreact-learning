<?php

namespace Shopyji\MyWallet\app\Listeners;
use App\Events\CompanySettingEvent;

class CompanySettingListener
{
    /**
     * Handle the event.
     */
    public function handle(CompanySettingEvent $event): void
    {
        $module = 'MyWallet';
        $methodName = 'index';
        $controllerClass = "Shopyji\\MyWallet\\Http\\Controllers\\Company\\SettingsController";
        if (class_exists($controllerClass)) {
            $controller = \App::make($controllerClass);
            if (method_exists($controller, $methodName)) {
                $html = $event->html;
                $settings = $html->getSettings();
                    $output =  $controller->{$methodName}($settings);
                $html->add([
                        'html' => method_exists($output, 'toHtml') ? $output->toHtml() : (string) $output,
                    'order' => 1,
                    'module' => $module,
                    'permission' => ''
                ]);
            }
        }
    }
}
