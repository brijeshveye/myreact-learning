<?php

namespace Shopyji\MyWallet\app\Listeners;

use App\Events\CompanyMenuEvent;

class CompanyMenuListener
{
    /**
     * Handle the event.
     */
    public function handle(CompanyMenuEvent $event): void
    {
        $module = 'MyWallet';
        $menu = $event->menu;
        $menu->add([
            'title' => 'MyWallet',
            'icon' => 'wallet',
            'name' => 'mywallet',
            'parent' => null,
            'order' => 40,
            'ignore_if' => [],
            'depend_on' => [],
            'route' => 'mywallet.index',
            'module' => $module,
            'permission' => ''
        ]);
    }
}
