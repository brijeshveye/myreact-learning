<?php

namespace Shopyji\MyWallet\app\Models;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use GeneaLabs\LaravelModelCaching\Traits\Cachable;

class WalletSetting extends Model
{
    use HasFactory, Cachable;

    protected $table = 'wallet_settings';

    protected $fillable = [
        'user_id',
        'bank_name',
        'account_name',
        'account_number',
        'ifsc',
        'branch',
        'upi_id',
        'upi_name',
    ];

    protected $casts = [
        'user_id' => 'integer',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
