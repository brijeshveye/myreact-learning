<?php

namespace Shopyji\MyWallet\app\Models;

use App\Models\Store;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use GeneaLabs\LaravelModelCaching\Traits\Cachable;

class WalletWithdrawRequest extends Model
{
    use HasFactory, Cachable;

    protected $table = 'wallet_withdraw_requests';

    protected $fillable = [
        'store_id',
        'user_id',
        'amount',
        'method',
        'status',
        'note',
        'paid_at',
        'paid_reference',
    ];

    protected $casts = [
        'store_id' => 'integer',
        'user_id' => 'integer',
        'amount' => 'decimal:2',
        'paid_at' => 'datetime',
    ];

    protected $appends = ['store_name', 'user_name'];

    public const STATUS_PENDING = 'pending';
    public const STATUS_APPROVED = 'approved';
    public const STATUS_REJECTED = 'rejected';
    public const METHODS = ['bank', 'upi'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function store()
    {
        return $this->belongsTo(Store::class);
    }

    public function getStoreNameAttribute()
    {
        return $this->store->name ?? null;
    }

    public function getUserNameAttribute()
    {
        return $this->user->name ?? null;
    }
}
