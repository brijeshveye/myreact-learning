<?php

namespace Shopyji\MyWallet\app\Models;

use App\Models\Store;
use App\Models\User;
use GeneaLabs\LaravelModelCaching\Traits\Cachable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Wallet extends Model
{
    use HasFactory, Cachable;

    protected $fillable = [
        'store_id', 'user_id', 'balance', 'withdrawn_total'
    ];

    protected $casts = [
        'store_id' => 'integer',
        'user_id' => 'integer',
        'balance' => 'decimal:2',
        'withdrawn_total' => 'decimal:2',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function store(): BelongsTo
    {
        return $this->belongsTo(Store::class);
    }

    public function transactions(): HasMany
    {
        return $this->hasMany(WalletTransaction::class);
    }

    public function addBalance($order)
    {
        $this->increment('balance', $order->total);
        $this->transactions()->create([
            'store_id' => $this->store_id,
            'user_id' => $this->user_id,
            'amount' => $order->total,
            'type' => 'credit',
            'source' => 'order',
            'reference' => 'Order #' . $order->id,
            'meta' => json_encode(['order_id' => $order->id]),
        ]);
    }
}
