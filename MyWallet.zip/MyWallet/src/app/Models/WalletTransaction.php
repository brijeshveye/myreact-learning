<?php

namespace Shopyji\MyWallet\app\Models;

use App\Models\Store;
use App\Models\User;
use GeneaLabs\LaravelModelCaching\Traits\Cachable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class WalletTransaction extends Model
{
    use HasFactory, Cachable;

    protected $fillable = [
        'wallet_id', 'store_id', 'user_id', 'type', 'source', 'amount', 'reference', 'meta'
    ];

    protected $casts = [
        'wallet_id' => 'integer',
        'store_id' => 'integer',
        'user_id' => 'integer',
        'amount' => 'decimal:2',
        'meta' => 'array',
    ];

    public function wallet(): BelongsTo
    {
        return $this->belongsTo(Wallet::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function store(): BelongsTo
    {
        return $this->belongsTo(Store::class);
    }
}
