<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use Illuminate\Support\Facades\Route;
use Shopyji\MyWallet\app\Http\Controllers\Company\WalletController;
use Shopyji\MyWallet\app\Http\Controllers\SuperAdmin\WalletAdminController;

Route::middleware(['auth', 'web', 'PlanModuleCheck:MyWallet'])->group(function () {
    Route::prefix('mywallet')->group(function () {
        // User Panel
        Route::get('/', [WalletController::class, 'index'])->name('mywallet.index');
        Route::post('/withdraw', [WalletController::class, 'storeWithdraw'])->name('mywallet.withdraw.store');
        // Transactions (ledger)
        Route::get('/transactions', [WalletController::class, 'transactions'])->name('mywallet.transactions');
        // User settings (bank/upi)
        Route::get('/settings', [WalletController::class, 'settings'])->name('mywallet.settings');
        Route::post('/settings', [WalletController::class, 'updateSettings'])->name('mywallet.settings.update');
    });
});

// Super Admin
Route::middleware(['auth', 'web', 'PlanModuleCheck:MyWallet'])->group(function () {
    Route::prefix('super-admin/mywallet')->group(function () {
        Route::get('/', [WalletAdminController::class, 'index'])->name('superadmin.mywallet.index');
        Route::post('/credit', [WalletAdminController::class, 'creditStore'])->name('superadmin.mywallet.credit');
        // Withdraw review
        Route::get('/withdraws/{id}', [WalletAdminController::class, 'review'])->name('superadmin.mywallet.withdraw.review');
        Route::post('/withdraws/{id}/approve', [WalletAdminController::class, 'approve'])->name('superadmin.mywallet.withdraw.approve');
        Route::post('/withdraws/{id}/reject', [WalletAdminController::class, 'reject'])->name('superadmin.mywallet.withdraw.reject');
        // Transactions
        Route::get('/transactions', [WalletAdminController::class, 'transactionsIndex'])->name('superadmin.mywallet.transactions');
        Route::get('/users/{user}/transactions', [WalletAdminController::class, 'userTransactions'])->name('superadmin.mywallet.user.transactions');
        // Store-specific transactions
        Route::get('/stores/{store}/transactions', [WalletAdminController::class, 'storeTransactions'])->name('superadmin.mywallet.store.transactions');
    });
});
