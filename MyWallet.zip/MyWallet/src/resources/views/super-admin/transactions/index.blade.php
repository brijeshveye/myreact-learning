@extends('layouts.app')

@section('page-title', __('All Wallet Transactions'))

@push('css')
<style>
    .stats-card { background: linear-gradient(135deg, #fff, #f8fafc); border:1px solid #e5e7eb; border-radius:8px; padding:16px; text-align:center; height:100%; }
    .stats-number { font-size:20px; font-weight:700; color:#1f2937; }
    .wallet-table th { background:#f8fafc; font-weight:600; color:#374151; border-bottom:1px solid #e5e7eb; }
</style>
@endpush

@section('content')
<div class="row mb-4">
    <div class="col-12 d-flex align-items-center justify-content-between">
        <h4 class="mb-0">{{ __('All Wallet Transactions') }}</h4>
        <a href="{{ route('superadmin.mywallet.index') }}" class="btn btn-outline-secondary btn-sm"><i class="ti ti-arrow-left"></i> {{ __('Back') }}</a>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-6 col-sm-6">
        <div class="stats-card">
            <div class="stats-number">{{ currency_format_with_sym($totals['credits']) }}</div>
            <div class="text-muted">{{ __('Total Credits (filtered)') }}</div>
        </div>
    </div>
    <div class="col-md-6 col-sm-6">
        <div class="stats-card">
            <div class="stats-number">{{ currency_format_with_sym($totals['debits']) }}</div>
            <div class="text-muted">{{ __('Total Debits (filtered)') }}</div>
        </div>
    </div>
</div>

<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="{{ route('superadmin.mywallet.transactions') }}" class="row g-3 align-items-end">
            <div class="col-md-2">
                <label class="form-label">{{ __('Type') }}</label>
                <select name="type" class="form-select">
                    <option value="">{{ __('All') }}</option>
                    <option value="credit" {{ ($type ?? '') === 'credit' ? 'selected' : '' }}>{{ __('Credit') }}</option>
                    <option value="debit" {{ ($type ?? '') === 'debit' ? 'selected' : '' }}>{{ __('Debit') }}</option>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">{{ __('Source') }}</label>
                <select name="source" class="form-select">
                    <option value="">{{ __('Any') }}</option>
                    <option value="order" {{ ($source ?? '') === 'order' ? 'selected' : '' }}>{{ __('Order') }}</option>
                    <option value="manual" {{ ($source ?? '') === 'manual' ? 'selected' : '' }}>{{ __('Manual') }}</option>
                    <option value="withdraw" {{ ($source ?? '') === 'withdraw' ? 'selected' : '' }}>{{ __('Withdraw') }}</option>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">{{ __('Store') }}</label>
                <select name="store_id" class="form-select">
                    <option value="">{{ __('All Stores') }}</option>
                    @foreach($stores as $s)
                        <option value="{{ $s->id }}" {{ (string)($storeId ?? '') === (string)$s->id ? 'selected' : '' }}>{{ $s->name }}</option>
                    @endforeach
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">{{ __('User') }}</label>
                <select name="user_id" class="form-select">
                    <option value="">{{ __('All Users') }}</option>
                    @foreach($users as $u)
                        <option value="{{ $u->id }}" {{ (string)($userId ?? '') === (string)$u->id ? 'selected' : '' }}>{{ $u->name }}</option>
                    @endforeach
                </select>
            </div>
            <div class="col-md-1">
                <label class="form-label">{{ __('From') }}</label>
                <input type="date" name="from" class="form-control" value="{{ $dateFrom ?? '' }}">
            </div>
            <div class="col-md-1">
                <label class="form-label">{{ __('To') }}</label>
                <input type="date" name="to" class="form-control" value="{{ $dateTo ?? '' }}">
            </div>
            <div class="col-12">
                <button type="submit" class="btn btn-primary"><i class="ti ti-filter"></i> {{ __('Filter') }}</button>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-header d-flex align-items-center justify-content-between">
        <h5 class="mb-0">{{ __('Transactions') }}</h5>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0 wallet-table">
                <thead>
                    <tr>
                        <th>{{ __('Date') }}</th>
                        <th>{{ __('Store') }}</th>
                        <th>{{ __('User') }}</th>
                        <th>{{ __('Type') }}</th>
                        <th>{{ __('Source') }}</th>
                        <th class="text-end">{{ __('Amount') }}</th>
                        <th>{{ __('Reference') }}</th>
                        <th>{{ __('Note') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($transactions as $tx)
                        <tr>
                            <td>{{ \Carbon\Carbon::parse($tx->created_at)->format('M d, Y H:i') }}</td>
                            <td>{{ $tx->store->name ?? '-' }}</td>
                            <td>
                                @if($tx->user)
                                    <a href="{{ route('superadmin.mywallet.user.transactions', $tx->user_id) }}">{{ $tx->user->name }}</a>
                                @else
                                    -
                                @endif
                            </td>
                            <td><span class="badge bg-{{ $tx->type === 'credit' ? 'success' : 'danger' }} text-capitalize">{{ $tx->type }}</span></td>
                            <td class="text-capitalize">{{ $tx->source }}</td>
                            <td class="text-end">{{ currency_format_with_sym($tx->amount) }}</td>
                            <td>{{ $tx->reference ?? '-' }}</td>
                            <td>{{ $tx->meta['note'] ?? ($tx->meta['status'] ?? '-') }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="8" class="text-center text-muted py-4">{{ __('No transactions found for the selected filters.') }}</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div class="p-3">
            {{ $transactions->links() }}
        </div>
    </div>
</div>
@endsection
