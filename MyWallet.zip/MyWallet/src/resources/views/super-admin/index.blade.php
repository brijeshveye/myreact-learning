@extends('layouts.app')

@section('page-title', __('MyWallet Overview'))

@push('css')
    <style>
        .wallet-hero-wrap {
            position: relative;
            overflow: hidden;
            border-radius: 12px;
            background: linear-gradient(135deg, #f0f5ff, #eef2ff);
            padding: 20px;
        }

        .wallet-hero-bg {
            position: absolute;
            inset: 0;
            background-size: cover;
            background-position: center;
            opacity: 0.06;
            filter: blur(2px);
        }

        .wallet-hero {
            display: flex;
            align-items: center;
            gap: 16px;
            z-index: 1;
        }

        .wallet-hero .settings-link {
            z-index: 1;
        }

        .wallet-icon {
            width: 64px;
            height: 64px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 12px;
            background: linear-gradient(135deg, #551dd8, #2549eb);
            color: #fff;
            box-shadow: 0 4px 12px rgba(139, 37, 235, 0.3);
            font-size: 32px;
        }

        .wallet-info h3 {
            margin-bottom: 4px;
        }

        .stats-card {
            background: linear-gradient(135deg, #fff, #f8fafc);
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            padding: 16px;
            text-align: center;
            height: 100%;
        }

        .stats-number {
            font-size: 22px;
            font-weight: 700;
            color: #1f2937;
        }

        .stats-label {
            font-size: 13px;
            color: #6b7280;
            margin-top: 4px;
        }

        .wallet-table th {
            background: #f8fafc;
            font-weight: 600;
            color: #374151;
            border-bottom: 1px solid #e5e7eb;
        }

        .wallet-table td {
            vertical-align: middle;
        }
    </style>
@endpush

@section('content')
    <div class="row mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="wallet-hero-wrap">
                        <div class="wallet-hero-bg"
                            style="background-image:url('data:image/svg+xml,<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 100 100\"><circle cx=\"20\" cy=\"20\" r=\"3\" fill=\"%232563eb\" opacity=\"0.3\"/><circle cx=\"80\" cy=\"30\" r=\"2\" fill=\"%232563eb\" opacity=\"0.2\"/><circle cx=\"60\" cy=\"70\" r=\"4\" fill=\"%232563eb\" opacity=\"0.15\"/></svg>')">
                        </div>
                        <div class="wallet-hero">
                            <div class="wallet-icon">
                                <i class="ti ti-wallet"></i>
                            </div>
                            <div class="wallet-info">
                                <h3 class="mb-1">{{ __('My Wallet Overview') }}</h3>
                                <div class="d-flex flex-wrap gap-3 text-muted">
                                    <div>{{ __('Total Balance') }}:
                                        <strong>{{ currency_format_with_sym($totalToPay) }}</strong>
                                    </div>
                                    <div>{{ __('Total Withdrawn') }}:
                                        <strong>{{ currency_format_with_sym($withdrawnAmount) }}</strong>
                                    </div>
                                    <div>{{ __('Status') }}:
                                        <span
                                            class="badge bg-{{ $status === 'active' ? 'success' : 'warning' }}">{{ ucfirst($status) }}</span>
                                    </div>
                                </div>
                            </div>
                            <div class="ms-auto d-flex gap-2 settings-link">
                                <a href="{{ route('superadmin.mywallet.transactions') }}" class="btn btn-outline-info btn-sm"><i
                                        class="ti ti-wallet"></i> {{ __('Transactions') }}</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row g-3 mb-3">
        <div class="col-md-3 col-sm-6">
            <div class="stats-card">
                <div class="stats-number">{{ currency_format_with_sym($totalToPay) }}</div>
                <div class="stats-label">{{ __('Total Balance to Pay') }}</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="stats-card">
                <div class="stats-number">{{ currency_format_with_sym($withdrawPending) }}</div>
                <div class="stats-label">{{ __('Withdraw Requests (Amount to Pay)') }}</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="stats-card">
                <div class="stats-number">{{ currency_format_with_sym($withdrawnAmount) }}</div>
                <div class="stats-label">{{ __('Amount Withdrawn') }}</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="stats-card">
                <div class="stats-number">{{ number_format($withdrawCount) }}</div>
                <div class="stats-label">{{ __('Number of Withdraw Requests') }}</div>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <!-- Withdraw Requests Table -->
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex align-items-center justify-content-between">
                    <h5 class="mb-0">{{ __('Withdraw Requests') }}</h5>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table wallet-table mb-0">
                            <thead>
                                <tr>
                                    <th>{{ __('Store') }}</th>
                                    <th>{{ __('Requested By') }}</th>
                                    <th>{{ __('Amount') }}</th>
                                    <th>{{ __('Method') }}</th>
                                    <th>{{ __('Status') }}</th>
                                    <th>{{ __('Requested At') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($withdrawRequests as $req)
                                    <tr onclick="window.location='{{ route('superadmin.mywallet.withdraw.review', $req->id) }}'" style="cursor:pointer;">
                                        <td>
                                            <a href="{{ route('superadmin.mywallet.withdraw.review', $req->id) }}">{{ $req->store_name ?? '-' }}</a>
                                        </td>
                                        <td>{{ $req->user_name ?? '-' }}</td>
                                        <td>{{ currency_format_with_sym($req->amount ?? 0) }}</td>
                                        <td class="text-capitalize">{{ $req->method ?? '-' }}</td>
                                        <td><span
                                                class="badge bg-{{ ($req->status ?? 'pending') == 'approved' ? 'success' : (($req->status ?? 'pending') == 'rejected' ? 'danger' : 'warning') }}">{{ ucfirst($req->status ?? 'pending') }}</span>
                                        </td>
                                        <td><small
                                                class="text-muted">{{ isset($req->created_at) ? \Carbon\Carbon::parse($req->created_at)->format('M d, Y') : '-' }}</small>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="6" class="text-center text-muted py-4">
                                            {{ __('No withdraw requests found.') }}</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Stores with MyWallet Activated -->
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex align-items-center justify-content-between">
                    <h5 class="mb-0">{{ __('Stores with MyWallet Activated') }}</h5>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table wallet-table mb-0">
                            <thead>
                                <tr>
                                    <th>{{ __('Store') }}</th>
                                    <th>{{ __('Owner') }}</th>
                                    <th class="text-end">{{ __('Available Balance') }}</th>
                                    <th>{{ __('Plan') }}</th>
                                    <th>{{ __('Activated On') }}</th>
                                    <th class="text-end">{{ __('Actions') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($activatedStores as $store)
                                    <tr>
                                        <td>{{ $store->name ?? '-' }}</td>
                                        <td>{{ $store->owner_name ?? '-' }}</td>
                                        <td class="text-end">{{ currency_format_with_sym($store->available_balance ?? 0) }}</td>
                                        <td>{{ $store->plan_name ?? '-' }}</td>
                                        <td><small
                                                class="text-muted">{{ isset($store->activated_at) ? \Carbon\Carbon::parse($store->activated_at)->format('M d, Y') : '-' }}</small>
                                        </td>
                                        <td class="text-end">
                                            <a href="{{ route('superadmin.mywallet.store.transactions', ['store' => $store->id]) }}" class="btn btn-sm btn-info" title="{{ __('View Transactions') }}">
                                                <i class="ti ti-eye"></i>
                                            </a>
                                            <button type="button" class="btn btn-sm btn-light" data-bs-toggle="modal" data-bs-target="#walletCreditModal" data-store-id="{{ $store->id }}" data-store-name="{{ $store->name }}" title="{{ __('Credit Balance') }}">
                                                <i class="ti ti-bolt"></i>
                                            </button>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="4" class="text-center text-muted py-4">
                                            {{ __('No stores have activated MyWallet yet.') }}</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Available Payment Methods -->
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex align-items-center justify-content-between">
                    <h5 class="mb-0">{{ __('Available Payment Methods') }}</h5>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table wallet-table mb-0">
                            <thead>
                                <tr>
                                    <th>{{ __('Name') }}</th>
                                    <th>{{ __('Code') }}</th>
                                    <th>{{ __('Status') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($paymentMethods as $pm)
                                    <tr>
                                        <td>{{ $pm['name'] }}</td>
                                        <td><code>{{ $pm['code'] }}</code></td>
                                        <td>
                                            <span
                                                class="badge bg-{{ ($pm['status'] ?? 'inactive') === 'active' ? 'success' : 'secondary' }}">
                                                {{ ucfirst($pm['status'] ?? 'inactive') }}
                                            </span>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="3" class="text-center text-muted py-4">
                                            {{ __('No payment methods available.') }}</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('modals')
    <div class="modal fade" id="walletCreditModal" tabindex="-1" aria-labelledby="walletCreditModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="walletCreditModalLabel">{{ __('Credit Store Wallet') }}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" action="{{ route('superadmin.mywallet.credit') }}">
                    @csrf
                    <div class="modal-body">
                        <input type="hidden" name="store_id" id="credit_store_id">
                        <div class="mb-3">
                            <label class="form-label">{{ __('Store') }}</label>
                            <input type="text" class="form-control" id="credit_store_name" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">{{ __('Amount') }}</label>
                            <div class="input-group">
                                <span class="input-group-text">{{ getAdminAllSetting()['CURRENCY_SYMBOL'] ?? '$' }}</span>
                                <input type="number" class="form-control" name="amount" step="0.01" min="0.01" placeholder="{{ __('Amount') }}" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">{{ __('Note') }} <small class="text-muted">({{ __('optional') }})</small></label>
                            <textarea class="form-control" name="note" rows="2" maxlength="500" placeholder="{{ __('Reason or reference') }}"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">{{ __('Cancel') }}</button>
                        <button type="submit" class="btn btn-primary">{{ __('Credit Balance') }}</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endpush

@push('scripts')
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var creditModal = document.getElementById('walletCreditModal');
            creditModal.addEventListener('show.bs.modal', function (event) {
                var button = event.relatedTarget;
                var storeId = button.getAttribute('data-store-id');
                var storeName = button.getAttribute('data-store-name');
                document.getElementById('credit_store_id').value = storeId;
                document.getElementById('credit_store_name').value = storeName;
            });
        });
    </script>
@endpush
