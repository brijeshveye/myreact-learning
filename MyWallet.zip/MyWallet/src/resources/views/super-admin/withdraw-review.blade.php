@extends('layouts.app')

@section('page-title', __('Withdraw Request Review'))

@push('css')
<style>
    .stats-card { background: linear-gradient(135deg, #fff, #f8fafc); border:1px solid #e5e7eb; border-radius:8px; padding:16px; height:100%; }
    .wallet-table th { background:#f8fafc; font-weight:600; color:#374151; border-bottom:1px solid #e5e7eb; }
</style>
@endpush

@section('content')
@if (session('success'))
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="ti ti-check me-1"></i> {{ session('success') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
@endif
@if ($errors->any())
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <div class="d-flex align-items-start">
            <i class="ti ti-alert-circle me-2 mt-1"></i>
            <div>
                <strong>{{ __('Please fix the following errors:') }}</strong>
                <ul class="mb-0 mt-1">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
@endif

<div class="row mb-4">
    <div class="col d-flex align-items-center justify-content-between">
        <h4 class="mb-0">{{ __('Withdraw Request Review') }}</h4>
        <a href="{{ route('superadmin.mywallet.index') }}" class="btn btn-outline-secondary btn-sm"><i class="ti ti-arrow-left"></i> {{ __('Back') }}</a>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="stats-card">
            <div class="fw-bold mb-1">{{ __('Store') }}</div>
            <div>{{ $withdraw->store->name ?? '-' }}</div>
            <div class="text-muted small mt-1">ID: {{ $withdraw->store_id }}</div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stats-card">
            <div class="fw-bold mb-1">{{ __('User') }}</div>
            <div>{{ $withdraw->user->name ?? '-' }}</div>
            <div class="text-muted small mt-1">{{ $withdraw->user->email ?? '' }}</div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stats-card">
            <div class="fw-bold mb-1">{{ __('Request') }}</div>
            <div>{{ currency_format_with_sym($withdraw->amount) }} • <span class="text-capitalize">{{ $withdraw->method }}</span></div>
            <div class="mt-1"><span class="badge bg-{{ $withdraw->status === 'approved' ? 'success' : ($withdraw->status === 'rejected' ? 'danger' : 'warning') }}">{{ ucfirst($withdraw->status) }}</span></div>
            <div class="text-muted small mt-1">{{ __('Requested at') }}: {{ $withdraw->created_at?->format('M d, Y H:i') }}</div>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-6">
        <div class="card h-100">
            <div class="card-header"><h6 class="mb-0">{{ __('Bank Details') }}</h6></div>
            <div class="card-body">
                <div class="row g-2">
                    <div class="col-6"><div class="text-muted small">{{ __('Bank Name') }}</div><div>{{ data_get($settings, 'bank_name', '-') }}</div></div>
                    <div class="col-6"><div class="text-muted small">{{ __('Account Name') }}</div><div>{{ data_get($settings, 'account_name', '-') }}</div></div>
                    <div class="col-6"><div class="text-muted small">{{ __('Account Number') }}</div><div>{{ data_get($settings, 'account_number', '-') }}</div></div>
                    <div class="col-6"><div class="text-muted small">{{ __('IFSC/SWIFT') }}</div><div>{{ data_get($settings, 'ifsc', '-') }}</div></div>
                    <div class="col-12"><div class="text-muted small">{{ __('Branch') }}</div><div>{{ data_get($settings, 'branch', '-') }}</div></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card h-100">
            <div class="card-header"><h6 class="mb-0">{{ __('UPI Details') }}</h6></div>
            <div class="card-body">
                <div class="row g-2">
                    <div class="col-6"><div class="text-muted small">{{ __('UPI ID') }}</div><div>{{ data_get($settings, 'upi_id', '-') }}</div></div>
                    <div class="col-6"><div class="text-muted small">{{ __('UPI Name') }}</div><div>{{ data_get($settings, 'upi_name', '-') }}</div></div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card mb-4">
    <div class="card-header d-flex align-items-center justify-content-between">
        <h6 class="mb-0">{{ __('Approve / Reject') }}</h6>
    </div>
    <div class="card-body">
        @if($withdraw->status === 'pending')
            <div class="row g-3">
                <div class="col-md-6">
                    <form method="POST" action="{{ route('superadmin.mywallet.withdraw.approve', $withdraw->id) }}" class="d-flex gap-2 align-items-end">
                        @csrf
                        <div class="flex-grow-1">
                            <label class="form-label">{{ __('Payment Reference') }}</label>
                            <input type="text" name="paid_reference" class="form-control" maxlength="150" placeholder="{{ __('TXN / UTR / Ref No.') }}">
                        </div>
                        <button type="submit" class="btn btn-success"><i class="ti ti-check"></i> {{ __('Approve') }}</button>
                    </form>
                </div>
                <div class="col-md-6">
                    <form method="POST" action="{{ route('superadmin.mywallet.withdraw.reject', $withdraw->id) }}" class="d-flex gap-2 align-items-end">
                        @csrf
                        <div class="flex-grow-1">
                            <label class="form-label">{{ __('Reason') }}</label>
                            <input type="text" name="reason" class="form-control" maxlength="500" required placeholder="{{ __('Reason for rejection') }}">
                        </div>
                        <button type="submit" class="btn btn-danger"><i class="ti ti-x"></i> {{ __('Reject') }}</button>
                    </form>
                </div>
            </div>
        @else
            <div class="alert alert-info mb-0">
                {{ __('This request has already been') }} <strong>{{ $withdraw->status }}</strong>.
                @if($withdraw->status === 'approved' && $withdraw->paid_reference)
                    <span class="ms-1">{{ __('Payment Ref:') }} <code>{{ $withdraw->paid_reference }}</code></span>
                @endif
            </div>
        @endif
    </div>
</div>

<div class="card">
    <div class="card-header"><h6 class="mb-0">{{ __('Past Withdraw Requests') }}</h6></div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table wallet-table mb-0">
                <thead>
                <tr>
                    <th>{{ __('Date') }}</th>
                    <th>{{ __('Amount') }}</th>
                    <th>{{ __('Method') }}</th>
                    <th>{{ __('Status') }}</th>
                    <th>{{ __('Note') }}</th>
                </tr>
                </thead>
                <tbody>
                @forelse($past as $p)
                    <tr>
                        <td>{{ $p->created_at?->format('M d, Y') }}</td>
                        <td>{{ currency_format_with_sym($p->amount) }}</td>
                        <td class="text-capitalize">{{ $p->method }}</td>
                        <td>
                            <span class="badge bg-{{ $p->status === 'approved' ? 'success' : ($p->status === 'rejected' ? 'danger' : 'warning') }}">{{ ucfirst($p->status) }}</span>
                        </td>
                        <td>{{ $p->note ?? '-' }}</td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="5" class="text-center text-muted py-4">{{ __('No past requests.') }}</td>
                    </tr>
                @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
