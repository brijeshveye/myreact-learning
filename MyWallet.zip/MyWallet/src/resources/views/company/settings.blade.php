@extends('layouts.app')

@section('page-title', __('Wallet Settings'))

@push('css')
<style>
    .wallet-hero-wrap { position: relative; overflow: hidden; border-radius: 12px; background: linear-gradient(135deg, #f0f5ff, #eef2ff); padding: 20px; }
    .wallet-hero { display: flex; align-items: center; gap: 16px; z-index: 1; }
    .wallet-icon { width: 56px; height: 56px; display: flex; align-items: center; justify-content: center; border-radius: 12px; background: linear-gradient(135deg, #1d4ed8, #2563eb); color: #fff; box-shadow: 0 4px 12px rgba(37,99,235,0.3); font-size: 28px; }
    .section-help { color: #6b7280; font-size: 13px; }
    .subtle { color: #6b7280; }
    .divider { height: 1px; background: #e5e7eb; margin: 8px 0 16px; }
</style>
@endpush

@section('content')
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="wallet-hero-wrap">
                    <div class="wallet-hero">
                        <div class="wallet-icon"><i class="ti ti-settings"></i></div>
                        <div>
                            <h3 class="mb-1">{{ __('Wallet Settings') }}</h3>
                            <div class="subtle">{{ __('Set your payout details for bank transfer or UPI') }}</div>
                        </div>
                        <div class="ms-auto d-flex gap-2">
                            <a href="{{ route('mywallet.index') }}" class="btn btn-outline-secondary btn-sm"><i class="ti ti-arrow-left"></i> {{ __('Back to Wallet') }}</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Settings Form -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header d-flex align-items-center justify-content-between">
                <h5 class="mb-0">{{ __('Payout Methods') }}</h5>
                <div class="section-help">{{ __('We’ll use these details to process your withdrawals') }}</div>
            </div>
            <div class="card-body">
                <form method="POST" action="{{ route('mywallet.settings.update') }}" class="row g-3">
                    @csrf
                    <div class="col-12">
                        <h6 class="mb-1">{{ __('Bank Account') }}</h6>
                        <div class="divider"></div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">{{ __('Bank Name') }}</label>
                        <input type="text" class="form-control" name="bank_name" value="{{ old('bank_name', $walletSettings['bank_name'] ?? '') }}" placeholder="{{ __('e.g., HDFC Bank') }}">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">{{ __('Account Holder Name') }}</label>
                        <input type="text" class="form-control" name="account_name" value="{{ old('account_name', $walletSettings['account_name'] ?? '') }}" placeholder="{{ __('e.g., John Doe') }}">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">{{ __('Account Number') }}</label>
                        <input type="text" class="form-control" name="account_number" value="{{ old('account_number', $walletSettings['account_number'] ?? '') }}" placeholder="{{ __('e.g., 1234567890') }}">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">{{ __('IFSC / SWIFT') }}</label>
                        <input type="text" class="form-control" name="ifsc" value="{{ old('ifsc', $walletSettings['ifsc'] ?? '') }}" placeholder="{{ __('e.g., HDFC0001234 or ABCDUS33') }}">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">{{ __('Branch') }}</label>
                        <input type="text" class="form-control" name="branch" value="{{ old('branch', $walletSettings['branch'] ?? '') }}" placeholder="{{ __('e.g., Andheri West') }}">
                    </div>

                    <div class="col-12 mt-5">
                        <h6 class="mb-1">{{ __('UPI') }}</h6>
                        <div class="divider"></div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">{{ __('UPI ID') }}</label>
                        <input type="text" class="form-control" name="upi_id" value="{{ old('upi_id', $walletSettings['upi_id'] ?? '') }}" placeholder="{{ __('e.g., username@bank') }}">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">{{ __('UPI Name') }}</label>
                        <input type="text" class="form-control" name="upi_name" value="{{ old('upi_name', $walletSettings['upi_name'] ?? '') }}" placeholder="{{ __('e.g., John Doe') }}">
                    </div>

                    <div class="col-12">
                        <button type="submit" class="btn btn-primary">{{ __('Save Settings') }}</button>
                        <a href="{{ route('mywallet.index') }}" class="btn btn-outline-secondary">{{ __('Cancel') }}</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
