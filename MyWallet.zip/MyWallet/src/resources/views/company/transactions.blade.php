@extends('layouts.app')

@section('page-title', __('Wallet Transactions'))

@push('css')
<style>
    .stats-card { background: linear-gradient(135deg, #fff, #f8fafc); border:1px solid #e5e7eb; border-radius:8px; padding:16px; text-align:center; height:100%; }
    .stats-number { font-size:20px; font-weight:700; color:#1f2937; }
    .stats-label { font-size:12px; color:#6b7280; margin-top:4px; }
    .wallet-table th { background:#f8fafc; font-weight:600; color:#374151; border-bottom:1px solid #e5e7eb; }
</style>
@endpush

@section('content')
<div class="row mb-4">
    <div class="col-12 d-flex align-items-center justify-content-between">
        <h4 class="mb-0">{{ __('Wallet Transactions') }}</h4>
        <div>
            <a href="{{ route('mywallet.index') }}" class="btn btn-outline-secondary btn-sm"><i class="ti ti-arrow-left"></i> {{ __('Back to Wallet') }}</a>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-4 col-sm-12">
        <div class="stats-card">
            <div class="stats-number">{{ currency_format_with_sym($totals['balance']) }}</div>
            <div class="stats-label">{{ __('Current Balance') }}</div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6">
        <div class="stats-card">
            <div class="stats-number">{{ currency_format_with_sym($totals['credits']) }}</div>
            <div class="stats-label">{{ __('Total Credits') }}</div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6">
        <div class="stats-card">
            <div class="stats-number">{{ currency_format_with_sym($totals['debits']) }}</div>
            <div class="stats-label">{{ __('Total Debits') }}</div>
        </div>
    </div>
</div>

<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="{{ route('mywallet.transactions') }}" class="row g-3 align-items-end">
            <div class="col-md-3">
                <label class="form-label">{{ __('Type') }}</label>
                <select name="type" class="form-select">
                    <option value="">{{ __('All') }}</option>
                    <option value="credit" {{ ($type ?? '') === 'credit' ? 'selected' : '' }}>{{ __('Credit') }}</option>
                    <option value="debit" {{ ($type ?? '') === 'debit' ? 'selected' : '' }}>{{ __('Debit') }}</option>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">{{ __('Source') }}</label>
                <select name="source" class="form-select">
                    <option value="">{{ __('Any') }}</option>
                    <option value="order" {{ ($source ?? '') === 'order' ? 'selected' : '' }}>{{ __('Order') }}</option>
                    <option value="manual" {{ ($source ?? '') === 'manual' ? 'selected' : '' }}>{{ __('Manual') }}</option>
                    <option value="withdraw" {{ ($source ?? '') === 'withdraw' ? 'selected' : '' }}>{{ __('Withdraw') }}</option>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">{{ __('From') }}</label>
                <input type="date" name="from" class="form-control" value="{{ $dateFrom ?? '' }}">
            </div>
            <div class="col-md-2">
                <label class="form-label">{{ __('To') }}</label>
                <input type="date" name="to" class="form-control" value="{{ $dateTo ?? '' }}">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100"><i class="ti ti-filter"></i> {{ __('Filter') }}</button>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-header d-flex align-items-center justify-content-between">
        <h5 class="mb-0">{{ __('Transactions') }}</h5>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0 wallet-table">
                <thead>
                    <tr>
                        <th>{{ __('Date') }}</th>
                        <th>{{ __('Type') }}</th>
                        <th>{{ __('Source') }}</th>
                        <th class="text-end">{{ __('Amount') }}</th>
                        <th>{{ __('Reference') }}</th>
                        <th>{{ __('Note') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($transactions as $tx)
                        <tr>
                            <td>{{ \Carbon\Carbon::parse($tx->created_at)->format('M d, Y H:i') }}</td>
                            <td>
                                <span class="badge bg-{{ $tx->type === 'credit' ? 'success' : 'danger' }} text-capitalize">{{ $tx->type }}</span>
                            </td>
                            <td class="text-capitalize">{{ $tx->source }}</td>
                            <td class="text-end">{{ currency_format_with_sym($tx->amount) }}</td>
                            <td>{{ $tx->reference ?? '-' }}</td>
                            <td>{{ $tx->meta['note'] ?? ($tx->meta['status'] ?? '-') }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="6" class="text-center text-muted py-4">{{ __('No transactions found for the selected filters.') }}</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div class="p-3">
            {{ $transactions->links() }}
        </div>
    </div>
</div>
@endsection
