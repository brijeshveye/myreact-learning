@php
	// Fetch existing settings from $settings helper if available
	$bankName = $settings['wallet_bank_name'] ?? '';
	$accountName = $settings['wallet_account_name'] ?? '';
	$accountNumber = $settings['wallet_account_number'] ?? '';
	$ifsc = $settings['wallet_ifsc'] ?? '';
	$branch = $settings['wallet_branch'] ?? '';
@endphp

<div class="dashboard-card">
	<div class="d-flex align-items-center justify-content-between gap-3 mb-3">
		<h4 class="m-0">{{ __('Wallet Bank Account') }}</h4>
	</div>
	<div class="alert alert-info">{{ __('Set the bank account to receive withdraw payouts.') }}</div>
	<div class="row g-3">
		<div class="col-md-6">
			<div class="form-group">
				<label class="form-label">{{ __('Bank Name') }}</label>
				<input type="text" name="wallet_bank_name" class="form-control" value="{{ $bankName }}" placeholder="{{ __('e.g., HDFC Bank') }}">
			</div>
		</div>
		<div class="col-md-6">
			<div class="form-group">
				<label class="form-label">{{ __('Account Holder Name') }}</label>
				<input type="text" name="wallet_account_name" class="form-control" value="{{ $accountName }}" placeholder="{{ __('e.g., John Doe') }}">
			</div>
		</div>
		<div class="col-md-6">
			<div class="form-group">
				<label class="form-label">{{ __('Account Number') }}</label>
				<input type="text" name="wallet_account_number" class="form-control" value="{{ $accountNumber }}" placeholder="{{ __('e.g., 1234567890') }}">
			</div>
		</div>
		<div class="col-md-6">
			<div class="form-group">
				<label class="form-label">{{ __('IFSC / SWIFT') }}</label>
				<input type="text" name="wallet_ifsc" class="form-control" value="{{ $ifsc }}" placeholder="{{ __('e.g., HDFC0001234 or ABCDUS33') }}">
			</div>
		</div>
		<div class="col-md-6">
			<div class="form-group">
				<label class="form-label">{{ __('Branch') }}</label>
				<input type="text" name="wallet_branch" class="form-control" value="{{ $branch }}" placeholder="{{ __('e.g., Andheri West') }}">
			</div>
		</div>
	</div>
</div>
