@extends('layouts.app')

@section('page-title', __('My Wallet'))

@push('css')
    <style>
        .wallet-hero-wrap {
            position: relative;
            overflow: hidden;
            border-radius: 12px;
            background: linear-gradient(135deg, #f0f5ff, #eef2ff);
            padding: 20px;
        }

        .wallet-hero-bg {
            position: absolute;
            inset: 0;
            background-size: cover;
            background-position: center;
            opacity: 0.06;
            filter: blur(2px);
        }

        .wallet-hero {
            display: flex;
            align-items: center;
            gap: 16px;
            z-index: 1;
        }

        .wallet-hero .settings-link {
            z-index: 1;
        }

        .wallet-icon {
            width: 64px;
            height: 64px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 12px;
            background: linear-gradient(135deg, #1d4ed8, #2563eb);
            color: #fff;
            box-shadow: 0 4px 12px rgba(37, 99, 235, 0.3);
            font-size: 32px;
        }

        .wallet-info h3 {
            margin-bottom: 4px;
        }

        /* Stats cards (aligned with GMC) */
        .stats-card {
            background: linear-gradient(135deg, #fff, #f8fafc);
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            padding: 16px;
            text-align: center;
            height: 100%;
        }

        .stats-number {
            font-size: 22px;
            font-weight: 700;
            color: #1f2937;
        }

        .stats-label {
            font-size: 13px;
            color: #6b7280;
            margin-top: 4px;
        }

        .stats-icon {
            font-size: 20px;
            color: #2563eb;
        }

        /* Table styling (aligned with GMC feed-table) */
        .wallet-table {
            border-radius: 8px;
            overflow: hidden;
        }

        .wallet-table th {
            background: #f8fafc;
            font-weight: 600;
            color: #374151;
            border-bottom: 1px solid #e5e7eb;
        }

        .wallet-table td {
            vertical-align: middle;
        }
    </style>
@endpush

@section('content')
    @if (session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="ti ti-check me-1"></i> {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif
    @if (session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="ti ti-alert-triangle me-1"></i> {{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif
    @if ($errors->any())
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <div class="d-flex align-items-start">
                <i class="ti ti-alert-circle me-2 mt-1"></i>
                <div>
                    <strong>{{ __('Please fix the following errors:') }}</strong>
                    <ul class="mb-0 mt-1">
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif
    <div class="row mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="wallet-hero-wrap">
                        <div class="wallet-hero-bg"
                            style="background-image:url('data:image/svg+xml,<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 100 100\"><circle cx=\"20\" cy=\"20\" r=\"3\" fill=\"%232563eb\" opacity=\"0.3\"/><circle cx=\"80\" cy=\"30\" r=\"2\" fill=\"%232563eb\" opacity=\"0.2\"/><circle cx=\"60\" cy=\"70\" r=\"4\" fill=\"%232563eb\" opacity=\"0.15\"/></svg>')">
                        </div>
                        <div class="wallet-hero">
                            <div class="wallet-icon">
                                <i class="ti ti-wallet"></i>
                            </div>
                            <div class="wallet-info">
                                <h3 class="mb-1">{{ __('My Wallet Overview') }}</h3>
                                <div class="d-flex flex-wrap gap-3 text-muted">
                                    <div>{{ __('Total Balance') }}:
                                        <strong>{{ currency_format_with_sym($totalBalance) }}</strong></div>
                                    <div>{{ __('Total Withdrawn') }}:
                                        <strong>{{ currency_format_with_sym($totalWithdrawn) }}</strong></div>
                                    <div>{{ __('Status') }}:
                                        <span
                                            class="badge bg-{{ $status === 'active' ? 'success' : 'warning' }}">{{ ucfirst($status) }}</span>
                                    </div>
                                </div>
                            </div>
                            <div class="ms-auto d-flex gap-2 settings-link">
                                <a href="{{ route('mywallet.transactions') }}" class="btn btn-outline-primary btn-sm"><i class="ti ti-receipt"></i> {{ __('Transactions') }}</a>
                                <a href="{{ route('mywallet.settings') }}" class="btn btn-outline-secondary btn-sm"><i class="ti ti-settings"></i> {{ __('Settings') }}</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @php
        // Icons for stats cards
        $status_icon = '<i class="ti ti-info-circle"></i>';
        $balance_icon = '<i class="ti ti-currency-dollar"></i>';
        $last_withdraw_icon = '<i class="ti ti-arrow-up-right-circle"></i>';
        $withdrawn_icon = '<i class="ti ti-cash"></i>';
    @endphp

    <!-- Stats Cards Section -->
    <div class="row g-3 mb-4">
        <div class="col-md-3 col-sm-6">
            <div class="stats-card">
                <div class="stats-icon mb-2">{!! $status_icon !!}</div>
                <div class="stats-number">{{ ucfirst($status) }}</div>
                <div class="stats-label">{{ __('Status') }}</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="stats-card">
                <div class="stats-icon mb-2">{!! $balance_icon !!}</div>
                <div class="stats-number">{{ currency_format_with_sym($totalBalance) }}</div>
                <div class="stats-label">{{ __('Available Balance') }}</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="stats-card">
                <div class="stats-icon mb-2">{!! $last_withdraw_icon !!}</div>
                <div class="stats-number">
                    {{ $lastWithdraw ? currency_format_with_sym($lastWithdraw['amount']) : __('N/A') }}</div>
                <div class="stats-label">{{ __('Last Withdraw') }}</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="stats-card">
                <div class="stats-icon mb-2">{!! $withdrawn_icon !!}</div>
                <div class="stats-number">{{ currency_format_with_sym($totalWithdrawn) }}</div>
                <div class="stats-label">{{ __('Withdrawn Total') }}</div>
            </div>
        </div>
    </div>

    <!-- Withdraw Request Form -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex align-items-center justify-content-between">
                    <h5 class="mb-0">{{ __('Withdraw Request') }}</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="{{ route('mywallet.withdraw.store') }}" class="row g-3">
                        @csrf
                        <div class="col-md-4">
                            <label class="form-label">{{ __('Amount') }}</label>
                            <div class="input-group">
                                <span class="input-group-text">{{ getAdminAllSetting()['CURRENCY_SYMBOL'] ?? '$' }}</span>
                                <input type="number" step="0.01" min="1" name="amount" value="{{ old('amount') }}" class="form-control @error('amount') is-invalid @enderror"
                                    required>
                            </div>
                            @error('amount')
                                <div class="invalid-feedback d-block">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">{{ __('Method') }}</label>
                            <select name="method" class="form-select @error('method') is-invalid @enderror" required>
                                <option value="bank" {{ old('method') == 'bank' ? 'selected' : '' }}>{{ __('Bank Transfer') }}</option>
                                <option value="upi" {{ old('method') == 'upi' ? 'selected' : '' }}>{{ __('UPI Transfer') }}</option>
                            </select>
                            <small class="text-muted">{{ __('Set bank details in Company Settings > Wallet') }}</small>
                            @error('method')
                                <div class="invalid-feedback d-block">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">{{ __('Note') }}</label>
                            <input type="text" name="note" value="{{ old('note') }}" class="form-control @error('note') is-invalid @enderror" maxlength="500"
                                placeholder="{{ __('Optional') }}">
                            @error('note')
                                <div class="invalid-feedback d-block">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary">{{ __('Submit Request') }}</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Withdraw History Table -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex align-items-center justify-content-between">
                    <h5 class="mb-0">{{ __('Withdraw Requests') }}</h5>
                    <a href="{{ route('mywallet.transactions') }}" class="btn btn-outline-primary btn-sm"><i class="ti ti-receipt"></i> {{ __('Transactions') }}</a>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table wallet-table mb-0">
                            <thead>
                                <tr>
                                    <th>{{ __('Date') }}</th>
                                    <th>{{ __('Amount') }}</th>
                                    <th>{{ __('Method') }}</th>
                                    <th>{{ __('Status') }}</th>
                                    <th>{{ __('Note') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($withdrawRequests as $req)
                                    <tr>
                                        <td>{{ \Carbon\Carbon::parse($req->created_at)->format('M d, Y') }}</td>
                                        <td>{{ currency_format_with_sym($req->amount) }}</td>
                                        <td class="text-capitalize">{{ $req->method }}</td>
                                        <td>
                                            <span
                                                class="badge bg-{{ $req->status == 'approved' ? 'success' : ($req->status == 'rejected' ? 'danger' : 'warning') }}">
                                                {{ ucfirst($req->status) }}
                                            </span>
                                        </td>
                                        <td>{{ $req->note }}</td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="5" class="text-center text-muted">
                                            {{ __('No withdraw requests yet.') }}</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
