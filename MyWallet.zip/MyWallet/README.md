# MyWallet package

A per-store, per-user wallet module for ShopyJi/Laravel that tracks balances and a full transaction ledger, lets users request withdrawals (Bank/UPI), and gives Super Admin tools to credit wallets and approve or reject withdraw requests.

## Overview

MyWallet adds:
- A Wallet dashboard for company users (store owners) to view balance, request withdrawals, and review history
- A Transactions ledger with filters by type, source, date range
- Payout settings page to capture Bank and UPI details per user
- Super Admin area to credit store wallets, review withdraw requests, and see global/user/store transactions
- Event-driven menu integration for both Company and Super Admin

Store-scoping: Balances and transactions are stored per user per store (unique [store_id, user_id]).

## Features

- Wallet balance and withdrawn total persisted in `wallets` table
- Full ledger in `wallet_transactions` (credit/debit, source: order/manual/withdraw, reference, meta JSON)
- Withdraw requests via `wallet_withdraw_requests` with statuses pending/approved/rejected and methods bank/upi
- User payout settings in `wallet_settings` (Bank + UPI)
- Super Admin: credit a store wallet, review/approve/reject withdraws, view aggregated transactions
- Clean Bootstrap-style UI: stats cards, filters, paginated tables
- Laravel auto-discovery for the service provider and event-based menus

## Requirements

- PHP 8.2+
- Laravel 11.x (project baseline)
- Database: users and stores tables present (foreign keys referenced)
- Optional: genealabs/laravel-model-caching (Cachable trait is used by models). If not installed, remove the trait or install the package.

## Installation

This repo includes MyWallet as a path package. If you need to include externally, add it to your composer or path repositories.

1) Auto-discovery
- Provider: `Shopyji\\MyWallet\\app\\Providers\\MyWalletServiceProvider`

2) Run migrations

```bash
php artisan migrate
```

3) Clear caches (recommended)

```bash
php artisan optimize:clear
```

## Additional Steps

1) # File:  App\Models\Utility @ GetValueByName
// My Wallet code start
$payment_methods = self::getPaymentGatewayfields();
if (in_array($name, $payment_methods)) {
    $is_mywallet_enabled = Setting::where('name', 'is_mywallet_enabled')->where('store_id', $store_id)->value('value');
    if (1 || $is_mywallet_enabled == 'on') {
        $store_id = 1;
    }
}
// My Wallet code end


2) # File: App\Http\Controllers\PaymentController @ getProductStatus
// MyWallet code
if (module_is_active('MyWallet') && \Auth::guard('customers')->user() && (isset($settings['enable_mywallet']) && $settings['enable_mywallet'] == 'on')) {
    \Shopyji\MyWallet\app\Models\Wallet::addBalance($order);
}


## Routes and UI

Middleware: all routes use `web`, `auth`, and `PlanModuleCheck:MyWallet`.

- Company (prefix `/mywallet`):
  - `GET /mywallet` → Wallet dashboard (name: `mywallet.index`)
  - `POST /mywallet/withdraw` → Submit withdraw request (name: `mywallet.withdraw.store`)
  - `GET /mywallet/transactions` → Transactions ledger (name: `mywallet.transactions`)
  - `GET /mywallet/settings` → Payout settings form (name: `mywallet.settings`)
  - `POST /mywallet/settings` → Save payout settings (name: `mywallet.settings.update`)

- Super Admin (prefix `/super-admin/mywallet`):
  - `GET /super-admin/mywallet` → Overview (name: `superadmin.mywallet.index`)
  - `POST /super-admin/mywallet/credit` → Credit a store wallet (name: `superadmin.mywallet.credit`)
  - `GET /super-admin/mywallet/withdraws/{id}` → Review page (name: `superadmin.mywallet.withdraw.review`)
  - `POST /super-admin/mywallet/withdraws/{id}/approve` → Approve (name: `superadmin.mywallet.withdraw.approve`)
  - `POST /super-admin/mywallet/withdraws/{id}/reject` → Reject (name: `superadmin.mywallet.withdraw.reject`)
  - `GET /super-admin/mywallet/transactions` → All transactions with filters (name: `superadmin.mywallet.transactions`)
  - `GET /super-admin/mywallet/users/{user}/transactions` → User transactions (name: `superadmin.mywallet.user.transactions`)
  - `GET /super-admin/mywallet/stores/{store}/transactions` → Store transactions (name: `superadmin.mywallet.store.transactions`)

Views namespaces: `my-wallet::company.*`, `my-wallet::super-admin.*`.

## Usage

- Company
  - Dashboard shows: current balance, total withdrawn, last withdraw, and a list of recent withdraw requests.
  - Submit a withdraw request (Bank/UPI). Balance is reserved immediately via a pending debit transaction.
  - Configure payout methods under Settings. Bank details and/or UPI details are required before requesting withdraws.
  - Use the Transactions page to filter by type (credit/debit), source (order/manual/withdraw), and date range.

- Super Admin
  - Credit Balance: Credit a store owner’s wallet (records a manual credit transaction).
  - Review Withdraw: Inspect request details, requester payout settings, and past requests.
  - Approve: Marks withdraw approved, increments `withdrawn_total`, updates transaction meta to approved.
  - Reject: Refunds reserved amount to balance, updates meta, and writes a compensating credit transaction.
  - Global Transactions: Filter by type, source, store, user, date range; view user or store-specific ledgers.

## Configuration and permissions

- Access is gated by `PlanModuleCheck:MyWallet` middleware. Ensure the module is enabled for the requesting user/store plan.
- Menus are registered via events for Company and Super Admin contexts.
- Payout settings (`wallet_settings`) are unique per user. Each user can have Bank and/or UPI details.

## Database schema

- `wallets`
  - id, store_id (nullable, FK), user_id (FK), balance decimal(14,2) default 0, withdrawn_total decimal(14,2) default 0
  - unique constraint: (store_id, user_id)

- `wallet_transactions`
  - id, wallet_id (FK), store_id (nullable, FK), user_id (FK)
  - type enum: credit|debit
  - source enum: order|manual|withdraw
  - amount decimal(14,2), reference varchar(191) nullable, meta json nullable
  - indexed by user_id, store_id, type, source, created_at

- `wallet_withdraw_requests`
  - id, store_id (nullable, FK), user_id (FK), amount decimal(12,2)
  - method enum: bank|upi
  - status enum: pending|approved|rejected
  - note varchar(500) nullable, paid_at timestamp nullable, paid_reference varchar(191) nullable
  - indexes on store_id, user_id, method, status, created_at

- `wallet_settings`
  - id, user_id (FK unique)
  - bank_name, account_name, account_number, ifsc, branch, upi_id, upi_name (all nullable)

## Events and menus

- Company menu listener adds “MyWallet” with route `mywallet.index`.
- Super Admin menu listener adds “ShopyJi Wallet” with route `superadmin.mywallet.index`.

## Troubleshooting

- Withdrawal amount exceeds balance
  - The module reserves funds by debiting balance at request time. Ensure the requested amount ≤ available balance.

- Missing payout details
  - Bank or UPI details are required depending on the chosen method. Update them under Wallet Settings.

- Duplicate wallet for user+store
  - The schema enforces unique (store_id, user_id). Use `Wallet::firstOrCreate([user_id, store_id])` pattern as in controllers.

- Model caching dependency
  - If you don’t use `genealabs/laravel-model-caching`, remove `Cachable` traits from the models or install the package.

## Internals at a glance

- Service provider: `app/Providers/MyWalletServiceProvider.php`
- Routes: `routes/web.php`, `routes/api.php`
- Company controllers: `app/Http/Controllers/Company/WalletController.php`
- Super Admin controllers: `app/Http/Controllers/SuperAdmin/WalletAdminController.php`
- Models: `app/Models/Wallet.php`, `WalletTransaction.php`, `WalletSetting.php`, `WalletWithdrawRequest.php`
- Migrations: `database/migrations/*create_wallet_*_table.php`
- Views: `resources/views/company/*`, `resources/views/super-admin/*`
- Menu listeners: `app/Listeners/CompanyMenuListener.php`, `SuperAdminMenuListener.php`

## License

MIT

## Support

Please reach out to ShopyJi support or the authors in `composer.json` if you need help.
